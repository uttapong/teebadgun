-- MySQL dump 10.13  Distrib 5.1.70, for unknown-linux-gnu (x86_64)
--
-- Host: localhost    Database: teebadgu_db
-- ------------------------------------------------------
-- Server version	5.1.70

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `GDN_Activity`
--

DROP TABLE IF EXISTS `GDN_Activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_Activity` (
  `ActivityID` int(11) NOT NULL AUTO_INCREMENT,
  `ActivityTypeID` int(11) NOT NULL,
  `NotifyUserID` int(11) NOT NULL DEFAULT '0',
  `ActivityUserID` int(11) DEFAULT NULL,
  `RegardingUserID` int(11) DEFAULT NULL,
  `Photo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HeadlineFormat` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Story` text COLLATE utf8_unicode_ci,
  `Format` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Route` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RecordType` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RecordID` int(11) DEFAULT NULL,
  `InsertUserID` int(11) DEFAULT NULL,
  `DateInserted` datetime NOT NULL,
  `InsertIPAddress` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DateUpdated` datetime DEFAULT NULL,
  `Notified` tinyint(4) NOT NULL DEFAULT '0',
  `Emailed` tinyint(4) NOT NULL DEFAULT '0',
  `Data` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ActivityID`),
  KEY `IX_Activity_Notify` (`NotifyUserID`,`Notified`),
  KEY `IX_Activity_Recent` (`NotifyUserID`,`DateUpdated`),
  KEY `IX_Activity_Feed` (`NotifyUserID`,`ActivityUserID`,`DateUpdated`),
  KEY `IX_Activity_DateUpdated` (`DateUpdated`),
  KEY `FK_Activity_InsertUserID` (`InsertUserID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_Activity`
--

LOCK TABLES `GDN_Activity` WRITE;
/*!40000 ALTER TABLE `GDN_Activity` DISABLE KEYS */;
INSERT INTO `GDN_Activity` VALUES (1,17,-1,1,NULL,NULL,'{ActivityUserID,You} joined.','Welcome Aboard!',NULL,NULL,NULL,NULL,NULL,'2013-12-12 06:45:08','127.0.0.1','2013-12-12 06:45:08',0,0,'a:0:{}'),(2,15,-1,1,2,NULL,'{RegardingUserID,you} &rarr; {ActivityUserID,you}','Ping! An activity post is a public way to talk at someone. When you update your status here, it posts it on your activity feed.','Html',NULL,NULL,NULL,2,'2013-12-12 06:45:11',NULL,'2013-12-12 06:45:11',0,0,NULL);
/*!40000 ALTER TABLE `GDN_Activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_ActivityComment`
--

DROP TABLE IF EXISTS `GDN_ActivityComment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_ActivityComment` (
  `ActivityCommentID` int(11) NOT NULL AUTO_INCREMENT,
  `ActivityID` int(11) NOT NULL,
  `Body` text COLLATE utf8_unicode_ci NOT NULL,
  `Format` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `InsertUserID` int(11) NOT NULL,
  `DateInserted` datetime NOT NULL,
  `InsertIPAddress` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ActivityCommentID`),
  KEY `FK_ActivityComment_ActivityID` (`ActivityID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_ActivityComment`
--

LOCK TABLES `GDN_ActivityComment` WRITE;
/*!40000 ALTER TABLE `GDN_ActivityComment` DISABLE KEYS */;
/*!40000 ALTER TABLE `GDN_ActivityComment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_ActivityType`
--

DROP TABLE IF EXISTS `GDN_ActivityType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_ActivityType` (
  `ActivityTypeID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `AllowComments` tinyint(4) NOT NULL DEFAULT '0',
  `ShowIcon` tinyint(4) NOT NULL DEFAULT '0',
  `ProfileHeadline` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FullHeadline` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RouteCode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Notify` tinyint(4) NOT NULL DEFAULT '0',
  `Public` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ActivityTypeID`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_ActivityType`
--

LOCK TABLES `GDN_ActivityType` WRITE;
/*!40000 ALTER TABLE `GDN_ActivityType` DISABLE KEYS */;
INSERT INTO `GDN_ActivityType` VALUES (1,'SignIn',0,0,'%1$s signed in.','%1$s signed in.',NULL,0,1),(2,'Join',1,0,'%1$s joined.','%1$s joined.',NULL,0,1),(3,'JoinInvite',1,0,'%1$s accepted %4$s invitation for membership.','%1$s accepted %4$s invitation for membership.',NULL,0,1),(4,'JoinApproved',1,0,'%1$s approved %4$s membership application.','%1$s approved %4$s membership application.',NULL,0,1),(5,'JoinCreated',1,0,'%1$s created an account for %3$s.','%1$s created an account for %3$s.',NULL,0,1),(6,'AboutUpdate',1,0,'%1$s updated %6$s profile.','%1$s updated %6$s profile.',NULL,0,1),(7,'WallComment',1,1,'%1$s wrote:','%1$s wrote on %4$s %5$s.',NULL,0,1),(8,'PictureChange',1,0,'%1$s changed %6$s profile picture.','%1$s changed %6$s profile picture.',NULL,0,1),(9,'RoleChange',1,0,'%1$s changed %4$s permissions.','%1$s changed %4$s permissions.',NULL,1,1),(10,'ActivityComment',0,1,'%1$s','%1$s commented on %4$s %8$s.','activity',1,1),(11,'Import',0,0,'%1$s imported data.','%1$s imported data.',NULL,1,0),(12,'Banned',0,0,'%1$s banned %3$s.','%1$s banned %3$s.',NULL,0,1),(13,'Unbanned',0,0,'%1$s un-banned %3$s.','%1$s un-banned %3$s.',NULL,0,1),(14,'Applicant',0,0,'%1$s applied for membership.','%1$s applied for membership.',NULL,1,0),(15,'WallPost',1,1,'%3$s wrote:','%3$s wrote on %2$s %5$s.',NULL,0,1),(16,'Default',0,0,NULL,NULL,NULL,0,1),(17,'Registration',0,0,NULL,NULL,NULL,0,1),(18,'Status',0,0,NULL,NULL,NULL,0,1),(19,'Ban',0,0,NULL,NULL,NULL,0,1),(20,'ConversationMessage',0,0,'%1$s sent you a %8$s.','%1$s sent you a %8$s.','message',1,0),(21,'AddedToConversation',0,0,'%1$s added %3$s to a %8$s.','%1$s added %3$s to a %8$s.','conversation',1,0),(22,'NewDiscussion',0,0,'%1$s started a %8$s.','%1$s started a %8$s.','discussion',0,0),(23,'NewComment',0,0,'%1$s commented on a discussion.','%1$s commented on a discussion.','discussion',0,0),(24,'DiscussionComment',0,0,'%1$s commented on %4$s %8$s.','%1$s commented on %4$s %8$s.','discussion',1,0),(25,'DiscussionMention',0,0,'%1$s mentioned %3$s in a %8$s.','%1$s mentioned %3$s in a %8$s.','discussion',1,0),(26,'CommentMention',0,0,'%1$s mentioned %3$s in a %8$s.','%1$s mentioned %3$s in a %8$s.','comment',1,0),(27,'BookmarkComment',0,0,'%1$s commented on your %8$s.','%1$s commented on your %8$s.','bookmarked discussion',1,0),(28,'Discussion',0,0,NULL,NULL,NULL,0,1),(29,'Comment',0,0,NULL,NULL,NULL,0,1);
/*!40000 ALTER TABLE `GDN_ActivityType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_AnalyticsLocal`
--

DROP TABLE IF EXISTS `GDN_AnalyticsLocal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_AnalyticsLocal` (
  `TimeSlot` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `Views` int(11) DEFAULT NULL,
  `EmbedViews` int(11) DEFAULT NULL,
  UNIQUE KEY `UX_AnalyticsLocal` (`TimeSlot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_AnalyticsLocal`
--

LOCK TABLES `GDN_AnalyticsLocal` WRITE;
/*!40000 ALTER TABLE `GDN_AnalyticsLocal` DISABLE KEYS */;
INSERT INTO `GDN_AnalyticsLocal` VALUES ('20131223',9,0),('20131224',2,0);
/*!40000 ALTER TABLE `GDN_AnalyticsLocal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_Ban`
--

DROP TABLE IF EXISTS `GDN_Ban`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_Ban` (
  `BanID` int(11) NOT NULL AUTO_INCREMENT,
  `BanType` enum('IPAddress','Name','Email') COLLATE utf8_unicode_ci NOT NULL,
  `BanValue` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Notes` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CountUsers` int(10) unsigned NOT NULL DEFAULT '0',
  `CountBlockedRegistrations` int(10) unsigned NOT NULL DEFAULT '0',
  `InsertUserID` int(11) NOT NULL,
  `DateInserted` datetime NOT NULL,
  PRIMARY KEY (`BanID`),
  UNIQUE KEY `UX_Ban` (`BanType`,`BanValue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_Ban`
--

LOCK TABLES `GDN_Ban` WRITE;
/*!40000 ALTER TABLE `GDN_Ban` DISABLE KEYS */;
/*!40000 ALTER TABLE `GDN_Ban` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_Category`
--

DROP TABLE IF EXISTS `GDN_Category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_Category` (
  `CategoryID` int(11) NOT NULL AUTO_INCREMENT,
  `ParentCategoryID` int(11) DEFAULT NULL,
  `TreeLeft` int(11) DEFAULT NULL,
  `TreeRight` int(11) DEFAULT NULL,
  `Depth` int(11) DEFAULT NULL,
  `CountDiscussions` int(11) NOT NULL DEFAULT '0',
  `CountComments` int(11) NOT NULL DEFAULT '0',
  `DateMarkedRead` datetime DEFAULT NULL,
  `AllowDiscussions` tinyint(4) NOT NULL DEFAULT '1',
  `Archived` tinyint(4) NOT NULL DEFAULT '0',
  `Name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `UrlCode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Description` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Sort` int(11) DEFAULT NULL,
  `CssClass` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Photo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PermissionCategoryID` int(11) NOT NULL DEFAULT '-1',
  `HideAllDiscussions` tinyint(4) NOT NULL DEFAULT '0',
  `DisplayAs` enum('Categories','Discussions','Default') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Default',
  `InsertUserID` int(11) NOT NULL,
  `UpdateUserID` int(11) DEFAULT NULL,
  `DateInserted` datetime NOT NULL,
  `DateUpdated` datetime NOT NULL,
  `LastCommentID` int(11) DEFAULT NULL,
  `LastDiscussionID` int(11) DEFAULT NULL,
  `LastDateInserted` datetime DEFAULT NULL,
  PRIMARY KEY (`CategoryID`),
  KEY `FK_Category_InsertUserID` (`InsertUserID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_Category`
--

LOCK TABLES `GDN_Category` WRITE;
/*!40000 ALTER TABLE `GDN_Category` DISABLE KEYS */;
INSERT INTO `GDN_Category` VALUES (-1,NULL,1,10,0,0,0,NULL,1,0,'Root','root','Root of category tree. Users should never see this.',1,NULL,NULL,-1,0,'Default',1,1,'2013-12-12 06:45:09','2013-12-12 06:45:09',NULL,NULL,NULL),(1,-1,8,9,1,0,0,NULL,1,0,'เรื่องทั่วไป','เรื่องทั่วไป','พูดคุยเรื่องทั่วไป ข่าวสาร กิจกรรม สอบถามปัญหา เทคนิควิธีการตีแบด หาเพื่อนตีแบด',8,'',NULL,-1,0,'Default',1,1,'2013-12-12 06:45:09','2013-12-23 15:18:04',NULL,NULL,NULL),(2,-1,6,7,1,0,0,NULL,1,0,'รีวิว อุปกรณ์แบดมินตัน','รีวิว','รีวิว อุปกรณ์แบดมินตัน เสื้อผ้า ไม้แบดมินตัน รองเท้า เอ็น กระเป๋า ถุงเท้า',6,'',NULL,-1,0,'Default',1,1,'2013-12-23 15:18:54','2013-12-23 15:18:54',NULL,NULL,NULL),(3,-1,4,5,1,0,0,NULL,1,0,'ประกาศจากผู้ดูแลระบบ','ประกาศจากผู้ดูแลระบบ','ประกาศกติการการใช้งานเว็บไซต์ตีแบดกันดอทคอม',4,'',NULL,3,0,'Default',1,1,'2013-12-23 15:22:16','2013-12-23 15:22:16',NULL,NULL,NULL),(4,-1,2,3,1,0,0,NULL,1,0,'แจ้งปัญหาการใช้งาน หรือข้อแนะนะ','แจ้งปัญหาการใช้งาน-หรือข้อแนะนะ','แจ้งปัญหาในการใช้งาน หรือข้อแนะนำที่อยากให้เว็บไซต์ตีแบดกันดอทคอมมี เช่น ระบบที่ต้องการเพิ่มเติมต่างๆ ทางแอดมิน รับฟังความคิดเห็นของสมาชิกทุกท่าน เพื่อร่วมกันพัฒนาสังคมแบดมินตันไทยให้ดีขึ้น',2,'',NULL,-1,0,'Default',1,1,'2013-12-23 15:24:03','2013-12-23 15:24:03',NULL,NULL,NULL);
/*!40000 ALTER TABLE `GDN_Category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_Comment`
--

DROP TABLE IF EXISTS `GDN_Comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_Comment` (
  `CommentID` int(11) NOT NULL AUTO_INCREMENT,
  `DiscussionID` int(11) NOT NULL,
  `InsertUserID` int(11) DEFAULT NULL,
  `UpdateUserID` int(11) DEFAULT NULL,
  `DeleteUserID` int(11) DEFAULT NULL,
  `Body` text COLLATE utf8_unicode_ci NOT NULL,
  `Format` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DateInserted` datetime DEFAULT NULL,
  `DateDeleted` datetime DEFAULT NULL,
  `DateUpdated` datetime DEFAULT NULL,
  `InsertIPAddress` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `UpdateIPAddress` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Flag` tinyint(4) NOT NULL DEFAULT '0',
  `Score` float DEFAULT NULL,
  `Attributes` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`CommentID`),
  KEY `IX_Comment_1` (`DiscussionID`,`DateInserted`),
  KEY `IX_Comment_DateInserted` (`DateInserted`),
  KEY `FK_Comment_InsertUserID` (`InsertUserID`),
  FULLTEXT KEY `TX_Comment` (`Body`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_Comment`
--

LOCK TABLES `GDN_Comment` WRITE;
/*!40000 ALTER TABLE `GDN_Comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `GDN_Comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_Conversation`
--

DROP TABLE IF EXISTS `GDN_Conversation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_Conversation` (
  `ConversationID` int(11) NOT NULL AUTO_INCREMENT,
  `Subject` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Contributors` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `FirstMessageID` int(11) DEFAULT NULL,
  `InsertUserID` int(11) NOT NULL,
  `DateInserted` datetime DEFAULT NULL,
  `InsertIPAddress` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `UpdateUserID` int(11) NOT NULL,
  `DateUpdated` datetime NOT NULL,
  `UpdateIPAddress` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CountMessages` int(11) NOT NULL DEFAULT '0',
  `LastMessageID` int(11) DEFAULT NULL,
  `RegardingID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ConversationID`),
  KEY `FK_Conversation_FirstMessageID` (`FirstMessageID`),
  KEY `FK_Conversation_InsertUserID` (`InsertUserID`),
  KEY `FK_Conversation_DateInserted` (`DateInserted`),
  KEY `FK_Conversation_UpdateUserID` (`UpdateUserID`),
  KEY `IX_Conversation_RegardingID` (`RegardingID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_Conversation`
--

LOCK TABLES `GDN_Conversation` WRITE;
/*!40000 ALTER TABLE `GDN_Conversation` DISABLE KEYS */;
INSERT INTO `GDN_Conversation` VALUES (1,NULL,'a:2:{i:0;s:1:\"2\";i:1;s:1:\"1\";}',NULL,2,'2013-12-12 06:45:09',NULL,0,'0000-00-00 00:00:00',NULL,1,1,NULL);
/*!40000 ALTER TABLE `GDN_Conversation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_ConversationMessage`
--

DROP TABLE IF EXISTS `GDN_ConversationMessage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_ConversationMessage` (
  `MessageID` int(11) NOT NULL AUTO_INCREMENT,
  `ConversationID` int(11) NOT NULL,
  `Body` text COLLATE utf8_unicode_ci NOT NULL,
  `Format` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `InsertUserID` int(11) DEFAULT NULL,
  `DateInserted` datetime NOT NULL,
  `InsertIPAddress` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`MessageID`),
  KEY `FK_ConversationMessage_ConversationID` (`ConversationID`),
  KEY `FK_ConversationMessage_InsertUserID` (`InsertUserID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_ConversationMessage`
--

LOCK TABLES `GDN_ConversationMessage` WRITE;
/*!40000 ALTER TABLE `GDN_ConversationMessage` DISABLE KEYS */;
INSERT INTO `GDN_ConversationMessage` VALUES (1,1,'Pssst. Hey. A conversation is a private chat between two or more members. No one can see it except the members added. You can delete this one since I&rsquo;m just a bot and know better than to talk back.','Html',2,'2013-12-12 06:45:09',NULL);
/*!40000 ALTER TABLE `GDN_ConversationMessage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_Discussion`
--

DROP TABLE IF EXISTS `GDN_Discussion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_Discussion` (
  `DiscussionID` int(11) NOT NULL AUTO_INCREMENT,
  `Type` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ForeignID` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CategoryID` int(11) NOT NULL,
  `InsertUserID` int(11) NOT NULL,
  `UpdateUserID` int(11) DEFAULT NULL,
  `FirstCommentID` int(11) DEFAULT NULL,
  `LastCommentID` int(11) DEFAULT NULL,
  `Name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Body` text COLLATE utf8_unicode_ci NOT NULL,
  `Format` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Tags` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CountComments` int(11) NOT NULL DEFAULT '0',
  `CountBookmarks` int(11) DEFAULT NULL,
  `CountViews` int(11) NOT NULL DEFAULT '1',
  `Closed` tinyint(4) NOT NULL DEFAULT '0',
  `Announce` tinyint(4) NOT NULL DEFAULT '0',
  `Sink` tinyint(4) NOT NULL DEFAULT '0',
  `DateInserted` datetime NOT NULL,
  `DateUpdated` datetime DEFAULT NULL,
  `InsertIPAddress` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `UpdateIPAddress` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DateLastComment` datetime DEFAULT NULL,
  `LastCommentUserID` int(11) DEFAULT NULL,
  `Score` float DEFAULT NULL,
  `Attributes` text COLLATE utf8_unicode_ci,
  `RegardingID` int(11) DEFAULT NULL,
  PRIMARY KEY (`DiscussionID`),
  KEY `IX_Discussion_Type` (`Type`),
  KEY `IX_Discussion_ForeignID` (`ForeignID`),
  KEY `IX_Discussion_DateInserted` (`DateInserted`),
  KEY `IX_Discussion_DateLastComment` (`DateLastComment`),
  KEY `IX_Discussion_RegardingID` (`RegardingID`),
  KEY `IX_Discussion_CategoryPages` (`CategoryID`,`DateLastComment`),
  KEY `FK_Discussion_CategoryID` (`CategoryID`),
  KEY `FK_Discussion_InsertUserID` (`InsertUserID`),
  FULLTEXT KEY `TX_Discussion` (`Name`,`Body`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_Discussion`
--

LOCK TABLES `GDN_Discussion` WRITE;
/*!40000 ALTER TABLE `GDN_Discussion` DISABLE KEYS */;
/*!40000 ALTER TABLE `GDN_Discussion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_Draft`
--

DROP TABLE IF EXISTS `GDN_Draft`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_Draft` (
  `DraftID` int(11) NOT NULL AUTO_INCREMENT,
  `DiscussionID` int(11) DEFAULT NULL,
  `CategoryID` int(11) DEFAULT NULL,
  `InsertUserID` int(11) NOT NULL,
  `UpdateUserID` int(11) NOT NULL,
  `Name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Tags` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Closed` tinyint(4) NOT NULL DEFAULT '0',
  `Announce` tinyint(4) NOT NULL DEFAULT '0',
  `Sink` tinyint(4) NOT NULL DEFAULT '0',
  `Body` text COLLATE utf8_unicode_ci NOT NULL,
  `Format` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DateInserted` datetime NOT NULL,
  `DateUpdated` datetime DEFAULT NULL,
  PRIMARY KEY (`DraftID`),
  KEY `FK_Draft_DiscussionID` (`DiscussionID`),
  KEY `FK_Draft_CategoryID` (`CategoryID`),
  KEY `FK_Draft_InsertUserID` (`InsertUserID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_Draft`
--

LOCK TABLES `GDN_Draft` WRITE;
/*!40000 ALTER TABLE `GDN_Draft` DISABLE KEYS */;
/*!40000 ALTER TABLE `GDN_Draft` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_Invitation`
--

DROP TABLE IF EXISTS `GDN_Invitation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_Invitation` (
  `InvitationID` int(11) NOT NULL AUTO_INCREMENT,
  `Email` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `Code` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `InsertUserID` int(11) DEFAULT NULL,
  `DateInserted` datetime NOT NULL,
  `AcceptedUserID` int(11) DEFAULT NULL,
  PRIMARY KEY (`InvitationID`),
  KEY `FK_Invitation_InsertUserID` (`InsertUserID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_Invitation`
--

LOCK TABLES `GDN_Invitation` WRITE;
/*!40000 ALTER TABLE `GDN_Invitation` DISABLE KEYS */;
/*!40000 ALTER TABLE `GDN_Invitation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_Log`
--

DROP TABLE IF EXISTS `GDN_Log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_Log` (
  `LogID` int(11) NOT NULL AUTO_INCREMENT,
  `Operation` enum('Delete','Edit','Spam','Moderate','Pending','Ban','Error') COLLATE utf8_unicode_ci NOT NULL,
  `RecordType` enum('Discussion','Comment','User','Registration','Activity','ActivityComment','Configuration','Group') COLLATE utf8_unicode_ci NOT NULL,
  `TransactionLogID` int(11) DEFAULT NULL,
  `RecordID` int(11) DEFAULT NULL,
  `RecordUserID` int(11) DEFAULT NULL,
  `RecordDate` datetime NOT NULL,
  `RecordIPAddress` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `InsertUserID` int(11) NOT NULL,
  `DateInserted` datetime NOT NULL,
  `InsertIPAddress` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `OtherUserIDs` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DateUpdated` datetime DEFAULT NULL,
  `ParentRecordID` int(11) DEFAULT NULL,
  `CategoryID` int(11) DEFAULT NULL,
  `Data` mediumtext COLLATE utf8_unicode_ci,
  `CountGroup` int(11) DEFAULT NULL,
  PRIMARY KEY (`LogID`),
  KEY `IX_Log_RecordType` (`RecordType`),
  KEY `IX_Log_RecordID` (`RecordID`),
  KEY `IX_Log_RecordIPAddress` (`RecordIPAddress`),
  KEY `IX_Log_ParentRecordID` (`ParentRecordID`),
  KEY `FK_Log_CategoryID` (`CategoryID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_Log`
--

LOCK TABLES `GDN_Log` WRITE;
/*!40000 ALTER TABLE `GDN_Log` DISABLE KEYS */;
INSERT INTO `GDN_Log` VALUES (1,'Edit','Configuration',NULL,NULL,NULL,'2013-12-12 06:45:11',NULL,1,'2013-12-12 06:45:11','127.0.0.1','',NULL,NULL,NULL,'a:1:{s:4:\"_New\";a:7:{s:13:\"Conversations\";a:1:{s:7:\"Version\";s:5:\"2.1b2\";}s:8:\"Database\";a:4:{s:4:\"Name\";s:7:\"vanilla\";s:4:\"Host\";s:9:\"localhost\";s:4:\"User\";s:4:\"root\";s:8:\"Password\";s:4:\"root\";}s:19:\"EnabledApplications\";a:2:{s:13:\"Conversations\";s:13:\"conversations\";s:7:\"Vanilla\";s:7:\"vanilla\";}s:14:\"EnabledPlugins\";a:2:{s:14:\"GettingStarted\";s:14:\"GettingStarted\";s:8:\"HtmLawed\";s:8:\"HtmLawed\";}s:6:\"Garden\";a:9:{s:5:\"Title\";s:13:\"Teebadgun.com\";s:6:\"Cookie\";a:2:{s:4:\"Salt\";s:10:\"IUTI5OWH11\";s:6:\"Domain\";s:0:\"\";}s:12:\"Registration\";a:1:{s:12:\"ConfirmEmail\";b:1;}s:5:\"Email\";a:1:{s:11:\"SupportName\";s:13:\"Teebadgun.com\";}s:7:\"Version\";s:5:\"2.1b2\";s:11:\"RewriteUrls\";b:1;s:16:\"CanProcessImages\";b:1;s:12:\"SystemUserID\";s:1:\"2\";s:9:\"Installed\";b:1;}s:6:\"Routes\";a:1:{s:17:\"DefaultController\";s:11:\"discussions\";}s:7:\"Vanilla\";a:1:{s:7:\"Version\";s:5:\"2.1b2\";}}}',NULL),(2,'Edit','Configuration',NULL,NULL,NULL,'2013-12-12 06:45:20',NULL,1,'2013-12-12 06:45:20','127.0.0.1','',NULL,NULL,NULL,'a:8:{s:13:\"Conversations\";a:1:{s:7:\"Version\";s:5:\"2.1b2\";}s:8:\"Database\";a:4:{s:4:\"Name\";s:7:\"vanilla\";s:4:\"Host\";s:9:\"localhost\";s:4:\"User\";s:4:\"root\";s:8:\"Password\";s:4:\"root\";}s:19:\"EnabledApplications\";a:2:{s:13:\"Conversations\";s:13:\"conversations\";s:7:\"Vanilla\";s:7:\"vanilla\";}s:14:\"EnabledPlugins\";a:2:{s:14:\"GettingStarted\";s:14:\"GettingStarted\";s:8:\"HtmLawed\";s:8:\"HtmLawed\";}s:6:\"Garden\";a:9:{s:5:\"Title\";s:13:\"Teebadgun.com\";s:6:\"Cookie\";a:2:{s:4:\"Salt\";s:10:\"IUTI5OWH11\";s:6:\"Domain\";s:0:\"\";}s:12:\"Registration\";a:1:{s:12:\"ConfirmEmail\";b:1;}s:5:\"Email\";a:1:{s:11:\"SupportName\";s:13:\"Teebadgun.com\";}s:7:\"Version\";s:5:\"2.1b2\";s:11:\"RewriteUrls\";b:1;s:16:\"CanProcessImages\";b:1;s:12:\"SystemUserID\";s:1:\"2\";s:9:\"Installed\";b:1;}s:6:\"Routes\";a:1:{s:17:\"DefaultController\";s:11:\"discussions\";}s:7:\"Vanilla\";a:1:{s:7:\"Version\";s:5:\"2.1b2\";}s:4:\"_New\";a:8:{s:13:\"Conversations\";a:1:{s:7:\"Version\";s:5:\"2.1b2\";}s:8:\"Database\";a:4:{s:4:\"Name\";s:7:\"vanilla\";s:4:\"Host\";s:9:\"localhost\";s:4:\"User\";s:4:\"root\";s:8:\"Password\";s:4:\"root\";}s:19:\"EnabledApplications\";a:2:{s:13:\"Conversations\";s:13:\"conversations\";s:7:\"Vanilla\";s:7:\"vanilla\";}s:14:\"EnabledPlugins\";a:2:{s:14:\"GettingStarted\";s:14:\"GettingStarted\";s:8:\"HtmLawed\";s:8:\"HtmLawed\";}s:6:\"Garden\";a:9:{s:5:\"Title\";s:13:\"Teebadgun.com\";s:6:\"Cookie\";a:2:{s:4:\"Salt\";s:10:\"IUTI5OWH11\";s:6:\"Domain\";s:0:\"\";}s:12:\"Registration\";a:1:{s:12:\"ConfirmEmail\";b:1;}s:5:\"Email\";a:1:{s:11:\"SupportName\";s:13:\"Teebadgun.com\";}s:7:\"Version\";s:5:\"2.1b2\";s:11:\"RewriteUrls\";b:1;s:16:\"CanProcessImages\";b:1;s:12:\"SystemUserID\";s:1:\"2\";s:9:\"Installed\";b:1;}s:7:\"Plugins\";a:1:{s:14:\"GettingStarted\";a:1:{s:9:\"Dashboard\";s:1:\"1\";}}s:6:\"Routes\";a:1:{s:17:\"DefaultController\";s:11:\"discussions\";}s:7:\"Vanilla\";a:1:{s:7:\"Version\";s:5:\"2.1b2\";}}}',NULL),(3,'Edit','Configuration',NULL,NULL,NULL,'2013-12-12 06:45:47',NULL,1,'2013-12-12 06:45:47','58.11.199.9','',NULL,NULL,NULL,'a:10:{s:13:\"Conversations\";a:1:{s:7:\"Version\";s:5:\"2.1b2\";}s:8:\"Database\";a:4:{s:4:\"Name\";s:11:\"teebadgu_db\";s:4:\"Host\";s:9:\"localhost\";s:4:\"User\";s:11:\"teebadgu_db\";s:8:\"Password\";s:8:\"lT0tCQbA\";}s:19:\"EnabledApplications\";a:2:{s:13:\"Conversations\";s:13:\"conversations\";s:7:\"Vanilla\";s:7:\"vanilla\";}s:14:\"EnabledLocales\";a:1:{s:4:\"thai\";s:5:\"th-TH\";}s:14:\"EnabledPlugins\";a:5:{s:14:\"GettingStarted\";s:14:\"GettingStarted\";s:8:\"HtmLawed\";s:8:\"HtmLawed\";s:8:\"Facebook\";b:1;s:9:\"jsconnect\";b:1;s:19:\"jsconnectAutoSignIn\";b:1;}s:6:\"Garden\";a:15:{s:5:\"Title\";s:13:\"Teebadgun.com\";s:6:\"Cookie\";a:2:{s:4:\"Salt\";s:10:\"DQ7N1YGWDE\";s:6:\"Domain\";s:0:\"\";}s:12:\"Registration\";a:7:{s:12:\"ConfirmEmail\";s:1:\"1\";s:6:\"Method\";s:7:\"Connect\";s:16:\"ConfirmEmailRole\";s:1:\"3\";s:17:\"CaptchaPrivateKey\";s:0:\"\";s:16:\"CaptchaPublicKey\";s:0:\"\";s:16:\"InviteExpiration\";s:7:\"-1 week\";s:11:\"InviteRoles\";a:5:{i:3;s:1:\"0\";i:4;s:1:\"0\";i:8;s:1:\"0\";i:16;s:1:\"0\";i:32;s:1:\"0\";}}s:5:\"Email\";a:1:{s:11:\"SupportName\";s:13:\"Teebadgun.com\";}s:7:\"Version\";s:5:\"2.1b2\";s:11:\"RewriteUrls\";b:1;s:16:\"CanProcessImages\";b:1;s:12:\"SystemUserID\";s:1:\"2\";s:9:\"Installed\";b:1;s:14:\"InstallationID\";s:22:\"143B-B37C3198-FEC7FC2F\";s:18:\"InstallationSecret\";s:40:\"50f49dc5a6039c080d0cae7ea7cf4d15fd602d81\";s:5:\"Theme\";s:13:\"EmbedFriendly\";s:5:\"Embed\";a:4:{s:5:\"Allow\";b:1;s:9:\"RemoteUrl\";s:37:\"localhost/laravel/public_html/forums/\";s:14:\"ForceDashboard\";b:0;s:10:\"ForceForum\";b:0;}s:14:\"TrustedDomains\";a:2:{i:0;s:9:\"localhost\";i:1;s:13:\"teebadgun.com\";}s:6:\"Locale\";s:5:\"th-TH\";}s:7:\"Plugins\";a:1:{s:14:\"GettingStarted\";a:5:{s:9:\"Dashboard\";s:1:\"1\";s:10:\"Discussion\";s:1:\"1\";s:7:\"Plugins\";s:1:\"1\";s:12:\"Registration\";s:1:\"1\";s:10:\"Categories\";s:1:\"1\";}}s:6:\"Routes\";a:1:{s:17:\"DefaultController\";a:2:{i:0;s:11:\"discussions\";i:1;s:8:\"Internal\";}}s:7:\"Vanilla\";a:3:{s:7:\"Version\";s:5:\"2.1b2\";s:11:\"Discussions\";a:1:{s:6:\"Layout\";s:5:\"table\";}s:10:\"Categories\";a:1:{s:6:\"Layout\";s:5:\"mixed\";}}s:4:\"_New\";a:9:{s:13:\"Conversations\";a:1:{s:7:\"Version\";s:5:\"2.1b2\";}s:8:\"Database\";a:4:{s:4:\"Name\";s:11:\"teebadgu_db\";s:4:\"Host\";s:9:\"localhost\";s:4:\"User\";s:11:\"teebadgu_db\";s:8:\"Password\";s:8:\"lT0tCQbA\";}s:19:\"EnabledApplications\";a:2:{s:13:\"Conversations\";s:13:\"conversations\";s:7:\"Vanilla\";s:7:\"vanilla\";}s:14:\"EnabledLocales\";a:1:{s:4:\"thai\";s:5:\"th-TH\";}s:14:\"EnabledPlugins\";a:6:{s:14:\"GettingStarted\";s:14:\"GettingStarted\";s:8:\"HtmLawed\";s:8:\"HtmLawed\";s:8:\"Facebook\";b:1;s:9:\"jsconnect\";b:1;s:19:\"jsconnectAutoSignIn\";b:1;s:12:\"embedvanilla\";b:1;}s:6:\"Garden\";a:15:{s:5:\"Title\";s:13:\"Teebadgun.com\";s:6:\"Cookie\";a:2:{s:4:\"Salt\";s:10:\"DQ7N1YGWDE\";s:6:\"Domain\";s:0:\"\";}s:12:\"Registration\";a:7:{s:12:\"ConfirmEmail\";s:1:\"1\";s:6:\"Method\";s:7:\"Connect\";s:16:\"ConfirmEmailRole\";s:1:\"3\";s:17:\"CaptchaPrivateKey\";s:0:\"\";s:16:\"CaptchaPublicKey\";s:0:\"\";s:16:\"InviteExpiration\";s:7:\"-1 week\";s:11:\"InviteRoles\";a:5:{i:3;s:1:\"0\";i:4;s:1:\"0\";i:8;s:1:\"0\";i:16;s:1:\"0\";i:32;s:1:\"0\";}}s:5:\"Email\";a:1:{s:11:\"SupportName\";s:13:\"Teebadgun.com\";}s:7:\"Version\";s:5:\"2.1b2\";s:11:\"RewriteUrls\";b:1;s:16:\"CanProcessImages\";b:1;s:12:\"SystemUserID\";s:1:\"2\";s:9:\"Installed\";b:1;s:14:\"InstallationID\";s:22:\"143B-B37C3198-FEC7FC2F\";s:18:\"InstallationSecret\";s:40:\"50f49dc5a6039c080d0cae7ea7cf4d15fd602d81\";s:5:\"Theme\";s:13:\"EmbedFriendly\";s:5:\"Embed\";a:4:{s:5:\"Allow\";b:1;s:9:\"RemoteUrl\";s:37:\"localhost/laravel/public_html/forums/\";s:14:\"ForceDashboard\";b:0;s:10:\"ForceForum\";b:0;}s:14:\"TrustedDomains\";a:2:{i:0;s:9:\"localhost\";i:1;s:13:\"teebadgun.com\";}s:6:\"Locale\";s:5:\"th-TH\";}s:7:\"Plugins\";a:1:{s:14:\"GettingStarted\";a:5:{s:9:\"Dashboard\";s:1:\"1\";s:10:\"Discussion\";s:1:\"1\";s:7:\"Plugins\";s:1:\"1\";s:12:\"Registration\";s:1:\"1\";s:10:\"Categories\";s:1:\"1\";}}s:6:\"Routes\";a:1:{s:17:\"DefaultController\";a:2:{i:0;s:11:\"discussions\";i:1;s:8:\"Internal\";}}s:7:\"Vanilla\";a:3:{s:7:\"Version\";s:5:\"2.1b2\";s:11:\"Discussions\";a:1:{s:6:\"Layout\";s:5:\"table\";}s:10:\"Categories\";a:1:{s:6:\"Layout\";s:5:\"mixed\";}}}}',NULL),(4,'Edit','Configuration',NULL,NULL,NULL,'2013-12-12 06:46:00',NULL,1,'2013-12-12 06:46:00','58.11.199.9','',NULL,NULL,NULL,'a:10:{s:13:\"Conversations\";a:1:{s:7:\"Version\";s:5:\"2.1b2\";}s:8:\"Database\";a:4:{s:4:\"Name\";s:11:\"teebadgu_db\";s:4:\"Host\";s:9:\"localhost\";s:4:\"User\";s:11:\"teebadgu_db\";s:8:\"Password\";s:8:\"lT0tCQbA\";}s:19:\"EnabledApplications\";a:2:{s:13:\"Conversations\";s:13:\"conversations\";s:7:\"Vanilla\";s:7:\"vanilla\";}s:14:\"EnabledLocales\";a:1:{s:4:\"thai\";s:5:\"th-TH\";}s:14:\"EnabledPlugins\";a:6:{s:14:\"GettingStarted\";s:14:\"GettingStarted\";s:8:\"HtmLawed\";s:8:\"HtmLawed\";s:8:\"Facebook\";b:1;s:9:\"jsconnect\";b:1;s:19:\"jsconnectAutoSignIn\";b:1;s:12:\"embedvanilla\";b:1;}s:6:\"Garden\";a:15:{s:5:\"Title\";s:13:\"Teebadgun.com\";s:6:\"Cookie\";a:2:{s:4:\"Salt\";s:10:\"DQ7N1YGWDE\";s:6:\"Domain\";s:0:\"\";}s:12:\"Registration\";a:7:{s:12:\"ConfirmEmail\";s:1:\"1\";s:6:\"Method\";s:7:\"Connect\";s:16:\"ConfirmEmailRole\";s:1:\"3\";s:17:\"CaptchaPrivateKey\";s:0:\"\";s:16:\"CaptchaPublicKey\";s:0:\"\";s:16:\"InviteExpiration\";s:7:\"-1 week\";s:11:\"InviteRoles\";a:5:{i:3;s:1:\"0\";i:4;s:1:\"0\";i:8;s:1:\"0\";i:16;s:1:\"0\";i:32;s:1:\"0\";}}s:5:\"Email\";a:1:{s:11:\"SupportName\";s:13:\"Teebadgun.com\";}s:7:\"Version\";s:5:\"2.1b2\";s:11:\"RewriteUrls\";b:1;s:16:\"CanProcessImages\";b:1;s:12:\"SystemUserID\";s:1:\"2\";s:9:\"Installed\";b:1;s:14:\"InstallationID\";s:22:\"143B-B37C3198-FEC7FC2F\";s:18:\"InstallationSecret\";s:40:\"50f49dc5a6039c080d0cae7ea7cf4d15fd602d81\";s:5:\"Theme\";s:13:\"EmbedFriendly\";s:5:\"Embed\";a:4:{s:5:\"Allow\";b:1;s:9:\"RemoteUrl\";s:37:\"localhost/laravel/public_html/forums/\";s:14:\"ForceDashboard\";b:0;s:10:\"ForceForum\";b:0;}s:14:\"TrustedDomains\";a:2:{i:0;s:9:\"localhost\";i:1;s:13:\"teebadgun.com\";}s:6:\"Locale\";s:5:\"th-TH\";}s:7:\"Plugins\";a:1:{s:14:\"GettingStarted\";a:5:{s:9:\"Dashboard\";s:1:\"1\";s:10:\"Discussion\";s:1:\"1\";s:7:\"Plugins\";s:1:\"1\";s:12:\"Registration\";s:1:\"1\";s:10:\"Categories\";s:1:\"1\";}}s:6:\"Routes\";a:1:{s:17:\"DefaultController\";a:2:{i:0;s:11:\"discussions\";i:1;s:8:\"Internal\";}}s:7:\"Vanilla\";a:3:{s:7:\"Version\";s:5:\"2.1b2\";s:11:\"Discussions\";a:1:{s:6:\"Layout\";s:5:\"table\";}s:10:\"Categories\";a:1:{s:6:\"Layout\";s:5:\"mixed\";}}s:4:\"_New\";a:9:{s:13:\"Conversations\";a:1:{s:7:\"Version\";s:5:\"2.1b2\";}s:8:\"Database\";a:4:{s:4:\"Name\";s:11:\"teebadgu_db\";s:4:\"Host\";s:9:\"localhost\";s:4:\"User\";s:11:\"teebadgu_db\";s:8:\"Password\";s:8:\"lT0tCQbA\";}s:19:\"EnabledApplications\";a:2:{s:13:\"Conversations\";s:13:\"conversations\";s:7:\"Vanilla\";s:7:\"vanilla\";}s:14:\"EnabledLocales\";a:1:{s:4:\"thai\";s:5:\"th-TH\";}s:14:\"EnabledPlugins\";a:6:{s:14:\"GettingStarted\";s:14:\"GettingStarted\";s:8:\"HtmLawed\";s:8:\"HtmLawed\";s:8:\"Facebook\";b:1;s:9:\"jsconnect\";b:1;s:19:\"jsconnectAutoSignIn\";b:1;s:12:\"embedvanilla\";b:1;}s:6:\"Garden\";a:15:{s:5:\"Title\";s:13:\"Teebadgun.com\";s:6:\"Cookie\";a:2:{s:4:\"Salt\";s:10:\"DQ7N1YGWDE\";s:6:\"Domain\";s:0:\"\";}s:12:\"Registration\";a:7:{s:12:\"ConfirmEmail\";s:1:\"1\";s:6:\"Method\";s:7:\"Connect\";s:16:\"ConfirmEmailRole\";s:1:\"3\";s:17:\"CaptchaPrivateKey\";s:0:\"\";s:16:\"CaptchaPublicKey\";s:0:\"\";s:16:\"InviteExpiration\";s:7:\"-1 week\";s:11:\"InviteRoles\";a:5:{i:3;s:1:\"0\";i:4;s:1:\"0\";i:8;s:1:\"0\";i:16;s:1:\"0\";i:32;s:1:\"0\";}}s:5:\"Email\";a:1:{s:11:\"SupportName\";s:13:\"Teebadgun.com\";}s:7:\"Version\";s:5:\"2.1b2\";s:11:\"RewriteUrls\";b:1;s:16:\"CanProcessImages\";b:1;s:12:\"SystemUserID\";s:1:\"2\";s:9:\"Installed\";b:1;s:14:\"InstallationID\";s:22:\"143B-B37C3198-FEC7FC2F\";s:18:\"InstallationSecret\";s:40:\"50f49dc5a6039c080d0cae7ea7cf4d15fd602d81\";s:5:\"Theme\";s:13:\"EmbedFriendly\";s:5:\"Embed\";a:4:{s:5:\"Allow\";b:1;s:9:\"RemoteUrl\";s:37:\"localhost/laravel/public_html/forums/\";s:14:\"ForceDashboard\";b:0;s:10:\"ForceForum\";b:0;}s:14:\"TrustedDomains\";a:2:{i:0;s:9:\"localhost\";i:1;s:13:\"teebadgun.com\";}s:6:\"Locale\";s:5:\"th-TH\";}s:7:\"Plugins\";a:2:{s:14:\"GettingStarted\";a:5:{s:9:\"Dashboard\";s:1:\"1\";s:10:\"Discussion\";s:1:\"1\";s:7:\"Plugins\";s:1:\"1\";s:12:\"Registration\";s:1:\"1\";s:10:\"Categories\";s:1:\"1\";}s:12:\"EmbedVanilla\";a:1:{s:9:\"RemoteUrl\";s:45:\"http://localhost/laravel/public_html/webboard\";}}s:6:\"Routes\";a:1:{s:17:\"DefaultController\";a:2:{i:0;s:11:\"discussions\";i:1;s:8:\"Internal\";}}s:7:\"Vanilla\";a:3:{s:7:\"Version\";s:5:\"2.1b2\";s:11:\"Discussions\";a:1:{s:6:\"Layout\";s:5:\"table\";}s:10:\"Categories\";a:1:{s:6:\"Layout\";s:5:\"mixed\";}}}}',NULL),(5,'Delete','Discussion',5,1,2,'2013-12-12 06:45:11',NULL,1,'2013-12-23 15:25:01','115.87.24.157','',NULL,NULL,1,'a:28:{s:12:\"DiscussionID\";s:1:\"1\";s:4:\"Type\";N;s:9:\"ForeignID\";s:4:\"stub\";s:10:\"CategoryID\";s:1:\"1\";s:12:\"InsertUserID\";s:1:\"2\";s:12:\"UpdateUserID\";N;s:14:\"FirstCommentID\";N;s:13:\"LastCommentID\";s:1:\"1\";s:4:\"Name\";s:35:\"BAM! You&rsquo;ve got a sweet forum\";s:4:\"Body\";s:974:\"There&rsquo;s nothing sweeter than a fresh new forum, ready to welcome your community. A Vanilla Forum has all the bits and pieces you need to build an awesome discussion platform customized to your needs. Here&rsquo;s a few tips:\n<ul>\n<li>Use the <a href=\"/dashboard/settings/gettingstarted\">Getting Started</a> list in the Dashboard to configure your site.</li>\n<li>Don&rsquo;t use too many categories. We recommend 3-8. Keep it simple!\n<li>&ldquo;Announce&rdquo; a discussion (click the gear) to stick to the top of the list, and &ldquo;Close&rdquo; it to stop further comments.</li>\n<li>Use &ldquo;Sink&rdquo; to take attention away from a discussion. New comments will no longer bring it back to the top of the list.</li>\n<li>Bookmark a discussion (click the star) to get notifications for new comments. You can edit notification settings from your profile.</li>\n</ul>\nGo ahead and edit or delete this discussion, then spread the word to get this place cooking. Cheers!\";s:6:\"Format\";s:4:\"Html\";s:4:\"Tags\";N;s:13:\"CountComments\";s:1:\"1\";s:14:\"CountBookmarks\";N;s:10:\"CountViews\";s:1:\"1\";s:6:\"Closed\";s:1:\"0\";s:8:\"Announce\";s:1:\"0\";s:4:\"Sink\";s:1:\"0\";s:12:\"DateInserted\";s:19:\"2013-12-12 06:45:11\";s:11:\"DateUpdated\";N;s:15:\"InsertIPAddress\";N;s:15:\"UpdateIPAddress\";N;s:15:\"DateLastComment\";s:19:\"2013-12-12 06:45:11\";s:17:\"LastCommentUserID\";s:1:\"2\";s:5:\"Score\";N;s:10:\"Attributes\";N;s:11:\"RegardingID\";N;s:5:\"_Data\";a:1:{s:7:\"Comment\";a:1:{i:0;a:15:{s:9:\"CommentID\";s:1:\"1\";s:12:\"DiscussionID\";s:1:\"1\";s:12:\"InsertUserID\";s:1:\"2\";s:12:\"UpdateUserID\";N;s:12:\"DeleteUserID\";N;s:4:\"Body\";s:341:\"This is the first comment on your site and it&rsquo;s an important one. \n\nDon&rsquo;t see your must-have feature? We keep Vanilla nice and simple by default. Use <b>addons</b> to get the special sauce your community needs.\n\nNot sure which addons to enable? Our favorites are Button Bar and Tagging. They&rsquo;re almost always a great start.\";s:6:\"Format\";s:4:\"Html\";s:12:\"DateInserted\";s:19:\"2013-12-12 06:45:11\";s:11:\"DateDeleted\";N;s:11:\"DateUpdated\";N;s:15:\"InsertIPAddress\";N;s:15:\"UpdateIPAddress\";N;s:4:\"Flag\";s:1:\"0\";s:5:\"Score\";N;s:10:\"Attributes\";N;}}}}',NULL);
/*!40000 ALTER TABLE `GDN_Log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_Media`
--

DROP TABLE IF EXISTS `GDN_Media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_Media` (
  `MediaID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Type` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `Size` int(11) NOT NULL,
  `InsertUserID` int(11) NOT NULL,
  `DateInserted` datetime NOT NULL,
  `ForeignID` int(11) DEFAULT NULL,
  `ForeignTable` varchar(24) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ImageWidth` smallint(5) unsigned DEFAULT NULL,
  `ImageHeight` smallint(5) unsigned DEFAULT NULL,
  `ThumbWidth` smallint(5) unsigned DEFAULT NULL,
  `ThumbHeight` smallint(5) unsigned DEFAULT NULL,
  `ThumbPath` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`MediaID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_Media`
--

LOCK TABLES `GDN_Media` WRITE;
/*!40000 ALTER TABLE `GDN_Media` DISABLE KEYS */;
/*!40000 ALTER TABLE `GDN_Media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_Message`
--

DROP TABLE IF EXISTS `GDN_Message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_Message` (
  `MessageID` int(11) NOT NULL AUTO_INCREMENT,
  `Content` text COLLATE utf8_unicode_ci NOT NULL,
  `Format` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `AllowDismiss` tinyint(4) NOT NULL DEFAULT '1',
  `Enabled` tinyint(4) NOT NULL DEFAULT '1',
  `Application` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Controller` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Method` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `AssetTarget` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CssClass` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Sort` int(11) DEFAULT NULL,
  PRIMARY KEY (`MessageID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_Message`
--

LOCK TABLES `GDN_Message` WRITE;
/*!40000 ALTER TABLE `GDN_Message` DISABLE KEYS */;
/*!40000 ALTER TABLE `GDN_Message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_Permission`
--

DROP TABLE IF EXISTS `GDN_Permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_Permission` (
  `PermissionID` int(11) NOT NULL AUTO_INCREMENT,
  `RoleID` int(11) NOT NULL DEFAULT '0',
  `JunctionTable` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `JunctionColumn` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `JunctionID` int(11) DEFAULT NULL,
  `Garden.Email.View` tinyint(4) NOT NULL DEFAULT '0',
  `Garden.Settings.Manage` tinyint(4) NOT NULL DEFAULT '0',
  `Garden.Settings.View` tinyint(4) NOT NULL DEFAULT '0',
  `Garden.Messages.Manage` tinyint(4) NOT NULL DEFAULT '0',
  `Garden.SignIn.Allow` tinyint(4) NOT NULL DEFAULT '0',
  `Garden.Users.Add` tinyint(4) NOT NULL DEFAULT '0',
  `Garden.Users.Edit` tinyint(4) NOT NULL DEFAULT '0',
  `Garden.Users.Delete` tinyint(4) NOT NULL DEFAULT '0',
  `Garden.Users.Approve` tinyint(4) NOT NULL DEFAULT '0',
  `Garden.Activity.Delete` tinyint(4) NOT NULL DEFAULT '0',
  `Garden.Activity.View` tinyint(4) NOT NULL DEFAULT '0',
  `Garden.Profiles.View` tinyint(4) NOT NULL DEFAULT '0',
  `Garden.Profiles.Edit` tinyint(4) NOT NULL DEFAULT '0',
  `Garden.Curation.Manage` tinyint(4) NOT NULL DEFAULT '0',
  `Garden.Moderation.Manage` tinyint(4) NOT NULL DEFAULT '0',
  `Garden.AdvancedNotifications.Allow` tinyint(4) NOT NULL DEFAULT '0',
  `Conversations.Moderation.Manage` tinyint(4) NOT NULL DEFAULT '0',
  `Conversations.Conversations.Add` tinyint(4) NOT NULL DEFAULT '0',
  `Vanilla.Approval.Require` tinyint(4) NOT NULL DEFAULT '0',
  `Vanilla.Comments.Me` tinyint(4) NOT NULL DEFAULT '0',
  `Vanilla.Discussions.View` tinyint(4) NOT NULL DEFAULT '0',
  `Vanilla.Discussions.Add` tinyint(4) NOT NULL DEFAULT '0',
  `Vanilla.Discussions.Edit` tinyint(4) NOT NULL DEFAULT '0',
  `Vanilla.Discussions.Announce` tinyint(4) NOT NULL DEFAULT '0',
  `Vanilla.Discussions.Sink` tinyint(4) NOT NULL DEFAULT '0',
  `Vanilla.Discussions.Close` tinyint(4) NOT NULL DEFAULT '0',
  `Vanilla.Discussions.Delete` tinyint(4) NOT NULL DEFAULT '0',
  `Vanilla.Comments.Add` tinyint(4) NOT NULL DEFAULT '0',
  `Vanilla.Comments.Edit` tinyint(4) NOT NULL DEFAULT '0',
  `Vanilla.Comments.Delete` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`PermissionID`),
  KEY `FK_Permission_RoleID` (`RoleID`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_Permission`
--

LOCK TABLES `GDN_Permission` WRITE;
/*!40000 ALTER TABLE `GDN_Permission` DISABLE KEYS */;
INSERT INTO `GDN_Permission` VALUES (1,0,NULL,NULL,NULL,3,2,2,2,3,2,2,2,2,2,3,3,3,0,2,2,2,3,2,3,0,0,0,0,0,0,0,0,0,0),(2,2,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0),(3,3,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,0,1,1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0),(4,4,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,0,1,1,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0),(5,8,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,0,1,1,1,0,0,0,0,1,0,1,1,1,0,0,0,0,0,1,0,0),(6,32,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,0,1,1,1,1,1,0,0,1,0,1,1,1,1,1,1,1,1,1,1,1),(7,16,NULL,NULL,NULL,1,1,0,0,1,1,1,1,1,1,1,1,1,1,1,1,0,1,0,1,1,1,1,1,1,1,1,1,1,1),(8,0,'Category','PermissionCategoryID',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,3,2,2,2,2,2,3,2,2),(9,2,'Category','PermissionCategoryID',-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0),(10,4,'Category','PermissionCategoryID',-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0),(11,8,'Category','PermissionCategoryID',-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,1,0,0),(12,32,'Category','PermissionCategoryID',-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1),(13,16,'Category','PermissionCategoryID',-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1),(14,2,'Category','PermissionCategoryID',3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0),(15,3,'Category','PermissionCategoryID',3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0),(16,4,'Category','PermissionCategoryID',3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0),(17,8,'Category','PermissionCategoryID',3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0),(18,32,'Category','PermissionCategoryID',3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0),(19,16,'Category','PermissionCategoryID',3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,1,0,0);
/*!40000 ALTER TABLE `GDN_Permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_Regarding`
--

DROP TABLE IF EXISTS `GDN_Regarding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_Regarding` (
  `RegardingID` int(11) NOT NULL AUTO_INCREMENT,
  `Type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `InsertUserID` int(11) NOT NULL,
  `DateInserted` datetime NOT NULL,
  `ForeignType` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `ForeignID` int(11) NOT NULL,
  `OriginalContent` text COLLATE utf8_unicode_ci,
  `ParentType` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ParentID` int(11) DEFAULT NULL,
  `ForeignURL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Comment` text COLLATE utf8_unicode_ci NOT NULL,
  `Reports` int(11) DEFAULT NULL,
  PRIMARY KEY (`RegardingID`),
  KEY `FK_Regarding_Type` (`Type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_Regarding`
--

LOCK TABLES `GDN_Regarding` WRITE;
/*!40000 ALTER TABLE `GDN_Regarding` DISABLE KEYS */;
/*!40000 ALTER TABLE `GDN_Regarding` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_Role`
--

DROP TABLE IF EXISTS `GDN_Role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_Role` (
  `RoleID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Description` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Sort` int(11) DEFAULT NULL,
  `Deletable` tinyint(4) NOT NULL DEFAULT '1',
  `CanSession` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`RoleID`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_Role`
--

LOCK TABLES `GDN_Role` WRITE;
/*!40000 ALTER TABLE `GDN_Role` DISABLE KEYS */;
INSERT INTO `GDN_Role` VALUES (2,'Guest','Guests can only view content. Anyone browsing the site who is not signed in is considered to be a \"Guest\".',1,0,0),(3,'Unconfirmed','Users must confirm their emails before becoming full members. They get assigned to this role.',2,1,1),(4,'Applicant','Users who have applied for membership, but have not yet been accepted. They have the same permissions as guests.',3,0,1),(8,'Member','Members can participate in discussions.',4,1,1),(16,'Administrator','Administrators have permission to do anything.',6,1,1),(32,'Moderator','Moderators have permission to edit most content.',5,1,1);
/*!40000 ALTER TABLE `GDN_Role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_Session`
--

DROP TABLE IF EXISTS `GDN_Session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_Session` (
  `SessionID` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `UserID` int(11) NOT NULL DEFAULT '0',
  `DateInserted` datetime NOT NULL,
  `DateUpdated` datetime NOT NULL,
  `TransientKey` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `Attributes` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`SessionID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_Session`
--

LOCK TABLES `GDN_Session` WRITE;
/*!40000 ALTER TABLE `GDN_Session` DISABLE KEYS */;
/*!40000 ALTER TABLE `GDN_Session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_Spammer`
--

DROP TABLE IF EXISTS `GDN_Spammer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_Spammer` (
  `UserID` int(11) NOT NULL,
  `CountSpam` smallint(5) unsigned NOT NULL DEFAULT '0',
  `CountDeletedSpam` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_Spammer`
--

LOCK TABLES `GDN_Spammer` WRITE;
/*!40000 ALTER TABLE `GDN_Spammer` DISABLE KEYS */;
/*!40000 ALTER TABLE `GDN_Spammer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_Tag`
--

DROP TABLE IF EXISTS `GDN_Tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_Tag` (
  `TagID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Type` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `InsertUserID` int(11) DEFAULT NULL,
  `DateInserted` datetime NOT NULL,
  `CategoryID` int(11) NOT NULL DEFAULT '-1',
  `CountDiscussions` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`TagID`),
  UNIQUE KEY `UX_Tag` (`Name`,`CategoryID`),
  KEY `IX_Tag_Type` (`Type`),
  KEY `FK_Tag_InsertUserID` (`InsertUserID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_Tag`
--

LOCK TABLES `GDN_Tag` WRITE;
/*!40000 ALTER TABLE `GDN_Tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `GDN_Tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_TagDiscussion`
--

DROP TABLE IF EXISTS `GDN_TagDiscussion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_TagDiscussion` (
  `TagID` int(11) NOT NULL,
  `DiscussionID` int(11) NOT NULL,
  `CategoryID` int(11) NOT NULL,
  `DateInserted` datetime DEFAULT NULL,
  PRIMARY KEY (`TagID`,`DiscussionID`),
  KEY `IX_TagDiscussion_CategoryID` (`CategoryID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_TagDiscussion`
--

LOCK TABLES `GDN_TagDiscussion` WRITE;
/*!40000 ALTER TABLE `GDN_TagDiscussion` DISABLE KEYS */;
/*!40000 ALTER TABLE `GDN_TagDiscussion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_User`
--

DROP TABLE IF EXISTS `GDN_User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_User` (
  `UserID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Password` varbinary(100) NOT NULL,
  `HashMethod` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Photo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Location` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `About` text COLLATE utf8_unicode_ci,
  `Email` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `ShowEmail` tinyint(4) NOT NULL DEFAULT '0',
  `Gender` enum('u','m','f') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'u',
  `CountVisits` int(11) NOT NULL DEFAULT '0',
  `CountInvitations` int(11) NOT NULL DEFAULT '0',
  `CountNotifications` int(11) DEFAULT NULL,
  `InviteUserID` int(11) DEFAULT NULL,
  `DiscoveryText` text COLLATE utf8_unicode_ci,
  `Preferences` text COLLATE utf8_unicode_ci,
  `Permissions` text COLLATE utf8_unicode_ci,
  `Attributes` text COLLATE utf8_unicode_ci,
  `DateSetInvitations` datetime DEFAULT NULL,
  `DateOfBirth` datetime DEFAULT NULL,
  `DateFirstVisit` datetime DEFAULT NULL,
  `DateLastActive` datetime DEFAULT NULL,
  `LastIPAddress` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `AllIPAddresses` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DateInserted` datetime NOT NULL,
  `InsertIPAddress` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DateUpdated` datetime DEFAULT NULL,
  `UpdateIPAddress` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HourOffset` int(11) NOT NULL DEFAULT '0',
  `Score` float DEFAULT NULL,
  `Admin` tinyint(4) NOT NULL DEFAULT '0',
  `Verified` tinyint(4) NOT NULL DEFAULT '0',
  `Banned` tinyint(4) NOT NULL DEFAULT '0',
  `Deleted` tinyint(4) NOT NULL DEFAULT '0',
  `Points` int(11) NOT NULL DEFAULT '0',
  `CountUnreadConversations` int(11) DEFAULT NULL,
  `CountDiscussions` int(11) DEFAULT NULL,
  `CountUnreadDiscussions` int(11) DEFAULT NULL,
  `CountComments` int(11) DEFAULT NULL,
  `CountDrafts` int(11) DEFAULT NULL,
  `CountBookmarks` int(11) DEFAULT NULL,
  PRIMARY KEY (`UserID`),
  KEY `FK_User_Name` (`Name`),
  KEY `IX_User_Email` (`Email`),
  KEY `IX_User_DateLastActive` (`DateLastActive`),
  KEY `IX_User_DateInserted` (`DateInserted`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_User`
--

LOCK TABLES `GDN_User` WRITE;
/*!40000 ALTER TABLE `GDN_User` DISABLE KEYS */;
INSERT INTO `GDN_User` VALUES (1,'admin','$P$BcolU2RgtI4NoLegnGfSf9AiMPUtYP.','Vanilla',NULL,NULL,NULL,NULL,'uttapong@gmail.com',0,'u',17,0,NULL,NULL,NULL,NULL,'','a:1:{s:12:\"TransientKey\";s:12:\"KFVTO4LCDOC1\";}',NULL,'1975-09-16 00:00:00','2013-12-12 06:45:08','2013-12-27 09:20:10','203.185.134.237','0.0.0.1,110.168.60.49,115.87.24.157,124.121.122.159,124.121.123.80,127.0.0.1,171.97.149.84,203.185.1','2013-12-12 06:45:08','127.0.0.1','2013-12-12 06:45:08',NULL,7,NULL,1,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL),(2,'System','OEEO17J3H7C7QV4UFB8L','Random','http://localhost/vanilla/applications/dashboard/design/images/usericon.png',NULL,NULL,NULL,'system@domain.com',0,'u',0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2013-12-12 06:45:09',NULL,NULL,NULL,0,NULL,2,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `GDN_User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_UserAuthentication`
--

DROP TABLE IF EXISTS `GDN_UserAuthentication`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_UserAuthentication` (
  `ForeignUserKey` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ProviderKey` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `UserID` int(11) NOT NULL,
  PRIMARY KEY (`ForeignUserKey`,`ProviderKey`),
  KEY `FK_UserAuthentication_UserID` (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_UserAuthentication`
--

LOCK TABLES `GDN_UserAuthentication` WRITE;
/*!40000 ALTER TABLE `GDN_UserAuthentication` DISABLE KEYS */;
/*!40000 ALTER TABLE `GDN_UserAuthentication` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_UserAuthenticationNonce`
--

DROP TABLE IF EXISTS `GDN_UserAuthenticationNonce`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_UserAuthenticationNonce` (
  `Nonce` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `Token` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `Timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Nonce`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_UserAuthenticationNonce`
--

LOCK TABLES `GDN_UserAuthenticationNonce` WRITE;
/*!40000 ALTER TABLE `GDN_UserAuthenticationNonce` DISABLE KEYS */;
/*!40000 ALTER TABLE `GDN_UserAuthenticationNonce` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_UserAuthenticationProvider`
--

DROP TABLE IF EXISTS `GDN_UserAuthenticationProvider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_UserAuthenticationProvider` (
  `AuthenticationKey` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `AuthenticationSchemeAlias` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `Name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `AssociationSecret` text COLLATE utf8_unicode_ci,
  `AssociationHashMethod` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `AuthenticateUrl` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RegisterUrl` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SignInUrl` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SignOutUrl` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PasswordUrl` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ProfileUrl` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Attributes` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`AuthenticationKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_UserAuthenticationProvider`
--

LOCK TABLES `GDN_UserAuthenticationProvider` WRITE;
/*!40000 ALTER TABLE `GDN_UserAuthenticationProvider` DISABLE KEYS */;
INSERT INTO `GDN_UserAuthenticationProvider` VALUES ('812583585','jsconnect','ตีแบดกันดอทคอม',NULL,'26ab1cb40c6b113065a5a9f3d2e745ff','md5','http://www.teebadgun.com/jsconnect','http://www.teebadgun.com/user/signup','http://www.teebadgun.com/login',NULL,NULL,NULL,'a:1:{s:8:\"TestMode\";b:0;}');
/*!40000 ALTER TABLE `GDN_UserAuthenticationProvider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_UserAuthenticationToken`
--

DROP TABLE IF EXISTS `GDN_UserAuthenticationToken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_UserAuthenticationToken` (
  `Token` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `ProviderKey` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `ForeignUserKey` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TokenSecret` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `TokenType` enum('request','access') COLLATE utf8_unicode_ci NOT NULL,
  `Authorized` tinyint(4) NOT NULL,
  `Timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Lifetime` int(11) NOT NULL,
  PRIMARY KEY (`Token`,`ProviderKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_UserAuthenticationToken`
--

LOCK TABLES `GDN_UserAuthenticationToken` WRITE;
/*!40000 ALTER TABLE `GDN_UserAuthenticationToken` DISABLE KEYS */;
/*!40000 ALTER TABLE `GDN_UserAuthenticationToken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_UserCategory`
--

DROP TABLE IF EXISTS `GDN_UserCategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_UserCategory` (
  `UserID` int(11) NOT NULL,
  `CategoryID` int(11) NOT NULL,
  `DateMarkedRead` datetime DEFAULT NULL,
  `Unfollow` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`UserID`,`CategoryID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_UserCategory`
--

LOCK TABLES `GDN_UserCategory` WRITE;
/*!40000 ALTER TABLE `GDN_UserCategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `GDN_UserCategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_UserComment`
--

DROP TABLE IF EXISTS `GDN_UserComment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_UserComment` (
  `UserID` int(11) NOT NULL,
  `CommentID` int(11) NOT NULL,
  `Score` float DEFAULT NULL,
  `DateLastViewed` datetime DEFAULT NULL,
  PRIMARY KEY (`UserID`,`CommentID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_UserComment`
--

LOCK TABLES `GDN_UserComment` WRITE;
/*!40000 ALTER TABLE `GDN_UserComment` DISABLE KEYS */;
/*!40000 ALTER TABLE `GDN_UserComment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_UserConversation`
--

DROP TABLE IF EXISTS `GDN_UserConversation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_UserConversation` (
  `UserID` int(11) NOT NULL,
  `ConversationID` int(11) NOT NULL,
  `CountReadMessages` int(11) NOT NULL DEFAULT '0',
  `LastMessageID` int(11) DEFAULT NULL,
  `DateLastViewed` datetime DEFAULT NULL,
  `DateCleared` datetime DEFAULT NULL,
  `Bookmarked` tinyint(4) NOT NULL DEFAULT '0',
  `Deleted` tinyint(4) NOT NULL DEFAULT '0',
  `DateConversationUpdated` datetime DEFAULT NULL,
  PRIMARY KEY (`UserID`,`ConversationID`),
  KEY `IX_UserConversation_Inbox` (`UserID`,`Deleted`,`DateConversationUpdated`),
  KEY `FK_UserConversation_ConversationID` (`ConversationID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_UserConversation`
--

LOCK TABLES `GDN_UserConversation` WRITE;
/*!40000 ALTER TABLE `GDN_UserConversation` DISABLE KEYS */;
INSERT INTO `GDN_UserConversation` VALUES (1,1,0,1,NULL,NULL,0,0,'2013-12-12 06:45:09');
/*!40000 ALTER TABLE `GDN_UserConversation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_UserDiscussion`
--

DROP TABLE IF EXISTS `GDN_UserDiscussion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_UserDiscussion` (
  `UserID` int(11) NOT NULL,
  `DiscussionID` int(11) NOT NULL,
  `Score` float DEFAULT NULL,
  `CountComments` int(11) NOT NULL DEFAULT '0',
  `DateLastViewed` datetime DEFAULT NULL,
  `Dismissed` tinyint(4) NOT NULL DEFAULT '0',
  `Bookmarked` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`UserID`,`DiscussionID`),
  KEY `FK_UserDiscussion_DiscussionID` (`DiscussionID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_UserDiscussion`
--

LOCK TABLES `GDN_UserDiscussion` WRITE;
/*!40000 ALTER TABLE `GDN_UserDiscussion` DISABLE KEYS */;
/*!40000 ALTER TABLE `GDN_UserDiscussion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_UserMerge`
--

DROP TABLE IF EXISTS `GDN_UserMerge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_UserMerge` (
  `MergeID` int(11) NOT NULL AUTO_INCREMENT,
  `OldUserID` int(11) NOT NULL,
  `NewUserID` int(11) NOT NULL,
  `DateInserted` datetime NOT NULL,
  `InsertUserID` int(11) NOT NULL,
  `DateUpdated` datetime DEFAULT NULL,
  `UpdateUserID` int(11) DEFAULT NULL,
  `Attributes` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`MergeID`),
  KEY `FK_UserMerge_OldUserID` (`OldUserID`),
  KEY `FK_UserMerge_NewUserID` (`NewUserID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_UserMerge`
--

LOCK TABLES `GDN_UserMerge` WRITE;
/*!40000 ALTER TABLE `GDN_UserMerge` DISABLE KEYS */;
/*!40000 ALTER TABLE `GDN_UserMerge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_UserMergeItem`
--

DROP TABLE IF EXISTS `GDN_UserMergeItem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_UserMergeItem` (
  `MergeID` int(11) NOT NULL,
  `Table` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Column` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `RecordID` int(11) NOT NULL,
  `OldUserID` int(11) NOT NULL,
  `NewUserID` int(11) NOT NULL,
  KEY `FK_UserMergeItem_MergeID` (`MergeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_UserMergeItem`
--

LOCK TABLES `GDN_UserMergeItem` WRITE;
/*!40000 ALTER TABLE `GDN_UserMergeItem` DISABLE KEYS */;
/*!40000 ALTER TABLE `GDN_UserMergeItem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_UserMeta`
--

DROP TABLE IF EXISTS `GDN_UserMeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_UserMeta` (
  `UserID` int(11) NOT NULL,
  `Name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Value` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`UserID`,`Name`),
  KEY `IX_UserMeta_Name` (`Name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_UserMeta`
--

LOCK TABLES `GDN_UserMeta` WRITE;
/*!40000 ALTER TABLE `GDN_UserMeta` DISABLE KEYS */;
INSERT INTO `GDN_UserMeta` VALUES (0,'Garden.Analytics.LastSentDate','20131223');
/*!40000 ALTER TABLE `GDN_UserMeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_UserPoints`
--

DROP TABLE IF EXISTS `GDN_UserPoints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_UserPoints` (
  `SlotType` enum('d','w','m','y','a') COLLATE utf8_unicode_ci NOT NULL,
  `TimeSlot` datetime NOT NULL,
  `Source` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Total',
  `UserID` int(11) NOT NULL,
  `Points` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`SlotType`,`TimeSlot`,`Source`,`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_UserPoints`
--

LOCK TABLES `GDN_UserPoints` WRITE;
/*!40000 ALTER TABLE `GDN_UserPoints` DISABLE KEYS */;
/*!40000 ALTER TABLE `GDN_UserPoints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GDN_UserRole`
--

DROP TABLE IF EXISTS `GDN_UserRole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GDN_UserRole` (
  `UserID` int(11) NOT NULL,
  `RoleID` int(11) NOT NULL,
  PRIMARY KEY (`UserID`,`RoleID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GDN_UserRole`
--

LOCK TABLES `GDN_UserRole` WRITE;
/*!40000 ALTER TABLE `GDN_UserRole` DISABLE KEYS */;
INSERT INTO `GDN_UserRole` VALUES (0,2),(1,16);
/*!40000 ALTER TABLE `GDN_UserRole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `albums`
--

DROP TABLE IF EXISTS `albums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `albums` (
  `album_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `album_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `album_description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`album_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `albums`
--

LOCK TABLES `albums` WRITE;
/*!40000 ALTER TABLE `albums` DISABLE KEYS */;
INSERT INTO `albums` VALUES (1,'ตบโด่ง','ตบโด่งเทส','2013-11-22 04:43:22','2013-11-22 04:44:07');
/*!40000 ALTER TABLE `albums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `amphurs`
--

DROP TABLE IF EXISTS `amphurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `amphurs` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `code` varchar(4) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `name_eng` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `geo_id` int(5) NOT NULL DEFAULT '0',
  `province_id` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=999 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `amphurs`
--

LOCK TABLES `amphurs` WRITE;
/*!40000 ALTER TABLE `amphurs` DISABLE KEYS */;
INSERT INTO `amphurs` VALUES (1,'1001','เขตพระนคร   ','Khet Phra Nakhon',2,1),(2,'1002','เขตดุสิต   ','Khet Dusit',2,1),(3,'1003','เขตหนองจอก   ','Khet  Nong Chok',2,1),(4,'1004','เขตบางรัก   ','Khet Bang Rak',2,1),(5,'1005','เขตบางเขน   ','Khet Bang Khen',2,1),(6,'1006','เขตบางกะปิ   ','Khet Bang Kapi',2,1),(7,'1007','เขตปทุมวัน   ','Khet Pathum Wan',2,1),(8,'1008','เขตป้อมปราบศัตรูพ่าย   ','Khet Pom Prap Sattru Phai',2,1),(9,'1009','เขตพระโขนง   ','Khet Phra Khanong',2,1),(10,'1010','เขตมีนบุรี   ','Khet Min Buri',2,1),(11,'1011','เขตลาดกระบัง   ','Khet Lat Krabang',2,1),(12,'1012','เขตยานนาวา   ','Khet Yan Nawa',2,1),(13,'1013','เขตสัมพันธวงศ์   ','Khet Samphanthawong',2,1),(14,'1014','เขตพญาไท   ','Khet Phaya Thai',2,1),(15,'1015','เขตธนบุรี   ','Khet Thon Buri',2,1),(16,'1016','เขตบางกอกใหญ่   ','Khet Bangkok Yai',2,1),(17,'1017','เขตห้วยขวาง   ','Khet Huai Khwang',2,1),(18,'1018','เขตคลองสาน   ','Khet Khlong San',2,1),(19,'1019','เขตตลิ่งชัน   ','Khet Taling Chan',2,1),(20,'1020','เขตบางกอกน้อย   ','Khet Bangkok Noi',2,1),(21,'1021','เขตบางขุนเทียน   ','Khet Bang Khun Thian',2,1),(22,'1022','เขตภาษีเจริญ   ','Khet Phasi Charoen',2,1),(23,'1023','เขตหนองแขม   ','Khet Nong Khaem',2,1),(24,'1024','เขตราษฎร์บูรณะ   ','Khet Rat Burana',2,1),(25,'1025','เขตบางพลัด   ','Khet Bang Phlat',2,1),(26,'1026','เขตดินแดง   ','Khet Din Daeng',2,1),(27,'1027','เขตบึงกุ่ม   ','Khet Bueng Kum',2,1),(28,'1028','เขตสาทร   ','Khet Sathon',2,1),(29,'1029','เขตบางซื่อ   ','Khet Bang Sue',2,1),(30,'1030','เขตจตุจักร   ','Khet Chatuchak',2,1),(31,'1031','เขตบางคอแหลม   ','Khet Bang Kho Laem',2,1),(32,'1032','เขตประเวศ   ','Khet Prawet',2,1),(33,'1033','เขตคลองเตย   ','Khet Khlong Toei',2,1),(34,'1034','เขตสวนหลวง   ','Khet Suan Luang',2,1),(35,'1035','เขตจอมทอง   ','Khet Chom Thong',2,1),(36,'1036','เขตดอนเมือง   ','Khet Don Mueang',2,1),(37,'1037','เขตราชเทวี   ','Khet Ratchathewi',2,1),(38,'1038','เขตลาดพร้าว   ','Khet Lat Phrao',2,1),(39,'1039','เขตวัฒนา   ','Khet Watthana',2,1),(40,'1040','เขตบางแค   ','Khet Bang Khae',2,1),(41,'1041','เขตหลักสี่   ','Khet Lak Si',2,1),(42,'1042','เขตสายไหม   ','Khet Sai Mai',2,1),(43,'1043','เขตคันนายาว   ','Khet Khan Na Yao',2,1),(44,'1044','เขตสะพานสูง   ','Khet Saphan Sung',2,1),(45,'1045','เขตวังทองหลาง   ','Khet Wang Thonglang',2,1),(46,'1046','เขตคลองสามวา   ','Khet Khlong Sam Wa',2,1),(47,'1047','เขตบางนา   ','Khet Bang Na',2,1),(48,'1048','เขตทวีวัฒนา   ','Khet Thawi Watthana',2,1),(49,'1049','เขตทุ่งครุ   ','Khet Thung Khru',2,1),(50,'1050','เขตบางบอน   ','Khet Bang Bon',2,1),(51,'1081','*บ้านทะวาย   ','*Bantawai',2,1),(52,'1101','เมืองสมุทรปราการ   ','Mueang Samut Prakan',2,2),(53,'1102','บางบ่อ   ','Bang Bo',2,2),(54,'1103','บางพลี   ','Bang Phli',2,2),(55,'1104','พระประแดง   ','Phra Pradaeng',2,2),(56,'1105','พระสมุทรเจดีย์   ','Phra Samut Chedi',2,2),(57,'1106','บางเสาธง   ','Bang Sao Thong',2,2),(58,'1201','เมืองนนทบุรี   ','Mueang Nonthaburi',2,3),(59,'1202','บางกรวย   ','Bang Kruai',2,3),(60,'1203','บางใหญ่   ','Bang Yai',2,3),(61,'1204','บางบัวทอง   ','Bang Bua Thong',2,3),(62,'1205','ไทรน้อย   ','Sai Noi',2,3),(63,'1206','ปากเกร็ด   ','Pak Kret',2,3),(64,'1251','เทศบาลนครนนทบุรี (สาขาแขวงท่าทราย)*   ','Tetsaban Nonthaburi',2,3),(65,'1297','เทศบาลเมืองปากเกร็ด*   ','Tetsaban Pak Kret',2,3),(66,'1301','เมืองปทุมธานี   ','Mueang Pathum Thani',2,4),(67,'1302','คลองหลวง   ','Khlong Luang',2,4),(68,'1303','ธัญบุรี   ','Thanyaburi',2,4),(69,'1304','หนองเสือ   ','Nong Suea',2,4),(70,'1305','ลาดหลุมแก้ว   ','Lat Lum Kaeo',2,4),(71,'1306','ลำลูกกา   ','Lam Luk Ka',2,4),(72,'1307','สามโคก   ','Sam Khok',2,4),(73,'1351','ลำลูกกา (สาขาตำบลคูคต)*   ','Khlong Luang(Kukod)',2,4),(74,'1401','พระนครศรีอยุธยา   ','Phra Nakhon Si Ayutthaya',2,5),(75,'1402','ท่าเรือ   ','Tha Ruea',2,5),(76,'1403','นครหลวง   ','Nakhon Luang',2,5),(77,'1404','บางไทร   ','Bang Sai',2,5),(78,'1405','บางบาล   ','Bang Ban',2,5),(79,'1406','บางปะอิน   ','Bang Pa-in',2,5),(80,'1407','บางปะหัน   ','Bang Pahan',2,5),(81,'1408','ผักไห่   ','Phak Hai',2,5),(82,'1409','ภาชี   ','Phachi',2,5),(83,'1410','ลาดบัวหลวง   ','Lat Bua Luang',2,5),(84,'1411','วังน้อย   ','Wang Noi',2,5),(85,'1412','เสนา   ','Sena',2,5),(86,'1413','บางซ้าย   ','Bang Sai',2,5),(87,'1414','อุทัย   ','Uthai',2,5),(88,'1415','มหาราช   ','Maha Rat',2,5),(89,'1416','บ้านแพรก   ','Ban Phraek',2,5),(90,'1501','เมืองอ่างทอง   ','Mueang Ang Thong',2,6),(91,'1502','ไชโย   ','Chaiyo',2,6),(92,'1503','ป่าโมก   ','Pa Mok',2,6),(93,'1504','โพธิ์ทอง   ','Pho Thong',2,6),(94,'1505','แสวงหา   ','Sawaeng Ha',2,6),(95,'1506','วิเศษชัยชาญ   ','Wiset Chai Chan',2,6),(96,'1507','สามโก้   ','Samko',2,6),(97,'1601','เมืองลพบุรี   ','Mueang Lop Buri',2,7),(98,'1602','พัฒนานิคม   ','Phatthana Nikhom',2,7),(99,'1603','โคกสำโรง   ','Khok Samrong',2,7),(100,'1604','ชัยบาดาล   ','Chai Badan',2,7),(101,'1605','ท่าวุ้ง   ','Tha Wung',2,7),(102,'1606','บ้านหมี่   ','Ban Mi',2,7),(103,'1607','ท่าหลวง   ','Tha Luang',2,7),(104,'1608','สระโบสถ์   ','Sa Bot',2,7),(105,'1609','โคกเจริญ   ','Khok Charoen',2,7),(106,'1610','ลำสนธิ   ','Lam Sonthi',2,7),(107,'1611','หนองม่วง   ','Nong Muang',2,7),(108,'1681','*อ.บ้านเช่า  จ.ลพบุรี   ','*Amphoe Ban Chao',2,7),(109,'1701','เมืองสิงห์บุรี   ','Mueang Sing Buri',2,8),(110,'1702','บางระจัน   ','Bang Rachan',2,8),(111,'1703','ค่ายบางระจัน   ','Khai Bang Rachan',2,8),(112,'1704','พรหมบุรี   ','Phrom Buri',2,8),(113,'1705','ท่าช้าง   ','Tha Chang',2,8),(114,'1706','อินทร์บุรี   ','In Buri',2,8),(115,'1801','เมืองชัยนาท   ','Mueang Chai Nat',2,9),(116,'1802','มโนรมย์   ','Manorom',2,9),(117,'1803','วัดสิงห์   ','Wat Sing',2,9),(118,'1804','สรรพยา   ','Sapphaya',2,9),(119,'1805','สรรคบุรี   ','Sankhaburi',2,9),(120,'1806','หันคา   ','Hankha',2,9),(121,'1807','หนองมะโมง   ','Nong Mamong',2,9),(122,'1808','เนินขาม   ','Noen Kham',2,9),(123,'1901','เมืองสระบุรี   ','Mueang Saraburi',2,10),(124,'1902','แก่งคอย   ','Kaeng Khoi',2,10),(125,'1903','หนองแค   ','Nong Khae',2,10),(126,'1904','วิหารแดง   ','Wihan Daeng',2,10),(127,'1905','หนองแซง   ','Nong Saeng',2,10),(128,'1906','บ้านหมอ   ','Ban Mo',2,10),(129,'1907','ดอนพุด   ','Don Phut',2,10),(130,'1908','หนองโดน   ','Nong Don',2,10),(131,'1909','พระพุทธบาท   ','Phra Phutthabat',2,10),(132,'1910','เสาไห้   ','Sao Hai',2,10),(133,'1911','มวกเหล็ก   ','Muak Lek',2,10),(134,'1912','วังม่วง   ','Wang Muang',2,10),(135,'1913','เฉลิมพระเกียรติ   ','Chaloem Phra Kiat',2,10),(136,'2001','เมืองชลบุรี   ','Mueang Chon Buri',5,11),(137,'2002','บ้านบึง   ','Ban Bueng',5,11),(138,'2003','หนองใหญ่   ','Nong Yai',5,11),(139,'2004','บางละมุง   ','Bang Lamung',5,11),(140,'2005','พานทอง   ','Phan Thong',5,11),(141,'2006','พนัสนิคม   ','Phanat Nikhom',5,11),(142,'2007','ศรีราชา   ','Si Racha',5,11),(143,'2008','เกาะสีชัง   ','Ko Sichang',5,11),(144,'2009','สัตหีบ   ','Sattahip',5,11),(145,'2010','บ่อทอง   ','Bo Thong',5,11),(146,'2011','เกาะจันทร์   ','Ko Chan',5,11),(147,'2051','สัตหีบ (สาขาตำบลบางเสร่)*   ','Sattahip(Bang Sre)*',5,11),(148,'2072','ท้องถิ่นเทศบาลเมืองหนองปรือ*   ','Tong Tin Tetsaban Mueang Nong Prue*',5,11),(149,'2093','เทศบาลตำบลแหลมฉบัง*   ','Tetsaban Tambon Lamsabang*',5,11),(150,'2099','เทศบาลเมืองชลบุรี*   ','Mueang Chon Buri',5,11),(151,'2101','เมืองระยอง   ','Mueang Rayong',5,12),(152,'2102','บ้านฉาง   ','Ban Chang',5,12),(153,'2103','แกลง   ','Klaeng',5,12),(154,'2104','วังจันทร์   ','Wang Chan',5,12),(155,'2105','บ้านค่าย   ','Ban Khai',5,12),(156,'2106','ปลวกแดง   ','Pluak Daeng',5,12),(157,'2107','เขาชะเมา   ','Khao Chamao',5,12),(158,'2108','นิคมพัฒนา   ','Nikhom Phatthana',5,12),(159,'2151','สาขาตำบลมาบข่า*   ','Saka Tambon Mabka',5,12),(160,'2201','เมืองจันทบุรี   ','Mueang Chanthaburi',5,13),(161,'2202','ขลุง   ','Khlung',5,13),(162,'2203','ท่าใหม่   ','Tha Mai',5,13),(163,'2204','โป่งน้ำร้อน   ','Pong Nam Ron',5,13),(164,'2205','มะขาม   ','Makham',5,13),(165,'2206','แหลมสิงห์   ','Laem Sing',5,13),(166,'2207','สอยดาว   ','Soi Dao',5,13),(167,'2208','แก่งหางแมว   ','Kaeng Hang Maeo',5,13),(168,'2209','นายายอาม   ','Na Yai Am',5,13),(169,'2210','เขาคิชฌกูฏ   ','Khoa Khitchakut',5,13),(170,'2281','*กิ่ง อ.กำพุธ  จ.จันทบุรี   ','*King Amphoe Kampud',5,13),(171,'2301','เมืองตราด   ','Mueang Trat',5,14),(172,'2302','คลองใหญ่   ','Khlong Yai',5,14),(173,'2303','เขาสมิง   ','Khao Saming',5,14),(174,'2304','บ่อไร่   ','Bo Rai',5,14),(175,'2305','แหลมงอบ   ','Laem Ngop',5,14),(176,'2306','เกาะกูด   ','Ko Kut',5,14),(177,'2307','เกาะช้าง   ','Ko Chang',5,14),(178,'2401','เมืองฉะเชิงเทรา   ','Mueang Chachoengsao',5,15),(179,'2402','บางคล้า   ','Bang Khla',5,15),(180,'2403','บางน้ำเปรี้ยว   ','Bang Nam Priao',5,15),(181,'2404','บางปะกง   ','Bang Pakong',5,15),(182,'2405','บ้านโพธิ์   ','Ban Pho',5,15),(183,'2406','พนมสารคาม   ','Phanom Sarakham',5,15),(184,'2407','ราชสาส์น   ','Ratchasan',5,15),(185,'2408','สนามชัยเขต   ','Sanam Chai Khet',5,15),(186,'2409','แปลงยาว   ','Plaeng Yao',5,15),(187,'2410','ท่าตะเกียบ   ','Tha Takiap',5,15),(188,'2411','คลองเขื่อน   ','Khlong Khuean',5,15),(189,'2501','เมืองปราจีนบุรี   ','Mueang Prachin Buri',5,16),(190,'2502','กบินทร์บุรี   ','Kabin Buri',5,16),(191,'2503','นาดี   ','Na Di',5,16),(192,'2504','*สระแก้ว   ','Sa Kaeo',5,16),(193,'2505','*วังน้ำเย็น   ','Wang Nam Yen',5,16),(194,'2506','บ้านสร้าง   ','Ban Sang',5,16),(195,'2507','ประจันตคาม   ','Prachantakham',5,16),(196,'2508','ศรีมหาโพธิ   ','Si Maha Phot',5,16),(197,'2509','ศรีมโหสถ   ','Si Mahosot',5,16),(198,'2510','*อรัญประเทศ   ','Aranyaprathet',5,16),(199,'2511','*ตาพระยา   ','Ta Phraya',5,16),(200,'2512','*วัฒนานคร   ','Watthana Nakhon',5,16),(201,'2513','*คลองหาด   ','Khlong Hat',5,16),(202,'2601','เมืองนครนายก   ','Mueang Nakhon Nayok',2,17),(203,'2602','ปากพลี   ','Pak Phli',2,17),(204,'2603','บ้านนา   ','Ban Na',2,17),(205,'2604','องครักษ์   ','Ongkharak',2,17),(206,'2701','เมืองสระแก้ว   ','Mueang Sa Kaeo',5,18),(207,'2702','คลองหาด   ','Khlong Hat',5,18),(208,'2703','ตาพระยา   ','Ta Phraya',5,18),(209,'2704','วังน้ำเย็น   ','Wang Nam Yen',5,18),(210,'2705','วัฒนานคร   ','Watthana Nakhon',5,18),(211,'2706','อรัญประเทศ   ','Aranyaprathet',5,18),(212,'2707','เขาฉกรรจ์   ','Khao Chakan',5,18),(213,'2708','โคกสูง   ','Khok Sung',5,18),(214,'2709','วังสมบูรณ์   ','Wang Sombun',5,18),(215,'3001','เมืองนครราชสีมา   ','Mueang Nakhon Ratchasima',3,19),(216,'3002','ครบุรี   ','Khon Buri',3,19),(217,'3003','เสิงสาง   ','Soeng Sang',3,19),(218,'3004','คง   ','Khong',3,19),(219,'3005','บ้านเหลื่อม   ','Ban Lueam',3,19),(220,'3006','จักราช   ','Chakkarat',3,19),(221,'3007','โชคชัย   ','Chok Chai',3,19),(222,'3008','ด่านขุนทด   ','Dan Khun Thot',3,19),(223,'3009','โนนไทย   ','Non Thai',3,19),(224,'3010','โนนสูง   ','Non Sung',3,19),(225,'3011','ขามสะแกแสง   ','Kham Sakaesaeng',3,19),(226,'3012','บัวใหญ่   ','Bua Yai',3,19),(227,'3013','ประทาย   ','Prathai',3,19),(228,'3014','ปักธงชัย   ','Pak Thong Chai',3,19),(229,'3015','พิมาย   ','Phimai',3,19),(230,'3016','ห้วยแถลง   ','Huai Thalaeng',3,19),(231,'3017','ชุมพวง   ','Chum Phuang',3,19),(232,'3018','สูงเนิน   ','Sung Noen',3,19),(233,'3019','ขามทะเลสอ   ','Kham Thale So',3,19),(234,'3020','สีคิ้ว   ','Sikhio',3,19),(235,'3021','ปากช่อง   ','Pak Chong',3,19),(236,'3022','หนองบุญมาก   ','Nong Bunnak',3,19),(237,'3023','แก้งสนามนาง   ','Kaeng Sanam Nang',3,19),(238,'3024','โนนแดง   ','Non Daeng',3,19),(239,'3025','วังน้ำเขียว   ','Wang Nam Khiao',3,19),(240,'3026','เทพารักษ์   ','Thepharak',3,19),(241,'3027','เมืองยาง   ','Mueang Yang',3,19),(242,'3028','พระทองคำ   ','Phra Thong Kham',3,19),(243,'3029','ลำทะเมนชัย   ','Lam Thamenchai',3,19),(244,'3030','บัวลาย   ','Bua Lai',3,19),(245,'3031','สีดา   ','Sida',3,19),(246,'3032','เฉลิมพระเกียรติ   ','Chaloem Phra Kiat',3,19),(247,'3049','ท้องถิ่นเทศบาลตำบลโพธิ์กลาง*   ','Pho Krang',3,19),(248,'3051','สาขาตำบลมะค่า-พลสงคราม*   ','Ma Ka-Pon Songkram*',3,19),(249,'3081','*โนนลาว   ','*Non Lao',3,19),(250,'3101','เมืองบุรีรัมย์   ','Mueang Buri Ram',3,20),(251,'3102','คูเมือง   ','Khu Mueang',3,20),(252,'3103','กระสัง','Krasang',3,20),(253,'3104','นางรอง   ','Nang Rong',3,20),(254,'3105','หนองกี่   ','Nong Ki',3,20),(255,'3106','ละหานทราย   ','Lahan Sai',3,20),(256,'3107','ประโคนชัย   ','Prakhon Chai',3,20),(257,'3108','บ้านกรวด   ','Ban Kruat',3,20),(258,'3109','พุทไธสง   ','Phutthaisong',3,20),(259,'3110','ลำปลายมาศ   ','Lam Plai Mat',3,20),(260,'3111','สตึก   ','Satuek',3,20),(261,'3112','ปะคำ   ','Pakham',3,20),(262,'3113','นาโพธิ์   ','Na Pho',3,20),(263,'3114','หนองหงส์   ','Nong Hong',3,20),(264,'3115','พลับพลาชัย   ','Phlapphla Chai',3,20),(265,'3116','ห้วยราช   ','Huai Rat',3,20),(266,'3117','โนนสุวรรณ   ','Non Suwan',3,20),(267,'3118','ชำนิ   ','Chamni',3,20),(268,'3119','บ้านใหม่ไชยพจน์   ','Ban Mai Chaiyaphot',3,20),(269,'3120','โนนดินแดง   ','Din Daeng',3,20),(270,'3121','บ้านด่าน   ','Ban Dan',3,20),(271,'3122','แคนดง   ','Khaen Dong',3,20),(272,'3123','เฉลิมพระเกียรติ   ','Chaloem Phra Kiat',3,20),(273,'3201','เมืองสุรินทร์   ','Mueang Surin',3,21),(274,'3202','ชุมพลบุรี   ','Chumphon Buri',3,21),(275,'3203','ท่าตูม   ','Tha Tum',3,21),(276,'3204','จอมพระ   ','Chom Phra',3,21),(277,'3205','ปราสาท   ','Prasat',3,21),(278,'3206','กาบเชิง   ','Kap Choeng',3,21),(279,'3207','รัตนบุรี   ','Rattanaburi',3,21),(280,'3208','สนม   ','Sanom',3,21),(281,'3209','ศีขรภูมิ   ','Sikhoraphum',3,21),(282,'3210','สังขะ   ','Sangkha',3,21),(283,'3211','ลำดวน   ','Lamduan',3,21),(284,'3212','สำโรงทาบ   ','Samrong Thap',3,21),(285,'3213','บัวเชด   ','Buachet',3,21),(286,'3214','พนมดงรัก   ','Phanom Dong Rak',3,21),(287,'3215','ศรีณรงค์   ','Si Narong',3,21),(288,'3216','เขวาสินรินทร์   ','Khwao Sinarin',3,21),(289,'3217','โนนนารายณ์   ','Non Narai',3,21),(290,'3301','เมืองศรีสะเกษ   ','Mueang Si Sa Ket',3,22),(291,'3302','ยางชุมน้อย   ','Yang Chum Noi',3,22),(292,'3303','กันทรารมย์   ','Kanthararom',3,22),(293,'3304','กันทรลักษ์   ','Kantharalak',3,22),(294,'3305','ขุขันธ์   ','Khukhan',3,22),(295,'3306','ไพรบึง   ','Phrai Bueng',3,22),(296,'3307','ปรางค์กู่   ','Prang Ku',3,22),(297,'3308','ขุนหาญ   ','Khun Han',3,22),(298,'3309','ราษีไศล   ','Rasi Salai',3,22),(299,'3310','อุทุมพรพิสัย   ','Uthumphon Phisai',3,22),(300,'3311','บึงบูรพ์   ','Bueng Bun',3,22),(301,'3312','ห้วยทับทัน   ','Huai Thap Than',3,22),(302,'3313','โนนคูณ   ','Non Khun',3,22),(303,'3314','ศรีรัตนะ   ','Si Rattana',3,22),(304,'3315','น้ำเกลี้ยง   ','Si Rattana',3,22),(305,'3316','วังหิน   ','Wang Hin',3,22),(306,'3317','ภูสิงห์   ','Phu Sing',3,22),(307,'3318','เมืองจันทร์   ','Mueang Chan',3,22),(308,'3319','เบญจลักษ์   ','Benchalak',3,22),(309,'3320','พยุห์   ','Phayu',3,22),(310,'3321','โพธิ์ศรีสุวรรณ   ','Pho Si Suwan',3,22),(311,'3322','ศิลาลาด   ','Sila Lat',3,22),(312,'3401','เมืองอุบลราชธานี   ','Mueang Ubon Ratchathani',3,23),(313,'3402','ศรีเมืองใหม่   ','Si Mueang Mai',3,23),(314,'3403','โขงเจียม   ','Khong Chiam',3,23),(315,'3404','เขื่องใน   ','Khueang Nai',3,23),(316,'3405','เขมราฐ   ','Khemarat',3,23),(317,'3406','*ชานุมาน   ','*Shanuman',3,23),(318,'3407','เดชอุดม   ','Det Udom',3,23),(319,'3408','นาจะหลวย   ','Na Chaluai',3,23),(320,'3409','น้ำยืน   ','Nam Yuen',3,23),(321,'3410','บุณฑริก   ','Buntharik',3,23),(322,'3411','ตระการพืชผล   ','Trakan Phuet Phon',3,23),(323,'3412','กุดข้าวปุ้น   ','Kut Khaopun',3,23),(324,'3413','*พนา   ','*Phana',3,23),(325,'3414','ม่วงสามสิบ   ','Muang Sam Sip',3,23),(326,'3415','วารินชำราบ   ','Warin Chamrap',3,23),(327,'3416','*อำนาจเจริญ   ','*Amnat Charoen',3,23),(328,'3417','*เสนางคนิคม   ','*Senangkhanikhom',3,23),(329,'3418','*หัวตะพาน   ','*Hua Taphan',3,23),(330,'3419','พิบูลมังสาหาร   ','Phibun Mangsahan',3,23),(331,'3420','ตาลสุม   ','Tan Sum',3,23),(332,'3421','โพธิ์ไทร   ','Pho Sai',3,23),(333,'3422','สำโรง   ','Samrong',3,23),(334,'3423','*กิ่งอำเภอลืออำนาจ   ','*King Amphoe Lue Amnat',3,23),(335,'3424','ดอนมดแดง   ','Don Mot Daeng',3,23),(336,'3425','สิรินธร   ','Sirindhorn',3,23),(337,'3426','ทุ่งศรีอุดม   ','Thung Si Udom',3,23),(338,'3427','*ปทุมราชวงศา   ','*Pathum Ratchawongsa',3,23),(339,'3428','*กิ่งอำเภอศรีหลักชัย   ','*King Amphoe Sri Lunk Chai',3,23),(340,'3429','นาเยีย   ','Na Yia',3,23),(341,'3430','นาตาล   ','Na Tan',3,23),(342,'3431','เหล่าเสือโก้ก   ','Lao Suea Kok',3,23),(343,'3432','สว่างวีระวงศ์   ','Sawang Wirawong',3,23),(344,'3433','น้ำขุ่น   ','Nam Khun',3,23),(345,'3481','*อ.สุวรรณวารี  จ.อุบลราชธานี   ','*Suwan Wari',3,23),(346,'3501','เมืองยโสธร   ','Mueang Yasothon',3,24),(347,'3502','ทรายมูล   ','Sai Mun',3,24),(348,'3503','กุดชุม   ','Kut Chum',3,24),(349,'3504','คำเขื่อนแก้ว   ','Kham Khuean Kaeo',3,24),(350,'3505','ป่าติ้ว   ','Pa Tio',3,24),(351,'3506','มหาชนะชัย   ','Maha Chana Chai',3,24),(352,'3507','ค้อวัง   ','Kho Wang',3,24),(353,'3508','เลิงนกทา   ','Loeng Nok Tha',3,24),(354,'3509','ไทยเจริญ   ','Thai Charoen',3,24),(355,'3601','เมืองชัยภูมิ   ','Mueang Chaiyaphum',3,25),(356,'3602','บ้านเขว้า   ','Ban Khwao',3,25),(357,'3603','คอนสวรรค์   ','Khon Sawan',3,25),(358,'3604','เกษตรสมบูรณ์   ','Kaset Sombun',3,25),(359,'3605','หนองบัวแดง   ','Nong Bua Daeng',3,25),(360,'3606','จัตุรัส   ','Chatturat',3,25),(361,'3607','บำเหน็จณรงค์   ','Bamnet Narong',3,25),(362,'3608','หนองบัวระเหว   ','Nong Bua Rawe',3,25),(363,'3609','เทพสถิต   ','Thep Sathit',3,25),(364,'3610','ภูเขียว   ','Phu Khiao',3,25),(365,'3611','บ้านแท่น   ','Ban Thaen',3,25),(366,'3612','แก้งคร้อ   ','Kaeng Khro',3,25),(367,'3613','คอนสาร   ','Khon San',3,25),(368,'3614','ภักดีชุมพล   ','Phakdi Chumphon',3,25),(369,'3615','เนินสง่า   ','Noen Sa-nga',3,25),(370,'3616','ซับใหญ่   ','Sap Yai',3,25),(371,'3651','เมืองชัยภูมิ (สาขาตำบลโนนสำราญ)*   ','Mueang Chaiyaphum(Non Sumran)*',3,25),(372,'3652','สาขาตำบลบ้านหว่าเฒ่า*   ','Ban Wha Tao*',3,25),(373,'3653','หนองบัวแดง (สาขาตำบลวังชมภู)*   ','Nong Bua Daeng',3,25),(374,'3654','กิ่งอำเภอซับใหญ่ (สาขาตำบลซับใหญ่)*   ','King Amphoe Sap Yai*',3,25),(375,'3655','สาขาตำบลโคกเพชร*   ','Coke Phet*',3,25),(376,'3656','เทพสถิต (สาขาตำบลนายางกลัก)*   ','Thep Sathit*',3,25),(377,'3657','บ้านแท่น (สาขาตำบลบ้านเต่า)*   ','Ban Thaen',3,25),(378,'3658','แก้งคร้อ (สาขาตำบลท่ามะไฟหวาน)*   ','Kaeng Khro*',3,25),(379,'3659','คอนสาร (สาขาตำบลโนนคูณ)*   ','Khon San*',3,25),(380,'3701','เมืองอำนาจเจริญ   ','Mueang Amnat Charoen',3,26),(381,'3702','ชานุมาน   ','Chanuman',3,26),(382,'3703','ปทุมราชวงศา   ','Pathum Ratchawongsa',3,26),(383,'3704','พนา   ','Phana',3,26),(384,'3705','เสนางคนิคม   ','Senangkhanikhom',3,26),(385,'3706','หัวตะพาน   ','Hua Taphan',3,26),(386,'3707','ลืออำนาจ   ','Lue Amnat',3,26),(387,'3901','เมืองหนองบัวลำภู   ','Mueang Nong Bua Lam Phu',3,27),(388,'3902','นากลาง   ','Na Klang',3,27),(389,'3903','โนนสัง   ','Non Sang',3,27),(390,'3904','ศรีบุญเรือง   ','Si Bun Rueang',3,27),(391,'3905','สุวรรณคูหา   ','Suwannakhuha',3,27),(392,'3906','นาวัง   ','Na Wang',3,27),(393,'4001','เมืองขอนแก่น   ','Mueang Khon Kaen',3,28),(394,'4002','บ้านฝาง   ','Ban Fang',3,28),(395,'4003','พระยืน   ','Phra Yuen',3,28),(396,'4004','หนองเรือ   ','Nong Ruea',3,28),(397,'4005','ชุมแพ   ','Chum Phae',3,28),(398,'4006','สีชมพู   ','Si Chomphu',3,28),(399,'4007','น้ำพอง   ','Nam Phong',3,28),(400,'4008','อุบลรัตน์   ','Ubolratana',3,28),(401,'4009','กระนวน   ','Kranuan',3,28),(402,'4010','บ้านไผ่   ','Ban Phai',3,28),(403,'4011','เปือยน้อย   ','Pueai Noi',3,28),(404,'4012','พล   ','Phon',3,28),(405,'4013','แวงใหญ่   ','Waeng Yai',3,28),(406,'4014','แวงน้อย   ','Waeng Noi',3,28),(407,'4015','หนองสองห้อง   ','Nong Song Hong',3,28),(408,'4016','ภูเวียง   ','Phu Wiang',3,28),(409,'4017','มัญจาคีรี   ','Mancha Khiri',3,28),(410,'4018','ชนบท   ','Chonnabot',3,28),(411,'4019','เขาสวนกวาง   ','Khao Suan Kwang',3,28),(412,'4020','ภูผาม่าน   ','Phu Pha Man',3,28),(413,'4021','ซำสูง   ','Sam Sung',3,28),(414,'4022','โคกโพธิ์ไชย   ','Khok Pho Chai',3,28),(415,'4023','หนองนาคำ   ','Nong Na Kham',3,28),(416,'4024','บ้านแฮด   ','Ban Haet',3,28),(417,'4025','โนนศิลา   ','Non Sila',3,28),(418,'4029','เวียงเก่า   ','Wiang Kao',3,28),(419,'4068','ท้องถิ่นเทศบาลตำบลบ้านเป็ด*   ','Ban Pet*',3,28),(420,'4098','เทศบาลตำบลเมืองพล*   ','Tet Saban Tambon Muang Phon*',3,28),(421,'4101','เมืองอุดรธานี   ','Mueang Udon Thani',3,29),(422,'4102','กุดจับ   ','Kut Chap',3,29),(423,'4103','หนองวัวซอ   ','Nong Wua So',3,29),(424,'4104','กุมภวาปี   ','Kumphawapi',3,29),(425,'4105','โนนสะอาด   ','Non Sa-at',3,29),(426,'4106','หนองหาน   ','Nong Han',3,29),(427,'4107','ทุ่งฝน   ','Thung Fon',3,29),(428,'4108','ไชยวาน   ','Chai Wan',3,29),(429,'4109','ศรีธาตุ   ','Si That',3,29),(430,'4110','วังสามหมอ   ','Wang Sam Mo',3,29),(431,'4111','บ้านดุง   ','Ban Dung',3,29),(432,'4112','*หนองบัวลำภู   ','*Nong Bua Lam Phu',3,29),(433,'4113','*ศรีบุญเรือง   ','*Si Bun Rueang',3,29),(434,'4114','*นากลาง   ','*Na Klang',3,29),(435,'4115','*สุวรรณคูหา   ','*Suwannakhuha',3,29),(436,'4116','*โนนสัง   ','*Non Sang',3,29),(437,'4117','บ้านผือ   ','Ban Phue',3,29),(438,'4118','น้ำโสม   ','Nam Som',3,29),(439,'4119','เพ็ญ   ','Phen',3,29),(440,'4120','สร้างคอม   ','Sang Khom',3,29),(441,'4121','หนองแสง   ','Nong Saeng',3,29),(442,'4122','นายูง   ','Na Yung',3,29),(443,'4123','พิบูลย์รักษ์   ','Phibun Rak',3,29),(444,'4124','กู่แก้ว   ','Ku Kaeo',3,29),(445,'4125','ประจักษ์ศิลปาคม   ','rachak-sinlapakhom',3,29),(446,'4201','เมืองเลย   ','Mueang Loei',3,30),(447,'4202','นาด้วง   ','Na Duang',3,30),(448,'4203','เชียงคาน   ','Chiang Khan',3,30),(449,'4204','ปากชม   ','Pak Chom',3,30),(450,'4205','ด่านซ้าย   ','Dan Sai',3,30),(451,'4206','นาแห้ว   ','Na Haeo',3,30),(452,'4207','ภูเรือ   ','Phu Ruea',3,30),(453,'4208','ท่าลี่   ','Tha Li',3,30),(454,'4209','วังสะพุง   ','Wang Saphung',3,30),(455,'4210','ภูกระดึง   ','Phu Kradueng',3,30),(456,'4211','ภูหลวง   ','Phu Luang',3,30),(457,'4212','ผาขาว   ','Pha Khao',3,30),(458,'4213','เอราวัณ   ','Erawan',3,30),(459,'4214','หนองหิน   ','Nong Hin',3,30),(460,'4301','เมืองหนองคาย   ','Mueang Nong Khai',3,31),(461,'4302','ท่าบ่อ   ','Tha Bo',3,31),(462,'4303','เมืองบึงกาฬ   ','Mueang Bueng Kan',3,97),(463,'4304','พรเจริญ   ','Phon Charoen',3,97),(464,'4305','โพนพิสัย   ','Phon Phisai',3,31),(465,'4306','โซ่พิสัย   ','So Phisai',3,97),(466,'4307','ศรีเชียงใหม่   ','Si Chiang Mai',3,31),(467,'4308','สังคม   ','Sangkhom',3,31),(468,'4309','เซกา   ','Seka',3,97),(469,'4310','ปากคาด   ','Pak Khat',3,97),(470,'4311','บึงโขงหลง   ','Bueng Khong Long',3,97),(471,'4312','ศรีวิไล   ','Si Wilai',3,97),(472,'4313','บุ่งคล้า   ','Bung Khla',3,97),(473,'4314','สระใคร   ','Sakhrai',3,31),(474,'4315','เฝ้าไร่   ','Fao Rai',3,31),(475,'4316','รัตนวาปี   ','Rattanawapi',3,31),(476,'4317','โพธิ์ตาก   ','Pho Tak',3,31),(477,'4401','เมืองมหาสารคาม   ','Mueang Maha Sarakham',3,32),(478,'4402','แกดำ   ','Kae Dam',3,32),(479,'4403','โกสุมพิสัย   ','Kosum Phisai',3,32),(480,'4404','กันทรวิชัย   ','Kantharawichai',3,32),(481,'4405','เชียงยืน   ','Kantharawichai',3,32),(482,'4406','บรบือ   ','Borabue',3,32),(483,'4407','นาเชือก   ','Na Chueak',3,32),(484,'4408','พยัคฆภูมิพิสัย   ','Phayakkhaphum Phisai',3,32),(485,'4409','วาปีปทุม   ','Wapi Pathum',3,32),(486,'4410','นาดูน   ','Na Dun',3,32),(487,'4411','ยางสีสุราช   ','Yang Sisurat',3,32),(488,'4412','กุดรัง   ','Kut Rang',3,32),(489,'4413','ชื่นชม   ','Chuen Chom',3,32),(490,'4481','*หลุบ   ','*Lub',3,32),(491,'4501','เมืองร้อยเอ็ด   ','Mueang Roi Et',3,33),(492,'4502','เกษตรวิสัย   ','Kaset Wisai',3,33),(493,'4503','ปทุมรัตต์   ','Pathum Rat',3,33),(494,'4504','จตุรพักตรพิมาน   ','Chaturaphak Phiman',3,33),(495,'4505','ธวัชบุรี   ','Thawat Buri',3,33),(496,'4506','พนมไพร   ','Phanom Phrai',3,33),(497,'4507','โพนทอง   ','Phon Thong',3,33),(498,'4508','โพธิ์ชัย   ','Pho Chai',3,33),(499,'4509','หนองพอก   ','Nong Phok',3,33),(500,'4510','เสลภูมิ   ','Selaphum',3,33),(501,'4511','สุวรรณภูมิ   ','Suwannaphum',3,33),(502,'4512','เมืองสรวง   ','Mueang Suang',3,33),(503,'4513','โพนทราย   ','Phon Sai',3,33),(504,'4514','อาจสามารถ   ','At Samat',3,33),(505,'4515','เมยวดี   ','Moei Wadi',3,33),(506,'4516','ศรีสมเด็จ   ','Si Somdet',3,33),(507,'4517','จังหาร   ','Changhan',3,33),(508,'4518','เชียงขวัญ   ','Chiang Khwan',3,33),(509,'4519','หนองฮี   ','Nong Hi',3,33),(510,'4520','ทุ่งเขาหลวง   ','Thung Khao Luangกิ่',3,33),(511,'4601','เมืองกาฬสินธุ์   ','Mueang Kalasin',3,34),(512,'4602','นามน   ','Na Mon',3,34),(513,'4603','กมลาไสย   ','Kamalasai',3,34),(514,'4604','ร่องคำ   ','Rong Kham',3,34),(515,'4605','กุฉินารายณ์   ','Kuchinarai',3,34),(516,'4606','เขาวง   ','Khao Wong',3,34),(517,'4607','ยางตลาด   ','Yang Talat',3,34),(518,'4608','ห้วยเม็ก   ','Huai Mek',3,34),(519,'4609','สหัสขันธ์   ','Sahatsakhan',3,34),(520,'4610','คำม่วง   ','Kham Muang',3,34),(521,'4611','ท่าคันโท   ','Tha Khantho',3,34),(522,'4612','หนองกุงศรี   ','Nong Kung Si',3,34),(523,'4613','สมเด็จ   ','Somdet',3,34),(524,'4614','ห้วยผึ้ง   ','Huai Phueng',3,34),(525,'4615','สามชัย   ','Sam Chai',3,34),(526,'4616','นาคู   ','Na Khu',3,34),(527,'4617','ดอนจาน   ','Don Chan',3,34),(528,'4618','ฆ้องชัย   ','Khong Chai',3,34),(529,'4701','เมืองสกลนคร   ','Mueang Sakon Nakhon',3,35),(530,'4702','กุสุมาลย์   ','Kusuman',3,35),(531,'4703','กุดบาก   ','Kut Bak',3,35),(532,'4704','พรรณานิคม   ','Phanna Nikhom',3,35),(533,'4705','พังโคน   ','Phang Khon',3,35),(534,'4706','วาริชภูมิ   ','Waritchaphum',3,35),(535,'4707','นิคมน้ำอูน   ','Nikhom Nam Un',3,35),(536,'4708','วานรนิวาส   ','Wanon Niwat',3,35),(537,'4709','คำตากล้า   ','Kham Ta Kla',3,35),(538,'4710','บ้านม่วง   ','Ban Muang',3,35),(539,'4711','อากาศอำนวย   ','Akat Amnuai',3,35),(540,'4712','สว่างแดนดิน   ','Sawang Daen Din',3,35),(541,'4713','ส่องดาว   ','Song Dao',3,35),(542,'4714','เต่างอย   ','Tao Ngoi',3,35),(543,'4715','โคกศรีสุพรรณ   ','Khok Si Suphan',3,35),(544,'4716','เจริญศิลป์   ','Charoen Sin',3,35),(545,'4717','โพนนาแก้ว   ','Phon Na Kaeo',3,35),(546,'4718','ภูพาน   ','Phu Phan',3,35),(547,'4751','วานรนิวาส (สาขาตำบลกุดเรือคำ)*   ','Wanon Niwat',3,35),(548,'4781','*อ.บ้านหัน  จ.สกลนคร   ','*Banhan',3,35),(549,'4801','เมืองนครพนม   ','Mueang Nakhon Phanom',3,36),(550,'4802','ปลาปาก   ','Pla Pak',3,36),(551,'4803','ท่าอุเทน   ','Tha Uthen',3,36),(552,'4804','บ้านแพง   ','Ban Phaeng',3,36),(553,'4805','ธาตุพนม   ','That Phanom',3,36),(554,'4806','เรณูนคร   ','Renu Nakhon',3,36),(555,'4807','นาแก   ','Na Kae',3,36),(556,'4808','ศรีสงคราม   ','Si Songkhram',3,36),(557,'4809','นาหว้า   ','Na Wa',3,36),(558,'4810','โพนสวรรค์   ','Phon Sawan',3,36),(559,'4811','นาทม   ','Na Thom',3,36),(560,'4812','วังยาง   ','Wang Yang',3,36),(561,'4901','เมืองมุกดาหาร   ','Mueang Mukdahan',3,37),(562,'4902','นิคมคำสร้อย   ','Nikhom Kham Soi',3,37),(563,'4903','ดอนตาล   ','Don Tan',3,37),(564,'4904','ดงหลวง   ','Dong Luang',3,37),(565,'4905','คำชะอี   ','Khamcha-i',3,37),(566,'4906','หว้านใหญ่   ','Wan Yai',3,37),(567,'4907','หนองสูง   ','Nong Sung',3,37),(568,'5001','เมืองเชียงใหม่   ','Mueang Chiang Mai',1,38),(569,'5002','จอมทอง   ','Chom Thong',1,38),(570,'5003','แม่แจ่ม   ','Mae Chaem',1,38),(571,'5004','เชียงดาว   ','Chiang Dao',1,38),(572,'5005','ดอยสะเก็ด   ','Doi Saket',1,38),(573,'5006','แม่แตง   ','Mae Taeng',1,38),(574,'5007','แม่ริม   ','Mae Rim',1,38),(575,'5008','สะเมิง   ','Samoeng',1,38),(576,'5009','ฝาง   ','Fang',1,38),(577,'5010','แม่อาย   ','Mae Ai',1,38),(578,'5011','พร้าว   ','Phrao',1,38),(579,'5012','สันป่าตอง   ','San Pa Tong',1,38),(580,'5013','สันกำแพง   ','San Kamphaeng',1,38),(581,'5014','สันทราย   ','San Sai',1,38),(582,'5015','หางดง   ','Hang Dong',1,38),(583,'5016','ฮอด   ','Hot',1,38),(584,'5017','ดอยเต่า   ','Doi Tao',1,38),(585,'5018','อมก๋อย   ','Omkoi',1,38),(586,'5019','สารภี   ','Saraphi',1,38),(587,'5020','เวียงแหง   ','Wiang Haeng',1,38),(588,'5021','ไชยปราการ   ','Chai Prakan',1,38),(589,'5022','แม่วาง   ','Mae Wang',1,38),(590,'5023','แม่ออน   ','Mae On',1,38),(591,'5024','ดอยหล่อ   ','Doi Lo',1,38),(592,'5051','เทศบาลนครเชียงใหม่ (สาขาแขวงกาลวิละ)*   ','Tet Saban Nakorn Chiangmai(Kan lawi la)*',1,38),(593,'5052','เทศบาลนครเชียงใหม่ (สาขาแขวงศรีวิชั)*   ','Tet Saban Nakorn Chiangmai(Sri Wi)*',1,38),(594,'5053','เทศบาลนครเชียงใหม่ (สาขาเม็งราย)*   ','Tet Saban Nakorn Chiangmai(Meng Rai)*',1,38),(595,'5101','เมืองลำพูน   ','Mueang Lamphun',1,39),(596,'5102','แม่ทา   ','Mae Tha',1,39),(597,'5103','บ้านโฮ่ง   ','Ban Hong',1,39),(598,'5104','ลี้   ','Li',1,39),(599,'5105','ทุ่งหัวช้าง   ','Thung Hua Chang',1,39),(600,'5106','ป่าซาง   ','Pa Sang',1,39),(601,'5107','บ้านธิ   ','Ban Thi',1,39),(602,'5108','เวียงหนองล่อง   ','Wiang Nong Long',1,39),(603,'5201','เมืองลำปาง   ','Mueang Lampang',1,40),(604,'5202','แม่เมาะ   ','Mae Mo',1,40),(605,'5203','เกาะคา   ','Ko Kha',1,40),(606,'5204','เสริมงาม   ','Soem Ngam',1,40),(607,'5205','งาว   ','Ngao',1,40),(608,'5206','แจ้ห่ม   ','Chae Hom',1,40),(609,'5207','วังเหนือ   ','Wang Nuea',1,40),(610,'5208','เถิน   ','Thoen',1,40),(611,'5209','แม่พริก   ','Mae Phrik',1,40),(612,'5210','แม่ทะ   ','Mae Tha',1,40),(613,'5211','สบปราบ   ','Sop Prap',1,40),(614,'5212','ห้างฉัตร   ','Hang Chat',1,40),(615,'5213','เมืองปาน   ','Mueang Pan',1,40),(616,'5301','เมืองอุตรดิตถ์   ','Mueang Uttaradit',1,41),(617,'5302','ตรอน   ','Tron',1,41),(618,'5303','ท่าปลา   ','Tha Pla',1,41),(619,'5304','น้ำปาด   ','Nam Pat',1,41),(620,'5305','ฟากท่า   ','Fak Tha',1,41),(621,'5306','บ้านโคก   ','Ban Khok',1,41),(622,'5307','พิชัย   ','Phichai',1,41),(623,'5308','ลับแล   ','Laplae',1,41),(624,'5309','ทองแสนขัน   ','Thong Saen Khan',1,41),(625,'5401','เมืองแพร่   ','Mueang Phrae',1,42),(626,'5402','ร้องกวาง   ','Rong Kwang',1,42),(627,'5403','ลอง   ','Long',1,42),(628,'5404','สูงเม่น   ','Sung Men',1,42),(629,'5405','เด่นชัย   ','Den Chai',1,42),(630,'5406','สอง   ','Song',1,42),(631,'5407','วังชิ้น   ','Wang Chin',1,42),(632,'5408','หนองม่วงไข่   ','Nong Muang Khai',1,42),(633,'5501','เมืองน่าน   ','Mueang Nan',1,43),(634,'5502','แม่จริม   ','Mae Charim',1,43),(635,'5503','บ้านหลวง   ','Ban Luang',1,43),(636,'5504','นาน้อย   ','Na Noi',1,43),(637,'5505','ปัว   ','Pua',1,43),(638,'5506','ท่าวังผา   ','Tha Wang Pha',1,43),(639,'5507','เวียงสา   ','Wiang Sa',1,43),(640,'5508','ทุ่งช้าง   ','Thung Chang',1,43),(641,'5509','เชียงกลาง   ','Chiang Klang',1,43),(642,'5510','นาหมื่น   ','Na Muen',1,43),(643,'5511','สันติสุข   ','Santi Suk',1,43),(644,'5512','บ่อเกลือ   ','Bo Kluea',1,43),(645,'5513','สองแคว   ','Song Khwae',1,43),(646,'5514','ภูเพียง   ','Phu Phiang',1,43),(647,'5515','เฉลิมพระเกียรติ   ','Chaloem Phra Kiat',1,43),(648,'5601','เมืองพะเยา   ','Mueang Phayao',1,44),(649,'5602','จุน   ','Chun',1,44),(650,'5603','เชียงคำ   ','Chiang Kham',1,44),(651,'5604','เชียงม่วน   ','Chiang Muan',1,44),(652,'5605','ดอกคำใต้   ','Dok Khamtai',1,44),(653,'5606','ปง   ','Pong',1,44),(654,'5607','แม่ใจ   ','Mae Chai',1,44),(655,'5608','ภูซาง   ','Phu Sang',1,44),(656,'5609','ภูกามยาว   ','Phu Kamyao',1,44),(657,'5701','เมืองเชียงราย   ','Mueang Chiang Rai',1,45),(658,'5702','เวียงชัย   ','Wiang Chai',1,45),(659,'5703','เชียงของ   ','Chiang Khong',1,45),(660,'5704','เทิง   ','Thoeng',1,45),(661,'5705','พาน   ','Phan',1,45),(662,'5706','ป่าแดด   ','Pa Daet',1,45),(663,'5707','แม่จัน   ','Mae Chan',1,45),(664,'5708','เชียงแสน   ','Chiang Saen',1,45),(665,'5709','แม่สาย   ','Mae Sai',1,45),(666,'5710','แม่สรวย   ','Mae Suai',1,45),(667,'5711','เวียงป่าเป้า   ','Wiang Pa Pao',1,45),(668,'5712','พญาเม็งราย   ','Phaya Mengrai',1,45),(669,'5713','เวียงแก่น   ','Wiang Kaen',1,45),(670,'5714','ขุนตาล   ','Khun Tan',1,45),(671,'5715','แม่ฟ้าหลวง   ','Mae Fa Luang',1,45),(672,'5716','แม่ลาว   ','Mae Lao',1,45),(673,'5717','เวียงเชียงรุ้ง   ','Wiang Chiang Rung',1,45),(674,'5718','ดอยหลวง   ','Doi Luang',1,45),(675,'5801','เมืองแม่ฮ่องสอน   ','Mueang Mae Hong Son',1,46),(676,'5802','ขุนยวม   ','Khun Yuam',1,46),(677,'5803','ปาย   ','Pai',1,46),(678,'5804','แม่สะเรียง   ','Mae Sariang',1,46),(679,'5805','แม่ลาน้อย   ','Mae La Noi',1,46),(680,'5806','สบเมย   ','Sop Moei',1,46),(681,'5807','ปางมะผ้า   ','Pang Mapha',1,46),(682,'5881','*อ.ม่วยต่อ  จ.แม่ฮ่องสอน   ','Muen Tor',1,46),(683,'6001','เมืองนครสวรรค์   ','Mueang Nakhon Sawan',2,47),(684,'6002','โกรกพระ   ','Krok Phra',2,47),(685,'6003','ชุมแสง   ','Chum Saeng',2,47),(686,'6004','หนองบัว   ','Nong Bua',2,47),(687,'6005','บรรพตพิสัย   ','Banphot Phisai',2,47),(688,'6006','เก้าเลี้ยว   ','Kao Liao',2,47),(689,'6007','ตาคลี   ','Takhli',2,47),(690,'6008','ท่าตะโก   ','Takhli',2,47),(691,'6009','ไพศาลี   ','Phaisali',2,47),(692,'6010','พยุหะคีรี   ','Phayuha Khiri',2,47),(693,'6011','ลาดยาว   ','Phayuha Khiri',2,47),(694,'6012','ตากฟ้า   ','Tak Fa',2,47),(695,'6013','แม่วงก์   ','Mae Wong',2,47),(696,'6014','แม่เปิน   ','Mae Poen',2,47),(697,'6015','ชุมตาบง   ','Chum Ta Bong',2,47),(698,'6051','สาขาตำบลห้วยน้ำหอม*   ','Huen Nam Hom',2,47),(699,'6052','กิ่งอำเภอชุมตาบง (สาขาตำบลชุมตาบง)*   ','Chum Ta Bong',2,47),(700,'6053','แม่วงก์ (สาขาตำบลแม่เล่ย์)*   ','Mea Ley',2,47),(701,'6101','เมืองอุทัยธานี   ','Mueang Uthai Thani',2,48),(702,'6102','ทัพทัน   ','Thap Than',2,48),(703,'6103','สว่างอารมณ์   ','Sawang Arom',2,48),(704,'6104','หนองฉาง   ','Nong Chang',2,48),(705,'6105','หนองขาหย่าง   ','Nong Khayang',2,48),(706,'6106','บ้านไร่   ','Ban Rai',2,48),(707,'6107','ลานสัก   ','Lan Sak',2,48),(708,'6108','ห้วยคต   ','Huai Khot',2,48),(709,'6201','เมืองกำแพงเพชร   ','Mueang Kamphaeng Phet',2,49),(710,'6202','ไทรงาม   ','Sai Ngam',2,49),(711,'6203','คลองลาน   ','Khlong Lan',2,49),(712,'6204','ขาณุวรลักษบุรี   ','Khanu Woralaksaburi',2,49),(713,'6205','คลองขลุง   ','Khlong Khlung',2,49),(714,'6206','พรานกระต่าย   ','Phran Kratai',2,49),(715,'6207','ลานกระบือ   ','Lan Krabue',2,49),(716,'6208','ทรายทองวัฒนา   ','Sai Thong Watthana',2,49),(717,'6209','ปางศิลาทอง   ','Pang Sila Thong',2,49),(718,'6210','บึงสามัคคี   ','Bueng Samakkhi',2,49),(719,'6211','โกสัมพีนคร   ','Kosamphi Nakhon',2,49),(720,'6301','เมืองตาก   ','Mueang Tak',4,50),(721,'6302','บ้านตาก   ','Ban Tak',4,50),(722,'6303','สามเงา   ','Sam Ngao',4,50),(723,'6304','แม่ระมาด   ','Mae Ramat',4,50),(724,'6305','ท่าสองยาง   ','Tha Song Yang',4,50),(725,'6306','แม่สอด   ','Mae Sot',4,50),(726,'6307','พบพระ   ','Phop Phra',4,50),(727,'6308','อุ้มผาง   ','Umphang',4,50),(728,'6309','วังเจ้า   ','Wang Chao',4,50),(729,'6381','*กิ่ง อ.ท่าปุย  จ.ตาก   ','*King Ta Pui',4,50),(730,'6401','เมืองสุโขทัย   ','Mueang Sukhothai',2,51),(731,'6402','บ้านด่านลานหอย   ','Ban Dan Lan Hoi',2,51),(732,'6403','คีรีมาศ   ','Khiri Mat',2,51),(733,'6404','กงไกรลาศ   ','Kong Krailat',2,51),(734,'6405','ศรีสัชนาลัย   ','Si Satchanalai',2,51),(735,'6406','ศรีสำโรง   ','Si Samrong',2,51),(736,'6407','สวรรคโลก   ','Sawankhalok',2,51),(737,'6408','ศรีนคร   ','Si Nakhon',2,51),(738,'6409','ทุ่งเสลี่ยม   ','Thung Saliam',2,51),(739,'6501','เมืองพิษณุโลก   ','Mueang Phitsanulok',2,52),(740,'6502','นครไทย   ','Nakhon Thai',2,52),(741,'6503','ชาติตระการ   ','Chat Trakan',2,52),(742,'6504','บางระกำ   ','Bang Rakam',2,52),(743,'6505','บางกระทุ่ม   ','Bang Krathum',2,52),(744,'6506','พรหมพิราม   ','Phrom Phiram',2,52),(745,'6507','วัดโบสถ์   ','Wat Bot',2,52),(746,'6508','วังทอง   ','Wang Thong',2,52),(747,'6509','เนินมะปราง   ','Noen Maprang',2,52),(748,'6601','เมืองพิจิตร   ','Mueang Phichit',2,53),(749,'6602','วังทรายพูน   ','Wang Sai Phun',2,53),(750,'6603','โพธิ์ประทับช้าง   ','Pho Prathap Chang',2,53),(751,'6604','ตะพานหิน   ','Taphan Hin',2,53),(752,'6605','บางมูลนาก   ','Bang Mun Nak',2,53),(753,'6606','โพทะเล   ','Pho Thale',2,53),(754,'6607','สามง่าม   ','Sam Ngam',2,53),(755,'6608','ทับคล้อ   ','Tap Khlo',2,53),(756,'6609','สากเหล็ก   ','Sak Lek',2,53),(757,'6610','บึงนาราง   ','Bueng Na Rang',2,53),(758,'6611','ดงเจริญ   ','Dong Charoen',2,53),(759,'6612','วชิรบารมี   ','Wachirabarami',2,53),(760,'6701','เมืองเพชรบูรณ์   ','Mueang Phetchabun',2,54),(761,'6702','ชนแดน   ','Chon Daen',2,54),(762,'6703','หล่มสัก   ','Lom Sak',2,54),(763,'6704','หล่มเก่า   ','Lom Kao',2,54),(764,'6705','วิเชียรบุรี   ','Wichian Buri',2,54),(765,'6706','ศรีเทพ   ','Si Thep',2,54),(766,'6707','หนองไผ่   ','Nong Phai',2,54),(767,'6708','บึงสามพัน   ','Bueng Sam Phan',2,54),(768,'6709','น้ำหนาว   ','Nam Nao',2,54),(769,'6710','วังโป่ง   ','Wang Pong',2,54),(770,'6711','เขาค้อ   ','Khao Kho',2,54),(771,'7001','เมืองราชบุรี   ','Mueang Ratchaburi',4,55),(772,'7002','จอมบึง   ','Chom Bueng',4,55),(773,'7003','สวนผึ้ง   ','Suan Phueng',4,55),(774,'7004','ดำเนินสะดวก   ','Damnoen Saduak',4,55),(775,'7005','บ้านโป่ง   ','Ban Pong',4,55),(776,'7006','บางแพ   ','Bang Phae',4,55),(777,'7007','โพธาราม   ','Photharam',4,55),(778,'7008','ปากท่อ   ','Pak Tho',4,55),(779,'7009','วัดเพลง   ','Wat Phleng',4,55),(780,'7010','บ้านคา   ','Ban Kha',4,55),(781,'7074','ท้องถิ่นเทศบาลตำบลบ้านฆ้อง   ','Tet Saban Ban Kong',4,55),(782,'7101','เมืองกาญจนบุรี   ','Mueang Kanchanaburi',4,56),(783,'7102','ไทรโยค   ','Sai Yok',4,56),(784,'7103','บ่อพลอย   ','Bo Phloi',4,56),(785,'7104','ศรีสวัสดิ์   ','Si Sawat',4,56),(786,'7105','ท่ามะกา   ','Tha Maka',4,56),(787,'7106','ท่าม่วง   ','Tha Muang',4,56),(788,'7107','ทองผาภูมิ   ','Pha Phum',4,56),(789,'7108','สังขละบุรี   ','Sangkhla Buri',4,56),(790,'7109','พนมทวน   ','Phanom Thuan',4,56),(791,'7110','เลาขวัญ   ','Lao Khwan',4,56),(792,'7111','ด่านมะขามเตี้ย   ','Dan Makham Tia',4,56),(793,'7112','หนองปรือ   ','Nong Prue',4,56),(794,'7113','ห้วยกระเจา   ','Huai Krachao',4,56),(795,'7151','สาขาตำบลท่ากระดาน*   ','Tha Kra Dan',4,56),(796,'7181','*บ้านทวน  จ.กาญจนบุรี   ','*Ban Tuan',4,56),(797,'7201','เมืองสุพรรณบุรี   ','Mueang Suphan Buri',2,57),(798,'7202','เดิมบางนางบวช   ','Doem Bang Nang Buat',2,57),(799,'7203','ด่านช้าง   ','Dan Chang',2,57),(800,'7204','บางปลาม้า   ','Bang Pla Ma',2,57),(801,'7205','ศรีประจันต์   ','Si Prachan',2,57),(802,'7206','ดอนเจดีย์   ','Don Chedi',2,57),(803,'7207','สองพี่น้อง   ','Song Phi Nong',2,57),(804,'7208','สามชุก   ','Sam Chuk',2,57),(805,'7209','อู่ทอง   ','U Thong',2,57),(806,'7210','หนองหญ้าไซ   ','Nong Ya Sai',2,57),(807,'7301','เมืองนครปฐม   ','Mueang Nakhon Pathom',2,58),(808,'7302','กำแพงแสน   ','Kamphaeng Saen',2,58),(809,'7303','นครชัยศรี   ','Nakhon Chai Si',2,58),(810,'7304','ดอนตูม   ','Don Tum',2,58),(811,'7305','บางเลน   ','Bang Len',2,58),(812,'7306','สามพราน   ','Sam Phran',2,58),(813,'7307','พุทธมณฑล   ','Phutthamonthon',2,58),(814,'7401','เมืองสมุทรสาคร   ','Mueang Samut Sakhon',2,59),(815,'7402','กระทุ่มแบน   ','Krathum Baen',2,59),(816,'7403','บ้านแพ้ว   ','Ban Phaeo',2,59),(817,'7501','เมืองสมุทรสงคราม   ','Mueang Samut Songkhram',2,60),(818,'7502','บางคนที   ','Bang Khonthi',2,60),(819,'7503','อัมพวา   ','Amphawa',2,60),(820,'7601','เมืองเพชรบุรี   ','Mueang Phetchaburi',4,61),(821,'7602','เขาย้อย   ','Khao Yoi',4,61),(822,'7603','หนองหญ้าปล้อง   ','Nong Ya Plong',4,61),(823,'7604','ชะอำ   ','Cha-am',4,61),(824,'7605','ท่ายาง   ','Tha Yang',4,61),(825,'7606','บ้านลาด   ','Ban Lat',4,61),(826,'7607','บ้านแหลม   ','Ban Laem',4,61),(827,'7608','แก่งกระจาน   ','Kaeng Krachan',4,61),(828,'7701','เมืองประจวบคีรีขันธ์   ','Mueang Prachuap Khiri Khan',4,62),(829,'7702','กุยบุรี   ','Kui Buri',4,62),(830,'7703','ทับสะแก   ','Thap Sakae',4,62),(831,'7704','บางสะพาน   ','Bang Saphan',4,62),(832,'7705','บางสะพานน้อย   ','Bang Saphan Noi',4,62),(833,'7706','ปราณบุรี   ','Pran Buri',4,62),(834,'7707','หัวหิน   ','Hua Hin',4,62),(835,'7708','สามร้อยยอด   ','Sam Roi Yot',4,62),(836,'8001','เมืองนครศรีธรรมราช   ','Mueang Nakhon Si Thammarat',6,63),(837,'8002','พรหมคีรี   ','Phrom Khiri',6,63),(838,'8003','ลานสกา   ','Lan Saka',6,63),(839,'8004','ฉวาง   ','Chawang',6,63),(840,'8005','พิปูน   ','Phipun',6,63),(841,'8006','เชียรใหญ่   ','Chian Yai',6,63),(842,'8007','ชะอวด   ','Cha-uat',6,63),(843,'8008','ท่าศาลา   ','Tha Sala',6,63),(844,'8009','ทุ่งสง   ','Thung Song',6,63),(845,'8010','นาบอน   ','Na Bon',6,63),(846,'8011','ทุ่งใหญ่   ','Thung Yai',6,63),(847,'8012','ปากพนัง   ','Pak Phanang',6,63),(848,'8013','ร่อนพิบูลย์   ','Ron Phibun',6,63),(849,'8014','สิชล   ','Sichon',6,63),(850,'8015','ขนอม   ','Khanom',6,63),(851,'8016','หัวไทร   ','Hua Sai',6,63),(852,'8017','บางขัน   ','Bang Khan',6,63),(853,'8018','ถ้ำพรรณรา   ','Tham Phannara',6,63),(854,'8019','จุฬาภรณ์   ','Chulabhorn',6,63),(855,'8020','พระพรหม   ','Phra Phrom',6,63),(856,'8021','นบพิตำ   ','Nopphitam',6,63),(857,'8022','ช้างกลาง   ','Chang Klang',6,63),(858,'8023','เฉลิมพระเกียรติ   ','Chaloem Phra Kiat',6,63),(859,'8051','เชียรใหญ่ (สาขาตำบลเสือหึง)*   ','Chian Yai*',6,63),(860,'8052','สาขาตำบลสวนหลวง**   ','Suan Luang',6,63),(861,'8053','ร่อนพิบูลย์ (สาขาตำบลหินตก)*   ','Ron Phibun',6,63),(862,'8054','หัวไทร (สาขาตำบลควนชะลิก)*   ','Hua Sai',6,63),(863,'8055','ทุ่งสง (สาขาตำบลกะปาง)*   ','Thung Song',6,63),(864,'8101','เมืองกระบี่   ','Mueang Krabi',6,64),(865,'8102','เขาพนม   ','Khao Phanom',6,64),(866,'8103','เกาะลันตา   ','Ko Lanta',6,64),(867,'8104','คลองท่อม   ','Khlong Thom',6,64),(868,'8105','อ่าวลึก   ','Ao Luek',6,64),(869,'8106','ปลายพระยา   ','Plai Phraya',6,64),(870,'8107','ลำทับ   ','Lam Thap',6,64),(871,'8108','เหนือคลอง   ','Nuea Khlong',6,64),(872,'8201','เมืองพังงา   ','Mueang Phang-nga',6,65),(873,'8202','เกาะยาว   ','Ko Yao',6,65),(874,'8203','กะปง   ','Kapong',6,65),(875,'8204','ตะกั่วทุ่ง   ','Takua Thung',6,65),(876,'8205','ตะกั่วป่า   ','Takua Pa',6,65),(877,'8206','คุระบุรี   ','Khura Buri',6,65),(878,'8207','ทับปุด   ','Thap Put',6,65),(879,'8208','ท้ายเหมือง   ','Thai Mueang',6,65),(880,'8301','เมืองภูเก็ต   ','Mueang Phuket',6,66),(881,'8302','กะทู้   ','Kathu',6,66),(882,'8303','ถลาง   ','Thalang',6,66),(883,'8381','*ทุ่งคา   ','*Tung Ka',6,66),(884,'8401','เมืองสุราษฎร์ธานี   ','Mueang Surat Thani',6,67),(885,'8402','กาญจนดิษฐ์   ','Kanchanadit',6,67),(886,'8403','ดอนสัก   ','Don Sak',6,67),(887,'8404','เกาะสมุย   ','Ko Samui',6,67),(888,'8405','เกาะพะงัน   ','Ko Pha-ngan',6,67),(889,'8406','ไชยา   ','Chaiya',6,67),(890,'8407','ท่าชนะ   ','Tha Chana',6,67),(891,'8408','คีรีรัฐนิคม   ','Khiri Rat Nikhom',6,67),(892,'8409','บ้านตาขุน   ','Ban Ta Khun',6,67),(893,'8410','พนม   ','Phanom',6,67),(894,'8411','ท่าฉาง   ','Tha Chang',6,67),(895,'8412','บ้านนาสาร   ','Ban Na San',6,67),(896,'8413','บ้านนาเดิม   ','Ban Na Doem',6,67),(897,'8414','เคียนซา   ','Khian Sa',6,67),(898,'8415','เวียงสระ   ','Wiang Sa',6,67),(899,'8416','พระแสง   ','Phrasaeng',6,67),(900,'8417','พุนพิน   ','Phunphin',6,67),(901,'8418','ชัยบุรี   ','Chai Buri',6,67),(902,'8419','วิภาวดี   ','Vibhavadi',6,67),(903,'8451','เกาะพงัน (สาขาตำบลเกาะเต่า)*   ','Ko Pha-ngan',6,67),(904,'8481','*อ.บ้านดอน  จ.สุราษฎร์ธานี   ','*Ban Don',6,67),(905,'8501','เมืองระนอง   ','Mueang Ranong',6,68),(906,'8502','ละอุ่น   ','La-un',6,68),(907,'8503','กะเปอร์   ','Kapoe',6,68),(908,'8504','กระบุรี   ','Kra Buri',6,68),(909,'8505','สุขสำราญ   ','Suk Samran',6,68),(910,'8601','เมืองชุมพร   ','Mueang Chumphon',6,69),(911,'8602','ท่าแซะ   ','Tha Sae',6,69),(912,'8603','ปะทิว   ','Pathio',6,69),(913,'8604','หลังสวน   ','Lang Suan',6,69),(914,'8605','ละแม   ','Lamae',6,69),(915,'8606','พะโต๊ะ   ','Phato',6,69),(916,'8607','สวี   ','Sawi',6,69),(917,'8608','ทุ่งตะโก   ','Thung Tako',6,69),(918,'9001','เมืองสงขลา   ','Mueang Songkhla',6,70),(919,'9002','สทิงพระ   ','Sathing Phra',6,70),(920,'9003','จะนะ   ','Chana',6,70),(921,'9004','นาทวี   ','Na Thawi',6,70),(922,'9005','เทพา   ','Thepha',6,70),(923,'9006','สะบ้าย้อย   ','Saba Yoi',6,70),(924,'9007','ระโนด   ','Ranot',6,70),(925,'9008','กระแสสินธุ์   ','Krasae Sin',6,70),(926,'9009','รัตภูมิ   ','Rattaphum',6,70),(927,'9010','สะเดา   ','Sadao',6,70),(928,'9011','หาดใหญ่   ','Hat Yai',6,70),(929,'9012','นาหม่อม   ','Na Mom',6,70),(930,'9013','ควนเนียง   ','Khuan Niang',6,70),(931,'9014','บางกล่ำ   ','Bang Klam',6,70),(932,'9015','สิงหนคร   ','Singhanakhon',6,70),(933,'9016','คลองหอยโข่ง   ','Khlong Hoi Khong',6,70),(934,'9077','ท้องถิ่นเทศบาลตำบลสำนักขาม   ','Sum Nung Kam',6,70),(935,'9096','เทศบาลตำบลบ้านพรุ*   ','Ban Pru*',6,70),(936,'9101','เมืองสตูล   ','Mueang Satun',6,71),(937,'9102','ควนโดน   ','Khuan Don',6,71),(938,'9103','ควนกาหลง   ','Khuan Kalong',6,71),(939,'9104','ท่าแพ   ','Tha Phae',6,71),(940,'9105','ละงู   ','La-ngu',6,71),(941,'9106','ทุ่งหว้า   ','Thung Wa',6,71),(942,'9107','มะนัง   ','Manang',6,71),(943,'9201','เมืองตรัง   ','Mueang Trang',6,72),(944,'9202','กันตัง   ','Kantang',6,72),(945,'9203','ย่านตาขาว   ','Yan Ta Khao',6,72),(946,'9204','ปะเหลียน   ','Palian',6,72),(947,'9205','สิเกา   ','Sikao',6,72),(948,'9206','ห้วยยอด   ','Huai Yot',6,72),(949,'9207','วังวิเศษ   ','Wang Wiset',6,72),(950,'9208','นาโยง   ','Na Yong',6,72),(951,'9209','รัษฎา   ','Ratsada',6,72),(952,'9210','หาดสำราญ   ','Hat Samran',6,72),(953,'9251','อำเภอเมืองตรัง(สาขาคลองเต็ง)**   ','Mueang Trang(Krong Teng)**',6,72),(954,'9301','เมืองพัทลุง   ','Mueang Phatthalung',6,73),(955,'9302','กงหรา   ','Kong Ra',6,73),(956,'9303','เขาชัยสน   ','Khao Chaison',6,73),(957,'9304','ตะโหมด   ','Tamot',6,73),(958,'9305','ควนขนุน   ','Khuan Khanun',6,73),(959,'9306','ปากพะยูน   ','Pak Phayun',6,73),(960,'9307','ศรีบรรพต   ','Si Banphot',6,73),(961,'9308','ป่าบอน   ','Pa Bon',6,73),(962,'9309','บางแก้ว   ','Bang Kaeo',6,73),(963,'9310','ป่าพะยอม   ','Pa Phayom',6,73),(964,'9311','ศรีนครินทร์   ','Srinagarindra',6,73),(965,'9401','เมืองปัตตานี   ','Mueang Pattani',6,74),(966,'9402','โคกโพธิ์   ','Khok Pho',6,74),(967,'9403','หนองจิก   ','Nong Chik',6,74),(968,'9404','ปะนาเระ   ','Panare',6,74),(969,'9405','มายอ   ','Mayo',6,74),(970,'9406','ทุ่งยางแดง   ','Thung Yang Daeng',6,74),(971,'9407','สายบุรี   ','Sai Buri',6,74),(972,'9408','ไม้แก่น   ','Mai Kaen',6,74),(973,'9409','ยะหริ่ง   ','Yaring',6,74),(974,'9410','ยะรัง   ','Yarang',6,74),(975,'9411','กะพ้อ   ','Kapho',6,74),(976,'9412','แม่ลาน   ','Mae Lan',6,74),(977,'9501','เมืองยะลา   ','Mueang Yala',6,75),(978,'9502','เบตง   ','Betong',6,75),(979,'9503','บันนังสตา   ','Bannang Sata',6,75),(980,'9504','ธารโต   ','Than To',6,75),(981,'9505','ยะหา   ','Yaha',6,75),(982,'9506','รามัน   ','Raman',6,75),(983,'9507','กาบัง   ','Kabang',6,75),(984,'9508','กรงปินัง   ','Krong Pinang',6,75),(985,'9601','เมืองนราธิวาส   ','Mueang Narathiwat',6,76),(986,'9602','ตากใบ   ','Tak Bai',6,76),(987,'9603','บาเจาะ   ','Bacho',6,76),(988,'9604','ยี่งอ   ','Yi-ngo',6,76),(989,'9605','ระแงะ   ','Ra-ngae',6,76),(990,'9606','รือเสาะ   ','Rueso',6,76),(991,'9607','ศรีสาคร   ','Si Sakhon',6,76),(992,'9608','แว้ง   ','Waeng',6,76),(993,'9609','สุคิริน   ','Sukhirin',6,76),(994,'9610','สุไหงโก-ลก   ','Su-ngai Kolok',6,76),(995,'9611','สุไหงปาดี   ','Su-ngai Padi',6,76),(996,'9612','จะแนะ   ','Chanae',6,76),(997,'9613','เจาะไอร้อง   ','Cho-airong',6,76),(998,'9681','*อ.บางนรา  จ.นราธิวาส   ','*Bang Nra',6,76);
/*!40000 ALTER TABLE `amphurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `badges`
--

DROP TABLE IF EXISTS `badges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `badges` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `desc` varchar(300) DEFAULT '',
  `expired` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `sql` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `badges`
--

LOCK TABLES `badges` WRITE;
/*!40000 ALTER TABLE `badges` DISABLE KEYS */;
INSERT INTO `badges` VALUES (1,'Social Animal','คุณเป็นพวกชอบแชร์ข้อมูลข่าวสาร บ้างก็ดูดี บ้างก็ไรสาระ แต่คุณก็ยังมีเพื่อนฝูงมากมายแวะเวียนมาติดตามคุณอยู่เสมอ นี่แหละที่มนุษย์ถูกเรียกว่าสัตว์สังคม',NULL,NULL,NULL,'select count(*)>0 as result  from users where fb_id<>0 and users.id='),(2,'สัมภเวสี','คุณสรรหาที่ตีแบดไปทั่ว เบื่อที่นึงก็ย้ายไปอีกที่ ย้ายไปเรื่อยๆ เหมือนผีตองเหลือง จนชาวบ้านเค้าสงสัยว่าพี่คนนี้เค้าอยู่ทีมไหนกันแน่ บางทีคุณเองก็ยังไม่แน่ใจ!',NULL,NULL,NULL,'select count(*)>5 as result  from users left join teammembers on users.id=teammembers.user_id where  users.id= '),(3,'ไอ้แมงมุม','อำนาจที่ยิ่งใหญ่ มาพร้อมกับความรับผิดชอบอันใหญ่ยิ่ง คุณได้รับการยอมรับให้เป็นผู้ดูแลทีม ผู้ซึ่งมีความสามารถจัดการและรับแรงกดดันจากลูกทีมต่างๆ นา ทุกวันที่ตีแบดมือของคุณจะยุ่งพัลวัลยังกับแมงมุม',NULL,NULL,NULL,'select count(*)>0 as result  from managers left join users on users.id=managers.user_id where  users.id= '),(4,'ผู้ร่วมก่อตั้ง','คุณได้รับเกียรติให้เป็นผู้ก่อตั้งห้าสิบอันดับแรกของสมาชิกเว็บไซต์ ตีแบดกันดอทคอม สิทธิประโยชน์จากทางเว็บไซต์จะส่งถึงบุคคลเหล่านี้ก่อนใคร',NULL,NULL,NULL,'select users.id<51 as result  from  users  where  users.id= ');
/*!40000 ALTER TABLE `badges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bans`
--

DROP TABLE IF EXISTS `bans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bans` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `message` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `expire` int(10) unsigned DEFAULT NULL,
  `ban_creator` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `bans_username_index` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bans`
--

LOCK TABLES `bans` WRITE;
/*!40000 ALTER TABLE `bans` DISABLE KEYS */;
/*!40000 ALTER TABLE `bans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blocks`
--

DROP TABLE IF EXISTS `blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blocks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `blocks_key_unique` (`key`),
  KEY `blocks_id_index` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blocks`
--

LOCK TABLES `blocks` WRITE;
/*!40000 ALTER TABLE `blocks` DISABLE KEYS */;
INSERT INTO `blocks` VALUES (1,'เกี่ยวกับเรา','ข่าวแบดมินตัน การแข่งขัน','<p>\r\n	 Teebadgun.com\r\n</p>\r\n<p>\r\n	 ติดต่อได้ที่\r\n</p>\r\n<p>\r\n	 admin@teebadgun.com\r\n</p>\r\n<p>\r\n	 0894852280\r\n</p>','2013-12-02 15:16:19','2013-12-06 04:22:28');
/*!40000 ALTER TABLE `blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `disp_position` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Test category',0);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `censoring`
--

DROP TABLE IF EXISTS `censoring`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `censoring` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `search_for` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `replace_with` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `censoring`
--

LOCK TABLES `censoring` WRITE;
/*!40000 ALTER TABLE `censoring` DISABLE KEYS */;
/*!40000 ALTER TABLE `censoring` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `authorable_id` int(10) unsigned NOT NULL,
  `authorable_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `commentable_id` int(10) unsigned NOT NULL,
  `commentable_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `petersuhm_commentable_comments_authorable_id_index` (`authorable_id`),
  KEY `petersuhm_commentable_comments_authorable_type_index` (`authorable_type`),
  KEY `petersuhm_commentable_comments_commentable_id_index` (`commentable_id`),
  KEY `petersuhm_commentable_comments_commentable_type_index` (`commentable_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config` (
  `conf_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `conf_value` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`conf_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES ('o_additional_navlinks',''),('o_admin_email','email'),('o_announcement','0'),('o_announcement_message','seed_data.announcement'),('o_avatars','1'),('o_avatars_dir','img/avatars'),('o_avatars_height','60'),('o_avatars_size','10240'),('o_avatars_width','60'),('o_board_desc','ร่วมสร้างสรรค์สังคมแบดมินตันที่ดี แบ่งปันความรู้ ข้อมูล ข่าวสาร พิพากย์วิจารณ์อย่างสร้างสรรค์ เพื่อเป็นส่วนหนึ่งในการพัฒนาวงการแบดมินตันไทย'),('o_board_title','ตีแบดกันดอทคอม'),('o_censoring','0'),('o_cur_version','2.0.0-alpha1'),('o_date_format','Y-m-d'),('o_default_dst','0'),('o_default_email_setting','1'),('o_default_lang','th'),('o_default_style','Air'),('o_default_timezone','0'),('o_default_user_group','4'),('o_disp_posts_default','25'),('o_disp_topics_default','30'),('o_feed_ttl','0'),('o_feed_type','2'),('o_forum_subscriptions','1'),('o_gzip','0'),('o_indent_num_spaces','4'),('o_mailing_list','email'),('o_maintenance','0'),('o_maintenance_message','seed_data.maintenance_message'),('o_make_links','1'),('o_quickjump','1'),('o_quickpost','1'),('o_quote_depth','3'),('o_redirect_delay','1'),('o_regs_allow','1'),('o_regs_report','0'),('o_regs_verify','0'),('o_report_method','0'),('o_rules','0'),('o_rules_message','seed_data.rules'),('o_search_all_forums','1'),('o_show_dot','0'),('o_show_post_count','1'),('o_show_user_info','1'),('o_show_version','0'),('o_signatures','1'),('o_smilies','1'),('o_smilies_sig','1'),('o_smtp_host',NULL),('o_smtp_pass',NULL),('o_smtp_ssl','0'),('o_smtp_user',NULL),('o_time_format','H:i:s'),('o_timeout_online','300'),('o_timeout_visit','1800'),('o_topic_review','15'),('o_topic_subscriptions','1'),('o_topic_views','1'),('o_users_online','1'),('o_webmaster_email','email'),('p_allow_banned_email','1'),('p_allow_dupe_email','0'),('p_force_guest_email','1'),('p_message_all_caps','1'),('p_message_bbcode','1'),('p_message_img_tag','1'),('p_sig_all_caps','1'),('p_sig_bbcode','1'),('p_sig_img_tag','0'),('p_sig_length','400'),('p_sig_lines','4'),('p_subject_all_caps','1');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contents`
--

DROP TABLE IF EXISTS `contents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `category` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'news',
  PRIMARY KEY (`id`),
  UNIQUE KEY `posts_slug_unique` (`slug`),
  KEY `posts_id_index` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contents`
--

LOCK TABLES `contents` WRITE;
/*!40000 ALTER TABLE `contents` DISABLE KEYS */;
INSERT INTO `contents` VALUES (1,'สอง ทนงศักดิ์ ชิวแชมป์ชายเดี่ยวซีเกมส์ 2013 ในรอบ 38 ปีประเทศไทย','สอง-ทนงศักดิ์-ชิวแชมป์ชายเดี่ยวซีเกมส์-2013-ในรอบ-38-ปีประเทศไทย','<p style=\"text-align: center;\">\r\n	 <img src=\"http://www.popcornfor2.com/upload/40/news-thumb-39050.jpg\">\r\n</p>\r\n<p style=\"text-align: center;\">\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		 <br>\r\n		  “สอง” ทนงศักดิ์ แสนสมบูรณ์สุข นักแบดมินตันไทย มือ 2 ของรายการ กู้หน้าให้ทัพแบดมินตันไทย หลังไล่ตบเอาชนะ คู่ปรับอินโดนีเซีย 2 เซตรวด สร้างประวัตศาสตร์คว้าแชมป์ชายเดี่ยวแรกให้ทีมขนไก่ไทยในรอบ 38 ปี ในศึกซีเกมส์ ครั้งที่ 27 เมื่อวันเสาร์ที่ผ่านมา<br>\r\n		 <br>\r\n		   การแข่งขัน แบดมินตัน ในศึก “เนปิดอว์ เกมส์” ณ สนาม วันนะ เต็กกี อินดอร์ สเตเดียม วันที่ 14 ธันวาคม เดินทางมาถึงรอบชิงชนะเลิศ โดยเหลือลุ้นในประเภทสุดท้ายที่ชายเดี่ยว ทนงศักดิ์ แสนสมบูรณ์สุข พบ รับบากา ดิโอนีซุส ฮายอม หลังพลาดในประเภทหญิงเดี่ยวและคู่ผสม<br>\r\n		 <br>\r\n		   ผลปรากฏว่า การแข่งขันในเซตแรกต่างคนต่างผลัดกันทำคะแนนอย่างสนุกสูสี ก่อนที่จะต้องมาลุ้นหนักในช่วงท้าย และเป็น “สอง” ที่ชิงปิดเซตได้ก่อน 22-20 จากนั้นกลับมาเซตที่สอง ตบขนไก่ไทยลงแข่งด้วยความมั่นใจและยังดักตบเอาชนะไป 21-17 ปิดแมตช์ ชนะ 2 เซ็ตรวด กู้ศรัทธาให้ทัพแบดมินตันไทยได้สำเร็จ<br>\r\n		 <br>\r\n		   สำหรับเหรียญทองประเภทชายเดี่ยวของ “สอง” ครั้งนี้ถือเป็นนักกีฬาไทยคนแรกที่คว้าเหรียญทองประเภทชายเดี่ยวได้ในรอบ 38 ปี ต่อจาก บันฑิต ใจเย็น อดีตขนไก่ไทย<br>\r\n		 <br>\r\n		   พร้อมให้สัมภาษณ์ว่า วันนี้มั่นใจเต็มร้อย เล่นได้เต็มที่ ตามแผนที่โค้ชสั่งวางไว้ โดยสไตล์การเล่นของคู่แข่งมีสไตล์คล้ายกัน แต่เกมนี้เราชิงบุกก่อนจึงไล่ทำคะแนนได้มาก\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>\r\n	  credit <a href=\"http://www.manager.co.th/Sport/ViewNews.aspx?NewsID=9560000153831\" target=\"_blank\">manager.co.th</a>\r\n</p>','2013-12-02 15:13:51','2013-12-15 08:13:52','news'),(8,'กีฬาแบดมินตันคืออะไร เล่นอย่างไร','','<p><h1>กีฬาแบดมินตัน คืออะไร</h1>&nbsp;กีฬาแบดมินตัน เป็นกีฬาที่เล่นเพื่อความสนุกสนานซึ่งเป็นกีฬาที่ยอดฮิตของประชาชนชาวไทย ไม่ว่าจะเป็นงานอดิเรกหรือฝึกฝนในระดับที่แข่งขันก็ยังได้ เพื่อพัฒนาสุขภาพโดยรวมของคุณอย่างเมื่อเล่นอย่างน้อย 30 นาทีต่อวัน <strong>หลายชาติและสถาบันสุขภาพต่างๆ ยังแนะนำให้คุณพยายามที่จะเพิ่มอัตราการเต้นหัวใจของคุณเป็นเวลาอย่างน้อย 30 นาทีต่อวันเพื่อให้การเผาผลาญอาหารของคุณซึ่งเป็นอัตราที่ดีต่อสุขภาพ</strong>\r\n</p>\r\n<p>\r\n	<br>\r\n	นอกจากนี้การเล่นแบดมินตันไม่เพียงเพื่อเพิ่มประโยชน์ของการเพิ่มอัตราการเต้นหัวใจและให้ผลกับกล้ามเนื้อแล้ว แข่งขันเต็มรูปแบบของกีฬาแบดมินตัน (อย่างน้อยสามเกม) คุณจะได้รับการเคลื่อนที่อย่างน้อย 30 นาที และร่างกายคุณจะได้รับการเคลื่อนที่อย่างรวดเร็ว ซึ่งจะสามารถทำให้กล้ามเนื้อยืดและปล่อยฮอร์โมนเข้าสู่ร่างกาย ในขณะที่คุณเคลื่อนที่ไปกลับซ้ำๆ<br>\r\n	<br>\r\n	ถึงแม้ว่าส่วนใหญ่ไม้แบดมินตันจะมีน้ำหนักเบาและง่ายต่อการแกว่ง แต่คุณต้องใช้กล้ามเนื้อทั้งเอว หัวไหล่ แขน ศอก ข้อมือ เพื่อให้การตีแบดมินตันเกิดประสิทธิภาพสูงสุด ซึ่งการใช้กล้ามเนื้อเหล่านี้ถือเป็นการบริหารอย่างหนึ่งที่ไม่แพ้การยกน้ำหนักเลยทีเดียวแต่อย่างไรก็ตามแบดมินตันไม่ได้เป็นกีฬาประเภท แอโรบิคซึ่งไม่ได้ใช้กล้ามเนื้อทุกส่วน การตีแบดมินตันจึงเป็นไปเพื่อความบรรเทิง มากกว่าจะได้ประโยชน์ในการลดน้ำหนัก ซึ่งปัจจุบันตามยิมและคอร์ทแบดมินตันต่างๆ ได้มีประชาชนมากมายหันมาสนใจการเล่นแบดมินตันเนื่องจากวิธีการเล่นที่ง่าย หาอุปกรณ์ได้ง่าย และเป็นที่นิยมในขณะนี้</p>','2013-12-05 05:14:29','2013-12-22 17:50:44','article'),(9,'แบดมินตันสำหรับผู้เริ่มต้น','badminton-for-beginner','<div><span style=\"color: rgb(34, 34, 34); font-family: thaisansbold, \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 36px; line-height: 1.1;\">พื้นฐานแรกสุด</span><br></div><div>จุดมุ่งหมายของการตีแบดมินตันคือการตีลูกขนไก่ด้วยแรคเก็ตให้ข้าตาข่ายไปในพื้นที่ฝั่งตรงข้าม ซึ่งการตีกลับไปกลับมานี้ หากเราสามารถตีลูกขนไก่ให้ตกลงพื้นฝั่งตรงข้ามได้จะทำให้เราได้คะแนน &nbsp;ซึ่งฝั่งตรงข้ามก็มีจุดมุ่งหมายเดียวกัน โดยแต่ละฝั่งจะสามารถตีลูกขนไก่ได้เพียงครั้งเดียวต่อการข้ามมาของลูกหนึ่งครั้ง ซึ่งไม่เหมือนกับวอลเล่ย์บอลซึ่งตีได้มากสุดสามครั้ง กีฬาแบดมินตันเป็นกีฬาที่จำเป็นต้องเล่นในที่ร่มหรือในอาคารเนื่องจากทิศทางและความแรงของลม มีผลต่อทิศทางของลูกขนไก่มาก ซึ่งมาตรฐานของการตีแบดมินตันสามารถแบ่งได้เป็น ประเภท ชายเดี่ยว หญิงเดี่ยว ชายคู่ หญิงคู่ และคู่ผสม</div><div><br></div><div style=\"text-align: center;\"><img src=\"http://i.imgur.com/H2XKWjh.gif\" width=\"416\"><br></div><h1>เส้นบนสนามบอกอะไรเราบ้าง?</h1><div>เมื่อคุณมองไปยังพื้นคอร์ทแบดมินตัน คุณอาจสงสัยว่าเส้นแต่ละเส้นมีไว้ทำหน้าที่อะไรบ้าง ซึ่งหากตอบแบบง่ายคือมีไว้สำหรับแบ่งการเล่นแบบประเภทคู่และเดี่ยว ซึ่งมีขนาดต่างกันเล็กน้อย โดยในการเล่นแบบคู่ ทั้งชายคู่ หญิงคู่ หรือคู่ผสม ระหว่างการเล่น เราสามารถตีลูกแบดมินตันให้ตกลงบนตำแหน่งใดก็ได้ของเส้นนอกสุด ยกเว้นในการเสิร์ฟลูก จะใช้หากลูกขนไก่เลยเส้นด้านในทางด้านหลังถือว่าเป็นการเสิรฟออก สำหรับด้านข้างใช้เส้นนอกสุดเช่นเดิม</div><div><br></div><div>สำหรับการเล่นประเภทเดี่ยว พื้นที่คอร์ทจะตรงกันข้ามกล่าวคือ พื้นที่ด้านข้างจะใช้เส้นในสุดเสมอ ส่วนด้านหลังใช้เส้นนอกสุดทั้งในการเสิร์ฟและระหว่างการเล่นลูกอื่น</div><div><br></div><h1>การเสิร์ฟลูก</h1><div>ในการเล่นประเภทเดี่ยว เราจะเสิร์ฟลูกไปยังฝั่งทแยงมุมของฝั่งตรงข้าม โดยต้องเสิร์ฟผ่านเส้นสั้น จึงจะถือว่าเป็นลูกที่ได้แต้ม เช่นเดียวกับในการแข่งขันประเภทคู่ &nbsp;ซึ่งคู่ของฝั่งตรงข้ามไม่มีสิทธิรับลูกเสิร์ฟ จะรับได้เฉพาะกับผู้ที่อยู่ในแนวทแยงมุมกับผู้เสิร์ฟเท่านั้น</div><div>หากรับผิดคนถือว่าฝั่งที่รับเสียคะแนน กติกาที่สำคัญในการเสิร์ฟลูกขนไก่ที่ต้องทราบคือ ในขณะที่เสิร์ฟจุดที่ไม้สัมผัสลูก จะต้องต่ำกว่าระดับเอว และข้อมือต้องสูงกว่าปลายไม้ที่สัมผัสลูกอย่างเห็นได้ชัด</div><div><br></div><div>ขณะที่ทำการเสิร์ฟผู้เสิร์ฟจะต้องยืนอยู่ภายในคอร์ทฝั่งใดฝั่งหนึ่งและไม่อยู่เลยเส้นสั้นไปทางคอร์ทและห้ามออกจากพื้นที่เสิร์ฟจนกว่าลูกขนไก่จะสัมผัสกับแรคเก็ต หากฝั่งตรงข้ามเสิร์ฟลูกผิดคอร์ท คือไม่อยู่ในคอร์ทที่ทแยงมุม ผู้รับสามารถปล่อยลูกให้ตกเป็นคะแนนเสียได้ เช่นเดียวกันกับฝั่งตรงข้ามซึ่งผู้รับลูกเสิร์ฟต้องไม่ขยับตัวออกจากจุดเดิมจนกว่าไม้ของผู้เสิร์ฟจะสัมผัสลูกขนไก่</div><div><br></div><div><i>สำหรับผู้ที่เริ่มต้นเล่นแบดมินตันอาจได้ทราบกติการที่เพียงพอสำหรับหัดเล่นคร่าวๆ แล้วครั้งต่อไปเราจะมาฝึกเทคนิคการเคลื่อนที่ และการตีลูกกันครับ</i></div>','2013-12-05 05:15:50','2013-12-23 15:08:04','article'),(10,'คนรักแบดคัพ ครั้งที่121-22 (รับสมัครพร้อมโอนเงินถึง6ธันวา)','คนรักแบดคัพ-ครั้งที่121-22-(รับสมัครพร้อมโอนเงินถึง6ธันวา)','<p>\r\n	 <a href=\"http://image.ohozaa.com/view2/x5SDPrjXHSObUacd\"><img border=\"0\" src=\"http://image.ohozaa.com/i/281/M4HgMU.jpg\"></a>\r\n</p>\r\n<p>\r\n	   คนรักแบด คัพ@อันโตนิโอ นครปฐม ครั้งที่1<br>\r\n	       วันที่ 21-22 ธันวาคม 2556<br>\r\n	       ณ สนามแบดมินตัน อันโตนิโอ นครปฐม <br>\r\n	      ชิงถ้วยรางวัล ผู้ว่าการกีฬาแห่งประเทศไทย<br>\r\n	       คุณ กนกพันธ์ จุลเกษม<br>\r\n	 <u>*ห้ามนักกีฬา20 อันดับแรก ของสมาคมแบดมินตันแห่งประเทศไทย,<br>\r\n	   นักกีฬาตัวแทนสถาบันศึกษาต่างๆ, นักกีฬาอดีตทีมชาติ อดีตนักกีฬาเขต ตัวแทนนักกีฬาแห่งชาติลงแข่งขัน<strong>วัตถุประสงค์1. เพื่อเป็นการส่งเสริมการกีฬาแบดมินตันให้เป็นที่นิยมแพร่หลาย<br>\r\n	   2. เพื่อสนับสนุนให้นักกีฬาแบดมินตันสมัครเล่นมีโอกาสแข่งขันมากขึ้น เพื่อพัฒนาฝีมือ<br>\r\n	   3. เพื่อเสริมสร้างความสามัคคี และความสัมพันธ์อันดีในหมู่คณะ<br>\r\n	   4. เพื่อส่งเสริมให้เยาวชนเล่นกีฬาห่างไกลยาเสพติด <br>\r\n	 <strong>ประเภทการแข่งขัน ดังนี้- ประเภทคู่มือ C+ 32 คู่   (แบ่งกลุ่ม ที่1-2 เข้ารอบ main draw)<br>\r\n	   - ประเภทคู่มือ C  32 คู่ (แบ่งกลุ่ม ที่1-2 เข้ารอบ main draw)<br>\r\n	   - ประเภทคู่มือ P  64คู่   (แบ่งกลุ่ม ที่1-2 เข้ารอบ main draw)<br>\r\n	   - ประเภทคู่มือ P-  64 คู่   (แบ่งกลุ่ม ที่1-2 เข้ารอบ main draw)<br>\r\n	   *ประเภทใดมีผู้สมัครจำนวนคู่ไม่ถึงครึ่งของจำนวนที่รับสมัคร คณะกรรมการจัดการแข่งขันจะยกเลิกการแข่งขันประเภทนั้น*</strong></strong></u>\r\n</p>\r\n<p>\r\n	 <u><strong><strong>*หากประเภทใดมีผู้สมัครเกินครึ่ง แต่ไม่ครบจำนวนคู่ที่กำหนดเงินรางวัลที่ได้รับจะถูกลดจำนวนลงครึ่งหนึ่ง<br>\r\n	 <strong>ระเบียบการแข่งขัน1. ใช้กติกาการแข่งขันของสหพันธ์แบดมินตันนานาชาติ <br>\r\n	   2. ให้นักกีฬามาก่อนการแข่งขัน 30 นาที เพื่อความรวดเร็วในการจัดการแข่งขันได้ <br>\r\n	   3. นักกีฬาสามารถสมัครแข่งขันได้ไม่เกิน 2ประเภท<br>\r\n	   4. คณะกรรมการจัดการแข่งขันขอสงวนสิทธิ์ในการเปลี่ยนแปลงแก้ไขสายการแข่งขันได้<br>\r\n	   ในกรณีมีการพิมพ์ผิดหรือ รายชื่อตกหล่น ซึ่งมิใช่เป็นการแก้สายการแข่งขันทั้งหมด<br>\r\n	   5. คณะกรรมการจัดการแข่งขัน หรือกรรมการผู้ชี้ขาด เป็นผู้รับผิดชอบมีสิทธิ์วินิจฉัยการประท้วง<br>\r\n	   และคัดค้านทุกกรณี และการวินิจฉัยชี้ขาดถือเป็นสิ้นสุดและยุติ<br>\r\n	   6. การแข่งขันใช้ลูกขนไก่ RSL SILVER<br>\r\n	   7. ในรอบmain draw ใช้วิธีนับคะแนนแบบ Rally pointแข่งขัน2ใน3เกม แต่ละเกมจะมีคะแนน 21 คะแนน ผู้ส่งถึง 21 คะแนน ก่อนเป็นผู้ชนะ ในกรณี 20 เท่ากัน ให้เล่นต่อจนกว่าจะ ชนะ 2 คะแนน ติดต่อกัน หรือถ้า 29 เท่ากัน ผู้ถึง 30 เป็นผู้ชนะในเกมนั้น ทันที<br>\r\n	   8. การจัดการแข่งขันอาจมีการเปลี่ยนแปลงตามความเหมาะสม ขึ้นอยู่กับคณะกรรมการจัดการแข่งขัน<br>\r\n	   9. ในรอบแบ่งกลุ่ม ใช้วิธีนับคะแนนแบบ Rally point สองเซ็ต แต้มสูงสุด21แต้ม ไม่มีการดิวส์<br>\r\n	 <br>\r\n	 <strong>กำหนดการ- เปิดรับสมัครตั้งแต่บัดนี้ ถึงวันที่ 30 พฤศจิกายน 2556<br>\r\n	   - ตรวจสอบแก้ไขรายชื่อได้ถึงวันที่ 15 ธันวาคม 2556<br>\r\n	   - โอนค่าสมัครภายในวันที่ 6 ธันวาคม 2556 (หรือหลังจากผ่านการพิจารณาเรียบร้อยแล้ว)<br>\r\n	   - จับฉลากแบ่งกลุ่ม วันที่ 16 ธันวาคม 2556 เวลา 18.00น. ณ สนามแบดมินตัน อันโตนิโอ นครปฐม<br>\r\n	   - ประกาศสายการแข่งขันวันที่ 18 ธันวาคม 2556<br>\r\n	   - แข่งขันวันที่ 21-22 ธันวาคม 2556 เวลา09.00น เป็นต้นไป ณ สนามแบดมินตัน อันโตนิโอ นครปฐม<br>\r\n	 <br>\r\n	 <br>\r\n	 <strong>ค่าใช้จ่าย- ค่าสมัครคู่ละ 600.- บาท<br>\r\n	   - ลูกขนไก่ลูกละ 15 บาท/คน/ลูก (คูปองใบละ 30.-)<br>\r\n	 <br>\r\n	   *** นักกีฬาทุกท่านต้องชำระค่าสมัครภายในระยะเวลาที่กำหนดข้างต้น <br>\r\n	   หากพ้นกำหนดจะคัดชื่อออกเพื่อ พิจารณานักกีฬาลำดับต่อไป ได้เข้าแข่งขันแทน<br>\r\n	   โอนเงินค่าสมัครผ่านบัญชี ธนาคารกรุงเทพ สาขาย่อย บิ๊กซีรัตนาธิเบศร์<br>\r\n	   ชื่อบัญชี นวพนธ์ เอกมงคลพงศ์<br>\r\n	   บัญชีออมทรัพย์ เลขที่ 018-012345-7<br>\r\n	   *** กรุณาเก็บหลักฐานการโอนเงินมาแสดงในวันแข่งขัน ***<br>\r\n	   รางวัลการแข่งขัน : เงินรางวัลพร้อมถ้วยทุกอันดับ <br>\r\n	       ชนะเลิศ รองอันดับ 1 รองอันดับ 2 รองอันดับ 2<br>\r\n	   คู่มือ C+   4000    3000        2000      2000<br>\r\n	   คู่มือ C     4000    3000        2000      2000<br>\r\n	   คู่มือ P  4000  3000  2000 2000<br>\r\n	   คู่มือ P  -  4000  3000 2000  2000<br>\r\n	 <br>\r\n	   กรรมการฯ จะพิจารณาคุณสมบัติโดยหลักฐานบัตรประชาชน และข้อมูลประวัติการแข่งขันของนักกีฬาเป็นรายบุคคล เพื่อตัดสิทธิ์ในการลงแข่งขัน<br>\r\n	   หมายเหตุ การประเมินคุณสมบัตินักกีฬาอยู่ในดุลยพินิจของคณะกรรมการ <br>\r\n	 <br>\r\n	 <br>\r\n	   กรรมการประเมินคุณสมบัติ : นวพนธ์ เอกมงคลพงศ์ และทีมงานคนรักแบด<br>\r\n	 <br>\r\n	   กรรมการดำเนินการแข่งขัน : นวพนธ์ เอกมงคลพงศ์ โทร 088-8659877<br>\r\n	 <strong>วิธีการสมัคร1.สมัครได้ทาง เวบไซด์ thaibadminton.com</strong></strong></strong></strong></strong></strong></u>\r\n</p>\r\n<p>\r\n	 <u><strong><strong><strong><u><strong>ใบสมัคร</strong></u></strong></strong></strong></u>\r\n</p>\r\n<p>\r\n	 <u><strong><strong><a href=\"https://docs.google.com/forms/d/19Gbtmnk_Z9arDzhzUa4Ef0x6uHUhHHS7nOsN6iui5Qo/edit\">https://docs.google.com/forms/d/19Gbtmnk_Z9arDzhzUa4Ef0x6uHUhHHS7nOsN6iui5Qo/edit</a></strong></strong></u>\r\n</p>\r\n<p>\r\n	 <u><strong><strong><strong><u>ตรวจสอบสถานะ</u></strong></strong></strong></u>\r\n</p>\r\n<p>\r\n	 <u><strong><strong><a href=\"https://docs.google.com/spreadsheet/ccc?key=0AijlIu17i59KdEYtcS1ScEw0MlhXWmk1YXhFSTZUUnc&amp;usp=sharing\">https://docs.google.com/spreadsheet/ccc?key=0AijlIu17i59KdEYtcS1ScEw0MlhXWmk1YXhFSTZUUnc&amp;usp=sharing</a><br>\r\n	   2.สนามแบดมินตัน อันโตนิโอนครปฐม<br>\r\n	   3.โทร 088-8659877<br>\r\n	     082-9803747 นวพนธ์<br>\r\n	   4.line id 082-9803747<br>\r\n	   โดยมีรายละเอียดดังนี้<br>\r\n	    สมัครมือ........ชื่อทีม(ถ้ามี).............<br>\r\n	    ผู้เล่นคนที่1. ชื่อ....................สกุล.........................ชื่อเล่น........เพศ......อายุ........เบอร์โทร...............<br>\r\n	     ประวัติการแข่งขัน1. ....................................................<br>\r\n	     2. ....................................................<br>\r\n	    ผู้เล่นคนที่2. ชื่อ....................สกุล.........................ชื่อเล่น........เพศ......อายุ........เบอร์โทร...............<br>\r\n	     ประวัติการแข่งขัน1. ....................................................<br>\r\n	     2. ....................................................<br>\r\n	     สมัครโดย........................เบอร์โทร.........................<br>\r\n	   พิเศษสุดสำหรับคนรักแบดครับ</strong></strong></u>\r\n</p>\r\n<p>\r\n	 <u><strong><strong>1.สำหรับคู่ที่อยู่ในสถานะ\"โอนแล้ว\"50 คู่แรก(100ท่าน)รับไปเลย</strong></strong></u>\r\n</p>\r\n<p>\r\n	 <u><strong><strong>  ถุงเท้าOmiger ถุงเท้าคุณภาพดีมูลค่าคู่ละ 75 บาท</strong></strong></u>\r\n</p>\r\n<p>\r\n	 <u><strong><strong><a href=\"http://image.ohozaa.com/view2/x6wz1oC4SbZR19Ku\">[img border=\"0\" src=\"http://image.ohozaa.com/i/a2f/7TbeOQ.jpeg\"&gt;</a> <a href=\"http://image.ohozaa.com/view2/x6wzjtwRkZeV8uQb\">[img border=\"0\" src=\"http://image.ohozaa.com/i/523/Bp125x.jpeg\"&gt;</a></strong></strong></u>\r\n</p>\r\n<p>\r\n	 <u><strong><strong>2.สำหรับคู่ที่อยู่ในสถานะ\"โอนแล้ว\"ลำดับที่51-100ลุ้นจับฉลากรับ  ถุงเท้าOmligerมูลค่า75 บาท10คู่(=ผู้สมัคร5คู่10ท่าน ครับ)</strong></strong></u>\r\n</p>\r\n<p>\r\n	 <u><strong><strong>3.สำหรับผู้สมัครทุกคู่ครับ ลุ้นรับ</strong></strong></u>\r\n</p>\r\n<p>\r\n	 <u><strong><strong>  3.1กระเป๋าAPACS 2 ใบ สำหรับ1 คู่ 2ท่าน</strong></strong></u>\r\n</p>\r\n<p>\r\n	 <u><strong><strong><a href=\"http://image.ohozaa.com/view2/x6wDbt8zjh1bqqm1\">[img border=\"0\" src=\"http://image.ohozaa.com/i/ca0/4GshrM.png\"&gt;</a></strong></strong></u>\r\n</p>\r\n<p>\r\n	 <u><strong><strong> 3.2เสื้อคนรักแบด 10 ตัว  สำหรับ5 คู่ 10 ท่าน</strong></strong></u>\r\n</p>\r\n<p>\r\n	 <u><strong><strong>จับรางวัล พร้อมประกาศรายชื่อ 10 ธันวาคม 2556</strong></strong></u>\r\n</p>\r\n<p>\r\n	 <u><strong><strong>รับรางวัลได้ในวันแข่งขัน</strong></strong></u>\r\n</p>','2013-12-05 06:56:44','2013-12-15 08:22:25','announcement'),(11,'ไท่ ซู หยิง พลิคล๊อคเอาชนะ หวัง ซี เซียน ในรอบชิงชนะเลิศ BWF World Superseries 2013','ไท่-ซู-หยิง-พลิคล๊อคเอาชนะ-หวัง-ซี-เซียน-ในรอบชิงชนะเลิศ-BWF-World-Superseries-2013','<p>\r\n	 สาวน้อยวัย 19 ปี ผู้มากับความสดใส ความสามารถ และโชค “ไท่ ซู่ หยิง” ได้เข้ามาเป็นผู้แข่งขันสองอันดับสุดท้ายในรอบชิงชนะเลิศในรายการ BWF World Superseries ที่มาเลเซียวานนี้ ซึ่งต้องเข้าชิงชนะเลิศกับ หวัง ซี เซียน มือวางหญิงอันดับหนึ่งจากจีน\r\n</p>\r\n<p>\r\n	 สาวไต้คนนี้ได้กลายมาเป็นขวัญใจแฟนแบดมินตันมาเลเซียในช่วยข้ามคืนจากการเอาชนะ หวัง ซี เซียน ซึ่งได้ดึงตัวเองขึ้นมาจากการต่อสู้กับหวัง ซี เซียน ซึ่งผู้ชมต่างลุ้นระทึกในการเชียร์กลางดึกคืนที่ผ่านมา ด้วยคะแนน 15-21 21-19 22-20 ซึ่งผู้เข้าชมต่างหมดลุ้นไปตั้งแต่เกมส์แรก กอปรกับตำแหน่งที่สูงมากของสาวน้อย หวัง ซี เซียน  ซึ่งเธอก็ได้ปาดเหงื่อเอาชนะและพุ่งเข้ากอดผู้ปกครองทันทีที่จบการแข่งขัน\r\n</p>\r\n<p>\r\n	 “ฉันไม่เคยนึกเลยว่าจะได้เข้ามาในรอบสุดท้าย เพราะฉันเข้ามาเป็นอันดับที่เก้าของซูเปอร์ซีรีย์” ซึ่งเอาชนะ หวัง ยี ฮาน จากจีนมาได้\r\n</p>\r\n<p>\r\n	 “ฉันแค่ทำให้ดีที่สุด ตอนนี้แต่แต้ม 14-19 ฉันรู้สึกว่า หวัง ซี เซียน ต้องการเอาชนะมา ฉันเลยลองเปลี่ยนเกมส์เป็นแบบยื้อ ผู้คนต่างให้กำลังใจเมื่อฉันเหนื่อย ซึ่งที่นี่แบดมินตันเป็นกีฬาที่ได้รับความนิยมมาก ซึ่งแฟนๆ ที่เห็นส่วนมากก็เป็นชาวมาเลเซียเสียเกือบทั้งหมด”\r\n</p>','2013-12-15 08:58:54','2013-12-15 08:59:16','news'),(12,'แข่งขันแบดมินตันรายการ Chill  Chill  Badminton  Cup  2014  ครั้งที่  3','chill-chill-badminton-cup-3rd-2014','<span style=\"background-color: rgb(255, 255, 255);\"><font size=\"2\" style=\"color: rgb(49, 48, 49); font-family: Tahoma, Verdana, \'MS Sans Serif\'; line-height: normal;\"><font color=\"#0033cc\"><strong><font size=\"3\">แข่งขันแบดมินตันรายการ Chill&nbsp; Chill&nbsp; Badminton&nbsp; Cup&nbsp; 2014&nbsp; ครั้งที่&nbsp; 3</font></strong></font><br><br>วันเสาร์และอาทิตย์ที่&nbsp; 1-2 กุมภาพันธ์&nbsp; พ.ศ.&nbsp; 2557<br><br>&nbsp;ณ&nbsp; สนามแบดมินตันซีซี<br>________________________________________<br><br><strong><u>1.&nbsp;&nbsp;&nbsp; บทนำ<br><br></u></strong>ชม รมชิลชิลแบดมินตัน(Chill&nbsp; Chill&nbsp; Badminton&nbsp; Club)&nbsp; ก่อตั้งขึ้นเมื่อเดือน&nbsp; มีนาคม&nbsp; 2553&nbsp; ที่สนามแบดมินตันมิตรเสนา&nbsp; ณ&nbsp;&nbsp; 72/1&nbsp; ซอยเสนานิคม&nbsp; 1&nbsp; พหลโยธิน&nbsp; 32&nbsp; แขวงจันทรเกษม&nbsp; เขตจตุจักร&nbsp; กทม.&nbsp; 10900&nbsp; เพื่อเป็นที่ชุมนุมของผู้ชื่นชอบ&nbsp; การออกกำลังกายด้วยกีฬาแบดมินตัน&nbsp; กิจกรรมหลักของชมรมคือ&nbsp; การเล่นแบดมินตันเพื่อออกกำลังกายระหว่างสมาชิกประจำของชมรมฯ&nbsp; และบุคคลทั่วไป&nbsp; ตลอดระยะเวลาที่ผ่านมา&nbsp; ชมรมฯได้ส่งสมาชิกเข้าร่วมการแข่งขันแบดมินตันสมัครเล่นในหลายๆ&nbsp; รายการ&nbsp; และมีผลงานในระดับที่น่าพึงพอใจมาโดยตลอด&nbsp;<br><br><br><u><strong>2.&nbsp;&nbsp;&nbsp; วัตถุประสงค์<br><br></strong></u>2.1.&nbsp;&nbsp;&nbsp; เพื่อส่งเสริมให้กีฬาแบดมินตันเป็นที่นิยมมากขึ้น<br>2.2.&nbsp;&nbsp;&nbsp; เพื่อสนับสนุนให้ผู้ที่ชื่นชอบในกีฬาแบดมินตันมีโอกาสแข่งขัน ทดสอบฝีมือ เพื่อพัฒนาฝีมือ&nbsp;<br>2.3.&nbsp;&nbsp;&nbsp; เพื่อเสริมสร้างพลานามัย&nbsp; ปลูกฝังนํ้าใจนักกีฬา&nbsp; ความมีระเบียบวินัย&nbsp; มีความรับผิดชอบ รู้แพ้&nbsp; รู้ชนะ&nbsp; รู้อภัย<br>2.4.&nbsp;&nbsp;&nbsp; เพื่อใช้ในการทำกิจกรรม&nbsp;&nbsp; หรือบริจาคให้กับสาธารณะกุศลต่อไป<br>2.5.&nbsp;&nbsp;&nbsp; เพื่อเป็นการพัฒนาฝีมือส่งเสริมให้มีกิจกรรมและพบปะสังสรรค์ ระหว่างนักกีฬาแบดมินตันด้วยกัน&nbsp;<br><br><u><strong>3.&nbsp;&nbsp;&nbsp; ประเภทการแข่งขัน<br><br></strong></u>3.1.&nbsp;&nbsp;&nbsp; ประเภทคู่จำกัดมือ&nbsp; รุ่นมือ&nbsp; B+ &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp; 8&nbsp; คู่&nbsp;&nbsp;&nbsp; แข่งขันแบบแบ่งกลุ่มๆ&nbsp; ละ&nbsp; 4&nbsp; ทีม (A คู่ B ลงได้)<br>3.2.&nbsp;&nbsp;&nbsp; ประเภทคู่จำกัดมือ&nbsp; รุ่นมือ&nbsp; B &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp; 16&nbsp; คู่&nbsp;&nbsp;&nbsp; แข่งขันแบบแบ่งกลุ่มๆ&nbsp; ละ&nbsp; 4&nbsp; ทีม (B+ คู่ C+ ลงได้)<br>3.3.&nbsp;&nbsp;&nbsp; ประเภทคู่จำกัดมือ&nbsp; รุ่นมือ&nbsp; C+ &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp; 16&nbsp; คู่&nbsp;&nbsp;&nbsp; แข่งขันแบบแบ่งกลุ่มๆ&nbsp; ละ&nbsp; 4&nbsp; ทีม<br>3.4.&nbsp;&nbsp;&nbsp; ประเภทคู่จำกัดมือ&nbsp; รุ่นมือ&nbsp; C&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp; 32&nbsp; คู่&nbsp;&nbsp;&nbsp; แข่งขันแบบแบ่งกลุ่มๆ&nbsp; ละ&nbsp; 4&nbsp; ทีม<br>3.5.&nbsp;&nbsp;&nbsp; ประเภทคู่จำกัดมือ&nbsp; รุ่นมือ&nbsp; P+&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp; 48&nbsp; คู่&nbsp;&nbsp;&nbsp; แข่งขันแบบแบ่งกลุ่มๆ&nbsp; ละ&nbsp; 4&nbsp; ทีม<br>3.6.&nbsp;&nbsp;&nbsp; ประเภทคู่จำกัดมือ&nbsp; รุ่นมือ&nbsp; P&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp; 48&nbsp; คู่&nbsp;&nbsp;&nbsp; แข่งขันแบบแบ่งกลุ่มๆ&nbsp; ละ&nbsp; 4&nbsp; ทีม<br>3.7.&nbsp;&nbsp;&nbsp; ประเภทคู่จำกัดมือ&nbsp; รุ่นมือ&nbsp; P-&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp; 16&nbsp; คู่&nbsp;&nbsp;&nbsp; แข่งขันแบบแบ่งกลุ่มๆ&nbsp; ละ&nbsp; 4&nbsp; ทีม<br>3.8.&nbsp;&nbsp;&nbsp; ประเภทคู่จำกัดมือ&nbsp; รุ่นมือ&nbsp; S&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp; 16&nbsp; คู่&nbsp;&nbsp;&nbsp; แข่งขันแบบแบ่งกลุ่มๆ&nbsp; ละ&nbsp; 4&nbsp; ทีม<br>3.9.&nbsp;&nbsp;&nbsp; ประเภทคู่จำกัดมือ&nbsp; รุ่นมือ&nbsp; WP&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp; 16&nbsp; คู่&nbsp;&nbsp;&nbsp; แข่งขันแบบแบ่งกลุ่มๆ&nbsp; ละ&nbsp; 4&nbsp; ทีม<br>3.10.&nbsp;&nbsp;&nbsp; ประเภทคู่จำกัดมือ&nbsp; รุ่นมือ&nbsp; WP-&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp; 16&nbsp; คู่&nbsp;&nbsp;&nbsp; แข่งขันแบบแบ่งกลุ่มๆ&nbsp; ละ&nbsp; 4&nbsp; ทีม<br>3.11.&nbsp;&nbsp;&nbsp; ประเภทชายเดี่ยว&nbsp;&nbsp;&nbsp; อายุไม่เกิน 12 ปี &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp;&nbsp; 8 &nbsp; คน &nbsp;&nbsp;&nbsp; แข่งขันแบบแพ้คัดออก( Knock&nbsp; Out)<br>3.12.&nbsp;&nbsp;&nbsp; ประเภทหญิงเดี่ยว อายุไม่เกิน 12 ปี &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; จำนวน&nbsp;&nbsp;&nbsp; 8&nbsp;&nbsp; คน &nbsp;&nbsp;&nbsp; แข่งขันแบบแพ้คัดออก( Knock&nbsp; Out)<br>หมาย เหตุ&nbsp;&nbsp; ประเภทใดมีผู้สมัครน้อยกว่า&nbsp; 8&nbsp; คู่&nbsp; คณะกรรมการจัดการแข่งขันจะยกเลิกการแข่งขันประเภทนั้น&nbsp;&nbsp; ถ้าเกินจำนวนที่รับสมัคร อาจจะพิจารณาปรับเพิ่มจำนวนคู่&nbsp; ตามความเหมาะสมของเวลาของการจัดแข่ง<br></font><br style=\"color: rgb(49, 48, 49); font-family: Tahoma, Verdana, \'MS Sans Serif\'; font-size: x-small; line-height: normal;\"></span><hr style=\"color: rgb(118, 142, 183); border-bottom-style: dotted; border-top-style: dotted; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; font-family: Tahoma, Verdana, \'MS Sans Serif\'; font-size: x-small; line-height: normal;\"><span style=\"background-color: rgb(255, 255, 255);\"><font size=\"2\" style=\"color: rgb(49, 48, 49); font-family: Tahoma, Verdana, \'MS Sans Serif\'; line-height: normal;\"><br></font><br style=\"color: rgb(49, 48, 49); font-family: Tahoma, Verdana, \'MS Sans Serif\'; font-size: x-small; line-height: normal;\"><font size=\"2\" style=\"color: rgb(49, 48, 49); font-family: Tahoma, Verdana, \'MS Sans Serif\'; line-height: normal;\"><span class=\"newbb_plus_css\"><font size=\"3\"><font color=\"#cc0000\"><u><strong>มือ S มาจาก Start</strong></u></font><br><br>สืบ เนื่องจากรายการ Chill Chill Cup 2013 เราคิดว่า ณ ตอนนี้ คนหันมาสนใจเล่นแบด และลงแข่งแบดในเว็บมากขึ้นกว่าก่อนมาก รวมทั้ง หลายๆ คน อายุอานาม เริ่มมาก<br><br>ส่งผลให้หลายๆ คนมีการปรับมือ ร่นลงมาเล่น รุ่นที่ต่ำกว่าเดิมเรื่อยๆ ซึ่งมันเป็นวัฎจักรของอายุคน<br><br>ส่งผลให้ แต่ละรุ่นมือ มันดูแข็งแกร่งมากขึ้น<br><br>ทำ ให้พื้นที่ยืน สำหรับกลุ่มที่ เป็นมือ พีลบ เบาๆ หรือกลุ่มที่เพิ่งเริ่มหัดเล่นใหม่ๆ ไม่มีเบสิค จะไม่มีที่ยืนในวงการแข่งแบดในเว็บนี้<br><br><u><strong>เราจึงอยากให้ มือ S เป็นกลุ่มของคนที่เพิ่งเริ่มเล่นใหม่ๆ ไม่มีเบสิค อะไรเลย</strong></u>&nbsp;มาร่วมแข่งขัน หาประสบการณ์ รับรู้อารมณ์ และสภาวะความกดดันในสนามแข่งบ้างนะครับ<br></font></span></font></span><hr style=\"color: rgb(118, 142, 183); border-bottom-style: dotted; border-top-style: dotted; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; font-family: Tahoma, Verdana, \'MS Sans Serif\'; font-size: x-small; line-height: normal;\"><span style=\"background-color: rgb(255, 255, 255);\"><font size=\"2\" style=\"color: rgb(49, 48, 49); font-family: Tahoma, Verdana, \'MS Sans Serif\'; line-height: normal;\"><span class=\"newbb_plus_css\"><font size=\"3\"><br></font></span><br><u><strong>4.&nbsp;&nbsp;&nbsp; รางวัลในการแข่งขัน<br><br></strong></u>4.1.&nbsp;&nbsp;&nbsp; ประเภทคู่จำกัดมือ&nbsp; รุ่นมือ&nbsp; B+&nbsp;<br>•&nbsp;&nbsp;&nbsp; ชนะเลิศ&nbsp; รับเงินรางวัล&nbsp; 6,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>•&nbsp;&nbsp;&nbsp; รองชนะเลิศอันดับหนึ่ง&nbsp; รับเงินรางวัล&nbsp; 4,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>•&nbsp;&nbsp;&nbsp; รองชนะเลิศอันดับสอง&nbsp;&nbsp; (มี&nbsp; 2 รางวัล)&nbsp;&nbsp; รับเงินรางวัล&nbsp; 2,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>4.2.&nbsp;&nbsp;&nbsp; ประเภทคู่จำกัดมือ&nbsp; รุ่นมือ&nbsp; B&nbsp;<br>•&nbsp;&nbsp;&nbsp; ชนะเลิศ&nbsp; รับเงินรางวัล&nbsp; 4,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>•&nbsp;&nbsp;&nbsp; รองชนะเลิศอันดับหนึ่ง&nbsp; รับเงินรางวัล&nbsp; 2,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>•&nbsp;&nbsp;&nbsp; รองชนะเลิศอันดับสอง&nbsp;&nbsp; (มี&nbsp; 2 รางวัล)&nbsp;&nbsp; รับเงินรางวัล&nbsp; 1,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>4.3.&nbsp;&nbsp;&nbsp; ประเภทคู่จำกัดมือ&nbsp; รุ่นมือ&nbsp; C+&nbsp;<br>•&nbsp;&nbsp;&nbsp; ชนะเลิศ&nbsp; รับเงินรางวัล&nbsp; 4,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>•&nbsp;&nbsp;&nbsp; รองชนะเลิศอันดับหนึ่ง&nbsp; รับเงินรางวัล&nbsp; 2,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>•&nbsp;&nbsp;&nbsp; รองชนะเลิศอันดับสอง&nbsp;&nbsp; (มี&nbsp; 2 รางวัล)&nbsp;&nbsp; รับเงินรางวัล&nbsp; 1,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>4.4.&nbsp;&nbsp;&nbsp; ประเภทคู่จำกัดมือ&nbsp; รุ่นมือ&nbsp; C&nbsp;<br>•&nbsp;&nbsp;&nbsp; ชนะเลิศ&nbsp; รับเงินรางวัล&nbsp; 4,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>•&nbsp;&nbsp;&nbsp; รองชนะเลิศอันดับหนึ่ง&nbsp; รับเงินรางวัล&nbsp; 2,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>•&nbsp;&nbsp;&nbsp; รองชนะเลิศอันดับสอง&nbsp;&nbsp; (มี&nbsp; 2 รางวัล)&nbsp;&nbsp; รับเงินรางวัล&nbsp; 1,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>4.5.&nbsp;&nbsp;&nbsp; ประเภทคู่จำกัดมือ&nbsp; รุ่นมือ&nbsp; P+&nbsp;<br>•&nbsp;&nbsp;&nbsp; ชนะเลิศ&nbsp; รับเงินรางวัล&nbsp; 4,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>•&nbsp;&nbsp;&nbsp; รองชนะเลิศอันดับหนึ่ง&nbsp; รับเงินรางวัล&nbsp; 2,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>•&nbsp;&nbsp;&nbsp; รองชนะเลิศอันดับสอง&nbsp;&nbsp; (มี&nbsp; 2 รางวัล)&nbsp;&nbsp; รับเงินรางวัล&nbsp; 1,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>4.6.&nbsp;&nbsp;&nbsp; ประเภทคู่จำกัดมือ&nbsp; รุ่นมือ&nbsp; P&nbsp;<br>•&nbsp;&nbsp;&nbsp; ชนะเลิศ&nbsp; รับเงินรางวัล&nbsp; 4,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>•&nbsp;&nbsp;&nbsp; รองชนะเลิศอันดับหนึ่ง&nbsp; รับเงินรางวัล&nbsp; 2,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>•&nbsp;&nbsp;&nbsp; รองชนะเลิศอันดับสอง&nbsp;&nbsp; (มี&nbsp; 2 รางวัล)&nbsp;&nbsp; รับเงินรางวัล&nbsp; 1,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>4.7.&nbsp;&nbsp;&nbsp; ประเภทคู่จำกัดมือ&nbsp; รุ่นมือ&nbsp; P-&nbsp;<br>•&nbsp;&nbsp;&nbsp; ชนะเลิศ&nbsp; รับเงินรางวัล&nbsp; 4,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>•&nbsp;&nbsp;&nbsp; รองชนะเลิศอันดับหนึ่ง&nbsp; รับเงินรางวัล&nbsp; 2,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>•&nbsp;&nbsp;&nbsp; รองชนะเลิศอันดับสอง&nbsp;&nbsp; (มี&nbsp; 2 รางวัล)&nbsp;&nbsp; รับเงินรางวัล&nbsp; 1,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>4.8.&nbsp;&nbsp;&nbsp; ประเภทคู่จำกัดมือ&nbsp; รุ่นมือ&nbsp; S&nbsp;<br>•&nbsp;&nbsp;&nbsp; ชนะเลิศ&nbsp; รับเงินรางวัล&nbsp; 4,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>•&nbsp;&nbsp;&nbsp; รองชนะเลิศอันดับหนึ่ง&nbsp; รับเงินรางวัล&nbsp; 2,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>•&nbsp;&nbsp;&nbsp; รองชนะเลิศอันดับสอง&nbsp;&nbsp; (มี&nbsp; 2 รางวัล)&nbsp;&nbsp; รับเงินรางวัล&nbsp; 1,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>4.9.&nbsp;&nbsp;&nbsp; ประเภทคู่จำกัดมือ&nbsp; รุ่นมือ&nbsp; WP&nbsp;<br>•&nbsp;&nbsp;&nbsp; ชนะเลิศ&nbsp; รับเงินรางวัล&nbsp; 2,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>•&nbsp;&nbsp;&nbsp; รองชนะเลิศอันดับหนึ่ง&nbsp; รับเงินรางวัล&nbsp; 1,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>•&nbsp;&nbsp;&nbsp; รองชนะเลิศอันดับสอง&nbsp;&nbsp; (มี&nbsp; 2 รางวัล)&nbsp;&nbsp; รับเงินรางวัล&nbsp; 500&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>4.10.&nbsp;&nbsp;&nbsp; ประเภทคู่จำกัดมือ&nbsp; รุ่นมือ&nbsp; WP-&nbsp;<br>•&nbsp;&nbsp;&nbsp; ชนะเลิศ&nbsp; รับเงินรางวัล&nbsp; 2,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>•&nbsp;&nbsp;&nbsp; รองชนะเลิศอันดับหนึ่ง&nbsp; รับเงินรางวัล&nbsp; 1,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>•&nbsp;&nbsp;&nbsp; รองชนะเลิศอันดับสอง&nbsp;&nbsp; (มี&nbsp; 2 รางวัล)&nbsp;&nbsp; รับเงินรางวัล&nbsp; 500&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลและประกาศนียบัตร<br>4.11.&nbsp;&nbsp;&nbsp; ประเภทชายเดี่ยว&nbsp; รุ่นอายุไม่เกิน&nbsp; 12&nbsp; ปี<br>•&nbsp;&nbsp;&nbsp; ชนะเลิศ&nbsp; รับเงินรางวัล&nbsp; 1,500&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลรางวัลและประกาศนียบัตร<br>•&nbsp;&nbsp;&nbsp; รองชนะเลิศอันดับหนึ่ง&nbsp; รับเงินรางวัล&nbsp; 1,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลรางวัล และประกาศนียบัตร<br>•&nbsp;&nbsp;&nbsp; รองชนะเลิศอันดับสอง&nbsp;&nbsp; (มี&nbsp; 2 รางวัล)&nbsp;&nbsp; รับเงินรางวัล&nbsp; 500&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลรางวัลและประกาศนียบัตร<br>4.12.&nbsp;&nbsp;&nbsp; ประเภทหญิงเดี่ยว&nbsp; รุ่นอายุไม่เกิน&nbsp; 12&nbsp; ปี<br>•&nbsp;&nbsp;&nbsp; ชนะเลิศ&nbsp; รับเงินรางวัล&nbsp; 1,500&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลรางวัลและประกาศนียบัตร<br>•&nbsp;&nbsp;&nbsp; รองชนะเลิศอันดับหนึ่ง&nbsp; รับเงินรางวัล&nbsp; 1,000&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลรางวัล และประกาศนียบัตร<br>•&nbsp;&nbsp;&nbsp; รองชนะเลิศอันดับสอง&nbsp;&nbsp; (มี&nbsp; 2 รางวัล)&nbsp;&nbsp; รับเงินรางวัล&nbsp; 500&nbsp; บาท&nbsp; พร้อมถ้วยรางวัลรางวัลและประกาศนียบัตร<br><br><u><strong>5.&nbsp;&nbsp;&nbsp; คุณสมบัติของนักกีฬา&nbsp;<br><br></strong></u>5.1.&nbsp;&nbsp;&nbsp; นักกีฬาหญิงที่ติดทีมชาติชุดปัจจุบัน&nbsp; ต้องลงแข่งขันในประเภท&nbsp; B+&nbsp; หรือตามแต่คณะกรรมการพิจารณามือ&nbsp; ให้ลงทำการแข่งขันตามความเหมาะสม<br>5.2.&nbsp;&nbsp;&nbsp; ประเภทเยาวชนรุ่นอายุไม่เกิน&nbsp; 12&nbsp; ปี&nbsp; นักกีฬาต้องไม่เกิดก่อนปี&nbsp; 2545<br>5.3.&nbsp;&nbsp;&nbsp; ผู้สมัครลงแข่งขันทุกประเภท&nbsp; จะต้องผ่านการพิจารณาคุณสมบัติโดยคณะกรรมการพิจารณามือ<br>5.4.&nbsp;&nbsp;&nbsp; ในกรณีที่นักกีฬามีสังกัดชมรม หรือ&nbsp; กลุ่ม&nbsp; จะต้องระบุไว้ในการสมัครให้ชัดเจน&nbsp; พร้อมแจ้งเบอร์โทรที่ติดต่อประสานงานได้สะดวก&nbsp; เพื่อสะดวกในการติดต่อและการจัดสายการแข่งขัน<br>5.5.&nbsp;&nbsp;&nbsp; ในประเภทมือ&nbsp; P- P C&nbsp; C+&nbsp; B&nbsp; B+&nbsp; สามารถอ้างอิงระดับฝีมือโดยใช้&nbsp; Chill Chill Badminton Cup 2013, Chill Chill Badminton Cup 2011, Li-Ning Badminton Cup 2011, MMOA Badminton Cup 2011, รายการดันลอป&nbsp; 18&nbsp; คอร์ทราชพฤกษ์ 2013&nbsp; ในบางกรณีได้&nbsp; ทั้งนี้&nbsp; คณะกรรมการจะพิจารณาอีกครั้ง&nbsp; หลังจากที่สมัคร<br><br><u><strong>6.&nbsp;&nbsp;&nbsp; การพิจารณาระดับฝีมือ<br><br></strong></u><strong>6.1.&nbsp;&nbsp;&nbsp; คณะกรรมการจัดการแข่งขันมีสิทธิ์ขาดในการพิจารณาระดับฝีมือแต่ละท่าน&nbsp; โดยคำตัดสินของคณะกรรมการถือเป็นข้อยุติ&nbsp; ทั้งนี้อ้างอิงตัวอย่างระดับฝีมือ&nbsp; ตามที่กำหนดไว้ได้</strong><br>6.2.&nbsp;&nbsp;&nbsp; ให้หัวหน้าทีมที่ส่งทำการแข่งขันรับรองระดับฝีมือ&nbsp; พร้อมเบอร์โทรติดต่อของหัวหน้าทีม<br>6.3.&nbsp;&nbsp;&nbsp; ในการสมัครกรุณากรอกข้อมูลให้ครบถ้วน&nbsp; โดยเฉพาะเบอร์ติดต่อของนักกีฬา<br><strong>6.4.&nbsp;&nbsp;&nbsp; กรณีประเภทมือ WP- WP S P- P P+ C และ C+&nbsp; นักกีฬาต้องลงทำการแข่งขันในรุ่นตัวเองหรือสูงกว่าเท่านั้น&nbsp; กรณีบางคู่&nbsp; ที่มีการจับคู่กันแบบต่างมือ&nbsp; ให้ลงในรุ่นที่สูงที่สุด&nbsp; ของคู่นั้นๆ&nbsp; เช่น<br>•&nbsp;&nbsp;&nbsp; นาย&nbsp; ก&nbsp; เป็นนักกีฬามือ P<br>•&nbsp;&nbsp;&nbsp; นาย ข&nbsp; เป็นนักกีฬามือ&nbsp; C<br>ดังนั้น&nbsp; หากนาย&nbsp; ก&nbsp; จับคู่กับนาย&nbsp; ข&nbsp; จะต้องลงในรุ่น&nbsp; มือ&nbsp; C&nbsp; ขึ้นไปเท่านั้น<br><br>6.5.&nbsp;&nbsp;&nbsp; ในรุ่นมือ B+ อนุญาตให้ลงแบบคุมมือได้ ตามนี้เท่านั้น<br>•&nbsp;&nbsp;&nbsp; A ต้องจับคู่กับคนระดับมือไม่เกิน B เท่านั้น<br>•&nbsp;&nbsp;&nbsp; ห้ามระดับมือ A ลงมาตีมือ B<br><br>6.6.&nbsp;&nbsp;&nbsp; ในรุ่นมือ B อนุญาตให้ลงแบบคุมมือได้ ตามนี้เท่านั้น<br>•&nbsp;&nbsp;&nbsp; B+ ต้องจับคู่กับคนระดับมือไม่เกิน C+ เท่านั้น<br>•&nbsp;&nbsp;&nbsp; ห้ามระดับมือ A ลงมาตีมือ B<br><br></strong>6.7.&nbsp;&nbsp;&nbsp; นักกีฬาที่สนใจสมัครการแข่งขัน&nbsp; แต่ไม่สามารถประเมินระดับฝีมือของตัวเองได้&nbsp; สามารถดำเนินการได้ดังนี้<br>•&nbsp;&nbsp;&nbsp; เข้ามาทดสอบฝีมือ&nbsp; เพื่อให้คณะกรรมการพิจารณามือ&nbsp; ได้ในวันเวลาดังนี้<br>6.7.1.&nbsp;&nbsp;&nbsp; ทุกวันอังคาร&nbsp; เวลา&nbsp; 20.00 – 01.00 น.<br>6.7.2.&nbsp;&nbsp;&nbsp; ทุกวันศุกร์&nbsp; เวลา&nbsp; 20.00 – 02.00&nbsp; น.<br>สามารถเข้ามาทดสอบได้ที่&nbsp; สนามมิตรเสนา&nbsp; ซอยพหลโยธิน&nbsp; 32 (เสนานิคม&nbsp; 1&nbsp; ซอย 2) ใกล้เมเจอร์รัชโยธิน<br>กรุณาโทรแจ้งล่วงหน้า&nbsp; เพื่อจัดเตรียมสนามรองรับไว้&nbsp; ให้ทดสอบ<br>•&nbsp;&nbsp;&nbsp; ติดต่อนัดหมายกับคณะกรรมการพิจารณามือ&nbsp; ให้ประเมินมือ&nbsp; ณ&nbsp; ที่ต่างๆ&nbsp; ตามวันและเวลาที่คณะกรรมการสะดวก<br>•&nbsp;&nbsp;&nbsp; ดูได้จากวิดีโอที่คณะกรรมการพิจารณามือจัดเตรียมไว้<br>•&nbsp;&nbsp;&nbsp; ดูได้จากตารางบุคคลมืออ้างอิงในมือต่างๆ&nbsp; เพื่อพิจารณาตัวเอง&nbsp; ว่าประมาณใคร<br>•&nbsp;&nbsp;&nbsp; โทรติดต่อสอบถาม&nbsp; แจ้งบุคคลอ้างอิง&nbsp; พร้อมทั้ง&nbsp; นักกีฬาที่ฝีมือใกล้เคียงกับนักกีฬาที่สอบถาม<br><br>&nbsp;<br><u><strong><font size=\"3\">7.&nbsp;&nbsp;&nbsp; ข้อตกลงร่วมกัน</font><br><br></strong></u><strong>7.1.&nbsp;&nbsp;&nbsp; คำตัดสินในทุกกรณีของคณะกรรมการ&nbsp; ให้ถือเป็นข้อยุติ</strong><br>7.2.&nbsp;&nbsp;&nbsp; นักกีฬาต้องทำการตรวจสอบชื่อจริง&nbsp; พร้อมทั้งชื่อเล่น&nbsp; ที่ส่งเข้าร่วมการแข่งขันให้ถูกต้อง&nbsp; ก่อนวันแข่งขัน&nbsp; ทั้งนี้ในวันทำการแข่งขัน&nbsp; กรุณานำบัตรทางราชการ&nbsp; เพื่อเป็นการยืนยันตัวตน<br>7.3.&nbsp;&nbsp;&nbsp; ถ้าคณะกรรมการพิจารณาเห็นว่า&nbsp; นักกีฬาจงใจให้ข้อมูลอันเป็นเท็จ&nbsp; เช่น&nbsp; ชื่อ-นามสกุล,&nbsp; ระดับฝีมือ&nbsp; เป็นต้น&nbsp; คณะกรรมการมีสิทธิ์ตัดสิทธิ์การแข่งขัน&nbsp; โดยไม่คืนเงินค่าสมัคร<br><font size=\"3\"><u><strong>7.4.&nbsp;&nbsp;&nbsp; ในกรณีถูกตัดสิทธิ์การแข่งขัน&nbsp; คณะกรรมการไม่คืนเงินที่เข้าร่วมการแข่งขัน</strong></u></font><br>7.5.&nbsp;&nbsp;&nbsp; หากตรวจสอบพบว่า&nbsp;&nbsp; ไม่ซื่อสัตย์&nbsp; ต่อการเข้าร่วมการแข่งขันในทุกกรณี&nbsp; คณะกรรมการสามารถตัดสิทธิ์การแข่งขันได้ทันที<br>7.6.&nbsp;&nbsp;&nbsp; ในวันทำการแข่งขันจริง&nbsp; หากคณะกรรมการพิจารณามือ&nbsp; พบนักกีฬาท่านใด&nbsp; ไม่ซื่อสัตย์ในการเข้าร่วมแข่งขัน&nbsp; มีการลงในรุ่นมือที่ต่ำกว่าที่ควรจะเป็น&nbsp; แม้จะผ่านการรับรองจากคณะกรรมการพิจารณามือ&nbsp; ก่อนการแข่งขันแล้วนั้น&nbsp;&nbsp; คณะกรรมการสามารถตัดสิทธิ์การแข่งขันได้ในทันที&nbsp; โดยไม่จำเป็นต้องมีผู้ประท้วง<br>7.7.&nbsp;&nbsp;&nbsp; การประท้วงระดับฝีมือของนักกีฬาก่อนวันแข่งขันจะต้องแจ้งรายละเอียด&nbsp; เช่น&nbsp; ประเภท&nbsp; ชื่อ&nbsp; ระดับฝีมือ&nbsp; ส่งทาง<br>•&nbsp;&nbsp;&nbsp; E-Mail&nbsp; มาที่&nbsp;&nbsp;<img src=\"http://www.thaibadminton.com/main/cache/email/moc_liamg_dabllihcllihc.png\" border=\"0\" alt=\"ThaiBadminton.com spam-mail protection system\" title=\"ThaiBadminton.com spam-mail protection system\">&nbsp;&nbsp;<br>•&nbsp;&nbsp;&nbsp; PM&nbsp; แจ้งทางคณะกรรมการ&nbsp; ผ่านทางเว็บบอร์ดของเว็บไทยแบดมินตัน<br>•&nbsp;&nbsp;&nbsp; แจ้งทาง&nbsp; Facebook&nbsp; ของชมรมที่&nbsp;&nbsp;<a href=\"http://www.facebook.com/ChillChillBadminton\" target=\"_blank\" style=\"color: rgb(0, 0, 0);\">http://www.facebook.com/ChillChillBadminton</a><br>•&nbsp;&nbsp;&nbsp; แจ้งผ่านทางเว็บไซต์&nbsp;&nbsp;<a href=\"http://www.chillchillbadminton.com/\" target=\"_blank\" style=\"color: rgb(0, 0, 0);\">http://www.chillchillbadminton.com</a><br><font size=\"3\"><u><strong>7.8.&nbsp;&nbsp;&nbsp; ในการประท้วง&nbsp; หรือปรับมือนั้น&nbsp; คณะกรรมการพิจารณามือ&nbsp; มีสิทธิ์ขาด&nbsp; สามารถตัดสินได้โดยไม่จำเป็นต้องมีผู้ประท้วงอ้างอิง</strong></u></font><br>7.9.&nbsp;&nbsp;&nbsp; ในการตัดสิทธิ์&nbsp; หรือปรับมือนั้น&nbsp; คณะกรรมการพิจารณามือ&nbsp; สามารถกระทำได้ทุกรอบการแข่งขัน&nbsp; แม้กระทั่งรอบชิงชนะเลิศ&nbsp; เนื่องจากนักกีฬาไม่ซื่อสัตย์ต่อตนเองและผู้เข้าร่วมการแข่งขันท่านอื่นๆ<br>7.10.&nbsp;&nbsp;&nbsp; ในการประท้วง&nbsp; หากนักกีฬาที่เข้าร่วมการแข่งขันท่านใด&nbsp; พบเห็นนักกีฬาบางคู่&nbsp; ไม่ได้ลงตามมือที่ควรจะเป็น&nbsp; สามารถโทรแจ้งมาได้ที่คณะกรรมการพิจารณามือที่&nbsp; 089-925-3325&nbsp; โดยไม่จำเป็นต้อง&nbsp; แจ้งชื่อ&nbsp; ทั้งนี้&nbsp; คณะกรรมการพิจารณามือ&nbsp; จะเข้าไปตรวจสอบด้วยตนเอง&nbsp; โดยท่านไม่จำเป็นต้องติดตามคณะ&nbsp; คณะกรรมการจะเข้าไปประเมินมือให้อีกครั้ง&nbsp; แต่ต้องถือการตัดสินของกรรมการเป็นข้อยุติ&nbsp; ทั้งนี้สามารถสอบถามผลและเหตุผลการประเมินได้<br>7.11.&nbsp;&nbsp;&nbsp; คณะกรรมการจะมีทีมงาน&nbsp; ที่คอยสอดส่องในการประเมินมือ&nbsp; ทุกรอบการแข่งขัน&nbsp; และทุกสนาม&nbsp; ดังนั้นนักกีฬา&nbsp; ควรเล่นให้เต็มฝีมือ&nbsp; เพื่อป้องกันการโดนตัดสิทธิ์การแข่งขัน<br>7.12.&nbsp;&nbsp;&nbsp; กรณีบางรุ่นไม่เต็มตามจำนวนรับสมัคร อาจจะมีบางกลุ่ม&nbsp; มีเพียง&nbsp; 3&nbsp; คู่&nbsp; และอีก&nbsp; 1&nbsp; คู่สำรอง&nbsp; เพราะฉะนั้น&nbsp; ในวันแข่งขันจริง&nbsp; อาจจะมีหรือไม่มีคู่สำรองได้<br>7.13.&nbsp;&nbsp;&nbsp; ในกรณีโดนปรับแพ้&nbsp; จะไม่คืนเงินค่าสมัคร<br>7.14.&nbsp;&nbsp;&nbsp; หากมีการแก้ไขเปลี่ยนแปลงการแข่งขัน&nbsp; คณะกรรมการสามารถปรับเปลี่ยนได้ตามความเหมาะสม&nbsp; ที่คณะกรรมการจัดการแข่งขันเห็นควร&nbsp; โดยไม่จำเป็นต้องแจ้งล่วงหน้า&nbsp; ทั้งนี้&nbsp; คณะกรรมการจะแจ้งให้ทราบในภายหลัง&nbsp; หรือก่อนหน้า&nbsp; ตามความเหมาะสม<br>7.15.&nbsp;&nbsp;&nbsp; ในวันแข่งขัน&nbsp; อนุญาตให้แจ้งเปลี่ยนรายชื่อได้&nbsp; หากมีเหตุความจำเป็น&nbsp; คณะกรรมการอาจพิจารณาอนุญาต&nbsp; ให้เปลี่ยนตัวผู้แข่งขัน&nbsp;&nbsp;&nbsp; ทั้งนี้&nbsp; หากนักกีฬาที่เปลี่ยนใหม่&nbsp; ไม่ได้ลงในรุ่นที่เป็นรุ่นตัวเอง&nbsp; คณะกรรมการจะตัดสิทธิ์การแข่งขัน&nbsp; โดยไม่คืนเงินค่าสมัคร<br>7.16.&nbsp;&nbsp;&nbsp; ในการสมัคร โปรดแจ้งไซต์เสื้อ ให้กับทีมงาน หากไม่แจ้ง ทีมงานขอให้เสื้อไซต์ L หรือ M โดยไม่ต้องติดตามสอบถามนักกีฬา ทั้งนี้รวมถึงผู้สมัครที่สมัครเข้ามาหลังจากที่ทีมงานทำการสั่งเสื้อแล้ว<br><br><u><strong>8.&nbsp;&nbsp;&nbsp; การรับสมัคร&nbsp;<br><br></strong></u><font size=\"3\"><strong>8.1.&nbsp;&nbsp;&nbsp; สามารถสมัครผ่านลิงค์&nbsp;&nbsp;<a href=\"http://www.chillchillbadminton.com/\" target=\"_blank\" style=\"color: rgb(0, 0, 0);\">www.chillchillbadminton.com</a>&nbsp;&nbsp; เท่านั้น</strong></font><br>8.2.&nbsp;&nbsp;&nbsp; กรุณาอ่านวิธีและเงื่อนไข&nbsp; ของการสมัครให้ละเอียดและเข้าใจ&nbsp; เพื่อประโยชน์ในการสมัครของตัวท่านเอง<br>8.3.&nbsp;&nbsp;&nbsp; การพิจารณาระดับฝีมือจะทำโดยคณะกรรมการพิจารณามือ&nbsp; หรือพิจารณาจากข้อมูล ที่ได้รับจากบุคคลอ้างอิง&nbsp; แต่ถ้ามีการให้ข้อมูลระดับฝีมือที่เป็นเท็จ ทางคณะกรรมการจัดการแข่งขันสามารถตัดสิทธิ์ในการลงแข่งขันได้<br>8.4.&nbsp;&nbsp;&nbsp; คณะกรรมการทำการพิจารณารายชื่อนักกีฬาที่สมัคร&nbsp; และจะประกาศผลการสมัครทางหน้าเว็บไซด์&nbsp; พร้อมทั้งจะระบุผลการพิจารณา&nbsp; จะประกาศผลทางเว็บไซต์&nbsp;&nbsp;</font><font size=\"2\" style=\"color: rgb(49, 48, 49); font-family: Tahoma, Verdana, \'MS Sans Serif\'; line-height: normal;\"><font size=\"2\"><font size=\"3\"><strong><a href=\"http://www.chillchillbadminton.com/\" target=\"_blank\" style=\"color: rgb(0, 0, 0);\">www.chillchillbadminton.com</a></strong></font></font>&nbsp;เท่านั้น<br>8.5.&nbsp;&nbsp;&nbsp; คณะกรรมการจะประกาศรายชื่อนักกีฬาที่สมัครลงแข่งขัน และทำการลงรายชื่อ พร้อมเรียงลำดับการสมัคร&nbsp;<br>8.6.&nbsp;&nbsp;&nbsp; นักกีฬาที่มีคุณสมบัติผ่าน&nbsp; แต่ชำระเงินค่าสมัครล่าช้าเกินกว่าวันที่กำหนด&nbsp; จะถูกปรับลำดับไปอยู่ท้ายรายชื่อสำรอง&nbsp; และนักกีฬาที่อยู่ในรายชื่อสำรอง&nbsp; จะถูกนำมาพิจารณาเป็นลำดับต่อไป&nbsp;<br>8.7.&nbsp;&nbsp;&nbsp; นักกีฬาคู่ใดที่ไม่ผ่านคุณสมบัติ&nbsp; ทางคณะกรรมอนุญาตให้แก้ไขรายชื่อให้คณะกรรมการพิจารณาอีกครั้งได้<br>8.8.&nbsp;&nbsp;&nbsp; ลำดับในการสมัคร จะพิจารณาตามเวลาการสมัครเข้ามา โดยไม่แบ่งแยกรุ่นมือ ทั้งนี้ ให้ถือว่าผู้สมัครทุกคน ยังไม่ได้ผ่านการพิจารณา ทำให้หลังจากการพิจารณาประเมินมือให้แล้วนั้น อาจจะมีการปรับเปลี่ยนรุ่นที่สมัครเข้ามา มีผลทำให้มีการไปแทรก ผู้สมัครท่านอื่น ในรุ่นนั้นๆ ทั้งนี้ สามารถตรวจสอบเวลาการสมัครเข้ามาในระบบได้<br>8.9.&nbsp;&nbsp;&nbsp; ไม่รับสมัครโดยตรงกับทางคณะกรรมการ และไม่มีการจองโควตา ให้สมัครผ่านทางเว็บไซต์เท่านั้น<br><u><br></u><strong><u>9.&nbsp;&nbsp;&nbsp; อัตราค่าสมัครและค่าใช้จ่ายอื่นๆ</u><br><br>9.1.&nbsp;&nbsp;&nbsp; รุ่นจำกัดมือ&nbsp; WP- WP&nbsp; S P-&nbsp; P&nbsp; P+&nbsp; C&nbsp; C+&nbsp; B&nbsp; B+&nbsp; ค่าสมัครคู่ละ 800&nbsp; บาท&nbsp;&nbsp; โดยนักกีฬาจะได้เสื้อ คนละ 1 ตัว&nbsp;<br>9.2.&nbsp;&nbsp;&nbsp; รุ่นเยาวชนอายุไม่เกิน&nbsp; 12&nbsp; ปี&nbsp; ค่าสมัครคนละ&nbsp; 300&nbsp; บาท<br>สามารถชำระได้โดยโอนผ่านบัญชีธนาคาร<br>•&nbsp;&nbsp;&nbsp; ธนาคารไทยพาณิชย์&nbsp; สาขาโชคชัย 4&nbsp; ประเภทออมทรัพย์<br>•&nbsp;&nbsp;&nbsp; ชื่อบัญชี&nbsp; นางสาวฐานิตา&nbsp; เตชะมานนท์&nbsp;&nbsp; เลขที่บัญชี&nbsp; 127-222-9999</strong><br><br>หมาย เหตุ : กรุณาโอนเงินเป็นเศษสตางค์ เช่น 800.07 บาท&nbsp;&nbsp; กรณีชำระเงินผ่านตู้&nbsp; A.T.M&nbsp; กรุณาส่ง&nbsp; SMS&nbsp; จากตู้ A.T.M (ฟรี)&nbsp; แจ้งไปยังหมายเลขโทรศัพท์&nbsp; 083-996-5144&nbsp; (พีท) เพื่อสะดวกในการตรวจสอบ&nbsp; หรือสแกนส่งเมล์มาที่&nbsp;&nbsp;<img src=\"http://www.thaibadminton.com/main/cache/email/moc_liamg_dabllihcllihc.png\" border=\"0\" alt=\"ThaiBadminton.com spam-mail protection system\" title=\"ThaiBadminton.com spam-mail protection system\">&nbsp; (โปรดเก็บหลักฐานการโอนเงินไว้ด้วย)<br><br>9.3.&nbsp;&nbsp;&nbsp; ค่าลูกจ่ายตามจริง&nbsp; 15&nbsp; บาท/ลูก/คน&nbsp;&nbsp; ในการแข่งขันจะใช้ลูกขนไก่&nbsp; Victor Champions No.1 speed 75<br>9.4.&nbsp;&nbsp;&nbsp; ค่าลูกจะจัดจำหน่ายเป็นคูปอง&nbsp; เล่มละ&nbsp; 300&nbsp; บาท&nbsp; โดยจะต้องทำการซื้อคูปองก่อนลงทำการแข่งขัน&nbsp; และมอบคูปองให้กับกรรมการเมื่อทำการแข่งขันจบในแต่ละเกม&nbsp; กรณีขอแลกคืนเงินค่าคูปอง&nbsp; ต้องทำการแลกเปลี่ยนวันต่อวันเท่านั้น<br><br><u><strong>10.&nbsp;&nbsp;&nbsp; วิธีการสมัครแข่งขัน<br><br></strong></u>10.1.&nbsp;&nbsp;&nbsp; แจ้งรายละเอียดการสมัครให้ครบถ้วน&nbsp; ประกอบด้วย<br>•&nbsp;&nbsp;&nbsp; รุ่นที่ต้องการลงแข่งขัน&nbsp;<br>•&nbsp;&nbsp;&nbsp; ชื่อ-นามสกุล,&nbsp; ชื่อเล่น,&nbsp; สังกัด,&nbsp; เบอร์โทรศัพท์&nbsp; และ&nbsp; email&nbsp; ที่ติดต่อได้<br>•&nbsp;&nbsp;&nbsp; รูปภาพตัวเองให้เห็นใบหน้าชัดเจน&nbsp; เพื่อช่วยในการพิจารณา&nbsp; กรณีไม่มีรูป&nbsp; สามารถถ่ายด้วยมือถือ&nbsp; ส่งมาพร้อมรายละเอียดการสมัคร&nbsp; เพื่อให้ทางทีมงานอัพโหลดให้&nbsp; ที่&nbsp; 089-925-3325<br>•&nbsp;&nbsp;&nbsp; บุคคลอ้างอิง/&nbsp; ผู้ประสานงาน/&nbsp; ผู้จัดการทีม&nbsp; เบอร์โทรติดต่อ<br>•&nbsp;&nbsp;&nbsp; ประวัติการแข่งขันรายการต่างๆ&nbsp; อาทิ&nbsp; Chill Chill Badminton Cup 2013, Chill Chill Badminton Cup 2011, Li-Ning Badminton Cup 2011, MMOA Badminton Cup 2011, รายการดันลอป&nbsp; 18&nbsp; คอร์ทราชพฤกษ์ 2013&nbsp;&nbsp; เพื่อช่วยในการพิจารณา<br>10.2.&nbsp;&nbsp;&nbsp; สมัครผ่านลิงค์&nbsp;&nbsp;</font><font size=\"2\" style=\"color: rgb(49, 48, 49); font-family: Tahoma, Verdana, \'MS Sans Serif\'; line-height: normal;\"><font size=\"2\"><font size=\"3\"><strong><a href=\"http://www.chillchillbadminton.com/\" target=\"_blank\" style=\"color: rgb(0, 0, 0);\">www.chillchillbadminton.com</a></strong></font></font>&nbsp; เท่านั้น<br>10.3.&nbsp;&nbsp;&nbsp; เริ่มรับสมัครตั้งแต่ วันพุธที่&nbsp; 25&nbsp; ธันวาคม&nbsp; 2556&nbsp; เวลาประมาณ&nbsp; 11.00&nbsp; น. เป็นต้นไป<br><br><u><strong>11.&nbsp;&nbsp;&nbsp; ระเบียบการแข่งขัน</strong></u><br><br>11.1.&nbsp;&nbsp;&nbsp; ประเภทรุ่นมือ&nbsp; WP- WP S P-&nbsp; P&nbsp; P+&nbsp; C&nbsp; C+ B และ B+&nbsp; เป็นการแบ่งกลุ่มการแข่งขัน&nbsp; ในแต่ละกลุ่มจะมี&nbsp; 4&nbsp; คู่&nbsp; แข่งขันแบบพบกันหมด&nbsp; ทั้งนี้อาจมีบางกลุ่มมีเพียง&nbsp; 3&nbsp; คู่&nbsp; เนื่องจากมีการสำรองไว้สำหรับกรณี&nbsp; โดนปรับรุ่นการแข่งขัน<br>11.2.&nbsp;&nbsp;&nbsp; ประเภทรุ่นเยาวชนอายุไม่เกิน&nbsp; 12&nbsp; ปี&nbsp;&nbsp; เป็นการแข่งขันแบบแพ้คัดออก(Knock Out)<br>11.3.&nbsp;&nbsp;&nbsp; ใช้ระบบ&nbsp; Rally&nbsp; Point&nbsp; 21&nbsp;&nbsp; แต้ม/เกม&nbsp;&nbsp; ในกรณีที่ได้&nbsp;&nbsp; 20&nbsp;&nbsp; คะแนนเท่ากันให้เล่นต่อจนกว่าฝ่ายใดจะได้&nbsp; 2&nbsp; คะแนนติดกัน&nbsp; ถือว่าเป็นผู้ชนะ&nbsp; แต่ถ้าได้&nbsp; 29&nbsp; คะแนนเท่ากันฝ่ายที่ได้&nbsp; 30&nbsp; คะแนนก่อนเป็นผู้ชนะ<br>11.4.&nbsp;&nbsp;&nbsp; ในการแข่งขันแบบแบ่งกลุ่ม&nbsp; ต้องแข่งขันกัน&nbsp;&nbsp; 2&nbsp; เกม&nbsp;<br>•&nbsp;&nbsp;&nbsp; ผู้ชนะได้&nbsp; 2&nbsp; คะแนน&nbsp; ผู้แพ้ได้&nbsp; 0&nbsp; คะแนน&nbsp; หากเสมอได้&nbsp; 1&nbsp; คะแนนเท่ากัน<br>•&nbsp;&nbsp;&nbsp; กรณีคู่ต่อสู้ไม่มา&nbsp; มาสายเกิน&nbsp; 15&nbsp; นาที&nbsp; หรือโดนตัดสิทธิ์&nbsp; ให้ถือว่าได้&nbsp; 2&nbsp; คะแนน&nbsp; โดยคะแนนดิบชนะ&nbsp; 21-0&nbsp; ทั้งสองเกม<br>•&nbsp;&nbsp;&nbsp; รอบแบ่งกลุ่ม&nbsp; ผู้ชนะมีคะแนนมากสุด&nbsp; 2&nbsp; อันดับแรก&nbsp; ให้เข้าไปเล่น&nbsp; รอบแพ้คัดออก(Knock Out)&nbsp; โดยอีก&nbsp; 2&nbsp; อันดับตกรอบ<br>•&nbsp;&nbsp;&nbsp; กรณีหากคะแนนในกลุ่ม&nbsp; คะแนนเท่ากัน&nbsp; ให้พิจารณาดูจากผลต่าง&nbsp; การรวมคะแนนดิบได้และเสีย&nbsp; จากเกมทั้งหมดที่ทำการแข่งขัน<br>•&nbsp;&nbsp;&nbsp; กรณีหากผลต่างคะแนนดิบ&nbsp; เท่ากัน&nbsp; ให้ทำการจับสลากต่อไป<br>•&nbsp;&nbsp;&nbsp; กรณีมีคู่โดนปรับแพ้ ทุกคู่ที่เจอกับคู่นี้ จะมีการปรับแต้มเป็น 0-0<br><br><strong>11.5.&nbsp;&nbsp;&nbsp; ในการออกสายการแข่งของรอบแพ้คัดออก(Knock&nbsp; Out)<br>•&nbsp;&nbsp;&nbsp; จะมีการจัดเรียงผลคะแนนของผู้ได้คะแนนเป็นที่ 1 ของกลุ่ม แล้วตามด้วยการจัดเรียงผลคะแนนของผู้ได้ที่ 2 ของกลุ่ม<br>•&nbsp;&nbsp;&nbsp; หลังจากเรียงลำดับเสร็จ จะทำการวางสายตามมือวาง<br>•&nbsp;&nbsp;&nbsp; ในการคิดคะแนน จะไม่นับรวมคู่ที่โดนปรับแพ้<br>•&nbsp;&nbsp;&nbsp; ในการคิดคะแนน จะคิดออกมาเป็นค่าเฉลี่ย&nbsp; ทั้งนี้เนื่องจาก บางกลุ่ม อาจจะมีจำนวนคู่ไม่เท่ากัน&nbsp; เช่น&nbsp; บางกลุ่มอาจจะมีบางคู่โดนปรับแพ้&nbsp; หรือในกลุ่มมีเพียง&nbsp; 3&nbsp; คู่&nbsp;&nbsp; เป็นต้น<br><br></strong>11.6.&nbsp;&nbsp;&nbsp; ในการแข่งขันแบบแพ้คัดออก(Knock&nbsp; Out)&nbsp; ในแต่ละรอบการแข่งขัน&nbsp; ต้องเล่นชนะ&nbsp; 2&nbsp; ใน&nbsp; 3&nbsp; เกม<br>11.7.&nbsp;&nbsp;&nbsp; นักกีฬาควรพร้อมทำการแข่งขันก่อนเวลาประมาณ&nbsp; 15&nbsp; นาที<br>11.8.&nbsp;&nbsp;&nbsp; หากนักกีฬามาช้ากว่าเวลาทำการแข่งขัน&nbsp; ให้รอนักกีฬาได้ไม่เกิน&nbsp; 15&nbsp; นาที&nbsp;&nbsp; หากเลยเวลา&nbsp; ให้ถือว่าแพ้ในเกมนั้น&nbsp; เว้นแต่นักกีฬาทั้งคู่ยินยอมให้เลื่อนเวลาออกไป<br>11.9.&nbsp;&nbsp;&nbsp; กรณีนักกีฬาลงมากกว่า&nbsp; 1&nbsp; ประเภท&nbsp; หากเวลาที่ลงแข่งขันตรงกัน&nbsp; อนุโลมให้มีการเลื่อนเวลาการแข่งขัน&nbsp; เพื่อไม่ให้ชนกันได้&nbsp; และให้นักกีฬาพัก&nbsp; หลังทำการแข่งขันในรอบก่อนหน้าได้ไม่เกิน&nbsp; 15&nbsp; นาที<br><strong>11.10.&nbsp;&nbsp;&nbsp; การพิจารณาตัดสินของคณะกรรมการจัดการแข่งขัน&nbsp; ถือเป็นข้อยุติทุกกรณี</strong><br><br>&nbsp;<br><u><strong>12.&nbsp;&nbsp;&nbsp; กำหนดการจัดการแข่งขัน<br><br></strong></u>12.1.&nbsp;&nbsp;&nbsp; รับสมัครแข่งขัน วันพุธที่&nbsp; 25&nbsp; ธันวาคม 2556 เป็นต้นไป<br>12.2.&nbsp;&nbsp;&nbsp; สิ้นสุดโอนเงินรอบแรก วันพฤหัสบดีที่&nbsp; 9&nbsp; มกราคม 2557<br>12.3.&nbsp;&nbsp;&nbsp; สิ้นสุดโอนเงินรอบสอง วันศุกร์ที่&nbsp; 24&nbsp; มกราคม 2557<br>12.4.&nbsp;&nbsp;&nbsp; ออกสายการแข่งขัน วันอังคารที่&nbsp; 28&nbsp; มกราคม 2557<br>12.5.&nbsp;&nbsp;&nbsp; ทำการแข่งขัน วันเสาร์ที่ 1 กุมภาพันธ์ 2557 และวันอาทิตย์ที่ 2 กุมภาพันธ์ 2557<br><br><u><strong>13.&nbsp;&nbsp;&nbsp; คณะกรรมการจัดการแข่งขัน<br><br></strong></u>13.1.&nbsp;&nbsp;&nbsp; คุณสัณหจุฑา&nbsp; จิราธิวัฒน์&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; ประธานกิติมศักดิ์ชมรม<br>13.2.&nbsp;&nbsp;&nbsp; คุณจิรภัทร&nbsp; ปัทมสุวรรณ&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; ประธานจัดการแข่งขัน<br>13.3.&nbsp;&nbsp;&nbsp; คุณอมฤต&nbsp; เลี๊ยบประเสริฐ&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; ที่ปรึกษาฝ่ายประเมิน<br>13.4.&nbsp;&nbsp;&nbsp; คุณประเสริฐ&nbsp; กังแฮ&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; ผู้จัดการและหัวหน้าฝ่ายประเมิน<br>13.5.&nbsp;&nbsp;&nbsp; คุณวรรณิสา&nbsp; เตชะมานนท์&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; เหรัญญิก<br>13.6.&nbsp;&nbsp;&nbsp; คุณปัทมาภรณ์&nbsp; บูรณ์กฤษดา&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; เลขานุการและเจ้าหน้าที่ฝ่ายประเมิน<br>13.7.&nbsp;&nbsp;&nbsp; คุณพันธกร&nbsp; สุขสมัคร&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; หัวหน้าฝ่ายประมวลผลและเจ้าหน้าที่ฝ่ายประเมิน<br>13.8.&nbsp;&nbsp;&nbsp; คุณชนาพร&nbsp; เชื้อญวณ&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; เจ้าหน้าที่ฝ่ายลงทะเบียน<br>13.9.&nbsp;&nbsp;&nbsp; คุณเกศนี พัฒนกูล&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; เจ้าหน้าที่ฝ่ายศิลป์<br>13.10.&nbsp;&nbsp;&nbsp; คุณนิธิภัทร&nbsp; สมหวัง&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; เจ้าหน้าที่ฝ่ายจัดสถานที่และเจ้าหน้าที่ฝ่ายประเมิน<br>13.11.&nbsp;&nbsp;&nbsp; คุณธีรพงษ์&nbsp;&nbsp; ใจชื้น&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; เจ้าหน้าที่ฝ่ายประมวลผล<br>13.12.&nbsp;&nbsp;&nbsp; คุณฐาปนา บุญชู&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; เจ้าหน้าที่ฝ่ายประมวลผล<br>13.13.&nbsp;&nbsp;&nbsp; คุณวศภณ เฟื่องสวัสดิ์&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; เจ้าหน้าที่ฝ่ายประมวลผล<br>13.14.&nbsp;&nbsp;&nbsp; คุณชาญณรงค์ ลาฮง&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; เจ้าหน้าที่ฝ่ายประมวลผล<br>13.15.&nbsp;&nbsp;&nbsp; คุณณฐพล ศิริ&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; เจ้าหน้าที่ฝ่ายประมวลผล<br>13.16.&nbsp;&nbsp;&nbsp; คุณพรประสิทธิ์ มะหะสิทธิ์&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; เจ้าหน้าที่ฝ่ายช่างภาพ<br><br><u><strong>14.&nbsp;&nbsp;&nbsp; คณะกรรมการพิจารณาฝีมือ<br><br></strong></u>14.1.&nbsp;&nbsp;&nbsp; คุณประเสริฐ&nbsp; กังแฮ<br>14.2.&nbsp;&nbsp;&nbsp; คุณปัทมาภรณ์&nbsp; บูรณ์กฤษดา<br>14.3.&nbsp;&nbsp;&nbsp; คุณพันธกร&nbsp; สุขสมัคร<br>14.4.&nbsp;&nbsp;&nbsp; คุณณัฐวุฒิ&nbsp; สมหวัง<br><br><strong><u>15.&nbsp;&nbsp;&nbsp; การติดต่อ</u><br><br></strong>15.1.&nbsp;&nbsp;&nbsp; สอบถามการประเมินมือ<br><strong>•&nbsp;&nbsp;&nbsp; คุณประเสริฐ&nbsp; กังแฮ(ตี้)&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; 089-925-3325</strong><br>•&nbsp;&nbsp;&nbsp; คุณปัทมาภรณ์&nbsp; บูรณ์กฤษดา(ต่าย)&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; 086-889-8918<br>•&nbsp;&nbsp;&nbsp; คุณณัฐวุฒิ สมหวัง(มั้น)&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; 086-664-1596<br>•&nbsp;&nbsp;&nbsp; คุณพันธกร&nbsp; สุขสมัคร(โนอา)&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; 081-989-3928<br>15.2.&nbsp;&nbsp;&nbsp; สอบถามการสมัคร<br>•&nbsp;&nbsp;&nbsp; คุณจิรภัทร&nbsp; ปัทมสุวรรณ(พัด)&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; 081-628-8989<br>•&nbsp;&nbsp;&nbsp; คุณประเสริฐ&nbsp; กังแฮ(ตี้)&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; 089-925-3325<br>•&nbsp;&nbsp;&nbsp; คุณพันธกร&nbsp; สุขสมัคร(โนอา)&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; 081-989-3928<br>•&nbsp;&nbsp;&nbsp; คุณปัทมาภรณ์&nbsp; บูรณ์กฤษดา(ต่าย)&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; 086-889-8918<br><br><strong>15.3.&nbsp;&nbsp;&nbsp; สอบถามการชำระเงิน<br>•&nbsp;&nbsp;&nbsp; คุณวรรณิสา&nbsp; เตชะมานนท์&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; 083-996-5144</strong></font></span><br>','2013-12-23 15:07:06','2013-12-23 15:07:06','announcement'),(13,'วิธีตบลูกขนไก่ที่ถูกต้องต้องทำอย่างไร','how-to-smash-badminton','<p class=\"p1\"><b>ลูกตบแบดมินตัน</b>&nbsp;ถือว่าเป็นลูกที่เล่นแล้วได้ผลต่อคะแนนมากที่สุดระหว่างการเล่นแบดมินตัน ซึ่งหากมีการตบที่ดีแล้วการตั้งรับใดๆย่อมเป็นไปได้ยาก ซึ่งสามารถทำได้ทั้งแบบ forehand และ backhand</p><p class=\"p2\"><span style=\"line-height: 1.428571429;\">ลูกตบคือลูกที่ขณะที่ไม้แบดกระทบลูกขนไก่อย่างรวดเร็วด้วยแรงและความเร็วสูง พุ่งลงไปยังสนามฝั่งตรงข้าม ซึ่งมุมและการกดลูกจะทำให้ฝั่งตรงข้ามรับลูกขนไก่ได้ยาก ซึ่งจุดที่สัมผัสลูกจะอยู่ในตำแหน่งค่อนไปด้านหน้ามากกว่าลูกตัดหยอด และลูกเซฟ และจุดที่สัมผัสลูกที่ดีที่สุดจะอยู่บริเวณค่อนไปทางด้านบนของตาข่ายแรคเก็ต</span></p><p class=\"p1\">ในขณะที่ตบลูกท่านสามารถกระโดดแล้วจึงตบเพื่อให้ได้มุมที่ทำให้ลูกตกใกล้กับตาข่ายมากยิ่งขึ้น การฝึกฝนควบคู่กับการสปริงตัวและดีดตัวขณะตบลูกจะทำให้ลูกตบมีพลังมากขึ้นขณะที่ตีกลางอากาศ&nbsp;<b>การตบลูกขนไก่จำเป็นต้องใช้พลังมาก จึงควรใช้ขณะที่เห็นว่ามีโอกาศได้คะแนน เช่น ขณะคู่ต่อสู้ไม่อยู่ในตำแหน่งตั้งรับ หรือ ขณะที่ลูกขนไก่ถูกส่งมาแค่กลางคอร์ท ไม่ตบพร่ำเพรื่อ</b></p><table style=\"background-color: rgb(240, 240, 240);\"><tbody><tr><td><br><br><center><img src=\"http://www.badminton-information.com/images/5_smash.gif\" alt=\"\" border=\"0\" height=\"234\" width=\"500\"></center><br><br><h3>การตบลูกขนไก่แบบโฟร์แฮนด์</h3><p class=\"p1\"></p><ol><li><span style=\"background-color: transparent; line-height: 1.428571429;\">การตบลูกขนไก่ด้านโฟร์แฮนด์จะมีลักษณะคล้ายกับการโยนลูกบอล หากคุณมีวงแขนกว้าง คุณจะสามารถตบได้แรงขึ้น การฝึกสามารถทำได้โดยการถือลูกขนไก่และปาลูกขนไก่ไปให้ไกลที่สุด ซึ่งระหว่างการตบลูกมีเทคนิคคือ</span><br></li><li><span style=\"background-color: transparent; line-height: 1.428571429;\">จับแรคเก็ตให้ถูกด้าน หันหน้ามือไปทางด้านที่จะตบ</span><br></li><li><span style=\"background-color: transparent; line-height: 1.428571429;\">ตั้งตัวให้ตั้งฉากกับตาข่าย ซึ่งไหล่ของเราด้านที่ไม่ได้ใช่ตบจะอยู่ใกล้กับตาข่ายมากกว่าอีกข้าง</span><br></li><li><span style=\"background-color: transparent; line-height: 1.428571429;\">ถ่ายน้ำหนักไปยังขาด้านหลังเพื่อเตรียมตัวกระโจนน้ำหนัก</span><br></li><li><span style=\"background-color: transparent; line-height: 1.428571429;\">เกร็งไกล่และยกข้อมือขึ้นสูงเหนือศรีษะ โดยเรียงศอกให้แหลมเป็นรูปตัว V</span><br></li><li><span style=\"background-color: transparent; line-height: 1.428571429;\">ยกแขนและมือด้านที่ไม่ได้ตีลูกขนไก่ขึ้นเพื่อทรงตัว และถ่ายน้ำหนัก</span><br></li><li><span style=\"background-color: transparent; line-height: 1.428571429;\">ตบลูกขนไก่ด้วยความเร็วสูงสุดที่ทำได้ ที่จุดห่างจากลำตัวไปด้านหน้าเล็กน้อย สะบัดข้อมือเพื่อให้ลูกมีความเร็ว</span><br></li><li><span style=\"background-color: transparent; line-height: 1.428571429;\">เหยียดแขนด้านที่ตีให้ตรงและอยู่จุดสูงสุด</span><br></li><li><span style=\"background-color: transparent; line-height: 1.428571429;\">เมื่อกระทบลูกแล้วปล่อยแขนให้ตกไปยังด้านฝั่งตรงข้าม คลายมือที่เกร็งจากการจับไม้</span><br></li><li><span style=\"background-color: transparent; line-height: 1.428571429;\">ขยับไปยังตำแหน่งเริ่มต้น</span><br></li></ol><p></p><p class=\"p2\"><br></p><p class=\"p1\"><i>ครั้งหน้าเราจะมาฝึกการตบลูกแบบแบ็คแฮนด์กับครับ</i></p></td></tr></tbody></table>','2013-12-24 02:23:29','2013-12-24 02:23:29','article');
/*!40000 ALTER TABLE `contents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `courts`
--

DROP TABLE IF EXISTS `courts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courts`
--

LOCK TABLES `courts` WRITE;
/*!40000 ALTER TABLE `courts` DISABLE KEYS */;
INSERT INTO `courts` VALUES (1,'ยาง'),(2,'ปูน(คอนกรีต)'),(3,'กระเบื้องยาง'),(4,'ไม้ปาเก้'),(5,'ผสม');
/*!40000 ALTER TABLE `courts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flux_users`
--

DROP TABLE IF EXISTS `flux_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flux_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned NOT NULL DEFAULT '3',
  `username` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `realname` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `signature` text COLLATE utf8_unicode_ci,
  `disp_topics` int(10) unsigned DEFAULT NULL,
  `disp_posts` int(10) unsigned DEFAULT NULL,
  `email_setting` int(10) unsigned NOT NULL DEFAULT '1',
  `notify_with_post` tinyint(1) NOT NULL DEFAULT '0',
  `auto_notify` tinyint(1) NOT NULL DEFAULT '0',
  `show_smilies` tinyint(1) NOT NULL DEFAULT '1',
  `show_img` tinyint(1) NOT NULL DEFAULT '1',
  `show_img_sig` tinyint(1) NOT NULL DEFAULT '1',
  `show_avatars` tinyint(1) NOT NULL DEFAULT '1',
  `show_sig` tinyint(1) NOT NULL DEFAULT '1',
  `timezone` float(8,2) NOT NULL DEFAULT '0.00',
  `dst` tinyint(1) NOT NULL DEFAULT '0',
  `time_format` int(10) unsigned NOT NULL DEFAULT '0',
  `date_format` int(10) unsigned NOT NULL DEFAULT '0',
  `language` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `style` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `num_posts` int(10) unsigned NOT NULL DEFAULT '0',
  `last_post` int(10) unsigned DEFAULT NULL,
  `last_search` int(10) unsigned DEFAULT NULL,
  `last_email_sent` int(10) unsigned DEFAULT NULL,
  `last_report_sent` int(10) unsigned DEFAULT NULL,
  `registered` int(10) unsigned NOT NULL DEFAULT '0',
  `registration_ip` varchar(35) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0.0.0.0',
  `last_visit` int(10) unsigned NOT NULL DEFAULT '0',
  `admin_note` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activate_string` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activate_key` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  KEY `users_registered_index` (`registered`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flux_users`
--

LOCK TABLES `flux_users` WRITE;
/*!40000 ALTER TABLE `flux_users` DISABLE KEYS */;
INSERT INTO `flux_users` VALUES (1,1,'admin','$2y$08$j.8..HdZaBGQtR3A80JikuPYkCTiNRNT.owYUJn033b1cT2wbOPwe','uttapong@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,1,1,1,1,0.00,0,0,0,'th','Air',0,NULL,NULL,NULL,NULL,1386596917,'::1',1386596917,NULL,NULL,NULL);
/*!40000 ALTER TABLE `flux_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_perms`
--

DROP TABLE IF EXISTS `forum_perms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_perms` (
  `group_id` int(10) unsigned NOT NULL,
  `forum_id` int(10) unsigned NOT NULL,
  `read_forum` tinyint(1) NOT NULL DEFAULT '1',
  `post_replies` tinyint(1) NOT NULL DEFAULT '1',
  `post_topics` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`group_id`,`forum_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_perms`
--

LOCK TABLES `forum_perms` WRITE;
/*!40000 ALTER TABLE `forum_perms` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_perms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_subscriptions`
--

DROP TABLE IF EXISTS `forum_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_subscriptions` (
  `user_id` int(10) unsigned NOT NULL,
  `forum_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`forum_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_subscriptions`
--

LOCK TABLES `forum_subscriptions` WRITE;
/*!40000 ALTER TABLE `forum_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forums`
--

DROP TABLE IF EXISTS `forums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forums` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `forum_name` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `forum_desc` text COLLATE utf8_unicode_ci,
  `redirect_url` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `num_topics` int(10) unsigned NOT NULL DEFAULT '0',
  `num_posts` int(10) unsigned NOT NULL DEFAULT '0',
  `last_post` int(10) unsigned DEFAULT NULL,
  `last_post_id` int(10) unsigned DEFAULT NULL,
  `last_poster` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sort_by` int(10) unsigned NOT NULL DEFAULT '0',
  `disp_position` int(11) NOT NULL DEFAULT '0',
  `cat_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forums`
--

LOCK TABLES `forums` WRITE;
/*!40000 ALTER TABLE `forums` DISABLE KEYS */;
INSERT INTO `forums` VALUES (1,'Test forum','Your first forum for testing.',NULL,0,0,NULL,NULL,NULL,0,0,1);
/*!40000 ALTER TABLE `forums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `galleries`
--

DROP TABLE IF EXISTS `galleries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `galleries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `galleries_slug_unique` (`slug`),
  KEY `galleries_id_index` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `galleries`
--

LOCK TABLES `galleries` WRITE;
/*!40000 ALTER TABLE `galleries` DISABLE KEYS */;
/*!40000 ALTER TABLE `galleries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_permissions`
--

DROP TABLE IF EXISTS `group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `value` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_permissions`
--

LOCK TABLES `group_permissions` WRITE;
/*!40000 ALTER TABLE `group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `parent_group_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` VALUES (1,'seed_data.administrators',NULL),(2,'seed_data.moderators',NULL),(4,'seed_data.members',NULL);
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gyms`
--

DROP TABLE IF EXISTS `gyms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gyms` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `lat` float DEFAULT NULL,
  `long` float DEFAULT NULL,
  `type` int(2) NOT NULL,
  `fee` varchar(30) DEFAULT NULL,
  `open_day` varchar(100) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `car_park` int(2) DEFAULT NULL,
  `court_count` int(3) DEFAULT NULL,
  `tel` varchar(30) DEFAULT NULL,
  `contact_person` varchar(50) DEFAULT NULL,
  `address` varchar(300) DEFAULT NULL,
  `owner` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `reported` tinyint(1) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `u_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gyms`
--

LOCK TABLES `gyms` WRITE;
/*!40000 ALTER TABLE `gyms` DISABLE KEYS */;
INSERT INTO `gyms` VALUES (4,'คอร์ทแบดมินตันสหสิน',14.0381,100.615,5,'110','จันทร์,อังคาร,พุธ,พฤหัส,ศุกร์,เสาร์,อาทิตย์','12:00:00','23:00:00',90,18,'0894852280','เทียน','คลองหนึ่ง คลองหลวง ปทุมธานี',2,'2014-02-09 09:25:05','2013-11-20 04:04:23',1),(12,'มหาวิทยาลัยธรรมศาสตร์ ยิมเนเซียม 4',14.0662,100.603,4,'80','จันทร์,อังคาร,พุธ,พฤหัส,ศุกร์,เสาร์,อาทิตย์','09:00:00','21:00:00',100,12,'','แดง','111 มหาวิทยาลัยธรรมศาสตร์ ศูนย์รังสิต',2,'2013-11-20 10:45:49','2013-11-20 10:45:49',NULL),(13,'คอร์ทแบดมินตันหมู่บ้านวราลักษ์',14.0249,100.657,4,'60','จันทร์,อังคาร,พุธ,พฤหัส,ศุกร์,เสาร์,อาทิตย์','10:00:00','24:00:00',20,2,'','','หมู่บ้าน วราลักษณ์ ตำบล คลองสาม จังหวัด ปทุมธานี ประเทศไทย',2,'2014-02-10 00:45:29','2013-11-20 10:49:25',1),(14,'สปิริตคอร์ท(SPIRIT BADMINTON COURT)',14.0206,100.752,1,'90','จันทร์,อังคาร,พุธ,พฤหัส,ศุกร์,เสาร์,อาทิตย์','08:00:00','24:00:00',60,8,'','เชิด','คลอง 7 จังหวัดปทุมธานี',2,'2014-03-21 07:00:07','2013-11-20 14:27:29',1),(15,'คอร์ทแบดมินตันมหาวิทยาลัยรังสิต',13.9651,100.588,4,'','จันทร์,อังคาร,พุธ,พฤหัส,ศุกร์,เสาร์,อาทิตย์','10:00:00','20:00:00',200,2,'','','',2,'2013-12-12 00:23:32','2013-12-12 00:23:32',NULL),(16,'สนามแบดมินตัน เล็กดี(Lex Dee Badminton Court)',13.8535,100.563,5,'125 บาทต่อชั่วโมง','จันทร์,อังคาร,พุธ,พฤหัส,ศุกร์,เสาร์,อาทิตย์','10:00:00','23:00:00',40,5,'083-433-3724','','KID ZONE 94/2 หมู่ 3 ถ.วิภาวดีรังสิต แขวงลาดยาว จตุจักร, กรุงเทพมหานคร 10900',2,'2014-04-22 18:36:37','2013-12-23 01:05:42',1),(17,'ฟีนิกซ์ วัชรพล',13.8737,0,1,'สมัครสมาชิก 1 ปี เพียง 500 บาท','จันทร์,อังคาร,พุธ,พฤหัส,ศุกร์,เสาร์,อาทิตย์','08:00:00','22:00:00',40,7,'02-7919791-2, 02-9984400-2','','55/99 ถ.วัชรพล-เพิ่มสิน แขวงท่าแร้ง เขตบางเขน',2,'2014-04-02 07:03:16','0000-00-00 00:00:00',1),(18,'18 คอร์ท ราชพฤกษ์',13.9195,100.454,1,'-','จันทร์,อังคาร,พุธ,พฤหัส,ศุกร์,เสาร์,อาทิตย์','00:00:00','00:00:00',60,18,'0891992600 0891294052','lieoryo@hotmail.com','อยู่บนถนน ราชพฤกษ์ ก่อนถึงโรงเบียร์ฮอลแลนด์ 2 กม.',2,'2014-03-21 12:26:02','0000-00-00 00:00:00',1),(19,'สกายวิลล์ (Sky Ville)',13.9041,100.514,1,'-','จันทร์,อังคาร,พุธ,พฤหัส,ศุกร์,เสาร์,อาทิตย์','00:00:00','00:00:00',20,8,'02 9626425','','108/118 แจ้งวัฒนะ ปากเกร็ด',2,'2014-02-10 00:56:34','0000-00-00 00:00:00',1),(20,'สนามแบดมินตันแบริ่ง',13.6564,100.61,1,'-','จันทร์,อังคาร,พุธ,พฤหัส,ศุกร์,เสาร์,อาทิตย์','09:00:00','24:00:00',12,5,'02-749-8228.02-7498232',NULL,'42/138 หมู่ที่ 3 แบริ่งซอย 9 ซอย สุขุมวิท 107 ถนน สุขุมวิท แขวง บางนา เขตพระโขนง กรุงเทพมหานคร 10260',2,'2013-12-25 00:00:00','2013-12-25 00:00:00',0),(23,'สนามแบดมินตัน รามอินทรา 67',13.8465,100.658,1,'90','จันทร์,อังคาร,พุธ,พฤหัส,ศุกร์,เสาร์,อาทิตย์','09:00:00','24:00:00',0,8,'02-945-8928, 02-945-8929','','ซ.รามอินทรา67 แขวง/เขต คันนายาว กทม 10230 ',2,'2014-03-06 00:02:51','2013-12-25 16:45:41',1),(24,'คอร์ทแบดมินตันสายไหม ซอย6',13.9197,100.637,5,'100-130','จันทร์,อังคาร,พุธ,พฤหัส,ศุกร์,เสาร์,อาทิตย์','09:00:00','02:00:00',20,9,'029905458','','116/27 ซอย 6 สายไหม',2,'2014-03-21 11:09:52','2013-12-25 17:18:14',1),(25,'Start Sport Arena - สตาร์ท สปอร์ต อารีน่า',13.9333,100.519,1,'','จันทร์,อังคาร,พุธ,พฤหัส,ศุกร์,เสาร์,อาทิตย์','08:00:00','24:00:00',0,17,'081-104-6000, 081-104-7000','Start Sport Arena','44/2 หมู่ 3 ถนนสุขาประชาสรรค์ 3 (ซอยวัดกู้ ด้านถนนติวานนท์) อำเภอ ปากเกร็ด จังหวัดนนทบุรี',21,'2014-01-02 11:04:46','2014-01-02 11:04:46',0);
/*!40000 ALTER TABLE `gyms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `managers`
--

DROP TABLE IF EXISTS `managers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `managers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `nonmember_name` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `managers`
--

LOCK TABLES `managers` WRITE;
/*!40000 ALTER TABLE `managers` DISABLE KEYS */;
INSERT INTO `managers` VALUES (28,22,0,'โอ๋','2013-12-11 17:52:48','2013-12-11 17:52:48'),(29,23,0,'ดอส','2013-12-11 17:56:00','2013-12-11 17:56:00'),(30,25,0,'ดอส','2013-12-11 17:57:53','2013-12-11 17:57:53'),(37,21,2,NULL,'2013-12-22 23:03:20','2013-12-22 23:03:20'),(38,21,0,'ต้นน๊อต','2013-12-22 23:03:20','2013-12-22 23:03:20'),(39,27,0,'ไกร','2013-12-25 10:23:20','2013-12-25 10:23:20'),(40,28,0,'ไกร','2013-12-25 10:29:27','2013-12-25 10:29:27'),(41,29,0,'ไกร','2013-12-25 10:34:16','2013-12-25 10:34:16'),(42,30,0,'ไกร','2013-12-25 10:46:10','2013-12-25 10:46:10'),(43,31,0,'ไกร','2013-12-25 10:47:15','2013-12-25 10:47:15'),(44,32,0,'ไกร','2013-12-25 10:47:38','2013-12-25 10:47:38'),(45,33,0,'ไกร','2013-12-25 10:50:00','2013-12-25 10:50:00'),(46,34,0,'ไกร','2013-12-25 10:50:34','2013-12-25 10:50:34'),(50,36,0,'สจ.มานะ','2013-12-25 12:17:04','2013-12-25 12:17:04'),(51,35,0,'ไกร','2013-12-25 12:18:41','2013-12-25 12:18:41'),(52,37,0,'-','2013-12-25 12:21:21','2013-12-25 12:21:21'),(53,38,0,'โจ้','2013-12-25 15:20:26','2013-12-25 15:20:26'),(54,38,0,'ยูนิต','2013-12-25 15:20:26','2013-12-25 15:20:26'),(55,39,0,'-','2013-12-25 15:24:12','2013-12-25 15:24:12'),(56,40,0,'บู','2013-12-25 15:39:16','2013-12-25 15:39:16'),(57,41,0,'แดง','2013-12-25 15:52:55','2013-12-25 15:52:55'),(62,26,0,'ดอส','2013-12-25 16:19:37','2013-12-25 16:19:37'),(63,26,0,'ตั้ม','2013-12-25 16:19:37','2013-12-25 16:19:37'),(64,42,0,'แบงค์, อู๋','2013-12-25 16:35:27','2013-12-25 16:35:27'),(65,43,0,'แบงค์, อู๋','2013-12-25 16:36:48','2013-12-25 16:36:48'),(66,44,0,'กุ๊ก','2013-12-25 16:48:46','2013-12-25 16:48:46'),(67,45,0,'ต๋อง, โต้ง','2013-12-25 16:58:17','2013-12-25 16:58:17'),(68,46,0,'เอ้','2013-12-25 17:23:42','2013-12-25 17:23:42'),(70,47,2,NULL,'2013-12-27 15:19:50','2013-12-27 15:19:50');
/*!40000 ALTER TABLE `managers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES ('lpg_0_0_1_create_albums_table',1),('lpg_0_0_2_create_photos_table',1),('2013_06_02_233121_create_password_reminders_table',2),('2013_08_22_171000_create_posts_table',3),('2013_08_22_172900_create_blocks_table',3),('2013_08_22_230100_create_settings_table',3),('2013_08_27_193000_create_tags_table',3),('2013_08_27_194400_create_uploads_table',3),('2013_08_29_164900_create_galleries_table',3),('2013_04_06_143214_create_comments_table',4),('2013_04_14_152240_add_indexes_to_commentable_table',4),('2013_05_31_140553_create_posts_table',5),('2013_05_31_141423_create_tags_table',6),('2013_06_02_233005_create_users_table',7),('2013_07_10_021355_add_user_to_posts',7),('2013_11_28_205454_add_id_to_tags_table',7);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opendays`
--

DROP TABLE IF EXISTS `opendays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `opendays` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `day` varchar(30) DEFAULT '',
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `gym` int(11) NOT NULL,
  `payment` text,
  `remark` text,
  `team` int(11) NOT NULL,
  `updated_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opendays`
--

LOCK TABLES `opendays` WRITE;
/*!40000 ALTER TABLE `opendays` DISABLE KEYS */;
INSERT INTO `opendays` VALUES (23,'7','18:00:00','24:00:00',13,'คิดหารกันตามใช้จริง','',22,'2013-12-11 17:52:48','2013-12-11 17:52:48'),(29,'6','18:00:00','23:30:00',4,'ค่าคอร์ท 60 ค่าลูก 14 บาท ซื้อชิพก่อนลงสนาม','ยินดีต้อนรับผู้เล่นทุกระดับ',21,'2013-12-22 23:03:20','2013-12-22 23:03:20'),(30,'1','18:00:00','24:00:00',4,'เหมือนเดิม','ไม่มี',21,'2013-12-22 23:03:20','2013-12-22 23:03:20'),(31,'3','19:00:00','25:30:00',4,'ค่าคอร์ท 60  บาทเหมาจ่ายทั้งคืน ค่าชิพชิพละ 14 บาท','วันอังคารคนเยอะรอหน่อยนะคะ',21,'2013-12-22 23:03:20','2013-12-22 23:03:20'),(35,'2','18:00:00','21:00:00',18,'','',36,'2013-12-25 12:17:04','2013-12-25 12:17:04'),(36,'4','19:00:00','24:00:00',18,'','',35,'2013-12-25 12:18:41','2013-12-25 12:18:41'),(37,'2','20:00:00','24:00:00',18,'','',35,'2013-12-25 12:18:41','2013-12-25 12:18:41'),(38,'6','20:00:00','24:00:00',18,'','คอร์ท B1 เปิดยาวถึง 18 คอร์ดถ้าคนเยอะ',35,'2013-12-25 12:18:41','2013-12-25 12:18:41'),(39,'6','19:00:00','24:00:00',18,'','',37,'2013-12-25 12:21:21','2013-12-25 12:21:21'),(40,'7','18:00:00','24:00:00',18,'','',38,'2013-12-25 15:20:26','2013-12-25 15:20:26'),(41,'1','14:00:00','19:00:00',18,'','',39,'2013-12-25 15:24:12','2013-12-25 15:24:12'),(42,'2','20:00:00','24:00:00',19,'','',40,'2013-12-25 15:39:16','2013-12-25 15:39:16'),(43,'4','20:00:00','24:00:00',19,'','',40,'2013-12-25 15:39:16','2013-12-25 15:39:16'),(44,'6','20:00:00','24:00:00',19,'','',40,'2013-12-25 15:39:16','2013-12-25 15:39:16'),(45,'4','19:00:00','23:00:00',21,'ค่าคอร์ดคนละ 60.- ตลอดคืน ค่าลูก ตามที่ใช้ RSL silver 15 บาท/ลูก/คน','',41,'2013-12-25 15:52:55','2013-12-25 15:52:55'),(46,'7','19:00:00','23:00:00',21,'ค่าคอร์ดคนละ 60.- ตลอดคืน ค่าลูก ตามที่ใช้ RSL silver 15 บาท/ลูก/คน','',41,'2013-12-25 15:52:55','2013-12-25 15:52:55'),(47,'6','20:00:00','23:00:00',21,'ค่าคอร์ดคนละ 60.- ตลอดคืน ค่าลูก ตามที่ใช้ RSL silver 15 บาท/ลูก/คน','',41,'2013-12-25 15:52:55','2013-12-25 15:52:55'),(56,'2','19:00:00','23:00:00',14,'ค่าคอร์ด คนละ 60 บาท ค่าลูก ลูกละ 13-14 บาท   สำหรับนักเรียน-นักศึกษา ค่าคอร์ทคนละ  40  บาท','',26,'2013-12-25 16:19:37','2013-12-25 16:19:37'),(57,'4','19:00:00','23:00:00',14,'ค่าคอร์ด คนละ 60 บาท ค่าลูก ลูกละ 13-14 บาท   สำหรับนักเรียน-นักศึกษา ค่าคอร์ทคนละ  40  บาท','',26,'2013-12-25 16:19:37','2013-12-25 16:19:37'),(58,'6','19:00:00','23:00:00',14,'ค่าคอร์ด คนละ 60 บาท ค่าลูก ลูกละ 13-14 บาท   สำหรับนักเรียน-นักศึกษา ค่าคอร์ทคนละ  40  บาท','',26,'2013-12-25 16:19:37','2013-12-25 16:19:37'),(59,'7','19:00:00','03:00:00',14,'ค่าคอร์ด คนละ 60 บาท ค่าลูก ลูกละ 13-14 บาท   สำหรับนักเรียน-นักศึกษา ค่าคอร์ทคนละ  40  บาท','',26,'2013-12-25 16:19:37','2013-12-25 16:19:37'),(60,'7','20:00:00','24:00:00',22,'','',43,'2013-12-25 16:36:48','2013-12-25 16:36:48'),(61,'3','20:00:00','24:00:00',17,'(ค่าคอร์ท 60 บาท ลูกแบด RSL Silver ลูกละ 15 บาท แทน 1 chip) chip เหลือนำมาแลกเงินคืนได้นะคะ (chip ละ 12 บาท)','',44,'2013-12-25 16:48:47','2013-12-25 16:48:47'),(62,'6','20:00:00','24:00:00',23,'(ค่าคอร์ท 60 บาท ลูกแบด RSL Silver ลูกละ 15 บาท แทน 1 chip) chip เหลือนำมาแลกเงินคืนได้นะคะ (chip ละ 12 บาท)','',44,'2013-12-25 16:48:47','2013-12-25 16:48:47'),(63,'2','20:00:00','24:00:00',16,'รายเดือน400บาทรายครั้ง60บาทลูกละ15บาท','',45,'2013-12-25 16:58:17','2013-12-25 16:58:17'),(64,'4','20:00:00','24:00:00',16,'รายเดือน400บาทรายครั้ง60บาทลูกละ15บาท','',45,'2013-12-25 16:58:17','2013-12-25 16:58:17'),(65,'2','19:00:00','02:00:00',24,'','',46,'2013-12-25 17:23:42','2013-12-25 17:23:42'),(66,'4','19:00:00','02:00:00',24,'','',46,'2013-12-25 17:23:42','2013-12-25 17:23:42'),(67,'6','19:00:00','02:00:00',24,'','',46,'2013-12-25 17:23:42','2013-12-25 17:23:42'),(68,'7','19:00:00','02:00:00',24,'','',46,'2013-12-25 17:23:42','2013-12-25 17:23:42'),(72,'2','18:30:00','21:00:00',4,'-','รับเฉพาะสมาชิกที่เรียนแบดมินตันกับทีม',47,'2013-12-27 15:19:50','2013-12-27 15:19:50'),(73,'4','18:30:00','21:00:00',4,'-','รับเฉพาะสมาชิกที่เรียนแบดมินตันกับทีม',47,'2013-12-27 15:19:50','2013-12-27 15:19:50'),(74,'5','18:30:00','21:00:00',4,'-','รับเฉพาะสมาชิกที่เรียนแบดมินตันกับทีม',47,'2013-12-27 15:19:50','2013-12-27 15:19:50');
/*!40000 ALTER TABLE `opendays` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opengyms`
--

DROP TABLE IF EXISTS `opengyms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `opengyms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) NOT NULL,
  `gym_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opengyms`
--

LOCK TABLES `opengyms` WRITE;
/*!40000 ALTER TABLE `opengyms` DISABLE KEYS */;
/*!40000 ALTER TABLE `opengyms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reminders`
--

DROP TABLE IF EXISTS `password_reminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reminders` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reminders`
--

LOCK TABLES `password_reminders` WRITE;
/*!40000 ALTER TABLE `password_reminders` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reminders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `photos`
--

DROP TABLE IF EXISTS `photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `photos` (
  `photo_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `photo_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `photo_description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo_path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `album_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`photo_id`),
  KEY `photos_album_id_foreign` (`album_id`),
  CONSTRAINT `photos_album_id_foreign` FOREIGN KEY (`album_id`) REFERENCES `albums` (`album_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `photos`
--

LOCK TABLES `photos` WRITE;
/*!40000 ALTER TABLE `photos` DISABLE KEYS */;
INSERT INTO `photos` VALUES (1,'','','MJeT264370_10151339716081862_765922305_n.jpg',1,'2013-11-22 04:43:47','2013-11-22 04:43:47'),(2,'test','test test','PyZr944530_10151452456011862_941038272_n.jpg',1,'2013-11-22 04:44:07','2013-11-22 04:44:07');
/*!40000 ALTER TABLE `photos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `poster` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `poster_id` int(10) unsigned NOT NULL DEFAULT '1',
  `poster_ip` varchar(39) COLLATE utf8_unicode_ci DEFAULT NULL,
  `poster_email` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8_unicode_ci,
  `hide_smilies` tinyint(1) NOT NULL DEFAULT '0',
  `posted` int(10) unsigned NOT NULL DEFAULT '0',
  `edited` int(10) unsigned DEFAULT NULL,
  `edited_by` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `topic_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `posts_topic_id_index` (`topic_id`),
  KEY `posts_poster_id_topic_id_index` (`poster_id`,`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provinces`
--

DROP TABLE IF EXISTS `provinces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `provinces` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `code` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `name_eng` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `geo_id` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=78 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provinces`
--

LOCK TABLES `provinces` WRITE;
/*!40000 ALTER TABLE `provinces` DISABLE KEYS */;
INSERT INTO `provinces` VALUES (1,'10','กรุงเทพมหานคร   ','Bangkok',2),(2,'11','สมุทรปราการ   ','Samut Prakan',2),(3,'12','นนทบุรี   ','Nonthaburi',2),(4,'13','ปทุมธานี   ','Pathum Thani',2),(5,'14','พระนครศรีอยุธยา   ','Phra Nakhon Si Ayutthaya',2),(6,'15','อ่างทอง   ','Ang Thong',2),(7,'16','ลพบุรี   ','Loburi',2),(8,'17','สิงห์บุรี   ','Sing Buri',2),(9,'18','ชัยนาท   ','Chai Nat',2),(10,'19','สระบุรี','Saraburi',2),(11,'20','ชลบุรี   ','Chon Buri',5),(12,'21','ระยอง   ','Rayong',5),(13,'22','จันทบุรี   ','Chanthaburi',5),(14,'23','ตราด   ','Trat',5),(15,'24','ฉะเชิงเทรา   ','Chachoengsao',5),(16,'25','ปราจีนบุรี   ','Prachin Buri',5),(17,'26','นครนายก   ','Nakhon Nayok',2),(18,'27','สระแก้ว   ','Sa Kaeo',5),(19,'30','นครราชสีมา   ','Nakhon Ratchasima',3),(20,'31','บุรีรัมย์   ','Buri Ram',3),(21,'32','สุรินทร์   ','Surin',3),(22,'33','ศรีสะเกษ   ','Si Sa Ket',3),(23,'34','อุบลราชธานี   ','Ubon Ratchathani',3),(24,'35','ยโสธร   ','Yasothon',3),(25,'36','ชัยภูมิ   ','Chaiyaphum',3),(26,'37','อำนาจเจริญ   ','Amnat Charoen',3),(27,'39','หนองบัวลำภู   ','Nong Bua Lam Phu',3),(28,'40','ขอนแก่น   ','Khon Kaen',3),(29,'41','อุดรธานี   ','Udon Thani',3),(30,'42','เลย   ','Loei',3),(31,'43','หนองคาย   ','Nong Khai',3),(32,'44','มหาสารคาม   ','Maha Sarakham',3),(33,'45','ร้อยเอ็ด   ','Roi Et',3),(34,'46','กาฬสินธุ์   ','Kalasin',3),(35,'47','สกลนคร   ','Sakon Nakhon',3),(36,'48','นครพนม   ','Nakhon Phanom',3),(37,'49','มุกดาหาร   ','Mukdahan',3),(38,'50','เชียงใหม่   ','Chiang Mai',1),(39,'51','ลำพูน   ','Lamphun',1),(40,'52','ลำปาง   ','Lampang',1),(41,'53','อุตรดิตถ์   ','Uttaradit',1),(42,'54','แพร่   ','Phrae',1),(43,'55','น่าน   ','Nan',1),(44,'56','พะเยา   ','Phayao',1),(45,'57','เชียงราย   ','Chiang Rai',1),(46,'58','แม่ฮ่องสอน   ','Mae Hong Son',1),(47,'60','นครสวรรค์   ','Nakhon Sawan',2),(48,'61','อุทัยธานี   ','Uthai Thani',2),(49,'62','กำแพงเพชร   ','Kamphaeng Phet',2),(50,'63','ตาก   ','Tak',4),(51,'64','สุโขทัย   ','Sukhothai',2),(52,'65','พิษณุโลก   ','Phitsanulok',2),(53,'66','พิจิตร   ','Phichit',2),(54,'67','เพชรบูรณ์   ','Phetchabun',2),(55,'70','ราชบุรี   ','Ratchaburi',4),(56,'71','กาญจนบุรี   ','Kanchanaburi',4),(57,'72','สุพรรณบุรี   ','Suphan Buri',2),(58,'73','นครปฐม   ','Nakhon Pathom',2),(59,'74','สมุทรสาคร   ','Samut Sakhon',2),(60,'75','สมุทรสงคราม   ','Samut Songkhram',2),(61,'76','เพชรบุรี   ','Phetchaburi',4),(62,'77','ประจวบคีรีขันธ์   ','Prachuap Khiri Khan',4),(63,'80','นครศรีธรรมราช   ','Nakhon Si Thammarat',6),(64,'81','กระบี่   ','Krabi',6),(65,'82','พังงา   ','Phangnga',6),(66,'83','ภูเก็ต   ','Phuket',6),(67,'84','สุราษฎร์ธานี   ','Surat Thani',6),(68,'85','ระนอง   ','Ranong',6),(69,'86','ชุมพร   ','Chumphon',6),(70,'90','สงขลา   ','Songkhla',6),(71,'91','สตูล   ','Satun',6),(72,'92','ตรัง   ','Trang',6),(73,'93','พัทลุง   ','Phatthalung',6),(74,'94','ปัตตานี   ','Pattani',6),(75,'95','ยะลา   ','Yala',6),(76,'96','นราธิวาส   ','Narathiwat',6),(77,'97','บึงกาฬ','buogkan',3);
/*!40000 ALTER TABLE `provinces` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(10) unsigned NOT NULL DEFAULT '0',
  `topic_id` int(10) unsigned NOT NULL DEFAULT '0',
  `forum_id` int(10) unsigned NOT NULL DEFAULT '0',
  `reported_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created` int(10) unsigned NOT NULL DEFAULT '0',
  `message` text COLLATE utf8_unicode_ci,
  `zapped` int(10) unsigned DEFAULT NULL,
  `zapped_by` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reports_zapped_index` (`zapped`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports`
--

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(10) unsigned NOT NULL DEFAULT '1',
  `created` int(10) unsigned NOT NULL DEFAULT '0',
  `last_visit` int(10) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0.0.0.0',
  `payload` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `label` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`),
  KEY `settings_id_index` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'application_name','Application Name','Teebadgun.com ','0000-00-00 00:00:00','2013-12-02 15:16:49');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tag` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `taggable_id` int(10) unsigned NOT NULL,
  `taggable_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `tags_id_index` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
INSERT INTO `tags` VALUES (19,'',7,'Davzie\\LaravelBootstrap\\Posts\\Posts','2013-12-05 05:00:31','2013-12-05 05:00:31'),(23,'',1,'Davzie\\LaravelBootstrap\\Blocks\\Blocks','2013-12-06 04:22:28','2013-12-06 04:22:28'),(24,'',6,'Davzie\\LaravelBootstrap\\Posts\\Posts','2013-12-15 08:04:59','2013-12-15 08:04:59'),(25,'',2,'Davzie\\LaravelBootstrap\\Posts\\Posts','2013-12-15 08:05:02','2013-12-15 08:05:02'),(26,'',3,'Davzie\\LaravelBootstrap\\Posts\\Posts','2013-12-15 08:05:04','2013-12-15 08:05:04'),(27,'',4,'Davzie\\LaravelBootstrap\\Posts\\Posts','2013-12-15 08:05:06','2013-12-15 08:05:06'),(28,'',5,'Davzie\\LaravelBootstrap\\Posts\\Posts','2013-12-15 08:05:08','2013-12-15 08:05:08'),(33,'yonex',1,'Davzie\\LaravelBootstrap\\Posts\\Posts','2013-12-15 08:13:52','2013-12-15 08:13:52'),(34,'super series',1,'Davzie\\LaravelBootstrap\\Posts\\Posts','2013-12-15 08:13:52','2013-12-15 08:13:52'),(36,'',10,'Davzie\\LaravelBootstrap\\Posts\\Posts','2013-12-15 08:22:25','2013-12-15 08:22:25'),(37,'',11,'Davzie\\LaravelBootstrap\\Posts\\Posts','2013-12-15 08:59:16','2013-12-15 08:59:16');
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teammembers`
--

DROP TABLE IF EXISTS `teammembers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teammembers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `team_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teammembers`
--

LOCK TABLES `teammembers` WRITE;
/*!40000 ALTER TABLE `teammembers` DISABLE KEYS */;
INSERT INTO `teammembers` VALUES (1,21,2,'2013-12-22 23:03:42','2013-12-22 23:03:42'),(2,21,23,'2013-12-27 15:05:48','2013-12-27 15:05:48'),(3,47,23,'2013-12-27 15:17:12','2013-12-27 15:17:12'),(4,47,25,'2013-12-27 15:29:28','2013-12-27 15:29:28'),(5,47,2,'2013-12-27 15:32:19','2013-12-27 15:32:19'),(6,47,21,'2014-01-02 10:52:35','2014-01-02 10:52:35'),(7,21,21,'2014-01-02 10:53:29','2014-01-02 10:53:29');
/*!40000 ALTER TABLE `teammembers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teams` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `tel` varchar(300) DEFAULT NULL,
  `logo` text,
  `motto` varchar(100) DEFAULT NULL,
  `description` text,
  `updated_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `owner` int(11) NOT NULL,
  `reported` tinyint(1) unsigned DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teams`
--

LOCK TABLES `teams` WRITE;
/*!40000 ALTER TABLE `teams` DISABLE KEYS */;
INSERT INTO `teams` VALUES (21,'ตบโด่ง','0894852280','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQ0AAAENCAIAAACacKdfAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAQ4FJREFUeNrsfQmcFNW9dfW+zb4yMDCswzKsw64yICoQEIkYNBqNCSAmX+R9wfeifjE+zWISjRHfQ18SBbK4oDGi6FNBlsAg2wSGYZNhmwUYh9mYtXt6ev1O9R2Kppfqqu6q7p6Ze2z7V/TUVNdU3XPP//zv/95SzJo1i6GgoOCFkl4CCgrKEwoKyhMKCsoTCgrKEwoKyhMKCsoTCgrKEwoKCsoTCgrKEwoKyhMKCsoTCgrKEwoKyhMKCsoTCgrKEwoKCsoTCgrKEwoKyhMKCsoTCgrKEwoKyhMKCsoTCgoKyhMKCsoTCgrKEwoKyhMKCsoTCgrKEwoKyhMKij4JNb0EFD5wa43tM+93JmYouiwJpVvUTRfpNaE8ofBFy7zVtpxRZNvWf1Tmpp8obBYad1FQXEdn/i0cSThtoZeF8oTiBpgLl/h8Yh1cyLM/SNU1uBBBGo27KPqQmPi3eEiKI32Qv0sBQ9pmr+D2T9m+TldVSvWEovfDmn9zwM/9yQNGNd/5pPfnHX5CRHlC0QuBRu/tTLwBPfFXEv59aNxFESXkjR4X8PPq0yfk+LquvEIhuyEMa5m3OhjTVO2NlCcUckFvNOWNHp+dNzQ7b0hKRjY2Qv5KXXWF1WIGZ7BRd7GipaEuYnNys5DdQBJQJeCPeitJKE+YlMzs5IwstEu9McG/Cydt8dpGh+Qd+cjJM/GNI6fMSM7IFvu7hEvcCbc21uH0zhw+eObIgfCCLiGBk0/WuO+gL/KEtE60s2CBDU/kg+Z4pboCLZJ05GGfALiRP3kmZESqPwpMGz8Lr9tB7LNHDhwr3iGK1UJaP/9YSi8Wkz7EE7TIkVNm5k+egTYaYXPEixxEbBeOcxhfdPv0BUvCUA9RfynYghdOr3jzOyCMMHMyKeQ+lnHzgkVcbEvq1eUtilmzZvX6yKpo6QPSdt4+QBd+vHhHybYtwUwCvnragm9OW7BEvnPgObfizW+XbN3CLxT1D7/Gs0NC6RbjiS8a7v8dD0+wj+nIR5QnPZUh6Fmj9o2QFzRKn4CnaOl3YsIQn3DxizffCKZ7cB3+eV4fDjChRkjSNz/biyVFlZeX1yujrLn3ff/ux54UkjiSlpkTim7PGz0e7bK1sR725rs/+y2CNLVGG+sLklAwswhXo+L4EYfd7suTsXfwm3gQwDL6VkalCdrd2iyJBzYFTA8o8FOnnepJ3AGt865H18jqAQR24TE/h4Bh2Cd/WusjLAi6eAIqQFtbzm/0DWe/TNqzwcfxWwcXksP2gpCst+nJvAdXLVz+GEnyxrwLj8e8jUYLYcG5XTh+pNvBDy605t/C/1shyxzZaSottd12f+y8lnmr7VnDOP0Bxwzn9il7cnF+78l3IdZa/OiaCNNZfQTwS8mZWRAWyIuQTFeImMRmIRWQUI/W2Su6AtUXOxN8h+pVOUPcVrOruZ7yJKokeejp30bZjfRooENJeTr7zeefqh9cGOnF95AEDgckCeZzNF4WXzNmun7hcmVqFqtm+z+xfrqRxl2UJPGLhJRU9YTbjrWrIjxO8p4NLmPy1TufdAUJz9RNF40nt3c7mXtW6+c/pDB0Z//UA0c6K0+5WuJdVXpDvfCyNc9QkoSHyElCoimQhCcTYDi7jw3P9CaQRFs415dFQ8fSuCsaxj1k+QlFQHQ63McbuyI8iK66lJ8kcC+Gs18SJUHERX18DACGwJLSFh8eDl3pjPwglrHz+HcwndzOUqUnk6Rnx12wJXc9uoY297Dxz5pOub8CDDGe+CJguMXBUXGS6omMmLbgm3E4kCc3DGqlQa3w/qSiw2l2uBPVTNKNn/PjXIv9qtUp99kmHthkmHUXD0kAZ20l5YlcSMnM7jsRF7iRZVCn6lVpOpVa6UuGKVlMvdV1sMn23ted2BigV+qUTKZWMUCnHKAPypxDdbKLiba2PDlBq5t7H88+9q8Oua1myhO5MH7W7bGtLIwO0vSqVINmWKKGf7csvfKuAXq8dtZ1vVFhhrxUsGPfrFwMNSqHGpR413mF2FCSQ1esckdc6fUnEXHx7+Y4XeL/oSpniHrIWIXB5Gqut5XuojwJ35n0ejFJ1CpHpepTdeLytrdl62aka396vK3C7OiOyiwuvJgmZnSCcrRJRRTms2rZu/Dkr48lzA+xQB6UBHpygwQVzoX+kCHI7k9uurPj1ccpT8LByCkze7GYILIalqzNSwyzxNikVvx6fJI3VQhOd7jwQlQ20qCIPB3MD2NXc+aMIoU+xD2CVnBBFwQE4uPNEG9tcVTG2Ov3yHxX/uQZvVhGpmYZwyYJR5WnxySaAtn6GqtrV7MzI8Nk1MvVRaodnf0yjCFJwvJk//8ynvFH43eeMq38pT9JOKrE/L70SJ701mJHmHWQBFSR4FB65QODgg+Q69W5/RLQmpVKhcTtSakYMChLnR46Dwkxgf0ABxIee5l/aCXmYtIjedJbR9/7mzQTMw1q6RouvIqJN1OclKAdmpuUYNRISJKB/RJ0WkGeqmvXe3AjIEkwGSEAl+IhcdwTeTK+V5JkbLpe2mOCJPD0IVt2/yxTZpoh+iSBXw+ZDSN7xsMN6nk8ScnM6n2eRHKSEIxLFqQVqUm6vP6JEcZgiOIEkoT1MKOn8Q8+EkBJ+mJeWG80eVbNGo+2TobSfYKo1sa6lga2xPraYofHWxvrfRYx6WVj8Ai04EnkMjx6of0gmjhisEtXOrpsogfpWU+SZTKISQwItOadH6yLl9sUHdstcNVDsjqWF38eYPyWlutlegIlUUttpsO34Nmmy1fMNrtT1G8JD7dEARFX/JS0yMgTtrRk/pLxRZEOnPssLdeb9CTLoMYrjk5IocjONF5psNiFUUU+kti/OmTd+W4cyb5MDJFp4axeFnSNTNXFz8m4WbBUSU8zNDZZHA5XyFBNlCcRDshI/ERcsvAE0kGWdWMoQqG/SWNQy5tHMTvcwnd2ufFy48UomJRUQ0tzJw9VQA8oiVKGiNHVXG9e/0y8FUdKyROERosfXdMXyhMlwYAEjdxfUWkW6jSImLB6Qt4ZJiFJ197a5XQGoEpqkk6SVHKA07CaLW//Ng4riCXjybwHV1EZEQ4oidgaxzBwsNEmtIGiI/dwxPPOvhCA6U0aS7vN7XZ7GxLEWhIOTfqQBErCeXd8vSpniDI1Cy93p9lReTKGtl4CntCFs8JAFEhSb3X5lELy6gkrKS43ERa3Z9utUCp1Ro3V3E02o16dnWHUyBMrciTRjJmuGlKgHjLWP3cMqmCfHskTuiZQeJCkiIsfO+tFFAV3awjZcHu2yf8qpVqndtmd6Sl6hFtypRCs5q6d72lvuhMk4SmgBHliVTscKU/omkDhIUkru57sqLMKJwmxJd0vptuiELuSlKhN1qs1Mqcc9IuWx/P9iogndz26hq4JFJ/YdJGdAyy4P7/Oi2u8Yd+0amWyUaNVyT4MKqQIn8hOrCxK+DyZUHR7NB8tQiEcZod7i99aKp1Wh8XK2hW4cJ9BDzcXd3mciULB6FTKBJ1KFR+FAtf/hA/WxSoVFiZPUjKz73hwFW2RkmCPB8kpKQ9/97spKSmRH/CVsx1k5MTlcndY7OTF/bTL5uyfZfILvNh3tUqhUys14Ici7q4SSOIzSbgH8GTxKjpOEhHsru4Y569/+9vy5d2h+S9+8YsL589HSJWPa6wHm2xQj9YOW1vH9bwwNMSoV6sRSiX4FtsrFAq1gtGqVHF7uUCS2BYOh7MO98jJM29avIy29UiAwCbDU9l12223Wa3dhhsb/fr1mzE9/HUTd9Z1/Vd5e12jpbHZSip/wY30FH2/DGNqks5k0Bh0aoWfWOCDOBQQAnZ4fsMzjnNHe56Pn/fQI7ShR4j6Tgcp7mppafH+vPXGf4pChdnxu7Kr1Y2dLo9YJSVowRC581SyAhpi/XRjPAzPi+YJxKQPrsIofSDhcDV3OVN1qtmzZ8OccJ/jn+EdcHut9fnDjbUtXURDMtMMOq2q514fyAhirXiYGU8gurMZX3QbbeURItO8O7/p99rTj2F78wcfEG7AlmzcuDE8nsCTPPFlHSEJGJIrT6171NC1672OVx+PH5KI1pOUzGxanxIeEm1nUzqPZFp2p3Ye4T50V72aMvixXTt3hn1Ys8P9ytmOT861WqwOWYuvopTe+OqQ9bONcfgwOnE86cULZ8kBvaMWrEi1HoGAqF3tAaKLqnVK/QBFv7vDdu1vVJhbrM7mNlZJstIMPZckUI+une/FlYaEzxM6+i4cOe3/O6bhudCBePlTipZDyuE/ZdRJohjyzkULGXFv8ZAErj0pQUsZEic8GU8JIBC1iXdaNTlDml/3DrQCwn3lQ2fjTuXgx1hh4WVLhdkBhhxssnnXpJD8b3LPJAlDqhtXXn/0HClOYV+Vp2I4sOgDxaxZswTump039JHn11EChOXaX9Y7vg6558+UrylSpo1L0Qwxqbgl6uBAKs3Oig4HSBKwZOvylQ6Yk/5Zph7tTAL3IJ464q79nwjl25hpCr3JVVsl+WQVEXqSQtPBYaHBNAevoc2vD2zdFNCleONEqx0vUcc36NXgScPVTp1W1aNHSwL04nqTftFyhcEkZE0JcAMvZWqWfuFy/BY45qg46Thdgg8jTwyIGI8vmDmb+pOw0WyYXJN0j8ptS+4KGojvUiyqV+SIzhZoVe1mu93hauuwud0MqBJv9YuRttGcIV3Fm4VLkP3El4jZVAPz1UPHasZM1920mJ3Wota6GmoYh112nsCcUJ5EApdC12S8qTZxscFRa7JX+e8AkpxUFIrudBUKRFw2m9Nmd3VaHbD1IAxMS+8Jwxx2b54Y7lmNP5lt9DyXuqXeVrKNsVpUg/LBEGViqjp/knb6fIVGy8Zj4tkigidFS7+TkklDr4hvujKxLmFei2FyQtdZnbPJ+0cgSRg8Ye+iUpGUoCVBF9jicrnBE3zSO4TFVvyhdzYMWmFa+UvIBVv0xdvinZfOYh/sCZ6wHYpay3qY/En241+KpYoInkwoup3yRCpY1f0RhuE90XbWy7QodikWhn1M+JNEE1vTZdSrU5N0Wo2qF1womHjrtjd95MXd0aKbvRT6ABpgmy8M62gBKxSJKdxse3AGvwXBoTzpMejQ5dcm3ulW6MAWpZutgf9EeV/kh4WwqFU93tDDaXS+9zJ5lpCvUNRWagvnosVrp813tzSESG057HDzritVEBaFwWQr3RXwmPxQ08Ya8zCsInXVxeT785tezmn/hF4QwhA05a59n/BUCmMHMqWePBwi5OwU+1eHIhmNEaEnI6fMyOg/kN5FmSx+g2lOo2lOrdV61ZXQpxlS/KHl3d+H9B5s6HXT4m79HDMdcsHv7COECD2pq66kRZCyol2bP0B3+byjL/7t6OwRHQmftEies8W5DqgK/ilfASWNu+IFekftmIbnhlrb9ij/2tfoEd5QoL30n6pF3TxR6E26uffJt3q3KD2poK1Zlnvgah/UumlI8+vYTmUYE9NhZnpz6MUWlVSeQvcfYfmWT+kknH3XrvdkkhQRPGlprKNtWnKkWo+Mqf+5d/XXdHdxJNlhyayCW5pJ82i4rhY2RnLVVpECR6nOEIeCn/Fe+wthWOx5QvVE8kArv+n3mebdPp/PdX8Wc5640QrdbqfTTZaFcbndyutrfDEalYJbEY9bo9vudDmc7gUD2AdNZmgUOiVeTIZW8eZbr1afPiGXNFWc9H6mNngiU4mxuCy7fH9wX8PA1k3TLz/gTxJgrLs0i6mN7elBSFQKdphfqehen9vmcnc5XFaby2JzNlvsV832pg5bQ4etvt1W19Z1pbWrscOGzwdomGnJqqFG5QC9AiRhPGUcMoZwp0t8tCtwK0/N4pJjlCc9JtCadvkBKAlP7fBi199jfp4KhYKlCt6V3RtK0EbJeN7Bn+6XSumh07VPiv0W/84bPU6+skAfixJsshf4o8wZ7K088vLkzJEDtKFH4tdBj8KvH020neXfc677U7j5uKCKspsqSiXHGc/LQxj23YsteJ1uC5DVnlAk1/q6JDtMtm2lu3jMCZTHcM9qCEt4XyRunTtza/O0Bd9Ua7S00YdBkjEN8Ou1Vk3/kC+nJsPO6MrdI+KBKh437/mfXQ5Pce3T7h95/mc8C+WxQZrDzfQ3qHyex52dN7Rk6xaH3S7HGbo7WjTjb2EfxPWXX/IMTboaarTT5kNS2DpiWX08wdkjB+jy2+FECMrE49kvCd8/y8XoamxdLiYeqKJSuhVuhdOtYB/iqGQU7JMcGYWLfQQXyw+vZ0Lgn5CUgmTfdjVyysxjxTvkOD0Y945XH4eShFwOD1GZtnCuftFy66cb5dUThs0O10++bWGfbe5tDneFxV3Z6TrU6jpt7n61O91o0KkaKYvY1awlYC5a3fHwV3crB3NNPcibovtzJXNdW4BWu6soM0DE8dXBYplOjy0ZFlAnrzQkQE/UA0c6K0+JrRcWrSd11RUxf4j78caummtPVBtgUucmqNP0KrnpUW52XbC4Gm0BGm6NZ31gnZKZmKSakKjSSVSqi6OBhAG/MRZUYf2Jwu1WuCAkjFPpUQ/ytDr80OsZQza3u7zdMSrxhqY1cvJMvdFktcRyBVTOycCotL/0qLx6AnRZzDEs9Lpqdf7+aPO5Fjt5lTZ07a7pPFRnvdrl0igV6VITpsbqLml17mhyYsPC+/Rcp5vd+ZzFlatXGiV6tk6OTnmyw8XEDbx1g7Moyhv+ySJBrRie4Hsjas6faaq9HMOTh+zob/s2+1cYTDhJUSshhcOT1oa6wtsWxsrNN1ld+2r9HoLjcFe12cEWQpgkrTIp4gcgQkNAj/0tTlE9OgIwUCXPIA1VjGwfztIvrqjiyXF1s4JsXHvv/sTidE9L1fgngS4cPxLbk4c/AUkYz4gka+gFz2oMhycOux0kidVceRAAZOh0BG46hDAgEiFMdTsuhOKq1cXzMqqVGr/5sWjub39tDy/mgbCAKiNMSp0U024H6JU1Xe52RxxRxYctSuYaYTyjKPg3rl5+wvWllbpDfI22dNfnsT1t+BOSGlaotZAX56WzcvkTgurTxxnmgVj9tQvzTG+daQsZnu2+bCEdmZBjwuH83wkpnM8BQyLJNeF3P21w3J8jzUoOizLVm+vscWJUfFNhCtaTKD3Pq7v2rGC4GPclqzvrxscDx8Pzbt2d1xuDesw0gSuDMWGsVx8PmN5PPyJFyqjPoFaMSNEYvBa/GqBXwEZHckw069MSWQudkrkjXa2L13sF1VCSIUilApfQ81JUWgL87TFfr8d1pSq8XwxTT2I+YeuRguT/PtZ8uSOiOU1QD9BjfLpufEaAJ6PPSlVNS1bVWF2Ndje8ChlorrGKaPolrc7RCdK07gytYmm2BqrS5WLiFmQwkgxL1noE2YfbKZnZsS19spXu0t50Jykxtpf+U16eQEDHF8V4qBEK8OTkNERfh65YxXIjN0E9IlkzPEWLjZAd+VCjcuiNARVaf1mbU2AmAK8ktaLvUOWGBJfVhavn/UnMnzDlaq5v++WDMPFiy/vF8URvNE1b8M1pC5bE8CGmMB7HG7uON9nOtdjCySCpFQZPwzWG1XzBHOhMoorZ2yyIKu0OJkm6OaM9iyoVnb48ScnMiocTC2MOjKB7CAEhVZ+xDbfOtdg/rzaHRw8OCNXwOsQwH1zogJ7MGWCE2xF7EFiXY+2uNgE5qJou1wBJh3RAlW/naD5tcMShrffTE98z7LlPLOTjCaLJoqUP5HtGUmN+omjW1/JXkgGEQeS2u8YCtyN2RH9ColKIpGRopF+REYEcVGVvs+N0R1zLirRhZ4ytV7DnOkwouv2OB1fFyUPi5SCJN+DjQRWxnSXin5C73Z+jIdOV5AB4ArbEcwyGvz2k7nHj4u5OM8lHsRN6O8094PmMUJLFq9bEySki3JKVJEBIQ++PAfrQrZ9MfJXvtEcnKAfoNZ6aGhFcsTXUV//pFW1mVtaCuwwyj2kICQ7VQ64/JIi5cSoVmU/vOF0S8wcGBW4fcVU5j7hI1uPPyTV+Iy8c2dR5Bp75bYzcF8cTg6krLBAWZ5uwMXunpaP99AnmNNNUvBM8AVtSpsxQxUfg4ANVzhC8tIVzhawQ6d/XJ2ewaQPyEDirpYMs8BBeYjpw3AW/vmzNz+LkYq3eI/vTX2HlF+aZxFqUzXUOno4cLHp4gDaag4MIwz4r/1orIKfUWV1Rv/Vj8KS7ORpN6UW3ZS1Yoo2PfFQwgCTm9c/wZKtgE0ZOmZk/eQa4wWMZQJhje3ecPXKwpUHoEkKK5386d+teu//3PfbKn+PEnESBJ4xnQObBkUkBBxzD48msVFUU9ASwdHSU7j1wtHh/6d79+CdafM7SB4S0eKfFDKrUb92CSIx8kjh6XFrRbTiCHOcZUn6FwNVcH7AkPm/0uGkLlojNxx7fu6N48ztC2KL64s3R/TKV+47cMLAd20pHH3xeHY1JCw4Xc7rZdscgEV1Du9MdrJIXzuGmVHUUGPLZW3//47O/Kdm5u/biJdY352SPzus3QtE5dWSeRqdtd7idwWMxpUZrGj4S3NCkpHV4ohFbY33rkYNNe3dqM7L1/XOlPVucidZmtp5hFw4mDyQJJ/4xmHxmWSG+WrbmmaKl3wlj8WsyYm5ubQ655hZ7LxfMYsv1Xnj9hoHt4s1vp2RmxYNRGZGijXDMRCA6He5zLfYRKUKLFxODVM7Du8+SnyTlR49v+PVLjbV1hB53LLu7sOimjH7XByhGMExXKgPrUtPlwjvXl0M94E9ADEt1ZWeg9oEdru7dCdMi+TnbtCbNmOmOypOWt3+r0JtUQwpg4sWu7eBNEtCjaGlE9bgImhavWgNJ+PhPa0P7+IBUwW8iIIScxZYnkpRyCY++Ikx5DdArF2XKXrP45efbNzzfPdv+/n/7wbx77w4W6kDZ2BqzdDb19N6H2059vMWHGzAnxryhKpOJ5L60GVm6zCzheTBPTk+Zq1dkaNgFu/Y2OyssrpAJLrxspbu6dr3X2bwOTp1lS85gIZzhFlVB+5730Cqp+nEcp6WhHtoQVMccVdcnu8Oo+FCFRH5gbcxjsENXrOdabVetrssd9k55JmPAx/98erqoX9nRdMNgH1rk7emyK8nFcxee/f7/IdujJo1/ct3vhPBq03/9EXEa91ujJk1ILxinHDjkisrIxpCeMUH+xFqipxPJ1LILPUJL8UmGZ9snl4BrIkJhPGzh1hNiRcaT40J8BbW5IWyrrXR8VcINqjzy/DrJC/XffP6pYNmwG3hCqPLaW10dFrd/ls2TRhgXLJPQ2lh3pbqitaFeVv2BqrxxqvWq1SnHwSFconw84ymLJOPinrovtVTVwfz4ybLvknALWPH0f9zyjTv4Pcy6//dzBGlceHbLwjuMCTKu8/36JXHLxISR873r0TVyOAK04XU/Xs4Xd3FAADZ8kGrNry0+VGlpqCvZugUvzgBxbGltrOcyBiTtIJ+khJyeFTbInBb4EzZlpFcKzBGDHhCQ29OZqKF0736QBA0djR7C4m1IApLkhdVPYDdCkp//+X9kZQjBUKPSv6CGZ2CePJJBM+lW62cbhYwnjpw8UybbnJyRPaHo9oDrJwUIEobnKdf+1OhPFW9Ef01uWUlCju9dog+eQF7CGKeXG0c9yV9oAmn9/Njw/O+53ZYsfygKJAEmJqr8eQKSsBOYg6fR4UyM33kKYVXnB+v415yf99Aj8p08gqaAPAkcJ4Aqm9aa8B4njQPdvKwk8QdCu+jko8WbE7aHmjTrJugDR5tgCbFSr58WzopSrTekI2C1TqPNZf10I39wBSuf8NjLPGtmo7+Xteg42AhMUCYkGBVQlYmj4+LZylEmSRi5ryjy5AIx4iMnTSBhGOfOfbD97x/i/ZvLHyL/jI6YcJIS0MvpbrvP8tZv+ad/IAzTL1puWvlL7webePf3cp88vAM8BXEQnrzzd7DBF1cQqrzwutV/wD6aON7YJZNxD+FYsg1MHAP2fcvGN+FVtmx86/5/+0FAJ4P3mxfe8dHGN4lXiRpVYFF0zQFG3wkHzOufMT741A3lj4GEJfEnf/KvUukn/2IUy9Y845+pCh1ZPblK/6MHhWaB5Jj9zC39GE3A0wsfcIwmvNs6oceXn20PJjus3e+XPWjEMA9tovesAc+4TeBIRJUzBKoCAoRc6wSkQgymLZzrY7XlPvmA6VxBPvVb87X9MpQQFh5nL2P8o4p2/OOp9UqMTxlZ8fS/c0nhwlk3rf7NswFVwtLB2oBBI9je9+ZvsKYf4sOfQZYWExKVwVYRgP1wVp6CV8G74Z7VAeOr6/fintXZeUOHKDpje9lV//ljQQ8PGNRfOW28+vQF59VWd0gnlJCSKuEpZhvVX9Z2OqI4GylJq9pdY/m40gwrj5dCwUi7DFIkyMkbOKxgtPc/iaH3Nc1X6vZ9vh0/umXhPOyz+6PPWq82KxgFjE20JEXR7nQHywWr8yfZSraxjzI98SU7DM9b7tXVP//mSRPGjRsfw8FuERktki++ZXIICZJ8rWX07v82IVXulba9ATvkPeT/WZX5rTNtH1zoYHoOvMkDwYEKechzJZrnMC1ZxRNTQSgYT/1vx6uPd+16j/9Qosb4Y6knBFqNYu4MjUKhKDsd1FinZGZLzvskrfLWXCO7xraCabO5HFGf6VrT4ahqs0NV0vWqHsETcANR2fTb55CoDJLyzeUP4ZNongO/pKgyc11XqlwNNYxn6q/jdIlqYH4wYelyMbl6ZQyn2oczjvbw3dphg4LaFfmGIKf303Nro5CBc4Yt8nUhNIpClWTcOvugobLHvscWkBSexS70C5dzA/CIwSAsU596pTo5Lw5n/Ic5kojo643njQEHIusuRmOoHk0Wr3S9MjokAeLW2cczoAA8k9WUqVnkQQsECEPmjx3x8ADt9BSVj3RkaBVCFiSIO54A/TKUb/zK9K35vga3paGutbEuCqcOevz2yNXokGThYFNaD4m44g3J50t4xuA1k27ltskTtHVKVoUeHqBZmq0BYfCalarCdo/UEw4/elD3yx8bEow3cP3M4YNRIMl/H2vujMrTDsCQ8BaaoACK33mD53mIkBTyuGp/WwsBAWHwgiLFfA1yCb4fMdimtSbvChe511qOJkk8EVcSbe7hoWTrFsQXttJdPItxqUdPY+JgKXvZecJcq3Dhhu3PHDkg35P4QI+3z7RFjSSeensNbfFhAG2AmyFoeeu3waIvMocxzpdUlVLP4FXgWIi5P3tEriqJ3TWW6HgSxjN0c88wat/Djbg2v811l2RJIeEzsXozTxjPWCSo8r2lukPXZnRJjoMiH+QQkX3PMxl6xfK40UdddUXJjW3AWVsZkCrOylN9jicED9+t/dUjdRqLLH9/1GqH2dXsc420xYcXcX38eoDlS8ggibdXwXbXvk/i/y+Sa74ehCWZ2XqcKZAjFoqOOVlKI64IIq5gw82u5nqoCjyJMiXL1VLPP3Wxl+sJQSbzLz3TIPlhQxoGogNhPNWE2ndJcHzvjpJQUTfoASXxJonnybh9T08I8t1/O674d2mPSVrw8cauc63XFyhK0yvT9arhyeyj5IijePZQE7XvMbElX7z5ehi/WH36BKI1vdHUF3kCSUllvmpmxkh72DS9CooxJ5fPw0RiY27NNVL7Hh5J3nz+KbFDAu5rKP/Xvomz5/W5uItghPtvMZD+xq5ISEhH36NAEqfTabfbrVZrV1eXzWbD9r5P/tFH4y4gkakayvyjgvlWNP+qyxFMFV5ISSInSTQajV6vV6vVeMc/VSoVCIMN8MTcevXkvn+OvfnWvsgTYKD78wbF1HYmL2p/1VVrmJXZsDcRJgD6IM4cOfDJn9aGJElSUlJycrJOF3SthZSUlLN7tw0pmGBKSetzcZeHi+bR7j9E868Ke317mgsWi+LN77y/9lc8JFEqlWlpaUOHDs3KyuIhCYHN2vnlu+vt1s6+yBMSfY2JLlXCsVI9bSZWbNHaWIdYi2eNdyIRgwcPBk/AFoGHbb5S88krP68pPxFXf2z01gXNYfY0M2NqmdlR+C6ETzw1YHNyjTUdDn/NmZ5NIy4RMlKy9SMeGUGUBXrAh4RxcKjK3nfXI/rKGjxcpTdOWXB3H+IJAEmxKjIlTxP7Y0AQnkAxvpFnAoue2Oc7AJqmV1FnIgQhn9VmMpkyMzPDY4g3zC1XK8tKsNHneAKMd/++VPGfcnv6e4YlQjE4qhjUivEZuunZBhJWBcwai32iQ18DpON48Y6SbVt4GGIwGKAheO99f7466t9nLnT/Qm6qgBhPTk7j1prwcR0BF5gcn055EpgeZ48cOHP44BneiRIw6BkZGTIxBMIS8wyYOhZfGQ2q+NODn1dx+AiHWKH69Any1CdshFw9R6PRQEMSE/nyhIMGDRo5ciSIhI1Lly4dOHBg07ubLBYLfjErM6t///78XwFPnz9jdmyvie/ztKKDS1fUp6pT61NWDRgVg9men1ebP6u6wYAuHGzqU2Pwbz7/VEDpELWmVEiGGI3GSZMmLVmyBAzx+VFbW9uax9ds27aNdYapaQUFBTxaBDFZ/ONnYyomlqjyBPTYf8xwtFzX1NI9mb5wwdLodxU+jxyCfe9rM+BfWnVvJBOzhWjIHXfcAYaAKjz7vP/++2AL2xDV6qlTpvIccOycb4ydsyAm1yqRqR7t/kOUeLK/zLDjkBE88f9R7qhx07/5HY0+quYPPAFb0vSqhXmmvpbmAkPAE/kYguBq+fLleBdyQEgKqAJ5AVVGjRzFE4OhkQyZOC3yP38g83ktM9vBCJqBN5T5x0D353AKsvMEDPl4j4kTkGDCiquQNXh4PLSh1oa6bPkfshFb+xEw7oqcIcDNN998//3388uID06dOrXs3mWgCrYnTpiYlZUlH1X0TMPN7tUOxgSq1CpmB3PI2K0/syfHvYebQCUjT85Uad/blhhQQwJi5IzZkNcoC8sNJ+ypUxpfdPu8B1f1Yp4Ub36HfxA9PIYAYAjCrTBOSXgAFmH0Uej+RSrz1fVukclsZwZ3KK6zRe9uwA7+8wvl4gkYsuOg6MnlWr1h0oKlksirKLQ21n38p7Vk2bGUzOzH1m7s3SZe4AJr8NZJSUlCGBIJSfypMnPGTB5br9Jo00eMu2nRUr1JxOPB4MXz3X/NYfaEd3ri1qsXAotV8ZsN6WXl4QxHOB2OmvITlWUlWr0xtd+A6ARa+z/5x/trf9XaWM99IvkjXOLKnHz+59dC7mYymRD/QEZCVi4STJo0CTyJ5MQKCgouX7586qtTLperubk5p19OsJIwt8tZeerYPz96r6OlOSE1LVHA0AroMc79395KIhYS6wmirJf+mgaqRH4omBaEYdBZmSIxaMihrVuOF+/wz/xMKLp98ao1vZInx/fugHIG+ymaZkJCgti6LLiRF198UZQnCYb5C+bDrmADhn5sAd8DHM+fP2+1sitUQVWGFEzIGTwc7yMGqxNN19teAlOd6K7KZA7DiEd4YlLyRDhJcE0HDRpksVgqKiqqL1bjk6zMrID6jkhswKhxI2fMSZFOXs6XlZRs//Rc6SE0C4UiwNnqjabHXvlz3M7VliPoIiYEMiK8sJcDwi0eMXl57cvr16+HTb9r8V0vvfQSP50gKfPmzxPi6c1mc2Wl73ODCws0rz2XIsd1kyzuEkWSJ554YuHChXPmzJk6dWr/nP5Xm6/u3rMbhDF7unbcLe9IrOVKzfnD+xCMYUPBKAwJSSq16Op3c8tVRHRnD+4u+eidSydLHZZ2rVaLNuFwOOx2trxF4QHZGR+pNdo4X/E2PAn94q03fD6EA8nwACFWwF4jJJYtW+Y/kkiwfsP63/zmN11dXdAH8LC1tbWwsJDnUDgZnV63e/dubDc2NQ4cODAYb3H7nE5nZ+cNM1VqG1w5War8wdKXVkijJ6AHSCIwtfXkk0+OHDnS50N0Idu2bduK/7Ztg+ijIxnQf0BqamqwkAzuJaVfLt5JVOaTU66vOo93u7Wz+UpNy5XLeAdPgpoipxOdE0Qc+obrTkTGmJDY+yTlk9fXHiveQbbBipSUlPAExAevvvpqQJWAOMyY2f2497m3zsVtxW7YWXj0lTcoz7+peN+4Cxcu2Gw3zI9IMCk+fC09wSTxMiDSMO/PW5IFkmTUqFEB/3J0JMs8wMX9+/vsf/86/C+DwYDwDITxCZfR6PG6LNFUHpVKleQBJ+jgDN53vP3GnY/8uNeQxGGpTzTvvnOuoaPTWFWbGHndu3eAEDjEuHTpejvzfB1Po/fGc88+t+zeZdhAiIEGECz3hRvXr1+/ixcven/YYXb/8rX2F56QuMBCgvmMZeU64dmtJUuW8O+Qm5v7+JrHDxw4sGH9hqKiojNnzuz6566Tp042NzdHpz2hi01PT8ft6aipJLrUO9B2/G8aQ275xQGXG1IlJAkbTVgsAT9H1MT1Pl9//TUu6YoVK4QccKYHZPtCxQX+OM0/6Cj+V1fpKXt88QQRF8RE4M6IYgX2KKz4zp8Pqhw8cPDeZfd2dHRAXg4fPozLHc22deijt+NwrnYYgDf7Yusl4WO+4qypl274dHmIC9Di0ZpnzJgBUyo8J4a+kiOYjwnxASQFwuIb2/+uFcISRz5+676Ek+eFPlv95ptvHjdOnDnGJQZhHnroIdi7w0cOX7p86evarzVqjcDBrwgBkjRdrhoycXqPJgli1D1v/dHpEL1WE6mEx13LzMqsra3dsXPHufPnIOzt7e06D8hu2GfYsMDPTIXPRDf3ox/9aM6cORqNiOwLtGjbF9saGthxcQWjCJYnYDy5bLfbjTjZ+0ObHS/3jInauOAJxOSND1LsDqGeCSSBPwnji3BL0C0Rthw7diyabCFeKHfU+B5KElAdJOFJYwSzkYiR7r//fpAE25MmTVq8ePHy5cuHDx9+5MiRi5cuwkaCMKABmikIMH269F2JXqcnhffgwJAhQ/j21OsbGxt9Pjx1zrHoVn2iSZqVUiI6ys5DJkmGFIVrC+QYkdjjjz8OLYZp2fvl3ij4lsqyEgRgPZQnpVs3N1+pEWXKwRDESP4RMsm1oO1C4fHPq81Xi/cW40YcPXo0mEXhAY6TOzD3ueee4wm8uzMQDkd9fX3ITIz/5+99KlnMHBFPxFZwhXdBA7IFgS+2cZPgW/jj175MFZwzWYpBOEnAEGgI//WHbywoKCAtuOxYGTa2b98u6sQgR6Sa6y9//cvnn38e7Is4Nx+yNwzIk093W2PPk/1lBrFicvHixRdffPHMmTORnzd3BQFSvxAdqvQgWy+WJIwnGylw3gioQjbgVWC1t2zZ4pOf5QeZc4KNsQVjDx06FPIu41tCBGn6AJOIYOWlSnxFwJNj4UxvwtV84YUX0GmtW7cOF1cSzkQNaHa7/rJObKwfE0/y5bvrQ5IElID3sHZZEcEePny4tbVVeMFvbm7uyhUryXb5mXIIy8aNGwUGC4i1DhxgV6WA+4fD4SFYwZju50whxguDJ2wI85U0PAkzUdjUojpTFX4yodEDhGGgCm4VaCP2CGS8liDYsL0cQKy/7Y8vxqT4XyBartRASfg9CSnvJUkk9OtwAmiIq1aJm3UDl/j39/+OXwdJLly4oFarESyETP6+//776zesZzxj7cOGDiM5A1HRlCi0m12SXNUw9WTHIckeXChKrzkcONi9TA5PqZxMsFk70RDRYcehsJw9uGfrH1/kJwlEY/Xq1VymFW0RbXfb1m2cbxZuFH/+3M/JdvXFarhEElcHu6FgFKiFiMtgMEycMJHLE4C0QfWk4PpzC8NL2JyrkubR0GHqydFyyVa74neNIeNjdEsxaZGXy0/UV53PnzFn5IzZMZyDyQEnc1RYasu/JCLXgzC+dNmyZS+//PKly+w445mzZ9D6QRKEVbint9xyC8cERNfvvPPOzp073W731ClTvfUf4sPTAITrCSlm9UeCURkznly6ouaf7y4KAWNi9D3QdISn3n7dW7vJvUlLTSMXHaE2uiVc9LKysk3vbkLflpiYmJWZFZ7aoOvyDoi5b/EXlpO7Pz97cHds2QJZw2kIt+ySTBThAJ6QWqz6+npcN3Kh9nlAvoszLfn5+f6/zj+ZXnh07TPOyCF/iDpmPNl/TLIGgb4k4FArQljcADYx8uM1P/zhD70vJSj07HPsak4IiKHLYAiuNdd1gXWPPvrotm3b8Otlx8qwTx4wKC9kRROi5OXLl3Mng2+B18Rp4P0CcwGhwtiCsfxsgWMBYaK5ciE0BN8rth4UDVdCqpBaLOLL4VKmTJni8138XSR/NEFyYsy1Mkohe/pgxGBpOvRwxuPf+jSp0yqNnCFQDnjPVqxc0dXFrgKsYBS4B8nJyWjB0Nbdu3c/88wzLc0tw4YNGzNmzNy5cxHy+jBNp9OBPytXrhw4cODJEyerqqsgPi63C7LA08U+/fTT+BbvgwwfPvzeZffiBpQeLSVDXTyjwk6Ho+lyNexBTfkJl8OhT0jSyiYvEJCqspL9//grvq7t2nTlZg/qG+qbrwGXTqPR+JfN49Ll5ORIeD4DcwdC4bHRae0UuL4wbtmKFStCptc2bNiAi894irh4QgM0jICFfwkmxZrvJWq1EgyFi9YTCYMuXKaAYgI1IN0DrjjCJ/RJuF7cT9GaSae1xAP+6BneFOEyQjh0dWjoCI4D9kwkZgt4EByB5Gccwuqj4BCat24u3bo5td+Ae1f8UJWYEskTVX3UA6+a8uP4CrLU4iAP0B1wJ4/rhljlwMEDZGICCRpBDG8lLC0t5bHOvmHV2pfbWln/zWMVvCUFhj5YgMRNqSBBspBvJ3UrjGe6K59XvHw54OffXmSUaiKKaJ6UnZFmVTjc2mCtXMjVgV6HLNEnRhAB2JiCMWBLe3t78d7igMve8Eyy4+4BjxwF7AK8V0Nst7na7U7ybne5sSFENPBqYWeYNYEY3hX+aGfB0q9kDBtgSxbef5+Y7KuHr3qvTXr06FEhfwIoB1VH60dHjg4bessTrUF4CU/QGcEc+kgKGeYXOIJ5PaV54ABxoazVDC4m+MaA5gQMuW+hZJIumidSZbrQkoJd963btnbzJMjVET6TgWDlipWXL12GLEATTp466a8qPNX+nJUUXnPpL3SJWiVezI2TI8EWh/uG2u9nn3vuq1Onyo+W8KyiQNqcEIPhLadXm69CZEgfAX2GyQ5pDGbMnMENmdfW1kLSESQLSXxdqLjgc/IwkGJJQpLIZJtnQYmWlpZgpV8v/CRZwlmN4myGxaqQZA4Dwq1gaoB2SW4PmnIwBYfhFvuNaC4kGQ9VQQzmczI8zY4bqBE+mikw0w3mpOpU3q9f/b+fmBtqGc+ki2Dzk0SttkjkFJ09iRsRiZECEJKM4gF3FzgPDRXiL57gmjVO3idGDSP1j/tFWAeSBOuhwJBgEdfPfpRYWCDlIwTF8eTSFWm+m0cNiCPkERPhNUi+l/7Z58gGGRQTIibsilIePSFT9oX3AuFdFtKsyTbI7F/UhCOH0eZwTDKGSMoW8V5eXs4/vAvPw21zFtnbJQY0cpyHqfm6JpKrQUb6CUmCrThcU1MTUEmgISDJojkSrxktjidnqyWY+BJsirxP/x3QD/AIkZAMJje+691KeG5kyAhQcuAkSffPeIbn/PMN4R127ctrB+ayTZ/MR2BCVfjm5uZyw/McTxobG3mECCRZMH+B/+X1nxkS0hSBJHA4iBIDksTpdJ4/fz7g8DxI8j/PpUhOEtE8uShF0MUTNZF0DU+cI8qWBAyjuyW7od6btyHzLaJMfITgAhiYCp/WwL+oj0ClqvcALZ6/BXNljt6nsWXLFiFhAtjofebr1q0TUiKJUAKmaOfOncOGDZs5Y2bABgDLfvbs2YAV4iMGqz98LX3EYFnmNovjSeQZ4WADi1yKg2wYPPDvTYVPrw/cW8+Yyd1ILvTyjjF8SMudTzSryLz7cu8AhhG8XklopTp7BtEXf6O/YTGHa46OX1IKPPA/c3gbnvkUuM5gCL7rp0//NCcnp2hW0bChwwKm70HvyspK6In/j6Ahf/tdquTLEYWZ74rQxMOA8q9Cy58R5o+4yKiLd5Qc8EZy2+iTQEWjB/ykhY8UtUAJGlPYFoUADZpcCsQ8o0aOIt8e4TGJOUYkiauEPgImDS2ePysARzd/QffURZwJiYL4c2VQbBIRsOahwCsS8cynIAvqebMd16q4uBinhN5h9OjRwQ5rt9vhFYPlf3/8vQQ5Yq3w9SRC8OSCfZqmv+aSMTWeFoC4ds3ja+677z7+ZA5HFVLBxXPMU1+Jzgh3q25TU4QXCmwndsK7Y46cJ+hBVq7sjqaqq6shKfwuBdeKkyAu/1ZeXs6T+OIUGwf3z0OAFfj1LV7AzVKpVLjdPBcZLIIhCUgSRFmQEblJElWegCH8dQroMEgqkPUDaWn+ARuPkpAhc7gICPeGDRv47ab3P9PT04UEgUzU4W+j+e0vrgB6isdWP4bGx2M84DrIFUA7BgPBE37nwJklSBB3Jl988QUPtbgrHHJyVUggxLroQcBYa+W9JpAkJ1MVhduh7LC4o3Pj0dD5xYRLLqG5+8c5wUJz8kRMH63YtGmTwLl1kXfSYuFte4SkHNArh1wAAB4dior+4mgpO/XtiSeeCDbo7jPpHFcJ14rfLHlLChkYwcF5qOgd3EZ4oWDZAxY4ghuvPZeyYpkxandN+cjTli+POKLwTSGL3rjWk5mV6d+agwVI6EfJpUT0zHX8uP0C05FChmLErlPB89VoymMKxiy7d9noMaNhbflbG9cxk9wRj6z5D4byeHSOJ1evXiV+g/9agYHkTIir4T/+KQ/I7Qh7ahDcCI+M3LfIABmRdhgxNE+uNLqeeaUTL2yE3HvkYFt4X4PmyN9zk3W4g5n4YCmpYNEReW6EwGgwZHtiH1uTk0MqymbMmMEomC+2f4HX4cOH0cX6s4in2XGeR6PWIFLnX5Sa65hJoM9npa4l07m15HiGEf0tBH/iy9/VEHb5fwXuBboAdFIQf/6nl/C7O7iRgDJC3Ahcu3x5rRD5LkhK2Wnnw0u135rPN5J40wRreNPieWyAT6YLfs6/4+RpIlyn691eha+HwHNiZACBzBXzdjWrVq0ii4WvX7/+ggfsVO9hw4TkxDh33tbeRlozT/qIK8INudpIQMBtBwxWiVKRhggLgQuOc/CefhjwUpBnmIAkkBQyr33jxo1cpRm6hj/84Q/vv/8+OhT/ddMFAk69trY24NgIiPHtRcZoBlpBfTyMymtvdT3yMzMIE5QnEzvxCuNrQoYunDnheTJyYKO55nHS+LiaKJCKhyeXL3VXBCUmJPL7E7JQWMBEM1ks/IttX5AuH03nX4f/xRU18VgjbnqtwwOSPgqqJzeuNiJ26TOedu+jVOFJCkgOniB6RGCGjcrKyilTpgiZEhfQr9fU1OAIAUlSNFUHGYkhSc5Xu5T+H635teWF163BwrDvL2m7b367US/O/fMnE9E9Ez3BJUZvJOrIuOX43bUvr0WDzsrKGjpsKE85LXpELqWGfjTCaX1knWnCUjQ4Ug/CBF+Xmrlx2THSRnmSyD785DksJ1NcyRN/GRh3GtZOK3eD+PPpkBTyLWx52JlyrkcIWSoWEjhn+PWAdSjEr7/wRFJ0klo+AAWgHPevMUM8AueFt+61w9//9UNbwGzY7TMs//lok1ivsm7dumB3giupyMsLpzci63luWL8BrfZnT/+Mp/X7RHfh1VP6fLV3PYi0i7j6rDbC0xy57C2UDS/yEHdBOu+1bB9/kpC9yPcu82GXJBktXDd/v45Aa+W9ps3/kxZlv07o8Y9tNnADDMEGEYygjRIM+cvmrq3FdpiWBbN8zzU9xfkfDzeXleve3ZYosJiFTEuEviMomjRpEhfwVFRUINYHPdLS0oJlSCJfbdXH9EtYr0XKK4mTrvm6JjU1lf9suZ0RTWFnnujIR09IEi9goIhuYsyYMcRyeCfKQlp573gYx8fd4SEYF7JG3r/AigSbX8V4ilCib9bR4OHS9x1xBEz/qkNyCzHYtr32h+/WTRzty4eJo7ryB9t2HjLtOGgUuIYq7vQmD0hKiix4N++Oefy/dfTo0QgfuxzQBUk1gIiQjzR9oif8cQhcR/fOV5uNY42i6uQRuwYzVKJGLYJN0ty+fXthYWFA6r689mV0Z9gfP43kMQE8FSjEivz4+6YoR1mEHoihQue7+AFnX3bacstk9Y8e1PXLuCFUg1FZPLvjpgmdH+8x7S8T0exIaCtwZ3AJjS/Cbsxn2n3IfhG3k8zRQ+OYNm0aTylUwO45GMgK7Tgswv0f/OAHogY6ccXCW+4sWB7Zv8VD83GG3n8pRBhxHVo2z2wQgQzhCU0RX61YZopmlAUrDgEAPYQMtatF0Q4vxGCIxHzYgjAM/v6u2WaxbBEOdHURFtVz5kTgzV6xcgVpT1OnTIWzguEWvr4rD6u9LY1wcJMKJVlViOdSoEsCVebNm0f+io8//hj9xeDBgyPR3rhiCEIkNOMPttqFDBiGwxPO4uP1vaW6e+ZrEoyKqLElwiZCRjxIgxMyTszNZGSuDXILVz9G/BA+v5viOn5cAVyHCCWFW58BOhkwgjrqAffPSJZvtlqt6F/igSH89kN6nhDA4v9jq+1bC7RRYwupRApbUsjSeIxn9SqxKTX0hWLnn6AnjnCqjLeL8G7NsNoR8gROg2xEfoZhO/VoMgSuAfEV6BFJKaM6EoIKZEtZuV6Sx24h+Ak5gyUg2HWmPZGG8KIjUv9HJOjkqZOjHKN++MMfCrfFkiToAroIxEWgStiTn8kKl4QkMj21r6WlBQLC49TvW2SIAkMQVm3b69haLC6+kp4nwtlimd++85BpX5k+8umQcCkICdBKhPepIAkpKAZDRPWg7Mq5y5YdOHgAhnvmzJk8K1X7N+gIh958XIRPwRt4InypOJ8DwqPDaYzMHyn5DE2n0wmGIMqy2QIPrC2ao19xr1HuXBaJryAgPGUlYUAxa9YsCQ8X0OVzQBi2/5g+kgencMjIyPAZhwnYzSPcQuPwXxORAL/OsyaVcIBFJOKfdcss4nfRjnmePChQTMhcQkSJc2+d6/NT8hRF4VSBhiDcKisrGzZ0WCQ5Kx6b3tbWFrC8l5Rm3bfQIPd4iCTxVZR4wrHlnvna4XmB2XLpinrHIaNUwRh4MnDgQJJc8l4RYseOHSRqCrbaPNk/jEcU+XfSK1auIF/kvQr1xo0bIzkstzYPGE7qDv0RcuVYjiEXLlyAKEnOEP4Qa8RgNUIsuScbShtfRZUnBBNHqwKOTnZH8FYFqALCSLJwXtiIsDUD6PVJ3MWJCQH0JOwBHyjhjJkziJgUzSriSTz4LLPvnUj48KMP9+/f39rSihArvAJeniwW6AGSBBOQ2R4TItPSJxy27rWHnb+Ktj/h18Gy0xbEYIjEbpms9rEuRr2bVB/DtIAtR8t1Ej5TRVRuIJL0EWwxIQmcj88Iw5kzZ8LmifDsXHl5OSTRZ2klLoVtMprwktCBtLe3NzY2BntwLBEQkETWEEvW+CoGenJDH2NUsMHYAk0w68I2rCot3ItU8ZhAINCHRQkvQ8pZiIDLAYdtfsJOPMgHSEebB4FvrkmB4AovWQUEYdUHW1l6yBpfxZgnHCAs82dp8M7XYZTrjp7RRZMwZK6iqBISxP2wJRaLBV1+wFwzGPjiiy+KGhglc/1heHgeSxRN4HwgIDwGHdJRNE1bNFUnKz1I/up8tSuGlyLaPCGAqiwo0syfpeaRl+gTBmESCIMunD9eKikpQVPesXNHYkIif3YVRxM4MMpNkNTr9XIYbgnpwXjGQEAPWeOrOKFHjHniLS83T1b71+37p8j2HzMgMIua6QdVIAXp6elEZBCUNzU1QT3EDoyQBZEDPoeILBJbVla2p3hPbW0tWJeWliat4RYOu91uNpt5gqu+SY944QnnXkAYnlQyB/LceojM2SptNG2MJEbIW6bAN6km1UQCswfgRjBr3qeCq3jnidh4jBMZcOZMtbbHcSa2ACXM1xAssoIjnz1NVzRVK6s1J5XtsbLmPZgnHCAsxO4LIQzljCTcyMlUFRZoIB2FY7TyRVYdFnfZaScZ94hmYrd38iRswpDYjKVNtZaQp28SA2TguIENfm5MKtDgXdbKK0hHWTlb1i5t2RXlSQDC3DJZc3OhOqSH8ZeaS1c0Ta0wNhps9Fa1gRG32WyEFUCwYkTGU9NeWICASiWrbjDXShKPscPNzviPrHoJT7w9zMTRqpsnq/HuM8YvBJ5HTIIw6s4uJZhjsSpjWzgTCSsIHwgxgikGmJA/WD3C8yIbsp4YCatYbpQ74taU9wmeeKObMKNEi4x/qNbYoqr6WmGza06cZf9Zf5XR6/Ux/wNJ+MR4ElPknfuERy4QQeVkqSaN0eRkKaOwJkNv5Ubv4cn1XtOTWZ4wWgXmCHcy/DhX5Wg3u4nynK10OFy6+iamtsGpUqm8KeTzT1GC4O2ziSBwn/vsENBaEBqAEv0y2Q3IRdTW8kEcBW5c8LiO3sqNXsgT/8BsWJ4ycp0J3H2a3Wer2BpVcOZKA9tE2s2uc1XXq1ZLT9kj/ApER4nXWrxnm/0rCBmIYsTkwrKiUe48X42Xq6f7DcoTX50BVSaOVk8YpcJGGH5GKoBUtfW+bQtkkNswREiM8xdZ0cB7XxCNvssTf6kBW4bnqWJOmzgEJOJKg5soBrb7ODH6NE/8adMvUwG1yc5QkGitD7ICoSMxG5QMlCfimDN8kAqGGJpDwrae/kdBGTosLCU8oRQ7Ck61gvJELpPjeWcFB/zxuGqFVIk1qbwEUYm6RjfhA/chBeVJ7MH5HI8WdTOHBHL+ZBOlAD5hEiEA40m4wVh704NCbqjpJYg8qrm2SZtsr4WSXgIKCsoTCgrKEwoKyhMKCsoTCgrKEwoKyhMKCsoTCgoKyhMKCsoTCgrKEwoKyhMKCsoTCgrKEwoKyhMKCsoTCgoKyhMKCsoTCgrKEwoKyhMKCsoTCgrKEwoKyhMKCgrKEwoKyhMKCsoTCgrKEwoKyhMKCsoTCgrKEwoKyhMKCgrKEwqKMPH/BRgAo3YF6B5seoEAAAAASUVORK5CYII=','ตบไปเถอะ','ยินดีต้อนรับทุกท่านทุกระดับฝีมือคร้า','2014-05-03 15:30:42','2013-11-27 20:24:22',2,1),(22,'ทีมแบดมินตันวรารักษ์','0998890778','data:image/jpg;base64,/9j/4AAQSkZJRgABAQEBXgFeAAD/4gxUSUNDX1BST0ZJTEUAAQEAAAxEVUNDTQJAAABtbnRyUkdCIFhZWiAH0wAEAAQAAAAAAABhY3NwTVNGVAAAAABDQU5PWjAwOQAAAAAAAAAAAAAAAAAA9tYAAQAAAADTLUNBTk8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA5yVFJDAAABLAAACAxnVFJDAAABLAAACAxiVFJDAAABLAAACAxyWFlaAAAJOAAAABRnWFlaAAAJTAAAABRiWFlaAAAJYAAAABRjaGFkAAAJdAAAACxjcHJ0AAAJoAAAAEBkbW5kAAAJ4AAAAHxkbWRkAAAKXAAAAJR3dHB0AAAK8AAAABR0ZWNoAAALBAAAAAxkZXNjAAAKXAAAAJR1Y21JAAALEAAAATRjdXJ2AAAAAAAABAAAAAAEAAkADgATABgAHQAiACcALAAxADYAOwBAAEUASgBPAFQAWQBeAGMAaABtAHIAdgB7AIAAhQCKAI8AlACZAJ4AowCoAK0AsgC3ALwAwQDGAMsA0ADVANoA3wDlAOoA8AD1APsBAQEGAQwBEgEYAR4BJAErATEBNwE+AUQBSwFSAVkBXwFmAW0BdQF8AYMBigGSAZkBoQGpAbABuAHAAcgB0AHYAeEB6QHxAfoCAgILAhQCHQImAi8COAJBAkoCUwJdAmYCcAJ6AoMCjQKXAqECrAK2AsACygLVAuAC6gL1AwADCwMWAyEDLAM3A0MDTgNaA2YDcQN9A4kDlQOhA60DugPGA9MD3wPsA/kEBgQTBCAELQQ6BEcEVQRiBHAEfgSMBJoEqAS2BMQE0gThBO8E/gUNBRsFKgU5BUgFWAVnBXYFhgWVBaUFtQXFBdUF5QX1BgUGFgYmBjcGSAZYBmkGegaLBp0Grga/BtEG4wb0BwYHGAcqBzwHTwdhB3MHhgeZB6sHvgfRB+QH+AgLCB4IMghFCFkIbQiBCJUIqQi+CNII5gj7CRAJJAk5CU4JZAl5CY4JpAm5Cc8J5Qn7ChEKJwo9ClMKagqACpcKrgrFCtwK8wsKCyELOQtQC2gLgAuYC7ALyAvgC/kMEQwqDEIMWwx0DI0MpgzADNkM8g0MDSYNQA1aDXQNjg2oDcMN3Q34DhMOLg5JDmQOfw6aDrYO0Q7tDwkPJQ9BD10PeQ+WD7IPzw/sEAkQJhBDEGAQfRCbELkQ1hD0ERIRMBFOEW0RixGqEcgR5xIGEiUSRBJkEoMSoxLCEuITAhMiE0ITYxODE6QTxBPlFAYUJxRIFGkUixSsFM4U8BURFTQVVhV4FZoVvRXfFgIWJRZIFmsWjxayFtUW+RcdF0EXZReJF60X0hf2GBsYQBhlGIoYrxjUGPoZHxlFGWsZkRm3Gd0aAxoqGlAadxqeGsUa7BsTGzsbYhuKG7Eb2RwBHCkcUhx6HKMcyxz0HR0dRh1vHZkdwh3sHhYePx5pHpMevh7oHxMfPR9oH5Mfvh/pIBUgQCBsIJcgwyDvIRshSCF0IaEhzSH6IiciVCKBIq8i3CMKIzcjZSOTI8Ij8CQeJE0kfCSqJNklCCU4JWcllyXGJfYmJiZWJoYmtybnJxgnSSd5J6on3CgNKD4ocCiiKNQpBik4KWopnSnPKgIqNSpoKpsqzisBKzUraSudK9EsBSw5LG0soizXLQstQC11Last4C4WLksugS63Lu0vIy9aL5Avxy/+MDUwbDCjMNoxEjFKMYExuTHxMioyYjKbMtMzDDNFM34ztzPxNCo0ZDSeNNg1EjVMNYc1wTX8Njc2cjatNug3JDdfN5s31zgTOE84jDjIOQU5QTl+Obs5+To2OnM6sTrvOy07azupO+c8JjxlPKQ84z0iPWE9oD3gPiA+YD6gPuA/ID9hP6E/4kAjQGRApUDnQShBakGsQe5CMEJyQrRC90M6Q31DwEQDREZEikTNRRFFVUWZRd1GIkZmRqtG8Ec1R3pHv0gFSEpIkEjWSRxJYkmpSe9KNkp9SsRLC0tSS5pL4UwpTHFMuU0CTUpNkk3bTiRObU62TwBPSU+TT9xQJlBwULtRBVFQUZpR5VIwUnxSx1MSU15TqlP2VEJUjlTbVSdVdFXBVg5WW1apVvZXRFeSV+BYLlh8WMtZGlloWbdaB1pWWqVa9VtFW5Vb5Vw1XIVc1l0nXXddyV4aXmtevV8OX2BfsmAEYFdgqWD8YU9homH1Ykhim2LvY0Njl2PrZD9klGToZT1lkmXnZjxmkmbnZz1nk2fpaD9olWjsaUNpmWnwakhqn2r3a05rpmv+bFZsr20HbWBtuW4RbmtuxG8db3dv0XArcIVw33E6cZRx73JKcqVzAXNcc7h0E3RvdMx1KHWEdeF2Pnabdvh3VXezeBB4bnjMeSp5iHnnekV6pHsDe2J7wXwhfIF84H1AfaB+AX5hfsJ/I3+Ef+WARoCogQmBa4HNgi+CkYL0g1eDuYQchICE44VGhaqGDoZyhtaHOoefiASIaIjNiTOJmIn+imOKyYsvi5WL/IxijMmNMI2Xjf6OZo7NjzWPnZAFkG2Q1pE/kaeSEJJ5kuOTTJO2lCCUipT0lV6VyZYzlp6XCZd1l+CYTJi3mSOZj5n7mmia1ZtBm66cG5yJnPadZJ3SnkCerp8cn4uf+aBooNehRqG2oiWilaMFo3Wj5aRWpMalN6Wophmmi6b8p26n4KhSqMSpNqmpqhyqjqsCq3Wr6KxcrNCtRK24riyuoa8Vr4qv/7B0sOqxX7HVskuywbM3s660JLSbtRK1ibYBtni28Ldot+C4WLjRuUm5wro7urS7LbunvCG8mr0UvY++Cb6Evv6/eb/0wHDA68FnwePCX8Lbw1fD1MRRxM3FS8XIxkXGw8dBx7/IPci7yTrJuco4yrfLNsu1zDXMtc01zbXONc62zzfPuNA50LrRO9G90j/SwdND08XUSNTL1U7V0dZU1tjXW9ff2GPY59ls2fDaddr623/cBNyK3RDdlt4c3qLfKN+v4DbgveFE4cviU+La42Lj6uRz5PvlhOYN5pbnH+eo6DLovOlG6dDqWurl62/r+uyF7RDtnO4n7rPvP+/L8Fjw5PFx8f7yi/MZ86b0NPTC9VD13vZs9vv3ivgZ+Kj5N/nH+lf65/t3/Af8mP0o/bn+Sv7b/23//1hZWiAAAAAAAABvoAAAOPIAAAOPWFlaIAAAAAAAAGKWAAC3igAAGNpYWVogAAAAAAAAJKAAAA+FAAC2xHNmMzIAAAAAAAEMPwAABdz///MnAAAHkAAA/ZL///ui///9owAAA9wAAMBxdGV4dAAAAABDb3B5cmlnaHQgKGMpIDIwMDMsIENhbm9uIEluYy4gIEFsbCByaWdodHMgcmVzZXJ2ZWQuAAAAAGRlc2MAAAAAAAAAC0Nhbm9uIEluYy4AAAAAAAAAAAoAQwBhAG4AbwBuACAASQBuAGMALgAAC0Nhbm9uIEluYy4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABkZXNjAAAAAAAAABNzUkdCIHYxLjMxIChDYW5vbikAAAAAAAAAABIAcwBSAEcAQgAgAHYAMQAuADMAMQAgACgAQwBhAG4AbwBuACkAABNzUkdCIHYxLjMxIChDYW5vbikAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWFlaIAAAAAAAAPbWAAEAAAAA0y1zaWcgAAAAAENSVCB1Y21JQ1NJRwAAASgBCAAAAQgAAAEAAAAAAAABAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVklUIExhYm9yYXRvcnkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAENJTkMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADzVAABAAAAARbPAAAAAAAAAAAAAAAAAAAAAwAAAAAAAAAAABQAAAAAAAEAAQAAAAAAAf/hApRFeGlmAABNTQAqAAAACAAKAQ8AAgAAAAYAAACGARAAAgAAAA0AAACMARIAAwAAAAEAAQAAARoABQAAAAEAAACaARsABQAAAAEAAACiASgAAwAAAAEAAgAAATEAAgAAABwAAACqATIAAgAAABQAAADGATsAAgAAAA8AAADah2kABAAAAAEAAADqAAAAAENhbm9uAENhbm9uIEVPUyA3RAAAAAABXgAAAAEAAAFeAAAAAUFDRCBTeXN0ZW1zIERpZ2l0YWwgSW1hZ2luZwAyMDExOjAyOjA2IDEwOjA4OjUxAConQXJTYUt1bGFZbycqAAAAGYKaAAUAAAABAAACHIKdAAUAAAABAAACJIgnAAMAAAABBkAAAJAAAAcAAAAEMDIyMZADAAIAAAAUAAACLJAEAAIAAAAUAAACQJEBAAcAAAAEAQIDAJIBAAoAAAABAAACVJICAAUAAAABAAACXJIEAAoAAAABAAACZJIFAAUAAAABAAACbJIJAAMAAAABABAAAJIKAAUAAAABAAACdJKQAAIAAAADMTUAAKAAAAcAAAAEMDEwMKABAAMAAAABAAEAAKACAAQAAAABAAAA+qADAAQAAAABAAAA+qIOAAUAAAABAAACfKIPAAUAAAABAAAChKIQAAMAAAABAAIAAKQBAAMAAAABAAAAAKQCAAMAAAABAAEAAKQDAAMAAAABAAEAAKQGAAMAAAABAAAAAAAAAAAAAAABAAAAHgAAAA4AAAAFMjAxMTowMjowNSAxODo1NTo1MAAyMDExOjAyOjA1IDE4OjU1OjUwAAAAAAUAAAABAAAAAwAAAAEAAAAAAAAAAQAAAicAAAItAAAAIwAAAAEAAPWXAAAACwAFDUcAAAA5/+EEs2h0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8APHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNS40LjAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iCiAgICAgICAgICAgIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIKICAgICAgICAgICAgeG1sbnM6cGhvdG9zaG9wPSJodHRwOi8vbnMuYWRvYmUuY29tL3Bob3Rvc2hvcC8xLjAvIgogICAgICAgICAgICB4bWxuczphdXg9Imh0dHA6Ly9ucy5hZG9iZS5jb20vZXhpZi8xLjAvYXV4LyI+CiAgICAgICAgIDxkYzpjcmVhdG9yPgogICAgICAgICAgICA8cmRmOlNlcT4KICAgICAgICAgICAgICAgPHJkZjpsaT4qJ0FyU2FLdWxhWW8nKjwvcmRmOmxpPgogICAgICAgICAgICA8L3JkZjpTZXE+CiAgICAgICAgIDwvZGM6Y3JlYXRvcj4KICAgICAgICAgPGRjOnJpZ2h0cz4KICAgICAgICAgICAgPHJkZjpBbHQ+CiAgICAgICAgICAgICAgIDxyZGY6bGkgeG1sOmxhbmc9IngtZGVmYXVsdCIvPgogICAgICAgICAgICA8L3JkZjpBbHQ+CiAgICAgICAgIDwvZGM6cmlnaHRzPgogICAgICAgICA8eG1wOkNyZWF0ZURhdGU+MjAxMS0wMi0wNVQxODo1NTo1MDwveG1wOkNyZWF0ZURhdGU+CiAgICAgICAgIDx4bXA6TW9kaWZ5RGF0ZT4yMDExLTAyLTA2VDEwOjA4OjUxPC94bXA6TW9kaWZ5RGF0ZT4KICAgICAgICAgPHhtcDpDcmVhdG9yVG9vbD5BQ0QgU3lzdGVtcyBEaWdpdGFsIEltYWdpbmc8L3htcDpDcmVhdG9yVG9vbD4KICAgICAgICAgPHBob3Rvc2hvcDpEYXRlQ3JlYXRlZD4yMDExLTAyLTA1VDE4OjU1OjUwPC9waG90b3Nob3A6RGF0ZUNyZWF0ZWQ+CiAgICAgICAgIDxhdXg6Rmxhc2hDb21wZW5zYXRpb24+MS80PC9hdXg6Rmxhc2hDb21wZW5zYXRpb24+CiAgICAgICAgIDxhdXg6RmlybXdhcmU+RmlybXdhcmUgVmVyc2lvbiAxLjEuMDwvYXV4OkZpcm13YXJlPgogICAgICAgICA8YXV4OlNlcmlhbE51bWJlcj40MzA0MjAxNzk8L2F1eDpTZXJpYWxOdW1iZXI+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgr/2wBDAAIBAQEBAQIBAQECAgICAwUDAwICAwYEBAMFBwYHBwcGBwYICQsJCAgKCAYHCg0KCgsMDA0MBwkODw4MDwsMDAz/2wBDAQMDAwQDBAgEBAgSDAoMEhISEhISEhISEhISEhISEhISEhISEhISEhISEhISEhISEhISEhISEhISEhISEhISEhL/wAARCAD6APoDASEAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD8p0kB3dh61ItwC20Z+pNeGz8xauCyM0mCuT0qXzS7kFse4pENCpIrMQGYAdqWSZpjtPGB+VAuUa8zn90Hb/Ch5WjHl7juPJweDQtR2Dflgen1p/nGSQRKc9fxpNA1c9a+CnhK20yyfxhqoGU/1QYelcf8Y/E7zaqNbiuVLxvldxxjB6H/AArxpVXVx6itkfWZRheTB83WR5p49+L1vcwI1nZLLOgzJIxwB+NcOPjvqVuXheKFlHYDOPpX1NPDqS1LhkFOUeab1GS/GXWb2f8A0W9dARkGMDH61YsfjHr1nMjagDcREgDAzn16Vbw0WrHTPI8LKnZbn1pL/wAE+v2HvF37HelftUD/AIKAeAvDnjq70qTVLv4b6nrlvcSXEoLsIFjjCywTMAAI2EnzEjPOR8+6V488MSxQ2ltcxxjAVVf5cD39KWLoy5VY8zGU8TjqSg4/B17mxb3EUk26Iqc+nepn1qW1kMZhDDtz1ryaUb17M9PKlKGGSZPZeLEyGlsSjseWrUt/EemSRkSSlCTzvXJr03Cx6bmmBvtKnB/0mMk/nX0P8BNOhtvCqPAgy469qxqRdjGs7xPOP2nvECaj4usNC2nbFIGbB4wDzXb/AAr1tGlitYOiqRgdOnFKSskZuK9mS/HvTZr/AMJv5RXPofevnyPR/wDRwC6r2yeRRfQ3w/wj4LO7hfcHyB69abJcalu2PHkeuOaV7nRcguWnA/eQnjqSKpfabA88j25rGprYJaFOIHBbfnvtNOVnZixI2+ops/Mx8ZzlUYEnqcU/G1CcgZODmmJihyoCcAdge9B/druI55yaLE2BBtySx55Az3oKhmYsfXBpWGwTCx7wM9hmtHwpp6ajrVvaykFXcAk9hSk+VNglfQ9n+IHiTSvCOgR6RYAM5jCrCvOOOTXy/wDEHxBc3lxJJPcSFAfubwWyexHT9fxryspouVeVWa3Z+iYaChGMFsked+KJtQ+xSTBVHbYBlyPUnpXLWGgahq1wrcxRscbn7/yr69SsjtersjudK8G6RoFr9vSPeY+rzgsxP90DoT7YrP1TUpJN1rZ2CW6Oc/ux85Pu3+FY8zkykuxzOou7SkKjBRnJIwTz1J9/8+laPh3UbieZLS6mkiB4WRSTx/tDPNa390NU7HovhjxJq+iTLZ3yq0IUEc5DD/ZNdlFDpniGJJ7W9+8MgA4xXnTpctX2iOaVNR0RI3h+4to9y64nAyFPOaI7KKWPbLfo+ByAK6VLQxSVxW0yElIrazkLFh83Jr6w+DtrJp/gi1jkG0ldzbucHFZVndGNV2VzwX9ojUlPxBd47nG0Hgn161tfs2+L9Wl1n7BIUkB6MBzUtKxstaR698SYGuPDN1cXigIi8ke1fPVtr3h5i0UjbWBPUH1rJaioSutC/Z6x4YkIjN2p47HBzWiltpFwN8boT61Mro1k5Iq6rp+nx2klxO64AzXFSazoAkYB161m4uQ4z0MwTRrw+SRStdIGww4PYVVrn53YFkAXMjdalSYD595HsaoTViVrqKYKoACr3FMmuoANkY+tDehDV2NEoznnPoaSacM4GfY1LGkKtxtAC4IA6n1q5o+sNp+pw3oUjYw4Hek0mtR21udZ8V/HQPh8aiLfefLA3MPu5HHPqa8AvXe8CFULTTbmUgdM9/wrTLqCopu5+hYCftKKkzB8U2s6Qm1t5sRIR5su7OWA5+teg/sxX/g691+28CePdFW5sr1tiy8BoiR98HtyB6cZ9a6MY5Ki3HdHqUIqUz2W5/Yt8Wanq0sGkwW1xCTshcShA+RkEenp9eM5qaT/AIJwePbiMtd3VjZ56RtMO2O/4g/hXh/2/TopKW56KyudR+6eX+Nv2Vte8AX01rqXhS5uIXlMSXEcfDkdAOvPfB9K4+++H9zo9lFcW3hq5SGM/PchCdv19uvT0Nevh8fSxEVK+5wVcNVpT5WjN1DxHpP2VIJbNo8DaWcYMZ6kY6/j6VL4W8R7UZ7O7I8psMgOeO3Nddr7HNPVHc2GpQ6jarOIeeeAcjIp7wOZ/NjXyw3PGcVGzOdpNl/SLrVI9SgiLNt3jJZs96+tvBFyn/CI22x1P7vJMfTp6VjVZx14yilY+dfjZcW1x43uC9iJQCQWAPHNTfAO9stP8bxKltsZx6Hr6fWhv3bG7T9me/8AxOmM3gu6jyBuU/Me9fKN/a6jazSMohcAt8vfrUwM8LsQZk6TaaVzz8narcV1JEuBdTwH05qp6qx2tIwPGnj7U4LU6Xb3pkDcE965qOO9Mak7zwOabioxRKsdO85fotCM80gAOQKwskj89tZakkkyNKFB6cnPrT5bgJEepz0PTNC03Ja1CGYxQbmx9CaiWXnBzub1OaezC3Umkk+QE54NQ+dLL8qjljng0WQJKxN5h4jC4AzmniYs64U/LyMd6T0Ja6kPxF8ZNq0um+HLNRuERKxZ4UnguffANcgYvss5jMDpKgIXd0wx/WuukuWJ95lt/q0H5GXfWMurX8WnmPCu3CoOoz/P61v+ANGP/CfQWkCsdq5JhG7Azjj16Uq79x+h61DSaZ9ofA3wX8Tta0yPVNOukuEm2czoSQD1A9cc/wD6694X4K+Jbi3t3El5mWLy5Y5WJ2kZwyn8T+FfmeY1YRqbH3WApOUbnI/Ef4E+NVtxcais37hMRpEMLLgjb+I6Z968y8SfDD4g3OiTf2PpcNpFMxVYvJ3PMAMEtxgDluPXk1vhMZGy1DEYZO+h8tfFT4F6rYw3F5qto4k3FnijQ7FUnpnHXJz1ryDRtCu9I8XS6UzMOflOM8HGG/WvvcuxSrw5V0Pjsdh/YPY9B8HNLDAyujYU7cdvfj611lheQXRARMkjlO4rskup41+WTTLkVll1AjwQeDivfPg4gs/CjfatULOUwFJ6f0rnnqiK2qPJ/iJppn8S3M6/NlsnntWd4Jd9E8S299IMDf1PXr1pN6Glv3Z9DeIYpPEngtvsxLGSPIx9K+afEOi3WnahLZuGRlPXp3qYysY4ZatFWJb6FRIZicevQ1leJ/Hb28TacsUbyY+8taRipSubzdldHGvGXk/tHUCcs24AmrCa5MUBWLjHGa1qx5rImOqN7ayqSOPoalhIgiMr9cVyWufByXQLcDBlYA45zSxlp5gpHyqc9aGSxZnBby8cdc+9Phi2gykc44pN2YmRSPlxGAeKljhNvF5hB+pqgeiFQdXAJLevSnlhGDIM4A9elS2Lc4/xANSg8Yw3Ui/u5YGxt6kcg/4fWrzf2fdXD2zFTKsoG9skEAAkfhXbF+6mfd5e/wDZoW7E2lS2NvftfzsEEgBB2njIOM/lmvQv2RtK07xN8aLSyitzPcNC7zhkztVVYDHucgYrlxs+ShKZ6+Fjz1Uj9T/2b/gjpXw+8Oafp+o6SJJ2jDuWGdhPJHXj0r2d9C0jeCtqSQN25iAeBxX5Li6ntJts/QsMnFIzdU8E6frsRS5gTCgrwOM+uP8APpXEan8HdD8h7We1iQOCTKrYLD+g/wAaypT5Toeu58wftM/BTQJrGaztFEcUO6V5ITy3H3c/4AV+d3xW0218NfFO5mhtDHBDaeTz/Hg4/r+lfccMV5VJOLPmM+pqMbmb8M/FSXl5PpN4gcbjsYDBOe31rs5rRrKbfYNye/pX1lWsqUuVnw9VNyuzV0nW7i3A+3RZ4z6VvWnj24sLbyYJXRem1SQK5p4iEh7qzIJfFNtd5llG4kcsaSPWtODiSJehyCRWf1iK0HdPQ7rwx+0JFpFiLO9tjIEGBiuR8feLtM8T6s97aWezd1zR9YSM6cXGd0cTro1u7byrZdiZxnPWsmLwbctIZ7l9zHsa3jjYRWxq05blXUPBmr3y5HCDog7U2PwpqSoqmIcDFKeMjMfwGrBD5mXJzimvudzEqcehFVY+BYtzIqfIAQcdTUkCLFbkyHk/nSE9iNciTjIIOcCnXN0UTAA57UnqCV2SabHkedMMZGcmrQxPIdmdnuKNtyJaMidjuKL90dMfSqpaS8n8mLJIblgOtS9diorqcz8Tr650jUbVlyAsOwED1bt+PNcfNr80dtbhnBkY72Az1J5r0KS/do+5yzXCw9B2qeILySJZEkcIvYZ69BX6C/8ABKz9mvWLfwz/AMLU8SaY8c2qt5kMko+cxL0IB6ZPOfpXh8SYj6tg2urZ9Rk1H2lfmeyP0e8Fa14F0aGDTfFHi/TdNndRthuZsNH2ya7Szh8A6zGJPDvxG0G+JJCrDcqWbHoOtfm08LWlH2jWh9dRxdNNwRr6f4ctobRnN/G5fJwjf/XrmvFngW/vLAtaRFo+SHViTt9Kz9m46HRGacj5U+Pfgm8s7idpbZypOFDqQDg9/TivzA/bO1Cz0/4qXmm3KKseBsZBjILEZ/OvqOE3fEWPE4htKimu5518H9NU6ze3UQ8wQvhXPp616W07Fg2zH+f519fjIOdW5+Y4zNIUKrhIDLJycnP1zS/aZGYKqtkd88Vyuizk/tmkugj3MpGMGnpcSnrn09qPYNiedU10HCeVsjafrSCaXdny1IHcjNHsWxPPKbXwj/PmHIXJIxg9qQ3UoQ7QeM/KaFhwWeUv5RBLKyYMf5cU3fddoxR7FoSz6mtomWXMa+Umcn0NEUfl5fapJHOa77s8IYi+bMZG/P0pXdpXwAcDvRsDiTTBbePzTyffvVaBJLiQs4yPX0peYLRXNK1s55mEMCtkHG4dKkvHjt/9FhJyRyR1NF+Z2M7Xkd1+zh+yn8Wv2q/FqaD4A0l4tMhcC91+4Qm2tRnJH/TRyOiKc/Svvwf8Em/gZbfDw+FzoT2Oo20OX1ZpibtmKbwzk8YYAkADAwVr5POs7qUKyp4fpv8A5H6Pwtw3RxOGdXGw+LRf5/5H53/t0/sZ/Ez9m7xpbaHr1qdQtLnItL61U8ZI4cdjg89j618xzbUnIZv3iuVII6c8V9dlOMjjcNGonvv6m0svllf+zt3S29D2P9jX9m/Vv2gfiXbWV7ZMdHsZI5bkspxIC3Cj2GDn6Gv2I8L+D/sHh/7LoV7HpsEES2qSwqP9HQDaAijvtA+lfE8W43nxkaMfsn1mSUOTDc7+0edfETU/2VPDUNxoHiy80jULxcm5uNbvTJO5PXO5wAAP4QD15xXIeA/BvwR8QeKUvfg7r0EE0eZIoLS4JR8cnaQWH6/yry1PHRpOo17p6UI4R1eSL94+ovh34s8R2vhaS8hildIo+WkOQOMV5D8bf2zPiX4cM3hn4cXskl/8wymflb8sf/rrzsLKNSt73zO2vTap2jueD+Lfjd+3R4qhMXiKw0xjIpKxGRY2bsOCMH86+AP2zdcuNU+IMf2+ya1uJ7NWmt5OsUokcMv5ivvMhhhPrV8P21PlM0deFDlq9yl8BPNHh+6kuAdzTDlu/H8q79T8oK4POa+gxDtM/Hs21xchflViFzg/w0H7h4zWV2kefYRcMc/Nx2zUgXBBLcDrS5hMAoxjnIpRjOFByffrSbYrC/MuOck8E0xmwSWXA9u9NO4tBwZSpzkZ6UB2Ax5p/Ok1YaV90Zed5LFQfw6Uxxv/AHSLyfXrWp0IRyqIEB+tLDGIyS54HSi9irjpDLeyDaDgcYxXoPwG/Z1+IPx68SroPgrSmZFP+kXjqRHCvfPv7UpMLObUUdT8evCXgj4K3A+GPhi6GpaxwlxMvzfP/dGOp9hXrP7Ef/BLf4gfGvXrbx18f9Dv/D/hBCJVsLjMV7qvP3dv3o48dXOGI4AHWvKzbMI5fh27+89j28hyeWZ4tK3uLc/WX4b/AAa+G/w58JWmieFfDOnaTpmmoFhs7OMJGmB6fqTnk9fWvzx/4KGf8FFNZ+DPxsv7HwdZzX0CWT2Wo20JIjETE7XLDOwqckE9iR3r4bLcM8ZXtJ6vVn7g2sNRslsrIi/bx8fW3jP9iHSPiT4suUvPEepaTDKm+2MW/cV2KiN8w42nnuSa/L/9qjwA3wl+LmoeGU08wQiOCbaTkZkjVuOx5ORX13CsvZN0+jb/AAt/meHnsOenGbWuh9w/8Eq9AttO+H+r+J4VRZbuWCGEk52gQqSP/Hvzr9CfCfgqfUfBbadF5yG6Uq8yghhxwM+uPSvj8/m/7TqS8/8AI9nKKf8AskE+x4L8YP2C/Cmv6Xe2Ol/Dq+uLu8lWc6no+pC1vI2Csv326ghyCCSDnkHjGr8PP2Xdc1abwbol/wDCl9Ag8GRm3g1U3iy3d4jFnkFxLuYybnYsc8Ak4A6VvHOZzwvsZPQ1eVwjW+sRWp9J3mhWPhjwVe6TptmR/o+N2OTXwn8YfhFquteHz4p0XxBPps3mOxulgnmUyh84lWIhzHt4wGXk55xiuPLa0aWJVWSujbF0Z1qDinZs8uufC/xQstC0hvDvxHh1/WhfO15Y280jWn2f5QixCQmVWGGZt5xlzgDAx8lf8FG9LvLL412Vzd2IgeXT4zIo5yxd25+vNfcZPXoVcw5qStdO58tmWHq0MHapK+pD4D0pNJ8M20UcYDyosjZHJJUVuAt5e0Hmvcm/e1PxXFyc60n5jgCRk4GKYFK9TyeKhHMncVVPQd+tPTG1gxzk5NVYbQoyqlgOT3FKDkbn6MOfaj0J2FOeC4JzSELu3YJI6H1qbi2Fdfl+7+OelNEHH3hVRVyrmbJIqoPLAB9BTCRhSy/jVI3SGlAQXY8jnFJEsl5MsUMbEnoADzQ+7LPpD9ib9hf4gftQeM4tJtbJrTSrXbJf6jOuFiT+7z3NfWmvaPL4N1qX9kz9ibRLdriICDWvF8q5ttPBHO514Z8chBk9zgc1zYnEwwdGWInsj0cswNTG1o0qekpbeS6s9p/Zq/YG+CHwGsY/FA0dtc8TXBL3viTVx5lxOxOTtB4jU+i/ma9estU07UNczfanFELE7Htiw4fpgjPoQQe3HNfkuJxtXMKzrVnf9D90yzLKGX0YUKKskvvfdnFftX/H2/8Ah/4DvZ9GvDGscTbcN8ztjj/9fQV+eHhT4T6dquvab4z+Mt6klp4o1uBtXvrliVe2Em54F/vDAAY9ACck9K9nAT9lBy6nZiIapRPWf2m7K1+I3j3W/iZ4/wBUtB4G8MFl0xdNVlh1G4i6LHuAzEhA/eYwxHyjFfEX7afwT8YfFX4T+Ef2ifDfhua4srjTi+qamXcv8szRwhlb0QIoI7DNe3lGIhhsTFydo3t82v8AM8/OKHtqMore1z3H/glWl3F8JX0+5jdQNSfZv7fKn8q/VH4CXWmS2X9m3ssX3V2qT90jvXz2dNPMqjezZ05fdYWKR23inw14GhtlnuNTtolI+/uJx6147d/F34bSeMpvC3gPVLjUZbI5nks0Hlwj+7nu3sK8udBauB7FGUnHVHS22savr2mXV7JYyGzlV4kdoyD+Xrx2rwTwx4k0v4f+Pz8N9fuI7WW8dmtROPkn5yAG6Zxng+hrHDupKVi2lGJ6D4j+Huh3enSaq9jaLOynMka8Pj0Oc81+TP8AwVC8E6Prv7ROj6XEQrLpxknVRjAWRgmR7lm/Kvq+GJSjmF5dmfJ8WVVQy6c7bHmVtB9ngSIAhQoVQfQVLhiwKocDocda+9erufz9J8zuwZwflfJPpQM9V6k557VKYrWEEe7JwOfepAPkICc02yb9AJ43A8D0FKqlV5B/GpC/QXlSCWyem4GhVZAW28+/amHQRiM5c4HtS5A48w/lQnYEiyPhb46YBv8AhHp/++ayNX0fUtGuPsWq2xideqvwatN9TslCcFzSRWhtru+mW2t4nkdjtCKPmY+mK+5f2KP+CddzoWgp8fP2j7a20bRIk8yCPVXEZUHoxDY5Pp1o+J2NKFOVWaUT0q+/a5+C/gprz4e/D34nab4U8PzymK5vYZ44by87FU8wqVHbdjOegFaXw5/4KL/8E+/hNpsXhjQ/iJBb+Qx8yO3tZZQWJ5ZpEVgzE9Tkn3r4/PqOPzSXsaEHyRP1XhvC4XLaTxFdr2j/AAX/AAepzn7RX/Bb/wCHuh2snh/4C6ZBrKMEjfxNPKPIsZZBwwiyDIRgZyFAyPTnwHwP/wAFHNV0bxvqsvxU16ObV7ScSJq2l3INtcxOmVHlZ2hlwfmBxj8Kww/C8o0LzXvM9uWcJTutjXH/AAUL+DvxX1S2sPif4l1XV0ursNJpcDmC0ijHKq8jYBXIBJyeBgCvoPxX+05+zb4v8HWEGrNBpVxasscOniaF4yhwdisp4UKN3QE/KOuRU1snxFBpWOyjmtOs9Njm/wBoW50H9qbxDpnhz4Za/LJ4E0q2EuqXtupWEHlUtEXAbzBg725GAcDHNfHX7UvxW/aAi8D+KvCvw9+IV3ZfDSxlFtb2KRKI5CcF4lkI3bB6A9Tj3rryyjS9vGnUV7W++5pmLmqLnS3/AEPfP+CcVxpd38G9J1KylzJqK/apz/01yQ4/ArX15o/xH1vwsWghnfkAjZ1K9P5V87nEf9tmvNm2Ct7CLXYxvGfxd+KHxb1ceBPDt22n227yrrUp5CMDGSq+pAI6eorrdD+ANn4E0K3134feKZNL1q3VnTWUG9nJ+9vB4PPPI4xjNcqcY2Vrnoppxs9zkB+15+2l8LtfvNA8W2n/AAldjIu+2u9KtFgQlezqSVB56jrXiXxx8V/FD4rS3nxC8YvDDf20qXFta2mMwlD/ABHjPGcgDpmu6MaN1Pm36djFc0He1jufBf7XaHwSLbWZ5IZbdPLkhkOCrYz+tfKfxu+DnxN+OPxMvPibZaSRbXMSQQFhz5a5IOPcsTXu5FhXTrSqHxPHOIlXwaoUurOVP7JHxTjUyvpy/L6jpXnfiXw/feF9Yk0jUkVZYmwQByK+uPx2thqlBLm6lT5cAscH+9TQV3E88VNjDUXcqnG4cjGaie8hjdI5MhpBjk9fpTjqUqbb0CfVbS3TLyAZ6c9PenxXsDoAkuc/ypuI3QqJc1iRZYZfuHkHOPwzTsjZjGc8AE9amxk9HqIV2H7p6dKMoep/WqjBT3BLmPuqPT7I4T7FCSfRa+S/2jNFmvfirLaWVqWJ4VE71o97H0eZvlopeZ3/AMKoPgr+yh4ftvjB8V7CLW/EqZk07w0xwiEfxyHsBXj37S//AAUX+NH7THiEzePdfu7u13/6F4fsJGt7GyUfdConLMB3JyfSnThzppHp5Ng/ZwVaa1ex8/694y1KW8kvw6RzM2T5Gcg5yCWyenvWBqF9qM9w2oC9k81zuMgYhyfr1rvhTUNj3G/Ik0zXvs8UkFxcMolULKjZ+fByPy7f1pt3qZvGJVzN0424JAAGPyAqlBKTkhKfQ0NNn1DT4VufIV4eFDsOYx6GuqtZ49ciDxytBcRLkksSrfUZ/EHtWNWCbTLi30PQPhB+1n+0X8DdFvvAvg3xrcLo9+G83Spfnj+dQrOmfuNgdR1xz1r3b4Z/CjRf2lP2fLj4a+D/AIn6jZWrXAvLjStUjSZY7jrywAdQx7gn6V5tTB04z9rBa3X4HRVzTFU6cYrZG/8AskXvif8AZxvl+C/xRsYtMurOVvs0ynMFxExyCr9CDkn1HcCvsrTLy31W3ivY5MqwBHfjvyOtfnnEFB0sVOT2ep9rkdeNfDxaIfiP8CLn4haQI/Cvi290XUApkj1DTXKyRtwWBOD8pwAe+Ca9A+DH7O/wO+Idy+j+LPir45sb6OaQvYanrM8oA4EUatHgEswYY5Owg8GufL67dPlS1R04lTpNzhHmXXyNfxh+wN4FOl3kXh79pHWdLgNrGzXo1wzIWLEt8skZK7R74wBxXxb8VfgZ48tvi43gP4b/ALQlz4h8OQ2Za/u7u3AkS4LlVjicgZAUAlsdenHNepTxNOScqkOhx+3eJ92mmktxuseBLOXWodAsm8wFlgaXGSdoAyfXCgkmu803xHokl+PDunSHfCNoU/wgDAFe7krtR5n1PkeJpN1owj0L9zGHgkHfByPTivhr4/Io+Juo4T7rYwe/vXvN9D8+zaV6cb9zinYlcMeBWdrHiTSNERpb+5VSF+6rAn8qSTbsjyMNQliJ8sTg9b+K9nHdGXTvOVT/ABAEhj9Kkg+K9nq9mLS/KpKAdsinG76eldXsNLn2P9mwdGKa1Rk+I/Hc13opj+0lpARhh+OR/L9azNL+IOqWkzuLhirgFY8n06VrGkrWOmGEhycskdRovxLvJbqPTmLeZJy5Gfl5/wA/nXbaN4n069uVsrMtM20FmXnI9fauOrS5HoeLj8sjGLlE1ZZAAzFwCPfrVJrsbj1rnm+U4spyyeOcuVbH6FJYGC3+2XLKkK8F5eBn0ryH4uweA/hh9r+MPxD2xxSsVsLFm/0i/k6hQv16noAOcVyY/FuDjh6fxSf3eZ9Xgcqhj37auvcjr6vsfFXxP+Ifij42+J5NW1Ccx2xYqkKNxnP3AfRRyc+hrm30aHT4JLLRxvZeJrkHkn+4D2GD9a9qilQgqaO+cueTkVp/CHk2qSsAuT97PT2A/qa53V/9Fzb2sZBPfHJ/HtXTGV2Zszjo9wHRNmWcZ5zkfWr1vZMtvt84CRRuHPf0rVsnlZsaNdQXUbWtxAwYjDBBll9/ce1aljpt7ZXcNg1woMqn7PcAfKwPYn0PrWE3ZFx0Lvn28oeC4tpBLDkNCp/eRf7SnuB6V33wR+NHjP4M+Lrbxp4c1E3KRIUcFjsmjI5Vxnlc9e/pXNNNouSUo2PTtb/awv8A9oa+u/CHjjQtN03UrG2F7pmoWDycvuA2EMeRg888g9jXpn7NH7X+o6dEvhLxHekNb/I8UjcoPVa+Zz7AKq5qKvs19x72QV3hoRi2fdHwS8daR4/0N7nw7qG+aIKSpPOO+frWp460zxJNBJrXh7dZ3ijc0yoCkhGMbkPU8dQQa+BpSlhqtmfZwleXMkeWeKf2gvjNFoU/heXwLbOp3J9se5nKKCu0sUDEEEdsV52dV1Xwro154k1acvd3OF811275P4Rt7AAFsD+7Xu81OsuSHWxhjMS1GyjZbs+UviX8eNB+LPj278HWbC6sdCYMt0jkedLyGdSCMhTxnOScmtXwX8R/Fvgu6W78M67LGcYKTqJA3tz/AI1/Q3C+RYCtk1OlWppvW76/efgnEeY4iWYzlGWmlj1nwl+1qJYxZeO9BCEgqLuyOQR6lGP9a+f/AI6X0F340u/EVoGeynOVnI4P+FeDnfDlbL71KPvQ/Fep5NbGvGwjSkrO/wAjxLxt8V4bKBrbRpwXzhpAMgD615vqGtX+qz/arqUkk53Y+YmvFoU7RvI+wy3ARwkPeWpSlS7lPnSuwAOMc9abJEYVPnkhz7/zrpsenrYrqkykvnC46HI/GozI6YaPjGDz2pEO5c03V5bYkowVnxl+9d94I8a6TpkPzMzsxzI+fvVjVjdGGKpe1puPc7qx8XafqlltgnKuBnY/BqBppixO8/nXi4hOMrH0PBWWQwtCpKo9Wz9HPGGvaR8PvDc/jb4k3saraKZIrKNvlB/hVV7t7mvzy/aj+O/iX49fECTWJD5VrZIYra3RiY7WPOTj3J5J6nPccV42QRlj8VPH1PRHRmHs8FhoYOl8zgdKnkstPt9PsflkuwSGIyY0JyW/mfoK3IrCySzdYoylrbISASMyt3c/TIxX1stHoeEtDn9YuJ5YVtYOA2NuOy+lZEHhya7nMwt9+1ixGDjA9fXmtFJQV2NXeh6r8C/2S/GXxYmm1WHT3Fvbr5ks7L8qjGevr+tRar+yB8VLO9R59MMNvcyPHBO5IEm04x+FeY81pxquEnsei8BN01JHGeKPhB4r8D3oi1bTGSdDlXjJxwem717/AENEX2680tpCvnJGQzxoDuX1YHoPfsfau+NaNeHNE4J03TdmGoNdXlrBq9m4W7gA/e5++o4BPuOh9qf4f8TRtP8AvrUQyk7JIl4Rj/8AX/Khx5o2Fs0VvFhmsdRtvEuh3LxEfuWQHkKRkH8v1Ga2/DfjBNbuol1O9ls9Qi4ivouDx0z61hiKfPFTW50UJcsuToz6N/Z8/bX8e/s0eKbbUvFNs8mn7lV7u1OYZV/9lb2Nfo/8FP2+P2efi94XTU49dtRLtDrGsg3j1BU85r8/zvK3Tl9Yoq6e/kfX5Zj1J+zm9S14y+NPwMazlvJmtkhKF3u3jxtweMA5HX8K/OD/AIKH/tPar4isRYfD26kstMurloFkAw0icBmB7ZGBu/2jWvD2FjVxcZS2FneIaoOKZ88fAu2U3l9cKBtS1QD0BLZGPwB4r0+yupo1QDDbzx61/THDUWsBHzbPw3OUpYl/I7bR9D0+10ttR1ufdgbhGx2qBXzn8d/izquv69ceHNGu0j02L5dtrJkyfV+n5ce1LizFPCYVUoOzlv6E8O4ZV8Q6k1eK2PLZo5S6iRsALwOgz9PWrVlpLXKpIQ0YPWVj8z+w9B71+Zykkz7xLoPnjsYI2McysqnHDZOazw4DlEtuW7vjJ+hoUrjcXsVpytyWWXPHyj3PpSroF7NZfaraFnUDDEducU3JLclRcjOCNG5XZnJwM1JbzyW7lkkKnGR/ntVeRD0epveDtfnTUI0klctvwXDYP05r2eG3tWhRstyoPQf415+Lh71zjxmPxWFjGNB2R7d/wUG/aCsviL4ktfBng67SSwso/OnvLfOyQklfvcB8KCMjjLda8o0r9iP9qT4l/CiX4peFfh00fh6ZXnS4vrqK3uL9EGWaCFmEkkYHIYLt9Ca8bLJ0cswFP2ztf82fTYylUx+Lm6S0R5NZC4t9Ykt74BWQGIoykeWByQPbAA/GughglntfscSMyyfvGVhkj0UnvnGa96TS1PJejsW7Two01rG0sQEshLhSOi9vzr2X4Pfsy3Pii7hsrbTTJLIVd0KE4BOFU+mWx17ZNeZj8WqNK7O3BYd1qh+o/wCyr+yl4U8LfD21+Hl4kAkuv3t3KfvuQei89fXHSu0+J37FHhvxfo9ufDOgW8TaNOlxDE6/LJHgh09sgivz6WIlOq2fXun7Omk9j5o/ap/YntvC+q3Vsvh+GXT7hyyKF4UY7H+9yP0r83P2gfglqvwp8WTXejRSR2yuSNoI298Ht0/DivqsjxbcuSbPCzPDprnied6rFmykwv7xgWBxhWXHzAjt6/n61hziWe3j1a23kxv5cx/uMehPse9fWQeh4TNHWrlmNxabA0bQiRSRnqoYfkQw+lc9pOowzJtjYZzwcnIoUfd0Dmsz2T4Oa8viGzk8NaqgnDLtUv8AxD0Pr+Vaw+EujeE9V/tixuLt23ZFraMyqv4g8j2rwqtWVCq6cOp7FKEalNS6o7j4frc+I2LahdXcOl2zbmSaZ2DHHAUE4HXsBXlX7XvjO217xbHpmmBRb2ESIiIeAXOcY+i/rSyqHPjU+iTDHz5MK03q7Gf8Jbh7Pw1c3R4+0SBVJ6kKD/UmvUPh6keoFLy5XdGnAPvX7vkK5cNSpvt/wT8pzZNVJz+Rx/7S3xF1fz08IWF/JFbYV5I4TgTZHAOOT+leLTCaSYSP/Ccu7c8+1fE8R4qeJzGfNstEfUZJQjh8HBJbq5r/AA/+H+ufEPxdDoWk2c08pG+VgpIiQdyPWvqfwb/wTQ8Z6n4Vt9Y8R2Vw95eZddOUkJCnGN3PzNzyBXweb5xHAtQ6s+qy/A/WFzPY6Hwj/wAEa/H/AIhuP7R1hW0633HESKDIR6k9Kk8bf8Ectb0Vg+l6rJNI53CJQx2J6t6V8/Li/llZI9eOQxlHfU4LxV/wSx+Jek+II7PS0NzYIC0t8kbACTj5MZ/2jXrXw9/4J7ad4a8LxeH9ZtHe4d5DNdYJI5DL+eefpSxvE6r0lGnua0MhjTm3N6Hy1+2j+yXqHwT1keIdOt2Ol3srKjY+4wAOCfoa+fGj8r55CT26e9fZZRi/r2FjV6nzOZYf6tXcQs7p7O8WcMDg9/T0r2LTbqGfTref7XJ88atz7gV1YiOx4ONeiPr79nXwR4W/4KC/8FBoNMt9I/4pHS7WS8eyC+WlxbWvRNq/dSWSRAfYnvX66fFLwd8I/wBmD9mTxL4s1bw94ZudVmsxEIdXaOIPhNqRAnGAOgQEYHAHavzvMuaNSjhn9mK+8/RME4rDznHeT/A/nU+JHhyaz8aarqtxcRSvc3UzI8Rwsp3ncyjsm/IHqBWz4Z0qSDRxd3luvmsA7cfdHRR9cDj8a+5pyvRil2PkKulR3Pbf2Tf2TPin+0h43g03wrozy7z5jvIv7uEA8FvYV+hfgD/gm5+0j8J9Oi13QNd0Uvassv2Qwjc5VeWJLD5ucD0A6V81mOLhVq+ya0PfwOHdGgpr4juvh18evEHws8X2fg39pKKTTs8W+oXlqqrkn+F1yNvPU5+or6UuL+az0+08SaRcxXVhcJ8ksDB0kU99w4I5H9cV4OMwapNVKWx6eHxDr/u6m5xvx60LQPGXgt7maANfIuLdjwQeOc9a/Pj9rD9ndNb1OTSZ9LBMrvH5wA+Rgm4Ej05xVYOvyVVJCqUuaDiz86viB4Ev9E3WDWxD2+YmU9TtO0E+uDz+NcT4a05JnvLOZdqTgqy4P7s+o9g3OK/QqFRTpXR8jVi4SaZY8TLa27y3Cny1iRUeP+6cDI+mT+tcVeaTe6RL9rgDNE3zKwHDLjORXbTtyamD+I6zwHrWrWeoQ6lpd48LjGG/xFe9eB9S1PxZLE2v6oGCjb5cWBurw8zhFe8tz18C5PTod3r5059E+zp5dlEi7VcEAnpzivlj4waVN9q/tiW5YyanqEgXfxiOMKqn26k1XDMPaVKjfRfqiM8mqcYqPf8AQ6bw7pV0+lWul6LC0kcS48yPlSc9c/UmvR9GuIfCuix2k8gLfecDsa/dMsioU1O+iW5+W45ucnHqeTfG1n13xat7aW7thAqkDOfxrmNF0Gd3ETYeXsMZEXv+tfmecVbY2rLzPtMAmsNCPkfoH/wSy/ZwsNN0J/iFrtkss2qyt5TSrnCJgAj6npX6PeAvA+mSbooLBHltVABYA7T6Afn+dfh3EOIlXx1TyP0bK4cmGikdppvgm4gti80O1pOQCAMj+lXLH4d297A0y2kTHGPuc+1fPOLZ7dN2auY+r/CyGxhazudDiG4nK7Rg5P8AnmvOPH/gK2sG8yHTSgAG0qvBIz2/GiLlDU0bUpaHyT/wUD+Fdl4/+BWpWMNmvnWpE8ZCfdKnkD3PIr8k/EmgSaRrktkx+423K9smv1Xg2r/s0qV9mfEcR017aMl2M3UtJMKLdLn5jjCZ4rprHW0SyhT+2SuEUbcHjivr6vvHyGJTaVj9Sf8Ag3I8OeEdT/av+JF5aaisy6Z4fgW2LnczRyXi+Yw9hsX/AL6r6r/bX8D3evpL4P8AF8stx4n12W5/svSpn3xHczATjB2hETcS3JG0YxX5zmsmsw18vyPvsvkoYWy8/wAz8f8A4heHoNc8eaoumPJJpukH7FBcDKgpH8q/ngn6tXafs4fs++Lfj748sPA/hXSnklu51RY44y2AD8zk+ijHPT86+rqYlYeg5dkfOU8N9YxCj3f5H7gfsl/sy+Ef2Y/hiNE8NafFFqnkkPeyJuIb3z/nmvFP2tv2vvjd+yrH/wAJf4703QL/AE64vFgij1a6bTojGRksLnDpuyCFQgFufQ18ThmsbXVNvc+pxLeEpuaWwWPxU+Hn7WXw9068fwtfaVcalbfb7az1MCRZImOFlhkUkPGxHDKcMMGvSf2VrbxR8J4Z/hnfXc194duzvgtpBuW3fjJRuoz3/CulzdJyw03sYNe15a8ND1Pxn8K9QvdIafSwZYl/eEp8xRfpXx1+0jp0+h65H9pTAuJzbtLswemO/fI4NeeoeznZHWkqibufmF+0NALXxVPd3MQg8x3ZFPXbvI6fUCvILqwt7Gyk1SOYIJpGWRQOjEnHNff4B3pJnyGNXLUcTj/GkkraLdySEGSSISPz7oP8ffiun+AOk23jvwlc6XqdusqWkvl8feUMMqR+Oa9HFScMO5LyMcOuesolrQ/hjd6R4gvfDUsDMYT5kLgEM0frXf8AhzwjrGkPHd2VzMgzkhuMV42LxMZKz6o9XD0HE968B/BS21/wpceLdbdMJDhVnYtkt7Z96+Of2ttTsW8fjRNMYNb2wJUjuCSBn6hQa14ZnKcq8uiSX43/AEMs/UUqUbbu/wCH/BOH0DxBqfh+0W40nUZ7Zycg28hUnnvjg1rr8Z/FYTytduVvEz95xiQfRh/hX22DzOvg5cqd49mfLV8FSr3k1ZnQ6f4l0zxjY+XpN0Uk2gSxSjaRz3NWtLt7W3jawtRtG8GW4c43njj/AD0ryc1qxrV5VY7M68LGVOkoPc/W79jzwrF4W8CeH9BESp9mtIuOmHI3E/mcV9efDHQ7gzwtFcMTK+WZSMt6fSvwvHJVMVN36n6Rg3y0Y+h7laeCfDMGmnUJw0srjDu5JA/Cs+20CGwvWitVyjcFDyB71X1eKhobqs7u+xV1bw1aXbOl2N4A/KvN/i5oEVpp5WCwgMYyyvnkcdz3rmqU+SOxtTqNs+Tf2kPD8R8OXVkkQC3C7Sp6dPT1r8gP24PhhcfDX4qyPZ27pb30S3CpnueCM+39a+z4Nr8tZw7ng8SQTpKXY8kutVV7eO0tlSQSgO2QcqR29627XwpPNbRzLarh1BHyH0r9DqPkPh69VU0rnt//AAS+/bkvf2E/2ttD+M99HLceHrhTpXiOxgBLS6dMVMjKP78ZCygdzGR3r9x/2w/FHgzxT4M0j42eEJ9M1aM6BeXOh+I7QCZXtZ4AD5b5+66NgZ6bvXNfGcRYT2eKp1ltLT5o+oyytz0ZU+x+T/ibwJcXurWvgHwpYtdXd5N5kqou5mlkYED69OPev1w/4JmfsQ+D/wBnv4cpqepWcU/im+iVr26ZP9UDz5SEj7oz+JyTiubNMQ3SVJbs3y+nyzlUa0PpnUrHS5Ue0knRcfKN/GP8a8i+MvwhufGfhy58Javp9hqumXI3HTtUhFzbt9A2cfy9uK8CK5JXTtY91tSj7yuee6R8E/GXizxvY6n4mngthpNqbW2+zxBWSL5dqgKANowcYx1xiva9S8J+FPhN8PrnxVeaoCllHukkkAVgcelT7Vzqc0ndjlyU4qEFoeAap/wUX8C+HLC5j0bUGe5Gd0TPtJHYc9vWvnr4tft9fBz4zK/g7xfp82j66rrLaXFym61nIP8ADKOAe+CBXtUMFPEQut0eRUxMcPUXNsz84/27dQi8OarHeWV99oiRNySKwYnczEDP414XdeIZdQ8Lssb4Qy52r3GMg/zr7HLYWw6ufPY2XNWbOa8U6m76P9iG1ZJMO2fvFR0H9a6/9lzxbbaFNe212cRM6tI391egb6A/zr2FhvrNOVHq07evQ4Y1vYVY1OzR9Qaj4a0DWL3T/EmnQxi4hXBK8iRT/Tk1e1OG0sYxaw2pXcoICjj86/PnKV1Te6PtFFSTa6k/xK/aJt/hN8E5beCNZ5NpaOCQgBmHC5HUjJ/SvgfxJ4n1PxTrM+vavMWmuG3Nt4C+gA7AelfT8PYf2GGlU/nf5HzedV/a11B/ZI7OaR41LNwM/hS3TFjgnOa988dG14H1GPT9XU3I3RyLsLE9DmvS/hPo9x49/aA8J+Are3YWVxqcHmKBnfmQElvwzxXn420YTk+zOvDRUpxj5n7UeHrDRfBWiPruo3cFpa2aB5JJztRQDzzVvwP/AMFNv2Z/BuuR6d4j8QNp6MQqTXaFEfnGcntX5FhcuqY5upFH29fFQw0YwPrn4TftFfCf4p6OLvwN4ss9RhuFB8y0mDgcd8dK7a0OnSqJI7hNxJwW4zWsqXsXyvdGlOoqsLrqc14+8TeGfBdhc654l1UQwRIXJU5JA9q+NPj7/wAFTf2XNKnXRIfEFzNdq3/HuYGXgdQc4wa2pZc8dpHcmtjvqsdTzrWPjF4C+Penf2p4PmZBC3z2VyNsiZHDBSeVPqK+Pv8AgrF8MLC28PeGfFaW0IS6mezkbGCjFN6n8wR+NdOSU54LMo05GGY1I4rAuoj4Mg8JS2t0I/spJJztz159a9gs/DxhtIoQ0nyIByfav0itV2Z+VZ5X9i4JeZ037Gv/AAT2+IP7Q3ihZbrSp4dDspws14vSdujRoR1A7tnjGOa/Sz4ufDV/2dv2Tp/BWn3c0dro+niCzsot3lRszhmCp/tYAxwMk8V8XnmZLEYuNCL92J+kZdhnQw7m1rI2/wDgnX+xPqEWt23xF+JOnebd2m25O/p5zDPT/ZBr9Bvh3Imm67JbSyFI8BdnZV+npXh4it7WvzdDupw9nT5Ea/im/wDDF7PJEfLO75UmDDCtjt61hQ6j4bFuCszSogw9xjEY/Hp1HalNRep6MOd01oMhfw5eyPLodzG8ikASQfMENeMftqeKok8M2fg9rqQJevidIj82wHLcfyrhhFRneJtJK1mfCn7R/wAc9V/Z01bw5qq/AvS9V8NamssYX+y570TTh9sVv9qjDbZpB82GQLlgMfKWFrx18LP2Y/2jfD+pT2vg+98K69p5aK80iaffJp0+MlSAWBHI5GeCK+ppU54WnDE0peqPn6so16kqFVbbH5TftO65eaf4muPhf9uNzFo11LF5wfO/DYAH0rmtBikh0RftOdjEcH2OABX3NKPLSXmfLVJXqNs53xDuGoeYjEsB168DpzVbTZryyuBe6VeNDKvAKnBFdkW42aOWVpXTPW/2cPjvrOgapH4G8RX7yWlw+23llbJgc/wkn+Ek4HoSK+g/EPjSCx0T+1b6RVEC5L+3b/PvXymZ4RQxScV8R9Rl+KcsPq9j5M+KHxk1vx95umSqi2wuC+RktIAcKD7AHoK4+OMzSBcZXoTX1UElCEUrWSR8xNuUnJu92X0DJ2yPbvUcz5wAOnerW+pNup7P+wt8IdP+MnxuXTdZtop7HR9OudSmilBKu6qEgVh3HnSx8e1fQXws/Zr1b4R/8FAvC3gDV38y6imiuim3aUHlyMM+5Cg89iM18rmuNcK1TD9oHv4TBr6vSxHVz/yP0v8AGPgnQ9R8Mm58Sy28VmhDD7WcR5XpnPGPrmvEvGHiz/gmzpelyaxr+kXGv3szSRrrGjae80W+ML5iJO2yIlQ65VWJ+b618RlyxVV+ywe/4H0GJjQpXqV9tTY/Zr+JPwy8B+L4L7wANT0uK6VZ/wCzdQs3tWeFj8knl9CpHRlJU194eGPE+u+ItHi1KwDtEMHnrWOMdRT5avxG9KNNQU6ezPGf2pfi5dQo2gXz+VGxJcyuVAVepJJ6DvXzJp/iz9iG7sriP4w2k81u6+b9qvNFuzY7Dk+YsgTBGFY7skfKfQ10YRYqrH/ZVqLEqhCKlX2Oq0T4d/A/XtNiu/gXren6haWm6OC50995TA+aJj1UjA+VsGvnb/gq1oElx+zfZ3FxGFe1v7d1duNjHcv9TWuBnN4+k6nxXsY4iEY4Sbj8Nj5H+E/wJufi3p0uoxW0saQWs0q3CLny5kjaUIR33GMj8aijniManf2FfcvEe1qyguh+R8VUJUY0Zvrf8D96/g/+zz4F+EPheDw94S8PwWdtaIEihhTYsaqOAAP8/XrXMfE74XaZ8UfF2meHNdtlextLhbySEHAlMbAop9gwzX5ZSnKU3Ulu/wAz9jqP3Uke/wDgqxsfDfh0R6fYgEAHauAXOMf5+ldJokNpLHNrMUSGeUBGkJ+8B/DXUtTnTszifFvgKy8Z+I4ptSeVPs53jynKlfwyMZ96k8V6jP4Nhs5tE8MXGsWNgrtPplqy+cWHRgpIDdxVKLvZnsU5e0iknsX/AIceL/hz8SNKTX4vD+veDtUGUk0LxNaiC5hIJByEZlK8ZDKSCDXhf7TEcviH402ehpPHcRQwENJD8w+8B/gKtQUfeRhCcpStJamXbfCGW6sZLnRbqBd8mZbS5DeVIw5VgR8yOD0YZ+lfJf7VvgnSv2N/Bvj74y307Pc6pH5v2eaXJMu3bGFbvlsDnsB6V34GpKpUjRvo2cmKUadN1GtT8crhtQ8WeLDe6hcNLPd3O6WRx1d2y1dn4jtbPRPB9o8AG65lBZT/AHRuY/8AoQ/I1+mS0tA+Cb5m5HB30/2lgEI3MM7f61nsphbeByODXSjF73RISLjbcW7FZY8EOvUY6fkcV7r4k8ay+JPgRa6+9yfOYYkX1ZQwOfxGfxrzsfT5pU59Uztwc3FSSPAEySCc1o26sUyFr0V3OFinO7k59TnpUDEE4207gfSH/BLnxGml/tPQ+HpWG3W9Nmt0Un77RvFchf8AyXNfa+jeD9ak/wCCj+oeKPFU051CwkDnzgf30bxuiyBuhwpTpwc18Dnz9nmE33gfaZSvbZfFPpI/SPTvAGm+KPAyWN9pVvcLOg/d3CBs59jXFePv2QPhX4+8J2/g7xh8JfDeqWVm/mwQalF8sTdNwCrjODjIAOOOnX4OjXnh6ilF2Po5U/ax12Gaf8BbyHUrL+3LX7aulRiGxtVmdobWELsEaKeAm3Ax04HAwK+gvhcLfwr4f/s28txlYkAOOM45q62Kc5Xk7ilRWigrI8T+Ofw10fx/qUsuq6CLu2lkViittYlCSAT3XJGR3xXE+Jf2P/h98YdW0jxl8ZfhJH4pvtBjEGnXmp3a/wCioHLhVAUfKGOQp4HOK3w2OqUYv2UrBUwsK1o1Y3Oi0D9mnwz4W8S33xAsvB1lZXuoAPN9nBzI2MB3I+8cdzXzl+3p8CNf+LHgOTwlpWkTmze+ht5dSERa3glLjG5sYHJGfTNLA4iUcVGrOV9RYuinQcGt9D5m/Zztf+Fb/skaxqer6WiPZardStOVOZDBbyxFQ3oZJY1+pr5oS3jRAhVsgY7V93l7c69ap52+4/IOOpKEcLRXSLf3s/pFvrGSOHaoBzxxx0HFeSeK9Rm0DxVBqVyp2qxjmIJ+QE/e618JFan6Y3dXPX9ChXU/DYurJ94HDjrW5oOi6ld6R5EcxTzAfnx933rdJvYhSSPl/wCKXjn45fsZfGbVtYm1u98R+DfEyR3EEl1ZG8GmzjajwFY13pCxywl+YIVIK4II9M8IftM+CfFniBdJ8TabHpupncIZreYS2t5gA7opRw6HPUE4yM4runRvBTgdsIu6XfY8v/bg8L+P/E/h228QfCn4i6r4Y1q5jeK3uLIh489P3kbA557jke9c7+yd4C+JtpbDUPirqV5qmpW9qIZbuZllaZ+rN8g2hOMAdfpUqtHk5Lam7o+7zJnql5qEHhxLqe+bYm7P0J71+XP/AAXC+Pena9pekfC6zvlL3dwbyWLPPlxcLn23kAfT2rvyWjKeMhdbO55ebSSwknc/OTwdFF9pk1OY4I3MD6HBGf5U/wAUatNcWC2wIISMKAe2Tz+lfo1ryPhm9LHIxsRLsc8/3s9Kl+ZuSOrYPPWukwIQHtpBPGpxnkV0SeLZU+H0vhvzTg3BkHPIDLyPzrKrBTS9TalPlbOYjQ4Bz7VfhPlQ43c1oYojkmDE9sj+HiogzEZJGf1pjvY674FfFDUPgv8AGXwx8VdOX95oWow3ZXbxJGrfOh9mQsp+tf0E+Fvgx8IPir4x8I/F681trmwm0+R7TVtMmWRbmBkRoz5nIIA7dsc18JxdRarUasVumj67hyqpUZ0pPqme7/CiafRL4eEfGiSQzJvNrdzx7RdwBsJMvrkYyOoz05FemaroOgNmRtV81emYyRxXws6Mai1Pq1OVKXLHY5LxB4j8N6IsmnWiLGzkAs/VsdDir2kzLqGnK9wDGHUtz0A7c/QVjUppJJCafNc8/bxppEPiKXQLy0Rv3pCseoB6GvS9C8KSalDtjt4o1xkMxJD/AOFKEFVWhsm6WrMTxdp8Gu+MLTwDbXyxp5Ml7e3kH3o4k2jaGPALMwGfQHivHPjbqGjt8Gtb+EdnLPBZW2qiyhvIZMzENIhJLdQcsct1x+nfShGknKSOerUc5JHwF/wUZs9A+Bnwp0j4OaBLGE128e6KRAqYo0cPLgejSlOe4X2r4t82H/nt+lfaZCpSwntZfabZ+Kcd1efNfZL7EUv1f5n9IviGzjji+02r+U7cjHOD2715x8QdKlvYpNWWAurL8yqOmBXxUpe9Y/U3F8t0bPwL+IANjL4Ue4UyxLiMMedvf6//AFq91sLYQaXE8fzEjoO+a6Kfuq5mnqn1OD+Mun+HvEGiGx8SwLsh+ZZt2GXp0OcjoDXyV8afBttoPh+41vTNRjvIVkaWNN/k/OyhRIQuPLkAAxJH97A3q+K78LOKfvH0OCpPF0PZLRrVHzZ8Of26LjQfHbfCH4lad4ieJJRaRXmp2cjAsRnKuuUdewZSAR1APFfXfh34kW3g3Q2vNQKwG7QEJJkMFwD/AIdqMdhVQkuR3ucftpwbdRW/rofLX7Z//BSLwX8M9PubTTbn7ZezErDBEeXIHPfoMEk9ABX5I/GX4q/ED45+JNV+MPjKV5fPmW2Vgf3cCHOyNQfbP5mvrMhwXsY+2nuz4/N8f7SXsonInVDZaaHdgN5LHt/kVUOpNfM0ueMYNfTxj1PDk7aFC7jUSGSMHA/Wlt33cM1aEN3JioDYDEqeozTPs6G2klVHZVxyvYknGfrik2C3uV3ngJDLHj2p63JcYPT1NNu4hpmzy5PHSmu5Qg459aBjywYF0AGfc/l+Nff/APwQ7+I/jaHUfHXg2bxbq1xpVtYwtaaN9pdreCWRpN0ix5IUkKASAM55rxeIUv7OqStqv8z0spk44uOu5+xdz8QX8afs12HxDmUrceHjHdxuTlkTKrKCewZC+fw9OLPiv4m+JvDel21paaVNd3N0RDbovAbjOWbsABzX5NWlFyXKfpNNJ01ZmF4t1G28FjTvF3jpXazAL3d3aI0ghJ6ZUZOBz2r0Lwb+0d8Kp/B8K6N4i0+6tcAmZ3B3DkAHPTg1pSTtdozqPmtY8W8R+JvAPiD4gpH4T8b2Go3l05hNlYTrLJbZPy5UHI7Zr174dfEfxNrOqN8MLO0A1OwizdTs37qCPqJGPqegGKx5ZxqWsdTknC7Od8PfEO0Pjr4gQxO15LoaxafLcIuY2dVaWRR6kb0yPpXzT8Xte1/wp8C5viE2uz2U93qMt/HDMN7FgMx8dwCq5FdMFJ1VB+XoeRjcR7OnOa7HwL8WLHxt8bfFknjf4q+NbrVtSkXaZZuFjXn5UQcKuTwFArmv+FLaN3uSPbBr7WjiHTgoU1ovQ/n/ABuIlicRKrWbbep/QDqszzRM5bCqeQKq+Hzp93ptxa3TodqkEty2a+NhHmldn7k3pZHkHiy0uPC2ry+JtC1yGLyW3NBMQoJHp6Zr2n4E/tGeHPHOgpZ31/GJR8jIrZKMB0rpcbdDKMtbXNX4gx+HvEFhcQNf+YYxwY2O5fYjvXyh8dfBug6ijWA1KWKMEk5Zir46YOeDTj7klY9alXlSipRdmjzjwr8W/hn+zrBPq6xC4vDGUgEpL4J54z19cDjNfL37W/7eP9nLc6jrN85ursMLfR4m2yzDnlsfdjHf1xXsYLCyr1E5I8bMsyklzSep+fvjjxx4o+KvimW91W7BurzKM/ISCMn7ijsoHHv39a2bn4d/2no0ej28ckWl2CM+WHOcZaQjoXbouemRX17mqKjFHwVfENS55bvc8b8Y217pmuTabfJtaE7dvt2qrZT7HwTx1r1oS5lc6Obmsy3JF5i7F/i6VUQGKXY2aodrk7HP19qtW9ze2+lXOnKVENw8cjjuSu7A+nzmkFiNtIaaLzAOfpVKSB4ztKkY9aadwsMyCMZBpcbwCV68jPegRraR4A8a6/JAujeG7yf7R/q2EZCMPXceMe/Sv0I/4Ir/AAY1r4R/tBXfiXxfrFp5uqaYbQWFqzPs3SAszN0JChsAZ71hnGW16mUV8Q1ZRXXrqgwmPpU8dSoxd5Nn6p+F7PSvBfgW3PiDZeeG7i7cahZXKl42RnKkEddoYqcV0Px9vtP+GklhqkTmWxmjebTw3UYAZ4ge528jP901+Jqmpw53ufqOGrScOWx5lqH7b3wi8IQrbzafql1dyw+a0EtsY1kGeMbuOce/Wueuf2mP2VfEiN4n8YfA9WuAQDG9oszyehGxgDXp08FXlDmhqiIKEZ8s3Y0PA/7Tf7HFrZ3Go+AoNE8O6gis7wy2otJgVBOCCBnv3PWup8A/EPXfh7+y54h+Omp6Xcte+M5JrqC4RNzx2YAEUmOoUjewH+1WVaFSg/fW5oqvu73RQ/ZB1lrL9jKT4pa/HI+r+KDc63ctcAiSSWVmfHPQBFUfQV8rf8FGfihqVj+y9qVvpCI9xYaH55j5MaeZPGOR0ORv9Dg1vl9pZjG6uuZfoeRj3z4ecX2Z8m+BdX0DU9Hi1i0tJYIp8K1sJWYRuQGIG4njJGOa0ZTZiRgLsjBPBUcV/T0uGMpxdOFSdFarorH87ValanUlHex+18vxW021tJonYFmP/LVsV498SvjZ4y8PSz3OhJYNCT84a4Kjg+561/MFKPNsf0PrHc+Vv2iv2nPFPiwz6XFqcybs74LWTYn4sp5ryf4cftHfF34S+IxrHhnVpJd2Fms52Pkuv88ns3avapUIShyyOOd1NSifVXw3/b18aeP9Mex0nQr+4voofNnskUu8K9AxxwVJ71wXxd/bO0fw1YXTeK73FzIjOtqqNJJgcHEagk88fWs6eXuU7I0nmVOEWpPU8v8AhB4b+Jn7V+sX19pfhfVNKsEkWNr6dEa6DMARsj5VMBt3JOOAcV87ftXf8E/vjt+zn4ouNZ+Kei317p93Nuh8SAl0mU52lz/yzYg9CAB7ivdoWw/urc+QzLETrPmWx5VoHgDSk1WGUw5wc4PODXotxp1pNbxaZHbfukBncBcfdHH/AI9z+FaVZuck2fOVqrnUSZ8p/Ga1H/CRz3irhhKVYnr7VyCsQ3GefevoqD/do9yhf2auX7OfzU8suR/tZ6Ul5D5g8xFIcHsa2bNloFncR79knB96t27W5nH2h8Lx+NLcfMjWi8jydsbFh/eHSqlxpsl7LHbWMJlllcIiRjcWYnAAx3JPSlH3mlHcUmkrs7rwz+yF8UvFkAu1FnaqSQfNkZ2T2bbkA+2c13Xgz9ijS9Ov4JPGniFr/DjNlbqY42B9TnJH5V9ll/CtWbU8S7Lt/mfM43iKnTvToq8l17HdWN3pF08PxCj0mPy7V5rKQQLgLArlEYKO6AD6rke9fQ37Gfie5tPjTp8GmSxhNSHk+Ymflzhsg98gEdupr0eKcPTnkOJglb3G/u1/Q4MnnOGaUJSd/esff2vJq/if4A6t4Z02NoGkhntxI53eVKAe/f5lBzW94t8Ma14//ZIjv9a1gXN34Xii1WCZYtpmWNVLJz0+XcM9wa/kpS0fN3P37DT1SON8efAGD4ifDXRvFHhKVba5gg/cyeWsiONx+V1PBBryTWvhX4jtZhDqnwK0W4lK4+0QBo1dum7aH/wr0cFjuSHJPoegpqVzPl/Ze1K20K58Saj4Ys11G9kS0sbW0g2Rxs3A5OSSdwA9K+qv219StPCv7PkPw1trVreFtOTTNqrzGvk+Wec+maxr4r6xNdrnFibQcYxMT4pWselfs86V4S0WMQmURWimPjbCVVTj/gIP5mvzq/4Kq61JBYaX8OtCvWQ+Jr5bV4I2xiGFQzD6AlB+Fenw5SWJzSnDvI8TNKnssJUqdkeF+AAJ/Akk9nlhJfSSR4/uqQB+i1vG500EieeQP/EBjg9+9f11QtClFR2sfgNaUnVly73P1Qaw0/4w+Fbfx34E+JGmalpl3GGhv9Lm3R4PbCnIYdwcEd8V5h40+DKyWs1z4r+KFzcxqCBBAdq/TOa/kCEpUJcjWp/QnuyimnoeCeMPhnosV20en2s0jzv5Vv5z8SMeAAvVifbNeF/tQaz4r+DetwfDvw8tpca7OgefYvmtaM33Ux0LnI4zxkV6+En7SooyOOquVXR+i/7I37EviD9lP4A2WifEbU5Lvx74riXUdcmc/PA8i5SDI6eWGxgcZBxXXW3/AATlufiBqt5q974WX7PemJW3jBZEIwCfTOT9T2r1efW0dj5erLnm5M9v+EP7M3hj4MWJtJNLCyyNvYou0bvX3/z1re8e/CXwX8T9Mm0TxbocF7a3EZjaOdNy7SORg8c+/wCRqXLUh2asz8d/+CiX7Bs/7HXxbt7/AMMQvceDvEDtJp9wwJNpIOWt2PsOV9V44Irxl7YLaTTGIZMW0554HP8AU1Um20fM4qPs61mfK/xK0t9T1jUoIUG4MWBrzWVXglMcnBU4I9819LhXzUke5hZJx5R8UrBs1oQzCdNyABsc10nUV7qzY/vY85HWrfhXw/4g8X69beF/Dmmy3d9dOEit4xksf6DuSeAK0p05VZxhDduwpTUIuTdktT3Jv2KPFehWMN34h8d2asGUXUFgjSfZg3G4sSAyg8EjIzXoQ/Zm8C/B/wAD3XjuC/utS1WGLbFfXLAJGZPkyqDjgE4Jya/QMt4VWGqe2xMryjqkfG43iGdaKpUI2jJ2fc9at7Mp8OtPk8Pwoj2MavHEgwG2jDD8R361maPqNvqwl1WEAOIyAp6qelfbTVkvQ+Ui7uT8zy34I6tu0LUdNuyMWeouGVuyOzK2fzzXs37HVtqel/tD6J4YtFUyDUY1hDdNhyP5E18tm658nq823JL8mfTYZyhmMOX+aP6H6g6TqgtPhp4lRm3f2ej3XK8LuiyePTrXofwR+Hep+JvgfN4T1zV5BFqukyRFYOCyvGe/vnFfx1o5KPdn7zTap+8cd+yR8VNH8VfAzQ7yKVJEeLypA2CI5EO1h/30DXpSTeG3f7Q9rafd5kKAnOelTaSk4s9eNlL5GJp+nR+Pfjr4W0TTNKSXTtCkbUtQlT7sZ2kQqR6l+enQVU/bS8P2/jE6f4QUc3l1GjtnoGfDH8iaOZRjG5x4iT9qjz/426zBN440zwRpMebW0t5JlAzyQpCivy//AOCgjapF+01qlxq4kWx8L6KGs426edOzgn6/L+gr7nw7pRxGd00+l39x8pxTUlTy6TXVpfecF4QkPhb4b2xuhgxWplIz3P8A+uvKLzxrJNdyyy6pMGZySFPGc1/SeNqexhTiux+Q4Kkqk5y8z9hfi1+xDr+veKbjx58ELDXfAfiK7cvdXHhmbybW9Y8kzW+fKYk9WCg+5rn9J/4J/ft/+K76KHxf+0rFbWZIUi00yCe6C98MRtH61/KEc1hy8talzNbM/dPqbi/3dSy7HoWqfsOQ/s4+Drvx1cajqOp61HAY11bXZPtN5K7fwoOI4l7lY1XjqTXkv/BNz/gm5qvxw/a4f9oD4rG6ufDngy7OqXEl/CPL1C8U7oosnrh9rMPRVHU4rqy2tOtUcnuzlxzjRoN3P038K/Dey8ReKbzxp4mDXBlnLJG3TGetepaZpseRDBbqFUAYxwK+i0ifIepS+K+iaa/hmG4liCmG5Qll4LDniubv/DUMUK3VhgwOoYAfSoepSSsfNv7e3wH0348fBHXvAl5Couni+1WN1ty0NxEN0ZB9zkH2Y1+Md9bPb2dxDdRhJIwyujdVYZBBHtijojxMzh78ZHzPPDHP4+mhkQFHmKtnng15n8RPDVz4Y8UXelXcbKyOcE/xA8gj6g5r6HBT+ydOElapYw1zjO6p7e4ZHznv0Fdyeh6R1ngHwfq/xC8SWfhnw3a+fd3j7VTsPUk9gBya+yvhd8CfAnwR0FUtLNHvp1AuNWnT55W74P8ACuSeBx7k191wdlsatSWLqL4dF69z5HijHypwjhabtfV+nY0dXt4rS5i1aOEOsYIeNeRLEw+ZfTlSSPcD0qj8YH/s74NroNvMZI1nVllP8cW4FT+Vff1o2g2fLUajdSGnU6f4b3xl0NIAudsfmKGGQccEfiKwFtz4Y8c3mmMoFtdKZUX0z/8AqqqrvSjIyp/xZx7nkHwTu0vPEviHTwN0d1c3CggHk9RX1H+xLqvhfRv2k/CHjLxaUSBw8DO/3I52RlRj6fNn8cV8dnCqYjIMSqe/LO33H1WFcaeb0VPa8T9B/CPizR107XjGIZotQd7VYTzlBlB+f8iK+hf2f0lbwZBoEhNrdfZzCoI+7kYDDPpX8f8ALKnV17n7re6R+RXxg/at+I3/AASV/ar8Wfs7al4SfX/BVxN/aukxwzmO6s7edmYopPDBWDrzg8DnPFdDB/wcB/Bq40kwaf8AD3xIt6B8kUtvGcN6bt3619j/AGC8ZCOJpNe9q79znqZp7Gfsprrp6H6I/wDBOG68f6j+zu3xs+LHha70LWfGNy2ow2F+AJUs2Ci3DDJ2lkG7b1G+s/8AaE8caJNq8mrwXZ+1Ws0QhZui/Nz+Q/lXyuLpKNb2a6HQqntJOR88/Eb9oywsdft/ENlZ7/sxdRI5wGBjxz+ZP4Cvzc+PPx2sv2hPGRv7zxBZtNqN2UliWQKRDGx2rg89/wBa/UvC3C0YY6piKrs1Gy+e58fxpXn9ThTgr3d38il8WNXi0fwu1mrKGlwoUcbVAyf5Cvmy51K+nuJJlkYB2LAY9TX7Pm0n7VQXRH55lMV7Jtn9ZGnQXEL/AOlaWDzznkVtjVWtUjttP08meU7UhgUs7t6ADk/hX8owptvbU/aak+Uq6z+z5rnxSKz+PVe0tekGlKwE0pzjdI/IRcdxlq7LSfAGgfC34aw+CvDunx2kMmR5cAK8Zz685J69euetfUYDCqhHme58rmOMeInyx2RL4VsGkAjSLCDHH866+wshaxYOT7mu+x52yOb+NM5t/Byx7eZLhAM9+tct4b1oT6RFYOQXj4I79eKXUaehzPxg0CK88MarqUA/48otzN/tcZ/nXw94m/Zr/Ydjv76/+LN/Z6NqV7PLO8criNZQxzvXOO7EVrFJnDjY05QvUPPLT9ln/gjrb649zP8AEHQmuy3Km7TIOf8Aer5E/wCC3/wB/ZR8LfDzwZ8Qv2W9XsL4pdzWGq/YplkZEZFeFiAem5ZB9SBXoYX3aquclH2EaqcJan5q7iWIHY96UDccV7Nj2z7F/wCCfPwoXSvB138T9Vts3Oqs0NqZBysKnkj/AHmz+C19C3jSR28lrNAk8LjmOTBDD/Pav2fhvCxw2XU491f7z8rz3E+3x82ujt9x51qTf8InqQhjYtpV0+za/LWch5C5/ut2PbBFR+JrUav4Hn0d/nNlIEDHr5Tcr+RyPwFerLWLgzOLV4TRL8GtXktbtfDWoYMkPC5HLJ2NT/HS8TRdHXxAqgSxwuoYfeGMjrUTklhW+xHxY1JdTwD9nbUPst4+o3LqGluJZMucdR69B+NaXxJ/aF1zw7fNpPw8v441t5jIt+oyxbduAX0A/WvhsfmP1LK3BfFLTX8WfW08J9azC72jqfoV+yL+05H8QvCOh+J7VFR9SUsrZysc6/eRl9pAw+hr9AP2aPiz/wAJRqSWSwpFcJDmRFJbae+Ca/lfNKfsMTJef6n7TRnz0FJeR5d/wVh/YE+Ef7V3gQfEzWfDbDxJ4djaUahbHZPNB1aPdjlO6gjg5IxuNfDn/BLj/gm98F/in8f/ABD411LRU1vw54ZuIoX+3puWOZMF029CWYrn2B9a9jB5lWhhZ0+n+Y50qcuWq1qvzP16+I3iaz8PeBridXCrHCcADheOBivgr9orx3qV5eppNhcj7TJGWLAbtpJ6k9Ohz+NfP71VfoXh7yi5Hwz+278ex4Q8KN4W0DVN08ytp1u8Z+Ztw/fTHn04H4V8PHy7m/eZ4wIox8oPQ4r9O4coeywin1Z8vnVTmxDiuiDVPiH4tuok0G11qdrcfLHE7bgmeuM8j8DWzZS61DZxQrfzgIgXAUdh9K+xWaYmFru/qfPPA0ZbKx/X7pvws8Q3aLLq+r21ru6xoDLJj25AH612PhXwRoXhhmn0q0Y3DAiS9nO6Rh6buw+mBX5bhMCqT557nvY7MnXXJT2Jb+4t7GbUNbvrhI7KztmeSZuilQWdvoFBP4V4f/w3F+yD8Rp1fwr+0n4NuYcDa/8AaCx8f8DxXrwi5K9jyHpsdNpn7SX7MulWokm+P/glF7ltbth+hfNa2mftOfs8axZNfaN8aPDt/ArFDLYXizruHbKZGafLJasHqc58TviZoHjqwsU8LX/2uzUtMLhFIVyflGMj0zXPeD9Tkt9Z85k3gqcj0IHFT5gja+JtjKnw3udKUfvrwhXYdiTuP6V+T3/BXbRrS21XQpTD/pEKzxAFPvJtVv0IH5mrjsc2Ms6TR+Sus6g1r44ubhIlLJLnBHWuy8QfFbTdR8AX2lXtunnzW5jAcA9RwfwP8hXqKjzcskR9Xi4RlFHzzqMTQXTdlY5FFhbS3t3FaW4JklcIqjuScf1r2Yq80vM7ea0bn6gfDnwfaeCvBOk+FbaPathapD/vFRyfxOT+Nbt7oq39uQkpSUAskgJx+VfvuChyUIxXRH4rWq+0rSnLdtnDeK9Cg1GOay1C1KuEEdxGDyVJyJF9Qpww+jD1rlvDv2pZ7jwnrLgXIVrOT/aDfcf6bgOfepqq079zuoT5qfoVPCAkl1G11SBSLrTpxFIgPLKTgg/TH6Vc/atWWL4ZzOmVaKVpNzDG1RyfwrmxD5cFU9GdNN2xtP1PiyDxTrVzbiwW8aO3RiBCp25GSfm9a19UcmyhlOcEdh+v1r8PxFedeSc3c/T6dONL3Yrc+pf+CZ3xJZb3WvhVel5GmA1Gww3zwyAbWK+oB2kj0ya/Uv8AZT8cXUXiDSvEu5ALhXjlTBG1uhH51+R8TUFSx0n31PuMrlz4RI+s/EeoLrmnC2uyrR3cJjYPyOVx/n6149+wx8DvCX7PP7P5g8LaasE3ijV7zW7sICSfNmYKOf7qKgHPavJo1pKLitmepaP1Z33Os+N2s/2j4dn06334K87O/FfEXxQ8PSy6hqWpaltQhSo81jhURScY4yCefwrCNT37Cwsf3ep+SHx4+IFz4++I2o6kcrBDK1vBH2VVYjPsWPP4+1ef6lfpFF9ntyMDqelftWCpeyoQh2R8DipudWUmWfCOiNdXwu7hdrDkKf4RWtc+PILW4ktfJB8timc9cHFdV1cwVup/WP4e/wCCjX7Lvid/L8Ea94k8RODj/iU+HNQdT9HaJU/8eqDxn+3x4hs5Lez8Bfs5eIr1JWAe/wBbnhsIYF9dgZpD9ABXyFlfUi1tiDT/ANpH4r/FnS9T8Nah4H0qwsLmFrd2xKzkONrD5jjlSR0715lP+xD+zpfw/wDEw+HlovTKWpaFf++VOKtuy91gjVtv+Cev7KFkkUlh8MNPmllAb98m7GfrXX6T+yb8MPCujm10/TLfT7RPn+zWwMaAHrwuKV21qx7alrTdCe+f+zdCst0UKhY1HAVBwK2tH8L6pZK0yxK0gcRqc8Ke/wBcUpOyDfU2/iHNpuleFxdapcCOKFcvI3f1/H0r8d/+CqXj+Pxz42t7m3jCW0L3CRRn0UKCfqa0j8NzlxlvZs/KLx3c20fie8WEHd5h5FZU11c3EYglUOT/ABY4x9K9yD5aaZ0U2o0kUr/4f6reWz3FignIG5UH38e/rU3wB8I3fi343eHfDccLbjqEbSIw5VUbe35BTXp5fJYmvThHujCrWUaFSXZM/TW3iCuMcLnGDzVyVFt0EqxlsZwrHqPT6+9f0FQ0irH4pJ3l7zMbxTosGs2Carps6rPFkJK4I2nHKP8A7Jzz6HBrzHxRodxq0bax4diaDVdMPlG3k4Mic4RvcbcD3UetZ4iOh6GDnyuzM/wM4f4pTOsTRx6hEl4qZ4+Zd388/lXnH7bHxYurrxbafCayRRbNEJrwnqzEZVPoDz+XpXzXEGLeGyqfLvJ2PfyvDqvmUHLor/cfNMUBikkQgDDdTW1fSZ0WE9MKOcV+Pt3Wp+jpK53/AOyP4k1Tw38evC+qaOsjN9q8qWKI8vGykOPy5/Cv2t+AmgatJ4HsNf0+yldmdpTGAQyg9yPpwcV+ccZ8sMRCXkfWcPtyw8kz32DxTqV34fjtreTZP0CTnhcD8+1Y3wB+K+n+IPBdr4T0shtQ8OudNv7YMwEciYJAJGDkFWHqDmvmE7U7o9hJOk4nbeIvClzqlmY47FWLnJXdXyP+278Afionh298R+ELYSosZWWOOby3VCPmI9f/AK9cWGqxjiI8+xtSi3SaR+GPj231Dw94o1HRNSt5Ybi3uZEkjlBDAgkdPxrC0+3N5O1zdHMcfP8AvEdBX7zSkpU4yjs0fnFWLU2nudDoEzw2t1qLsRtQsD71zBG875FYseSeOtXG5nyn9hMenfFbxZH5MixaDZMMbIRukx6egrS0P4N+GdLf7XfrJdzn71xctucn1HpXyINXNmPw14WsAfL0qEZxn/GszVpdKlY2llp0TMTzhaFcLWL+jaItjB590BvIzz2rlfiB4mW9uG0Wxkyif611PpzimTcv+GLB9K0xYIwBd3uHZj/yyToPpxW7YQtcFfsFuTDbAgO5wo9WJ9TUz1KTPJv2mvGcdv4Tvpnn3rGpDyN3A52gemf8mvx6/bj1p7nU9NM7jfMk8m1uerKP5/1rWn8ByYyzpn55a34bXWfGNzGrbQ0pwRVu48G2theCziRnZcZNei6zsomTrNxUUdNpeh2nhzSrjxJqg2w2cbSFj3x0H196T9gnRk1j4z6h42vlz9ljMIdhwZJi2fx2hq+h4QoqvmdNPa/5annY+bp4GtPyPtqRwIA/UdPlPOPTNWdI1RL0nTrp1Z9pZMjiQDuB7d/Sv6CoaRsz8plZq6KOvJcaK73qyboXG2Qufkdc4Cv6Y6BvbB9a84+Ic82iX669p6Sb0TbKpHzSRdeR3ePhhj7yA46czidYO/Q78CveXmZPhGKym8UaZrWlkiOMzWUgU52g/vE/D58A+lfKPx18RnxR+0HrWpictGt75ERz0VSFB/8AHa+A4wqcuChBdZH2nDkefFSk1sjlorfzL66jGMBuPzq5q8Ih0VImTHy/3T9a/NNnofaLzPu//gin+wT/AMLs8Uj43/EW0uU0nT9y6dABsNw5BDPn07A9+a/ZjwX8KNA0vT4dP02FoI4D8rdPzr8b4sxn1vMZRT0irH6Bk2H9jg1JrV6mP8e/EXhv4XeBNU8VakAq6fZySs5AG7apwM1+NP8AwTy/4KIa94Z/b/1O98Ya+0eheOb8wNFJITHFOnERyT1IBXPqV+ld2Q4JYvBV21dqP/BOLH4p0ZQiurP3B8MePbXVbIX0SrLE6AjbnJH5+9VPH2n2Pi7Tri0EClJVIZJec5HUHtXytVWlY9rByPyI/wCClX/BM+PxPr134/8AA22x1ORuGdD5U390OByMjgN29xX5w+NvCPiH4darN4N8TaPNYXtmwWSCcYOT0YHoQexHFfrXC+aRxuFjRk/eivwPkM8wXsKzrRWjJIgIvDJTkGUhR781z5R8nn9K+nTa2PCvbc/tFlu4Ih8qjpgCqV3qnJx+VfIokw9T1mWZ/stqf3jdQO1X9C0ZLRBd3PLnuaq/QW+pmePvGZ0+1/s3TT/pMwwoAPy+/wBK5Hwtp4vtVPmgvFBiSR+8j9Qvvk80LRD6noNjp6THbNJ8zndcSr+iCrviTVotO0V1XbHDGpwi8bj2qdhnyT+114u3aJNpUb4RMhlQ/fkPb/PpX5Hf8FCvHI0H4/aR4CeTJh0Uu5J6O8zZ/LaPyrppR542OXExUonyTp/7zxhJIwBBlPNenReGtLmdLpYPnwOD0NVUdrWPOqz5Tj/jdqcl3ZRfDPQrYm6uts1xL0SCIE4JPuQfyru/2V/B9v4D+G8XiCC4E8t9q7StIBgMsYEePp9+v0bgPBP2qrS7NnmZxWdLBey6tr/M+jNLvlimk0uVA7qN0e7/AJaxnp+VLq2nqFS9snIQvkK77dreof8AhcdieCOOlftMNj882muxY0/xVHLbNaaucEP5fnsCqk91dSfkY9OeD2rmPH3hyxls3jWRoY/vReVzJbMDwY89v9k9O2OlFW0ou5pQk4VEonjC+PG+Gq63DrwWKY2rPDs4SV0HyFfTO7p26dOa+UUvjqHjcXE2SZZCxJPJOCTn8a/JuLq3PKnRvsn+h+lZDQ5eequtjQ0mASXM5xy0mPTHNfU37HH7APib9pjxTp+seK9PntPDiyKxj2kPeqDz/uqfXvX5rnWZLLcLKt1tofZZdhHja8YLZbn7bfs5fB3w38GPBVpoXhzSY7cQxLHHDEmFjUDAGPyAr1VbqWwtw1yx+cnAA6Zr8Sm5Vp+0luz9ClaEbRPzz/4LkftWw/DP4D3ngzR9SK32vstoiIfmIJJP6Ka/ExJ4/wC0YrywuZI5DKjB4HKuHDAhlPY56e+DX6twfh3SwDqNfE/wPis6rc2I5V0P2+/4I6/t3H9o/wCFA8H+M9UjbxR4bK2l/GeDMuMJOP8AfCsD6MpHpn7oFozQM6PlM/KCa/P85wf1LF1KPZ6enQ+ky2t7WjGRx/xS+HmlfEDTm06/tF81l2sDjLAj+Wa+A/23/wDgm54f+K+hy2c9o1rqNsD9g1ZV/eWx9D/eQnqp/CsspzGeW4mNSOx6GMwsMZQdKXU/MD4wfCfxt8Fdfk8A/EDSmtbu2OFcA+XcoP8AlojY5GePUHg4NcZFo7SRLJtHzAHkH/Cv22hXVemqkdU9T82r0XQqOnLdH9idxekg5J/Osy91Gadvs1oCzE4r5m3U52amg6ElnGbm4G6RuSx5qv4x8U22g2DSM/zYwkeepoC1keb3M97ezSX902Z5eqk9Pauz8B6LJBZxzTDZEDuZj/G56Y+lDdkCV9TpbeRlAjVcAcDHb1rmPiJq8ccGx5gkEPzPJ/eI9B3rNAz5S+Lk0fiHxLLfXcRWw01TMQT0Cgsc+7EYr8V/+CknjC4m/a9m1l3LPBp0EbLg8Fmd/wD2avRwtr6m+Fw31qXKeE6P4lF9r/mRL85Ocj617V4ZubyfTUlu12lh9z0p4mmoJNHk4ygqKs90zyD46+J5/D3iXVbexZlub0xoG3conljGP/Hvxr6A+BEX2D9n3waH3NHNbPK5z1ZppCTmv1XgaanXjHoofqfPZ7HlwkH3l+Fmey2NiNV0W3ke5ZJIh+5vE+9Gfcd/cd6uaZrpa9GjeIoY7a7mG1ZVGbe9Uf3fQj06iv1Wm/ss+BkuaNupLquhXNkv2+3jeaNFw0UY3Sxp3APR4x/cP4VyfjuxuLnw8b/w9ciVFGfs6MSPcoTypH90/nU4i6g7G2GmnUTex4F8atvi/wAH3dzMuLqGHkqMHK9HH8iO4NfNXh6RpPFEXbIbkj2r8g4siliYzXVH6dkL/dOHY+zf+Cd37B2rfGbUIPib460gtpKyMbDT5VwLxgeZH/6Zg9B/FjPTFfsj+zz8AtF+GugQ3Ulise1BgBSMY9P8Bx2r+eeLsz+t4v2EH7sdD9ZyLCLD4ZTa1keweE4FmlaQHapP3W7Y6VT+J3jKDQ7C5cgfukxnHSvmYx5lY7qmjsfz8f8ABV/4/XPx7/al1bSLW9L6V4ac2USq3ytJwZW+ucL/AMBPrXy/Ckum3cN3CmTDIsgJHXaQR/Kv3DKaP1fBU6W2h+fY2ftK0pHrv7Gf7Vuqfsp/tN6d8YonddJvLgw6pawn/WW0jgvwO6Ehx7rjvX9EXwX+KGhfEnwhaa1pd/FcW93AssVwjZR1YZDA+hBB/GviONcJy1oYnurfd/w572Q1f3bpvobOtQILlb4vnAx+Gf8ACszxR4O0fxppjiSNd5G7LDOfavgJpX5T62m7K58X/tvfsI+EfjV4Tu9D13T3huU3Pa38Mf760k7MrfzHQivzYvv+Ccf7UWlXs2l2uiaTcxWztElx5oXzQpwGwTkZxnBr9A4V4ghh8M8PXe2x8/nmVTxNVVaW/U/qBvSfKPNN8LqrXUjMoJB6mvbPiDorr5Yjt447V5b48kkk8WRxO5ZQMhScimgM23+d1Lcnah59a9PAEdnFHGNq+SPlHAqGNbEluzbc7jXnnxJd2v2RmJCqSoJ4H0oRLPmj4vEr4K1F1OC8pDEfxDB4NfiN/wAFBSW/ad18sc/uLfr/ALld9HY9nI/96+TPGPDQA8ZWgA6nn9a9+0niCPHpV4v4UeTxGkqzseC/tXoifE2IogBNpHkge7V9U/AqONv2W/CW6NT/AKI/Uf8ATWSv0rw9/j/9ufqfIcRf7nS9f0Z6L4Ukk/4RJW8xs5HOau+LFWXwZfmRQ2yGORd3O1v7w9/ev1x/EfAS/iM6DwZPPPoFrJPM7s1sGLOckn1+tcB49JtfiZc2dsfLhdUZoo+FY+pHTNKr0OjDpe1Z498So418Y3sSoArR8qBwa+U/BaJN49sIZkDo1zGjIwyCC6ggj0IJH41+ScX6O/8Ai/Q/ReG9V9x/QZ+yBp2n2mnWcFpYwxJGsaKkaBQqhSAAB0GBjFfTmtySR6dtjcqFHABxiv5QxDvXm2fui0SSNDRWYadu3HPrXkX7SVxcLoF4VnccdmNaYf8AiR9Tlr7P0P50fiNPPc/EfXJ7mZ5Hk1C4LO5yWPmPyT3rnLtmMTZY8Zr92ofw4n53U+KRSk5vbTPcpn361+4X/BE7VdUvf2UPDy3mpXEoSKWNRLIW2qJ5FCjPYAAY9BXzHGiX1OD/AL36HrZF/HPu11U2jgqPujtVbQubvaem7pX5NHdn3MPhOR+McMR06QmJckZzivnu8sbJryUmziJLnkoPWpi2pOxvDVH/2Q==','','','2014-04-28 13:29:13','2013-12-11 17:52:48',2,1),(26,'Dragon Force','02-904-3295,  08-1442-1778','data:image/jpg;base64,/9j/4AAQSkZJRgABAQEBLAEsAAD/4gxYSUNDX1BST0ZJTEUAAQEAAAxITGlubwIQAABtbnRyUkdCIFhZWiAHzgACAAkABgAxAABhY3NwTVNGVAAAAABJRUMgc1JHQgAAAAAAAAAAAAAAAAAA9tYAAQAAAADTLUhQICAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABFjcHJ0AAABUAAAADNkZXNjAAABhAAAAGx3dHB0AAAB8AAAABRia3B0AAACBAAAABRyWFlaAAACGAAAABRnWFlaAAACLAAAABRiWFlaAAACQAAAABRkbW5kAAACVAAAAHBkbWRkAAACxAAAAIh2dWVkAAADTAAAAIZ2aWV3AAAD1AAAACRsdW1pAAAD+AAAABRtZWFzAAAEDAAAACR0ZWNoAAAEMAAAAAxyVFJDAAAEPAAACAxnVFJDAAAEPAAACAxiVFJDAAAEPAAACAx0ZXh0AAAAAENvcHlyaWdodCAoYykgMTk5OCBIZXdsZXR0LVBhY2thcmQgQ29tcGFueQAAZGVzYwAAAAAAAAASc1JHQiBJRUM2MTk2Ni0yLjEAAAAAAAAAAAAAABJzUkdCIElFQzYxOTY2LTIuMQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWFlaIAAAAAAAAPNRAAEAAAABFsxYWVogAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z2Rlc2MAAAAAAAAAFklFQyBodHRwOi8vd3d3LmllYy5jaAAAAAAAAAAAAAAAFklFQyBodHRwOi8vd3d3LmllYy5jaAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABkZXNjAAAAAAAAAC5JRUMgNjE5NjYtMi4xIERlZmF1bHQgUkdCIGNvbG91ciBzcGFjZSAtIHNSR0IAAAAAAAAAAAAAAC5JRUMgNjE5NjYtMi4xIERlZmF1bHQgUkdCIGNvbG91ciBzcGFjZSAtIHNSR0IAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZGVzYwAAAAAAAAAsUmVmZXJlbmNlIFZpZXdpbmcgQ29uZGl0aW9uIGluIElFQzYxOTY2LTIuMQAAAAAAAAAAAAAALFJlZmVyZW5jZSBWaWV3aW5nIENvbmRpdGlvbiBpbiBJRUM2MTk2Ni0yLjEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHZpZXcAAAAAABOk/gAUXy4AEM8UAAPtzAAEEwsAA1yeAAAAAVhZWiAAAAAAAEwJVgBQAAAAVx/nbWVhcwAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAo8AAAACc2lnIAAAAABDUlQgY3VydgAAAAAAAAQAAAAABQAKAA8AFAAZAB4AIwAoAC0AMgA3ADsAQABFAEoATwBUAFkAXgBjAGgAbQByAHcAfACBAIYAiwCQAJUAmgCfAKQAqQCuALIAtwC8AMEAxgDLANAA1QDbAOAA5QDrAPAA9gD7AQEBBwENARMBGQEfASUBKwEyATgBPgFFAUwBUgFZAWABZwFuAXUBfAGDAYsBkgGaAaEBqQGxAbkBwQHJAdEB2QHhAekB8gH6AgMCDAIUAh0CJgIvAjgCQQJLAlQCXQJnAnECegKEAo4CmAKiAqwCtgLBAssC1QLgAusC9QMAAwsDFgMhAy0DOANDA08DWgNmA3IDfgOKA5YDogOuA7oDxwPTA+AD7AP5BAYEEwQgBC0EOwRIBFUEYwRxBH4EjASaBKgEtgTEBNME4QTwBP4FDQUcBSsFOgVJBVgFZwV3BYYFlgWmBbUFxQXVBeUF9gYGBhYGJwY3BkgGWQZqBnsGjAadBq8GwAbRBuMG9QcHBxkHKwc9B08HYQd0B4YHmQesB78H0gflB/gICwgfCDIIRghaCG4IggiWCKoIvgjSCOcI+wkQCSUJOglPCWQJeQmPCaQJugnPCeUJ+woRCicKPQpUCmoKgQqYCq4KxQrcCvMLCwsiCzkLUQtpC4ALmAuwC8gL4Qv5DBIMKgxDDFwMdQyODKcMwAzZDPMNDQ0mDUANWg10DY4NqQ3DDd4N+A4TDi4OSQ5kDn8Omw62DtIO7g8JDyUPQQ9eD3oPlg+zD88P7BAJECYQQxBhEH4QmxC5ENcQ9RETETERTxFtEYwRqhHJEegSBxImEkUSZBKEEqMSwxLjEwMTIxNDE2MTgxOkE8UT5RQGFCcUSRRqFIsUrRTOFPAVEhU0FVYVeBWbFb0V4BYDFiYWSRZsFo8WshbWFvoXHRdBF2UXiReuF9IX9xgbGEAYZRiKGK8Y1Rj6GSAZRRlrGZEZtxndGgQaKhpRGncanhrFGuwbFBs7G2MbihuyG9ocAhwqHFIcexyjHMwc9R0eHUcdcB2ZHcMd7B4WHkAeah6UHr4e6R8THz4faR+UH78f6iAVIEEgbCCYIMQg8CEcIUghdSGhIc4h+yInIlUigiKvIt0jCiM4I2YjlCPCI/AkHyRNJHwkqyTaJQklOCVoJZclxyX3JicmVyaHJrcm6CcYJ0kneierJ9woDSg/KHEooijUKQYpOClrKZ0p0CoCKjUqaCqbKs8rAis2K2krnSvRLAUsOSxuLKIs1y0MLUEtdi2rLeEuFi5MLoIuty7uLyQvWi+RL8cv/jA1MGwwpDDbMRIxSjGCMbox8jIqMmMymzLUMw0zRjN/M7gz8TQrNGU0njTYNRM1TTWHNcI1/TY3NnI2rjbpNyQ3YDecN9c4FDhQOIw4yDkFOUI5fzm8Ofk6Njp0OrI67zstO2s7qjvoPCc8ZTykPOM9Ij1hPaE94D4gPmA+oD7gPyE/YT+iP+JAI0BkQKZA50EpQWpBrEHuQjBCckK1QvdDOkN9Q8BEA0RHRIpEzkUSRVVFmkXeRiJGZ0arRvBHNUd7R8BIBUhLSJFI10kdSWNJqUnwSjdKfUrESwxLU0uaS+JMKkxyTLpNAk1KTZNN3E4lTm5Ot08AT0lPk0/dUCdQcVC7UQZRUFGbUeZSMVJ8UsdTE1NfU6pT9lRCVI9U21UoVXVVwlYPVlxWqVb3V0RXklfgWC9YfVjLWRpZaVm4WgdaVlqmWvVbRVuVW+VcNVyGXNZdJ114XcleGl5sXr1fD19hX7NgBWBXYKpg/GFPYaJh9WJJYpxi8GNDY5dj62RAZJRk6WU9ZZJl52Y9ZpJm6Gc9Z5Nn6Wg/aJZo7GlDaZpp8WpIap9q92tPa6dr/2xXbK9tCG1gbbluEm5rbsRvHm94b9FwK3CGcOBxOnGVcfByS3KmcwFzXXO4dBR0cHTMdSh1hXXhdj52m3b4d1Z3s3gReG54zHkqeYl553pGeqV7BHtje8J8IXyBfOF9QX2hfgF+Yn7CfyN/hH/lgEeAqIEKgWuBzYIwgpKC9INXg7qEHYSAhOOFR4Wrhg6GcobXhzuHn4gEiGmIzokziZmJ/opkisqLMIuWi/yMY4zKjTGNmI3/jmaOzo82j56QBpBukNaRP5GokhGSepLjk02TtpQglIqU9JVflcmWNJaflwqXdZfgmEyYuJkkmZCZ/JpomtWbQpuvnByciZz3nWSd0p5Anq6fHZ+Ln/qgaaDYoUehtqImopajBqN2o+akVqTHpTilqaYapoum/adup+CoUqjEqTepqaocqo+rAqt1q+msXKzQrUStuK4trqGvFq+LsACwdbDqsWCx1rJLssKzOLOutCW0nLUTtYq2AbZ5tvC3aLfguFm40blKucK6O7q1uy67p7whvJu9Fb2Pvgq+hL7/v3q/9cBwwOzBZ8Hjwl/C28NYw9TEUcTOxUvFyMZGxsPHQce/yD3IvMk6ybnKOMq3yzbLtsw1zLXNNc21zjbOts83z7jQOdC60TzRvtI/0sHTRNPG1EnUy9VO1dHWVdbY11zX4Nhk2OjZbNnx2nba+9uA3AXcit0Q3ZbeHN6i3ynfr+A24L3hROHM4lPi2+Nj4+vkc+T85YTmDeaW5x/nqegy6LzpRunQ6lvq5etw6/vshu0R7ZzuKO6070DvzPBY8OXxcvH/8ozzGfOn9DT0wvVQ9d72bfb794r4Gfio+Tj5x/pX+uf7d/wH/Jj9Kf26/kv+3P9t////4QHsRXhpZgAATU0AKgAAAAgABwEPAAIAAAAGAAAAYgEQAAIAAAAFAAAAaAESAAMAAAABAAEAAAEaAAUAAAABAAAAbgEbAAUAAAABAAAAdgEoAAMAAAABAAIAAIdpAAQAAAABAAAAfgAAAABOb2tpYQA1NTMwAAAAAAEsAAAAAQAAASwAAAABABaCmgAFAAAAAQAAAYyCnQAFAAAAAQAAAZSIJwADAAAAAQBoAACQAAAHAAAABDAyMjCQAwACAAAAFAAAAZyQBAACAAAAFAAAAbCRAQAHAAAABAECAwCSAQAKAAAAAQAAAcSSAgAFAAAAAQAAAcySCAADAAAAAQAEAACSCQADAAAAAQAJAACSCgAFAAAAAQAAAdSgAAAHAAAABDAxMDCgAQADAAAAAQABAACgAgAEAAAAAQAAALCgAwAEAAAAAQAAALCkAQADAAAAAQAAAACkAgADAAAAAQAAAACkAwADAAAAAQAAAACkBAAFAAAAAQAAAdykBgADAAAAAQAAAACkBwADAAAAAQABAAAAAAAAAAAAAwAAAGQAAAAOAAAABTIwMTA6MDg6MjEgMDk6NDg6NTQAMjAxMDowODoyMSAwOTo0ODo1NAAAAAnhAAAB9AAAASkAAABkAAAAJQAAAAoAAAABAAAAAf/hAftodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvADx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDUuNC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIgogICAgICAgICAgICB4bWxuczpwaG90b3Nob3A9Imh0dHA6Ly9ucy5hZG9iZS5jb20vcGhvdG9zaG9wLzEuMC8iPgogICAgICAgICA8eG1wOkNyZWF0ZURhdGU+MjAxMC0wOC0yMVQwOTo0ODo1NDwveG1wOkNyZWF0ZURhdGU+CiAgICAgICAgIDxwaG90b3Nob3A6RGF0ZUNyZWF0ZWQ+MjAxMC0wOC0yMVQwOTo0ODo1NDwvcGhvdG9zaG9wOkRhdGVDcmVhdGVkPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4K/9sAQwAIBgYHBgUIBwcHCQkICgwUDQwLCwwZEhMPFB0aHx4dGhwcICQuJyAiLCMcHCg3KSwwMTQ0NB8nOT04MjwuMzQy/9sAQwEJCQkMCwwYDQ0YMiEcITIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIy/8AAEQgAsACwAwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/aAAwDAQACEQMRAD8Am1D4m3ECnytLhTAwDLKzfyArJtvHOv6nM7GeOGJf4YYR/XJrk9cb98BmrWigCI5zz1+lc/Mz9Bo5dho13CMdEdvB4v1ONk8wxSDjllwc/wCRXEXekRyvdXM87zzztvLSdVJPb1/+tWnvJbHIH86gvGEdqzKf4eRjGafMzsnlmEinJwRyN1aLaj/WHd6VWxuXK4J6kZ5rTm/0u3dwfmTsazjbE2/m5wwPQ+lVGrI+ZxmBp814rQR4ZVi3FG2+uKrEMOen4Vt2d3LPaCFcGJerMoP4D3rSkjstioWK5GdrpuHT1BzQ69hU8mVWPNCVl5nHEFjkn9ajK+v866WXSLeYgpEGyOGibj8uKpS6EwOMTL2wYqarRZy1MoxEHpqYmD6ioz9a1m0cL1kcY7FCKBpCE9ZG4zwtP2sTBZbiOxkEDuabkVtf2UowPLc+7HFP/s9FX5kVfTvSdVGiyyszBwS2FGfwp6xM5wore8hLfDOpA7ELVK8iaGYTRgmNuo9KSq3Yp4B01zS1sVo7J+N3erKWEffNOjPmdOmKu20ElxIEjXJNTKozsw+Dpu2lyjNpoMRZOCO1a3huJ0tnLf3+hq+mlBVzNLyP4VFNee309SsCgEnJJ5NJTZ0YnJ09djXj3YB6A+ta1tc21uoaWdB9DmuTju5Zh1JzVpw6W5ck9KXOxwyOna7bINWRpbtUUGpoWFmFVu/Wr8tuDKsoUnaOprK1AuxL59uO1J7n08qfsm6j6m6jggMp4J7/AEqldb12vn5c4Ye1Ns7qNbJPPcKBxz3qJna9VgG2wg43f0pvbUdStzLkp6yfQy5AomkS1DOXPCjt9aaunTvFuuHG1f4F7VrLbmNNgBC98d/rSycRbQABjoKz5zlWWJrnqu77dDOWKO3iyg+gquyS3bsVztRCSfTJA/rU4DFtmMjOMfWr2nwhNK1GdjjJiiH1Ykn9FpJXOSq+a0VokReWI7AKMHaM0yCc7AWcj6GkuZf3XlrgVSeQlkiU9euKSNqlRRkoo0ppZGiBRXkOeBnr9aoJPOLlY54wofgEGtPBWAAkYA5z0qkZY3lR1EhEZ6quRVxehji4NJSjL5ChAZR3xxUlxahoMjgjpSQyLK7OjBhntWgiq6c/kajqd1GnGpF2MuXairbTgZJHJ9GUYrOniNtL5XDxsM7a6DXbIy3WkiIfNdQREH3XIb9QKxJpP+JgqsOkZz7Vol1PGrSvdPe6QxbJSjNbN1HMZPNaGn6hHH5ds6iEKcu3c/X1qhE+y7iZO5rUu7RJgWYBX/vCp5tbM6cPRcU6lHS3QNSucTIE+63Ssq/z5wGe1VpmntJ1ZiXRTxUiTfa7hWJ+8cVbXYxnivbtxlo29je0y1C2ayycA9KratqC7DFEfyq5qxe30tBD0zjj6VyhctyTzUpHTja3sIqhE7+SVUtWaRgOO47+1c/Jeb8xxKXZjkjHJp5NxqW1nLJBwAMfyH9atw2scRIiUAZwff61UpJHU/bYx+77sfxZjfYpXuVMr9+gPSt9CEATaMAYAqvHEBM27gDpn1qw20cEcjrWLk2duDwlPDxut2SAj0K/rUdxtxk4B9MVG04XOMioGYyt3A9aEbVqitZEmm7POuLhsEW8LSkHucbVGP8AeYVQvr+W00qC2jjIWafzWc9H2jYAPzNX7zTkXQY5yjrNcTkRuCQdi4z7csR19DWDqRltr5bK6ZH+yny8oODg8/qa2hofJY2rNScRZZWBzzz61JaRFn3Ec9qhUqyCVj+7B2jFacChGGeO9Q0dGHXPNO5bfEkYT5cD9aVOAQRximbxsyDxVaPUojMVKlBjG4nFKKk9UelXrUYW53uM01VaSd+mX2jHatN5hBbySZPHT354rIa4RZT5EqRqBk995qrJdzTgK75XPGBxW0abk7s8j+04YWk6cNZa69DSn1l5Lq2mfmKxXEI6EDcWOfckkVUiQzTz3csfltMxYJ/dUnpVNnAxuXIGcg+lSXGvT3NwjyxxqqxrGFQfwqP51pODtoeXh8bHn5q78/mJNA8Em4H3FXo7n7QnLYb09aIJ4r2M/LgjsahktTG25Wx7VyOPRnvUZJLnpO6Y+ezLod3NZqW5hnG09OlakVywyrCi5tw0SzRdQORVKTSsKvho1ffjujTiuIr2x8lziQDv/jXOXlmYGLAZXOM1fSJriLzICRIowUH8xTbq68yzNvIvzA5DYwfxqrdhV6ntY2rL3uj7msJePu8YxQHkYHAGKiwTwKeFPr+FZM+hhJ2G3ErBAOFUHJOeSakmkBAG3JYc0jwbkzmpXhbavTJHekS+ZXIASRjbxTIbC6nmWK2dvMkYKqHnJPSnNJOhyLdXHqrVb03Xf7LuGvXsJHkjRhAcYCyEcE/QZNaxgzzMXiKPI+a6YXuo3NlqkA1KzWaDTB5ZW1JZdyknnPq/J/KuXLC5knuHI3EEnP8AETyT+ddD/a9qdIe2xN580u6YsnBRfur+JJJrGmjtbvbEhUMPnkfoR7ZrRroeG7TfNCafkyJLYrDGkWcuRlfU1p2+SCjfK47VQtkczYjlDovTcfX3FaRYjG5CPTA4xWUrrQ9HBRUffjoIShlKK+x8dKhewEkgZnB56BetV7d1k1Z3yNoGM9qsXnmRyxvHKUDfKT1Aq0rdSJyp1abnKN7Nop3It7YtEq+ZITkluiD+tVnZ5ZBxknsBitSCwKOWkYMxOSDV14oQOEAI7jrVqqkjkWUVK8efSK7GLFp084A+VMtj52xmquq6Rc6RfS2l2oEkbYJU5B9wfQ10Mk0cMLGV8Lj8fy/GsnxBq8usXcMksaoIYUiO0/f28bm98Yq4Scjix+CoYaKjGV2Z1pO8MyvuPWuiTDrk855rmYVyQvXmukiyqqMcYrPEJaWO7IpSfNF7CtCrDJqNQ0Ufqobp6irIwYyc4x29aRIw0XOOveue573sovYp7jbz+fGPlP3lq7cWsd5GJEOCR1/vfWoGTnGODS25a1k8pjiN/u+xpqTRg4Jpwmrp/h6FpV+bjpTypBFHRCyj8Kh+3RqxVtoI6gmizZ6c69OjZTdrk7t8hxjIHQ0yb7UsSbPLYEdzUEk4lQhJsZzwuCf1qMOJIFU3zAgdiBjmtIxZ5tfHwlpFv5MngGpXE8cMFssssjBERTyze1aYn1q8hWzXTY2g03fLMFfAJzyzH/x0Y9OKy1WCG3WWDVLtb0uRiM7QqY67vUnIwKS5soFtbaOyu7l5GUm6Eh2oh/hUD+LjrnvWsVFHjV6ladrX8tUxdU1O51K6muJrKFMHmKNdqLgYCj2xiqG1Y7UmazzJJ82eBzVl7S1RtrFm2+pxmmrb27zNIcsoA2rz1pOVxww9RWi2r7dNCGG28kBwkisRn5Xqe4nW3tck/MRhQepq0ZLdflACnvnAqlIsLTCUnJTvnKislrK53NqlRcaUk5MzmY2kDRkfvJvmP+yKga5lbaGdiB0zVuW0kmDy+YrdW59qYmmKWAM3z8g45xXQpRWrPnpUsRKSUb26Cfb7gHh+tRtqFzjHmk/UVYNiu3Jdmxx0AP8AOoPsEjNkc84AOM1ScCan1xaNsjDtIcuxZvUmmTDI+lTJaS+btwBzz7VYuLEptWImUlcnCniq5ktjm9jWmuaQaHps17NM0cZZYIzKw74zjI9eufwrZ2ZXIzx61Doss+mvFqC+WhicRmJyS8oOc/L3UjitjVYbWGWK5s5ka0u1MsY3jcnqrD1ByPwrmrJs+lyeVOFPlelzJZTGcjNSQHfA2ezUoeNl+8Kis3QxTqXH3uK57M9hTgpaMk2Z54omi8yPaTyOR9aajhgQCCR6VLuJXGD+J6UGtoyVxz/cbB7GqUXE0pZHJLDG1fatAYYY7dxVi2tHnnSG3haSdzhVUZJ+n/161hLoTjMI68oz5rWMe5R5CrCNlVAx3FcdulQ2ZlXT8gREng7kyRzXb3sFpocDW5ihvtYYFCNu+K2z2A/jf9BWdplpYaTpcs+pRLcX8rEQ2ZfAjH9+TH6L1rW7W54X1e9XTW+3n5+hzFufLSRtpaZpDtAGO1PCPEqSiFw4B8wn+IHrWmYgSTg88g9P/wBVJtUDG3AHTFR7RHbHJ6nKm5Gexh+1F5MMhUGPeMimKwkuYRHHFuz96MEY+tapiDcZbAHFJ5Kjsenej2iFLKK0rXa3uZMHlorCXHmZJJZeaSVVk+0PGvyCMDIGOa1hbr3B/OmNEAfmDY+tL2iE8oqONm1YyDE8Kq0KvtCjKHofXFSaeA8skmCC0mcGr4CJlf505I13DFJ1Loqllzp1ItS2KWoRligIz868HkDimCF1IO2JSASGCGtFk3TZJJAX1681VltmnupEEjJHGowBVQnoY4nBvnc97uxmGOI2wY480E7txOc560iXLLbzorvtBXBBPPqM1sx2Plq25mc56n0qpPahGJ2kAnkY4o9pEwll1ZJN6EMoAjZlhnBwTkvwOKIFM1xFHJOY0aNC0i9snGTjk471Oiqw25znrmrtjY2c95BFfytDbE7TIi7ime/Xp6+1NSRMsFVtzJ3RE9vHb3TIl55iq5UPuysnuARms3TlkdZuJ3z3WQAV1beGIdK1pLfUJTFbvzFdxJvUqejDnp6+1U7zw0dK1SSGbY8TLuilQnZKvUMuD+lO6RMcPOpKKj1Mu2yj4OVbb/EcnrV/Bzz1J61SMIgc7CMY6D61aQnaPqcCudntYVSjDlkbOl6DfapKZLZFS3T/AFtxMSscY9S1dHZKodtM8Lo8s7qRdaow24TvsJ+4vXnqagWw1bWrQXOq3iadoyNkeYgjjA9EjH32qvqeuQ/YjpekRtb6Ypy5f/WXLDu/oPat1FRVzOpKriJ8kdfL7K9X1fkJqF/YaBC9po7Lc3u0rNqJGQp7iIH/ANCrlbUMyOzMS5bLZPNSys88gSKNmkY8KgyfbjvxW34e8IahfROZWit0Dc7jlh/wEVNpT6DhOhhqr55XfcxCdoz0xTVOcjvgnFdhe2vg/QEA1G/W6uMZMYkzj8F/rWXN8RdFsbjGk6Llc43Oqx8emetaLDyZjiM/owfuK5FZaJqV8SLeynYHuRgD8a1n8DaoIvMmltoRwMFiT+grn7n4qa6+9bZba1VhgfKXI/FuK5y+8Va3qIIuNWunGPurJtH5LWiwyW55lbiSq/gSR6TZeBpp2xJfwJzgBUYk/rV+48JeHtOhZtU1bayj7vmqn868YN9cMBuu7ggesrf41WeZS33QSe55NWqMEcM8+xc1bmO41G20M3OLLVEKH7v70NVix8Pm5YCHUIiCOrA+o9K89ZVcc0kReFsxyOh9Vcj+VDowZjTzbEQd7nqreCL9Yty3NsxAGBkjOfwqq3hHVUBlEUTqwGdsgrhY9e1iDHlapeDHbzicfmauQeM/EFuu3+0GcH/nqit/T+tT9XR2Rz6q2uZHUyaFqlu217Gb0yBuqCbTZwjCW2kT/ejIqra/E/WoXVpoLWYjjnKZ/Imt2D4uiR83ejfJgf6qUN+hAqHhux3U+Irq04nHz2xibK8j2pqTHPI49Old3J4p8H6+rR3ES2shPDTx+Xj/AIEOPzNYWpeGP3ok0yUSo4yqMwBI9j3rKVGSNIZnRnLR2Lmi63bT2g0jWSzWDH9zOOXtm9R6r61qW5fQbg6ZrEIv9InG6GaM9B13Rn+lcQ8M9lL5c8Tx88h1xXTeG/EQsw1hqFuL3S5eTAx5jP8AeQ9vpRGXRnQ6fNHnp6+S/NeZBrugGGJtQ06UXmnM3+sX7yezjsawYm2jPIPpXc3mn3GnI+seG7r7VZY/epjJUf3ZE9PesYWmna85Nh5djqHX7K7YjkP+wx6fQ1M4PoOniHF3buu/VeqJXfVfEd+okknu7gj5QTwo+nRRW4/h/SvD9iLvxBdxs3VYQ+F/HHLfhUOr+N9L8OW76d4chjnmC4afOUVu+T/Gf0ry/VdUu9Vuzc3tw88p6M56fQdh7V1xpdZHlY3O5OLpYdcsTpNR8dxQSSR6Rp6JDnAaQbQPcKOT+NYEvinWb63e3lv5hAWy0UJCKfwHX8ayduelNjG2RgevWtEktj56pVlN3bJCx7AU0Kck+tLwKM1RiBFKc9O1J0BNB/nQFwJ7UbR6UnbpR2FMQECmEHtTjj0ooAaQ3rTTuqQ9KbQFxAzA0byOgpaUUahcaWY8kVf0zV7/AEmTfZTlAfvIQGQ/gf6VRpQccjrQOLtsd1a+NLK/UQ6zaRxdArgFkz3Oeq/rV6HRBc6ip0iUSxOpK5bIP415t3NXdJ1m/wBDvVuNPnMTdCpwVb6g1nOlGa1PRwuY1sPJNM7uSbUvD18JYmkt5xwR/Cw9+zCrLLpHiZsxlNN1RuiHiGc/7J/haksvH2m65brZa3bLbykYEnJib3JPK/jxTNV8LNGpk09xcRN8wQEHI7YPeuaVNxPdhj6OJd/hkefuQuO30qA/Mw5pzc0gBFdp8kG3AyKaw+cP2Iwaf1FN6hl7daBXG4wcGjp16UZyMUhyeKBCmkB4o6cZoJxQIBQTTSeBS80BcDSe9H1ooHcM96TgmgvtHNRlxnigRIcAcmm76jJZz7U4J6mgBd2TSjjNGMUUAOz2pv8AEPrQDls0EHI+tAxTgE8CtrRfE2paJIvkS+dbjrbyklD9O6n6ViE/N2oHIwelA4ycXdFs9KBSnjpTecjFMVxDyfxpOj07BxTD94UguNxg0UrdTRtzTC4mM0YzTulNLAUiQI4o4A5qNpM8DNRsXf1oAlaQY5qIyswwBSiLOM08KB2oGQhHYcmn+Wop9FACAccUUtJQIO1HJFFKPegY0DFKaD1o46UBcQjmjpSk4pvegReNJ+FKTntQOlUMTnGaYwz0p5ptIQxvvUpbjIoI+akx7UDGFmNN2E8k1JijtQIYFAPSl+lO7UhoASmkc0vajNAAOKQmg/pSHrQMX1pCaKO9IQHFIaU8UmcjNABnmg4Ao70N0oARjmjPFB6A4oOMUAf/2Q==','จงมุ่งมั่น ในสิ่งที่รัก.....กล้าที่จะเผชิญในสิ่งตนชอบ ','การ ที่เรามารวมตัวกันเพื่อ แลกเปลี่ยน ..ฝีมือ หรือ รู้จัก สมาชิกใหม่ๆๆ และเป็นการ ส่งเสริม กับผู้ที่สนใจ หรือ มีใจรัก ในการพัฒนาฝีมือ ตนเอง ทางก๊วนเรา มิได้หวังสิ่งอื่นใด นอกจาก ความรู้สึกดีๆๆที่จะมีให้กันครับ','2014-05-03 18:37:32','2013-12-11 17:59:05',2,1),(35,'Overhead','089-182-4057',NULL,'','คอร์ท B1 เปิดยาวถึง 18 คอร์ดถ้าคนเยอะ , เล่นกันไปเลย จนหมดแรง ดึกสุดเช้าอีกวัน ยังไม่เลิก ติดต่อคุณไกร 089-182-4057   เปิดให้เล่นทุกระดับ หลากสีสรรที่คอยสลับสับเปลี่ยนมือสร้างความสนุกให้กับเพื่อนๆ','2014-05-03 18:37:35','2013-12-25 11:49:38',2,1),(36,'ทีมนนทบุรี','',NULL,'','','2014-05-08 02:08:45','2013-12-25 12:17:04',2,1),(37,'ราชพฤกษ์ คลับ','',NULL,'','','2014-04-16 04:04:41','2013-12-25 12:21:21',2,1),(38,'GoldRacket','083-171-4355,089-777','data:image/jpg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAIBAQEBAQIBAQECAgICAgQDAgICAgUEBAMEBgUGBgYFBgYGBwkIBgcJBwYGCAsICQoKCgoKBggLDAsKDAkKCgr/2wBDAQICAgICAgUDAwUKBwYHCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgr/wAARCADwAPADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD6oaCQyElz1OeTQIZCOpOferr2vzsAM8/nTvswDZC8dwK/eudWPwblZRSF0yNxwfepBE2ep7d6ufZsnO36UotiScjGDzRzoORvcqCJ8/fP5mlET93P51aFuScnpUqW+9eR07UudD5HsU/JfOQxzThDJ3Y/nVwWrDnGR705rdiPkH19qXOhqDbKQiYcbiMe9WLWN2lCknGanSyGTlfzp627Q/MmPfFcdb2kotnoUJUYSitu7Oi8PDywpxg+tdfasDCDu5ridFudkfzkkk9T2rpbK9Z4CynI718NjYTVV3P0HCSpukuUsajubPzHHbmud1S1Z2ZyMj69K09SvnVN0ZyR2xWRe6gZhzHxVYWM9GicQ4WdzJl8yJ9rZK44zU0NmN4kY4GOKVgsmX2gUkUxXKs2PSvoIufIfPtU+cmkgDsXJPPYGqN9A4lXaxxj1q/E5c5zwaju4i5GKvCSlTroyxsFUwrS3M5YT0DHrTliYD7xzVwW24AY596d9mGOFr3edM+Y5GnYpLCxPJI/Gn+RICRk469at/ZiBkrTxbqP4aOcnlsUVhY4605YZP7x/Orv2buB+dOFtz0pc6BRZREMh/jb8DSiGTHUn861ItHupl3xwkj2q5D4Zbyg052nHArnqY3D0vikjro4DFVvhizBEEnq3H1pRDLnqx6c5rVk0iVXC9R602XT2VyqDNVHFUpWsyJYTEQTbi9DNETgZJP505IpdwG49eauizZRlgafFZtvU8HnkVbqozVOTdjmTaZYgZ5JwfalFtg/d5+lchd+C/it4Amkvvhr4kHiDTzJvfw14rvXMqAyFn+z3+HkX5WYiOdZgSqIrwIONXwf8WfCvirW/wDhELy3vdD8QiGSZvDmu24gu2ijYK8seGaO5iBZAZYHkjBdQWB4rnjiFfllo/62f9PyOh0NLwd1/W6/peZuCHn7h+hpwtge2D9aueRnqO/pSTFLdTIwz6Y61p7SxCg27FMWjngoPYYqSO12nOKlhulmZQinGOc1a+zk9FxkUlVTG6Tjuip9nPUD6U5bcg5Pf0q2Lfrx0Hani39BRzi5GVEgx0FMmh24UflWgLbBxjtTWsy7CT09aipPmi0jWjFRqJyQzT3SPBI7cGtO31NUQqDj2rNeFw2FXGBQIpnzgEfjXgYjBOdR9T6nD5hGNJX0Ld3dvMDsY9OOarpudcSH6ZqSK1kCYI5+tTC3yMqpzmumlgoQp2tqcVTMZzq3voUmhbdhTwaRrRiQwHfnAq8tpkn5efWn/ZBjb/k10xhJRscksRBzuinDEqDB4x3FOaA5JPSm6xrfhzw9NBba5rlray3JP2aCaZRJMeM7F+8/UdAetc78QPinp/gXTo9RvbOG0tpThNS168WxtF+XcMs+XB6fLsB57AHHk47NsrylN4itGL7XvL/wFXf4Hq4LBZhmslGhScvO2n3vT8Tpo7cMu7HT0qnq/iDw94fRRrWsW1qZAfJjmmVXlI7IucufZQTXzv8AEz9t3wxp8z6RonjC41tpLsC3i8J24treWJZEO1ruYs43KrruiUg84Ixx4xeftWfF+91vUviD4L0Kw8JJNtgWa0gSaSZgWG5rq6yxbBPzKqgckYNfDZr4s5bhk44ODm11ei+SV2/nyn2+U+Emc4pqWMtTT2T0f4/opH29feNRa6fHrbaT9i0twpfVteu49PgTcu5RiU+Zu6fKUHUc1gfs6/FDwr+0J8V77wBp3xNXUJtIsxqdxa6HYNbwmDfCoR5JMuW3SHIVgBjkDjP5+eLv2gJdQOo6fN4y1PVNSmEsBv7gs8kkT4Bj86SR5BwDjbkcle5J9s/4ImwXsH7ZHiDSbm3UG+8EXksG9txVPtlo65J6nGOe9fnWI8Ss5zjGQw/tXGMm01F8vR6aPm+Tk+p+kx8I8tyXKauNnG8oJNcyvfVXeumi6pLWx95+OfAV/wCDr9762lM+kyIjb2xvtSVBO4/xJk8N1XvkcjMjtzkE89/rXpbXIbVZLLessaRhJI27lRtPXjqD/KuS8UeET4c/4nGgQmXSuTc26jL2J4OVA6x8nK9U7ZXhf0PhfjSpQgsHmEm47Rm915SfVdpdOumq/J+IOEYVqn1vAxSl9qC2fnFd+669NdHBay+VDyo6etQXWpciMn8aRJRPHuicMjqCrKcgg9CKrzWjuOVP1r7dYecqnMjwXiacKai3YWabbkq/OenpTY5dw3gZPemNExUKQcjsamhtGU85JJ9a3VHlMJV1LYjK+a+AKlitfmXcQeeRUws2DZCnipI4GBAA79c12QlV5LLY82qsP7Xme/4HLiIMdyZxzWZ4w+H3hD4g6M3h7xp4dttRtS4dUuIxmJx92SNhho3U8q6kMp5BB5qv8Lfid4E+KejtqPgrxJbX32cqt5bqxS4tHZQwjuIHAkt5MHmORVcdCAa6G7WdRiLgY5OK6VVhUh3TOF0ZU6ltmeenwx8YPhmJZfBurf8ACY6OjyyjQ9fvNmpwJsBWG2vW+WcArhVuvnZpCXugAANfwV8UfA3xCvJdAsrmWy1q0iWS/wDDurW5tr61BAOWif76AkqJYy8TFTtdgM11hsRIu9pCcisjxf8ACvwb8Q7O3sfGOipeCzuRc6fcK7RXFlOEZRNBNGVkglCsyiSNlYBiM8ms+aUfhenZ/wBafiaKMJfHv3X+Rfj0xFmEqLjjBAq2tqFGFPT3rhodJ+N3wwKR6PK/j3QkSJRa31xDba1bjJDFJjst7wYKYWTyHAV2aaVmAro/h58TvAfxKE0XhjVyL+0GdR0XULd7XULHLMo8+2mCyxAlG2syhXA3KWUglxrxvZ6PsTOhJq61Xf8ArY2PJCgl+OOSaSNraQHDgY65qfUxDFbkSZO48AVQ2qE3Ke2cms62L9k0jqw2X/WINt2LqwD7y8qemKeLbqCKzdM1Mx3gtNww7YCn1NebfsnftyfCf9sTxR448MfC7w74gtG8B6nFZahd6zBbRxXvmNMqS2/lTyO8ZMDkMyqCMYycgJ46jGUISkk5Xsu9tyJZfXSnKKbjHd9r6L7z10WZbqmfWnJZgrkD9Kfe6jpenMY7y8RZAMiBfmkI6ZCLlj+AriviH+0b8Mfhm8q+LfEunaaEjUpJqF8oMjNuwqxx75GxgZyq/eGPbz8x4hyfKv8Aeq8Yvte7+5Xf4HZl2QZvms1HCUZTv2Wn37Hara5GMVX1DUtI0kBdRvo42IJWLO6R8ddqDLN9ADXyH8U/+CnfhKO5ls/hxPqOtzee4tU2DSrUIFQBmZi08pDCU4UoCrJlSQRXzb8Qf24P2h9X1NoLbxYfD8MkzzvF4ct/sko3HGDLzK3AAyX6Dv3/ADnOfF/KcHBrBwc33ei+5b/emfqGQeCXEea1uXEtU9L26/5r7mvM/ST4nfGHw58NNJj1rXtY0rS7VbiLz5tf1BbZmhbdkxRcyuwwDt2DjjrXhvxH/wCClvwk8I3kkOiQ6v4sIhHlHS4hpljI7DAHmSlp2xzllUqccDpj4GtfFmueIdQuGls7m+1S4nLC+Z3lkct13MxLEk4Od3XOQc8ZOsXF5Dq01ktzHFGC250bIYqT1I5Jz6+1flOc+KfEOZRlyVHCL6R0X4a/JuR+05B4G5BgMTGGJjzySv73Xzsr/JrlPprxx+3n8eL20j03w9qWjeDInjZlh0uDdMYxzvlmm8yRjxnKqhP1rxTxb8XNN8S373WpT6zreoPOzTanqNyR5xzkktIZHAPJIwM57AAVyps4k0oRTTfbVvR5iyxspMBDAZYEbhxuGARkkZJxzRll0620wQLA/wBqaU5nQjnjAAIGf1/Cvga+a42s37SW/wDXp+B+rZbwvlGChyUIa33SS+935nba3Mdn4T+IXiPxhrs0V4Ft/I0xhvtLIF4oV2LnKLuJVecn1JY965/xH4ni1HxPNqU8zzNNeCUmVSCce5bPUc8+nJxms23a4sVmEqRpGwLtu53tg/KNwPI3dPz9arGfVtYmXTo281VDRxqsRdsddqgZPX8MnPqa5J4itVioNntU8rwdGq6qjZJdPx8/+GJ/7Q1B9Sk8QWc7W7GYsLp5G3I5GT82Sx4z3Jr64/4IveJ7aP8Abl06e4eI/avDWo2yLArAf6lZOSxJz+7zjvz6AV4n8Mf2Df2nviVOp0z4YXOmWhkA/tLXXWzjAJwMB/mbPGNqtnNen/8ABOvRLr4B/wDBUHwx8O/E91am50zVtW0m9uLeTdG0y2dzGSCcHBYdwOAOnNelleHxFDMcPUnFqLkkm9LtnicT1sDjOHsZRpTjKUaUnZO7SS6n6X+N/jJofhL4v23gnxQjWE2pgtot/cMRbzuZGT7PuPCvwzAHqDxydp7JNRZrhLy2lUFgCRnKyrjoSP0I6H1GRXln/BQGLwUPhtqur/E20lXQdItje3VzZ/vJkcTH5jCSBPGAUZk64Tj5tpHm37L/AO0L4l8PaFp3gn4ia7b+JNEuIPN8NeNrK5MyzW5I5lcgNIFZgHYjzIs5mGAZB+pU+0vk/wBPX8z+XZNJ3X3dfX0/I9/8Q+E006V9X8NQFrZzuutPiXLREnl41HJGckp+K88HnLzxZpdhqltYXcTLb3EEkiai88Kw5VS5QBnEkjbRn5EYAdSK7DTNYfUFS8G2Gdf3ZOd6lscqGHDjPp+hrnfiLoUeh2V54+8N+Hoby7+xzpf6Z53l+crgM5jk2t5bMyru+UhsdNwBr6rKuLcXlOHVCrL92npJpvkXVWWrj5brppa3zmacNYbMqrrU4+/bZNLmfR32T/B9et44tRtLqa2SOxugtzEGWSW2aML9VkCsOSowVzlh6HF37JtcBQRg9a8d/Z8+I/7SPxA8M6L4l+J3hbRtH069tI4LZpNSEl5LcIxaRpmjVlDNFDIWjKR7ZDtJGM17sbZTwU5PWv0XJc1eaqpL3klytc0eV2kr7duqfnufCZpgP7KlCN4tvmT5XzLR/n0a/AzkjB6jPNTJbhyCRjPSrX2NORg809LfbgEd+te/GfKrHiz5ZyujyTx78Avht8RbtNY1vRHtdYtin2PxFo9zJZajbqr7wi3MJWQx7hlomJjfkOrDIrDeD9oz4YTIJI7f4laHvlMzIINO122QLlAF+SzvWLZB5s9q4IEhyD6i4ZgTGep4NZGo2/i1rhhZXKiMjghRmsrRk7p2ff8Arc3XMtHqvP8ArQxfhx8Zfhr8TNSuPDfh7WZLbXbG1judS8MavavZ6pZROSEkltZgsqxsysFk2lH2nazYzXYrboPlzzivkr/goT8YD8ItK8NR+Nv2edT8cRX95LLFqNnew20mk+UY8yQzmRJYZz5g2GJg3B5r0Lw1pP7TfhXQbHxF4J8cN4p0S9hW8Gg+NJVt9Ts4ZIw6wQ30SkSbM7QlwjuxPz3IxmsIY6Mq8qF7yja9ul9v6TfodE8DJUI1doy2v1t5/wCaR7qtvg4HP0rA8f8Awe8DfE6CI+KdJYXloCdO1iwupLW/sSWViYLqFlliyVXcFYK4G1wykg+U2v7Y/wAMvDOnmf4ufEKP4e30NsJ7rRPHzLZTKD1WJyWhvMHgm1lmUHjOeK8t+KH/AAWY+Ffhx59N+DXgbUfG84gBttU2Np2nSMTjh5QZztOSf3Kgjo3escdmuXYGnzYmrGK83r92/wCBWFyvH4mpy4eDb7pafft+J79qsPx2+G8hfVIH+IOgIs0kl1ZQw2uuWwyCimBQlvejBfLRm3dQqhYpmYkJa/GP4W6no93q9r8QNOijsbv7JqMN9N9mnsbjYsn2eeCYLJBNsZX8uRVbaynGCCfzv+LP/BQb9v744eIbTTNJ8XQ+BtDntd09p4UtBbyyxkr8xuZmeZWwSMo0Y74rb/bL1i40H4FfBCzsxLb69d/DWxvdU8SRlhqs8ssSs4e6YeZPHvLMY3d4y5yUJVdv51n/AIj5fgcPKWEi6jS3lor7L+89d72P0rhLw7zLOcyp4WtNU+Z7LeyTb6WWi0tdH2f4m+Onw20Pw6fGL+KbX7O0DS2s0t2sCzDHy7N3zOTkcKM45r5z0v8Abl8AfBeDXp/A9pNrWsa3r66gGSyWwtWBaSRonZW80xqXARCXyu7JBJB+LG+I/jPTUtv7ZN5rYiO2W+STE5XGMvF0bGOTHjO4ARADJuWvjTSNb077Xpzxy/Oy+ZGwyp7qw6q4zgggEdMZr8Jz/jbirOakZ1anLGN7Kn7qXMrPVe9ZrRqTZ/S/DnhTwplUJU5wc5ytfn1b5XdeWm942+8+mviZ+0z8Qddt1vvE/wAU10qxv5oJ7/RfDMjxXAhkyWUlhnzQh+821SMAE14p4w+I3g6++16b4d0u6Y3CDOq6tMJLqYq7Y52kouCBgMc7ec5zXJnUY1Y3cpR3kdxJcSOSRuA2gAnPGDzz16VR1GeGW732zMi7f4Hz9PvD+lfPVcVWqQ1l/X9dkfaZdkmGwVVxVOyWuiSWmystX827/caX9t6np8sdreSLFDsVoylqEkYcN97G7o3Bz0xiqVzcwzX8l+IfkkdvunAVjyBk5PBI7k8e9TSPqeq3Ky3srZVFRcnc+0KAOB7D0Fd58GP2b/ib8dp5W8Ix2sFhDcJHdajqN6Vjt3PO4pHvkYBeTtQ/ma54Qq4iahTi2/LU9R1MJgU6tSUY99Ul/wAP97Z51pd7eJefbLa7nEzIys8EpQnOc8jHXP6UsSLc3SQRxvNLJtRcuSc5wB159Bz+Fej/ABj/AGdvFHwH8d6XoK+JLPWxrM7RWF7pO/aLmOZUeJ1kVGDAspKsOVlXvkD1D9vn9mPwd8CdH8Lat4J8OSWsl1eXdrqsktw0jXMm1GjlKs5Kt/rB8oCA4wM5rqeW4pUqknpyWuvX8PP0MFnOBljKSjr7VPla68qu77PfRefTqeK+C/hf8TviPYz+IND8H6rqOj6c6xXeorAwt7QZAAPG3OCDjOeefWt6L9nDxt4l+EuqfHnT57J9FtNWWyWztI3+0SXDypGoWMIFRd0igc5/2elfWvxO/aW8G/sPaJ4O/Zp8KfDmWC3uvBkUuv6zcIDcCXfIWmhRJAu6SeN/vnoFO0DO7R/Yf8Oab8ZP2cPFh8PeG10/S9S+Jcl/baXcXSNHBHBJb3kSfKBuKMEUEnBB6Hkj2KWS4WVZYbn5qnK7rtK2lvLU+Zr8Q42lB45U+SlzRUdvei5Pmb7SdtLbLfueOeKP2Yvgv+z78SfCXws+KOpX+pzayPtuvw3erbLaGBbZxHtihBdm8/IXLbiqMuF8zjr/ANpf9on9mH4Tr4l+CP7PXwvv0cyyQxxafpcNnBarvVhvZi88zLtU4c4yOpySc3xX4e8WaT/wVb8J6b4ynt7qLVtRsjZCaMeWlr5RVUIRRnDox4zk89SRVn9vf9qDwHoms+Of2d/CPwekk1K9JttW1V1jijgnBileeFYAGmYIpQtKSoDMcEhWrqtSw2EruHLTSm4q8bydo7J+fzOKEcTjcfhVV5q3NBTdpcsU3LWTW3u7WVm0rHpNn+398QPG/wCzJ4z+Ovwx8H2fhzU/DV39msmu5I7xGVxAsjOHjO6RhckYyNgTIyTg/K/7FfxA17xl/wAFGPh58RPF9wt3qeueOYm1G7iiSNZJrgsjEIoCqCZP4QB1wK7b9mKz8TXX/BNf4v2GmWQXTbfUjPe3IDgnEdoQhOMHBXOBznk8V47+xNqMelftc/C3U/srhYPiBo7MwXcFT7ZEGJ/D8ua58TjcTWxWClOTafLLsr8zV7bdEjtoZTgcLluaU6UUmlOF+tvZp2b1e7bt5+Z+sX/BSLwvqniT9mf4h2NjfLb3EXhLVbq0RH5Dx2fynb/EPmJwRjIH1r57/wCCR/wMksPgfe33jhje/wBuxLejTZQWs7QmJ0LQxMSImZZGVnHzMAATgAD7L/as0eLW/hf4v0eKVQLzwrqEDRhRgu9nJGvbueK8H/4JuTSz/A3wzcPDtWTQZInj6EMshTkdsYPFfolnez2/4c/mhu0o/wBdv8zQ0afxj+zVLB4R8SanFqnheS+S2s71pj9rtWYBgQNuCCQ6+Xk4CLsIyEPrsOpW+t6M19p13HNbXEYeC5jIaOZD3BHXNeY/t1+L5PAv7MHivx3pmk2dxf6Ro82oQR6khaBhbzQtIkmCCAUZl3AggZIIODXkP7Df7Q9j8UfhbdfFz4ZaZeR+GzcOPEWh6gWD6deLgzLHJKVjkUqUKTxfI6kiVUkUvUuPuuMtV/W/l5/f0LUkpK27/rT/AC+7qfQmp+HH0VL7V/DkISYKTcWHnER3C7HUyoOglCueRjdwrEjaR1fh3X9G8WWLanol2JY0naGZCMPBKuN0br1VxkZB9QehBrz/AEf4r+CfH1gh8O6t9qjvBIttO8DeXIUA8xGAwVdQfmU4IrevLHUbU2Pj7Qbm3tdTuLOH7TCVbyNTjCnbHKQDgjd8kmNyn+8pKV9Hw1xBPJcRKlU96k7ebjvqvLuvmuz8HP8AI6ebUVUp6VFf0e2j/R/J912f2cj+HP0pTFHEA0jAD3ql4H8aaF4/0c6tocrK0b+VeWc4xNaSjBMbr2POQRlWBDKSpBNrUbG8n+aMEEHgZGK/XKeKp16SqUmnF6p9GfmLwrpVnTqqzWjXU5cou8gk9xR5SEYJ718o+OP+CpnwS8M6j/Yfgq41LxdftsFu+mWbRWrM5+XdNKqkr/tIsn414F8cf+CkH7aHjnSUtPhVbaX4Nhkn2XVzYWwvblIyCD+8nTavbkRoQehr5/HcV5HgHyzrKT7R1/Hb8T38Lw1m2L96NPlXeWn4b/ge1/8ABX/QbTXPh14S0qfVLqy827vWjurWYo8ZRrRs+jDggqQQQcEVa8Rf8FOv2WPhL4NsfA/wY0PWvGcWj2aWVq1tbPa2ipAgT5ri4QM+QOGjjkB65wQa+KZpfGdxpN9qPjnxXq+uapcW0f2u/wBa1CS5nY/OQC8jMcfM2OcVqaD4TudK8N2ul2jQrHKMyFcO0TOcsGf14x1r4TMeMq2HqPF4SKTq6Lm1aUdNOl3o+q0PsMFwvRrU1hsTK6p66aXcu/XT5HW/tQftL+OP24PB198NvF3gDRdJ8ISzx3EGnW8JmnkkjkwvmyscOBlmwI0wQp6815Dq/wAHfFHw3FoPg1qMt9CrgS6Jr6vc2yoFxiK5/wBbb5xn5jKi9kFepeH/AAvZ6PA0VzGxDOhRTLnJLbvu55HA4rYm1G0VCttbGMdH3DnHAOAc7R17fjXwOYZ5mGY4p1a8+d+e1vTb7j7DB5Vg8Bh1Sox5V5b/AH/5nhejz67J4kis/jVqTeCrq6gUKl0ENncjO3bHeKTCXJAxGzrKRg+XivpX/gp54es/DM/wi8GQW8kraT8KtNjYNICI0BeIhscDJRT2HP58nrI0/VdGurXUNMW8tZoWjnhvAHikQqcqynIII7HFRf8ABTP9m20+Fn7QHhXwZ8FJ7/S4dY8KWMltotzcyXmn7pbmeNUtYHI+xRkqB5Vu0cQYM2w7jnxcyqQrYGd/denpuu2vTz9T7bgilOHEVPlV1yyem9rWe7S6+R4Ro1pp15C0V7eeUzQkxhYmIZ+yn2zxntkV0nw1/Y/+K37RGt3Vh8HPAGp6nqthbKby907ZEI4gSV3yyFYm6nEb7sk8LmvoWPxH+yT+zP4P8Qfsw/tL+BNF0HxbY6M51Xxp5X9qac8oYkyW96sKTwy8IyrLFCigkDf1Ojo/xs8Sfsk/sYeBdU8P6Wkt78Qbm6vbi7kuPMRYs7DPFCPlDGIwKrNvztb5QCK8iOTywdZSr1PcSblyu7TTS5eq3fofqtXiKWY0nHCUm5yklBTVk04t86WjtZN7p7O+58zeC/gJ8RJ5PGh+IVhdWg8AWMlzrIs9H86aGRGk2xTWhcPj5MM0Ql7sUVenqf8AwTD+FnwX+Onxl15Pi9Ypq/hzSvCl1qC/Zp2ZUkjlijDkI6h9vmcoTg4IwTgH6H8afD/U9E+I/wAarm2064FzN8Lba81CS6uB5ihrS8jeR8KASQgGBnge9eA/8E1fhMPHvxg8Yy+GJtQ03VU8CXTR32lTxKHeSe2iU3KzI1vNHllGZhhM7kZGAYdlLBYWjmNCnKOrcr3V07N2uunnb7jirZrmGJyXFVIztFRp2s7OPMk3aW730vr3fft/23/h/wDs+3/wI0b4zfs9+H7C3shrL2LX+iaWkFrdWcivjflVfzUlijb50Dfv2U4Cjc/9iHwj8SPiB+yr8Tofhfq66TqralDHaXsMjWxR3RMAMqlgNqtlgeAcd686bxj4n+H3/BNK38I/E7wNcLpXiPxet1oXizSgZYT5DzCSOSEyAwlnUkFROu2MsZI+UPUfsWfFLxD4V/Yv+JviP4Z6sYtQgu4L+z1WzuM+VGqKRJHg4IJCjOCMZHTNaXisxhVlG0ZU23y6K/K9vlqc6p/8JVWlCV5wrKK59W0px37q902rrTTodN8e4rm8+N3wN/Ztks7OTWPBiwz6hc28YXc7LbyMzqMnMgtDMQe0ue+a7n9rbwz8R/Gv7HHjDxF410Z1/wCEb+KMmp6MZpC0ktjtgjE8Y8wkRsJX6rkbeoBNdF440r4e+Ofjf8OP2stZ+IFnbDUPCc13qOpandx20SPcQKbZTlVWONDLcoR0Gwjsa8Kn/wCCg/8AwtDwT4+8LfGbRre2h1PQW0/QY9F0wu7LskiWRzNKQpBMZ3KR04XHA6MVPD4dVo1p29pdR7WUFyt+mnzOXBUsbinh5YanpS5XLe6k6j5lHbfXTovU7b9rz9nzW/2kv2n/AAJr+j6VeXnhaXwhFZ6rqluyhIBBLPIQrKG8sMJk2hhlmLHpnFTwj4oj+Bn7B/xi8I/DDxVJMdH+I1za6fqDzLHcNFIthAzptKlmARzlVwCFOeleWeE/+ChvxT8IfBe0+EsehWV1cabCbew1m7mkJtowuBiAEJI4XHzMD/q1yPvBvEtP+IHjyPQrrwFY+JrtdIv783V3pq3BCXUuF+d1BO8jYpG7IBGeteVWzbBKrKtQTc5xd3tZuKVl6PU9+hkeaTwscPinFUqTjyq/xKMnJt9m1p08z7R+M3xd+HXiyw+BP7Sep+IdPt77Trm2m19LiRfOdWjVJSY2JMoilifBC4AlPPOTnfFj9vj4E6f4b8R6H8O9Pe8uvEej3ljeXtvpKxmUzxPEXmkk8tnO1sBthOBjjAr4kMP2mGUT3RDW8Q2q4GX56cn0Pv0p+oraW0mXmAUxqVw2WHtziuWpnuLk5OmknK13vqklfyvY7KPC+Ww5I15ylyXslorOXMk927N9zrvAf7RfxE+H/wAIPEPwO8PXcCaD4mlEuqwyrKzOcKudu8J0UclCRgEHpVD4LeMYPBfxX8NeKZbcEWOv2Vy0agMxRLhHPH0WuUkn05UiS1tyWPzTSSt1OenHGP8AH2ybK6pc2Uv9oW2yKSJD5RVRgY/3icV58K9T2tNzbajay7K9z28XhaM8PW9lTs5p3fVu1rvd/wDAR+8v7S3xF8EeCLy00DxyqJba3b+UuNrscsUOIs75ANwJ2q20DJAGSPM/2WvB+r+DbmDS1uop7NInZHiYGN98m7zEIPAOXJGSCTkEjBPqfx9+HvgL4z+B4LPxvoCXcdxZReU8ZxLDu+cMjHG0g4Ofavl/w7afFv8AYZ8Qf2jay3Pin4fXt+slzdajqTE6TCyhSoTy2df3mG3biPnbcMKCv69JTVZSeiT38nbc/j1JOnb+vkezftmeHLPxf+yH8RdNuIFlE/gnVI1jGCGDWkhweufu159+w5pHh/wX8FvDXhPT9IWJLvQre4hjSFfLCv5Sup9CRKrY9FJ7GvUx4y8EfHP4QatpWkX8csOr6NNA9spBaKOaKRFLAdirZBHynIIJ615X+zwtrpXwq0zw9qM+y90vQ4oxvYo0qwxhgyHuD9nJPP8AAR0rSpOPPbvYzUZaNef6EPiC78G/DH4lJF4H09LddV1JDJo0cfkM0vkIrsm/oRG8eV+UqA7KHAda9m+Hnivw74q8EWItJnYRWcSTwSgq8PyAq3bCkcq3Q445BA+Zf+Cm3wp1Lxd8QvhdeadcSWUVp42s5pry24flnYqrDlGJiQbs9CcA849R0PQbmy8PaRrvgrXrSz1uDS2VBKqyNqT/ALwkyfOvmFmGSW4feT8rKGHPQn7Oq0/T+v69DeouaN0db4r0fxP4P8Sp458O3YXbFHDG+MpKgkJMNwvUod7MHGCjfMP4lk7vwB4/0X4g2c/2NGtdQsJBFq2lTsDNaSEZGccOjDlJFyrjkHggcZ8PPibo/jCKTQb+zaO7YOLrTJ4ywIBw+3cPmUE4KkBlyFYDK7qPxQ8M6npUEPxG+HmoyWWpaRblrW+tF80yQKpb7LNFyLiFyAuD8ylt6FXAavqsnzutk8nd81J6tdvNefddfU+ezTJqWapOOlRbPv5P/Pp6H5LaN4e0+1nV0TZIir5fl5XhACSODnnHp+taunC3uNGRLSykMRnA3SyFV2464znHfHfNaOl6I9rceZNGMFTiKMbm5/vEcA4A6+tX4dLkls4rWLTUt44T+7L4545IXoPzr81nUu9z7qMNDnPF08VtpEiyQsB5ARFAGBzjjH410/gjw9/wj/h9LK68tDJczyrEiMMiSd5QeTuz83r+FcR8S9Us9Pu47O+8T2cUp27/ADblEHD5I+Y5GAM85Nd1q3xM+GNhcR20fxA0BUKBmU6vANysNykfNyMEckcjHrXpZjGby3DRSe0n+RwYGcfrddt9V+po3El2JmW0sSoRBiZ+Bg+3UfiKy5bYT3ObuUtIG2kOxwvuOoz+RpjfEr4ZTwolx8S9C9Uij1SDj/x/APWmp4z+HV1cJPbePNH4bC7tXhJx6cNk9fU14qjUX2X9zPTcoPqX0sLFrGVd7BSh6lgM4POTyc/Wvaf+ChSr48/4KPfCDwubeKNrjTvD1mxuWEaFX1acbnJB2j5+vOBzz0rxa08ZeAYkP/FSWUjNJ83l3CsDnjBIzVr/AIKafHXwX4m/bHs/Gvw38Ui6h0XQdOXT7y0s5Cgmgd3GAyno3Pftz3rmx3PHByk4uylH8G3+h9dwQoVM9cFJJunU183ypfme2aP4U+Eniz9tX4n+B/Hnhmy1bxXPfWVz4fn1LTHlKWcNirSSKWZ1TIWMfePJG04BFeY+KP2PNF/aC/Zk+F2u/AZF8N6jpWoyReLJo752sJ0MnlO7WRPkI26HLNH5c0pcZfjif4i/8FVvhxD4RufEvwk8Cavo/jvVLIw3OqweHZIvspJ+fEqqzzgFpCqbUX5gSPlKn50+HH7b/wAVPhP4I1P4feDvGWrJpF3cG5a0u/B09ygucgeYnmQNsbBJ3c4IyBk5qqmMw1Obpxi5xlzN2j3kpRTvu1Z38rI+0o4DG16cK0pqnOHs1FSn/LBwk1y6xTumkuqbPqOD463bfH74oeEPjjDDcaLd+EbDStd8W+B7S5ns4IwJJG822ZWu4GzKVYKs8UbxuWlwEJseGvjB+xf+y98Y7fVfgp4rsb7wzqHgOW21ebQ9QXVP7Rujf2dzFG8iSTqOIcnBjA2bcKTk/C8fj201S4P2yTXJGvJfMu3k0a8PmOSfmYtFycnqfU81V1aDwjqutXWp2+ja7o1/czoz3WlaPJDI21TgSpKm2YAYH70Njkgg81zf2nVqLmdHlmm2pWb3bdrdF3s/l23nk9PDVFD6zz0nFKUU0m+WKjfs31Sa0/mva/0L+2H+1B4X+Ot7pHh74a+D7vQvD2jISLe7uVZ7icjBbanyxqPmAGSfnYnGdo8Z0fW/GPhvTtX0PwB4pv8AQovECLFrUOl/LFqS8fu54/uyA9MjD44Dij4S+KfBGmeONLsfjx4W1jU/DIjuZtU1nw5YPb3KgQu0UbW7BiRvWNWaIux3ErFyBWx8GvjRoXhD4o6f8UfhtY3l5FoOqJdoWVUeAByQjqzbon2FR8+1lPYHFebWWPdf6zOorSdm42slp000t0drnu4atk8cGsJTw75oK8VNNNu71Utdbq91tdWOTvp/G3hjRrXUPidot3a2BlltbPVgjm1MkQiMkZVvmgKrNEx3DYokX94eav294JAt9Jl4ygKsrfK4IJBBHBHevUv2qf2sfE/7Snj228X654Jkt0tIGS1tftazkM235pJnkDSuVSJSQFwsargYzXh15o+oF5bjw3pNzpF07SH7NAtu1rJKcsXkhMwySxLMylGYk5bmuXE0sJKvJQlpfRvZ+drtr8fRHfhcbj/qqlUpPa7SvzLyTaUZer5e92eheAvhv4w+I9/LaeBfBGoa3NAoeVLSIv5YOeXK5C5xx+lZtwLvSrm6srrbaSorRSRfx5DYKHI3D8R7V6//AMEy/wBta0/Zj+ONgvjj4MzrcX+pltJ8RyapYpa6bKlvMvmPJcOsW0iQECVogrhfmbG1+T1v4VfEv4sfEjxb460vway6X/wmtxaT6pq2q2FrbSXcszskIk8/a7sDnCZwD1wRW88qawdOpTfNOTkmtLK1tnfXz7HFTzq+Z1qGITjThGLTd7ty6NW01Wl9X00OGls1hiWNrIjzZgrO0bGSNVHOASAc7gT9B0rM8h97NcxDEmQCOpGcjB578V1Pjvw/8S/C3i7VPBnjL4czwX9kRLe7buEwxq0QZSrCQ5BV0xk5xxXI215rslyJIdCiiZZREZHvk78Y4BAHv0wetcM6FWm7adt16dz1cJmOGrJqzeie0nvqnttsOxCqsqRGRw339vygVYSWdpVWOJy20AE9sj6fSl1ix8aWkL2dz4fsI2tF3S41ZMMpK/3YyCQWwe/QcYqOWbxPqeox/wBg+F7SF1iSPH9pyfeAOWb9x698/h2C+r1JaaX9V/mbvMcMo3inbV3s7Lbd27arQ/oC0O/i1n4K+HNUyuL3wtYzB4yON8ULZ/8AHq+QvCP/AAUW8LwftTeKP2UfjtokNpjxS2leHNasY2mgufMCmK2uYvmZHIZVDjKHdlggBY9T4J/4KK/s1+Cf2UvBvh34hfGjwVpevW/gnTbS+04+I5J7mK4FrDlTCltuDAqQR1BBHUV8jfsv+KvBn7QH/BRn4h/Fj4e+Gwt8sWmXepXOoWEwFrII44mwJRCxD7VZWCkncCVUDNftcI1FDmlHS3X5H8cYmUI1nGMtVK2nzPq34qfs16v8MPHkHxZ+AV5dWZi3mbQhfSLaOjPHJI0QJKJJuVjhgQQ8gxlgRq/s/fHD4c+PLuXw1qsS6Pr3ntaz6VcxtE3nSQyBkUNwThz8pyD/AAlypNe9BBqtvNbX+mBImdk8qVlYSoOjHGcZ64PIrwT4m+APgX8dPF15oHhLX1tvF/hq5NpqN7prAXNm42MIrlCP3kbgIRuBUhVIztFclXDyhK61S6dvQ0jUjJa7/n6k/wC1Xod94zj0O61C9MclreQywwsWKq2/dj68xrnAzyT1rG1bT5J/hpDM2sGxMN20kDWsWbjd5qnJD7mUANIw2AA5Prhvmv8AbV/aY/as/Z60zRfAt1rMj6iJbezuNe1Qo0Nwg8qM3e/yXRgRuZl8oyI395c7eG+DL/G3xz49i8GfF79pW58KuJTNp0FukuoWl35pKrseO4gt/LcDcsyxSRP/ALKsN3kVMPVrTdSDSTul36dO52wrQppRkr2t/XofRPwhsPH/APwl2t6B478fywNbarN/wh+vFv36yq7KkEkhD/u+RtZgXC7lLFAqV9G/DH4sajql4ngv4oaX/ZOusmyWzlkRkvE2sQ6GMsFcqOUJ5GSucMB8/HUofAVpdad4++IOmSLa6iLGaeQxLJOWSNlk2gruaQyxkKgyG3bQRwlv48X3idfGXwY8D+HNMbVNN8T6VewXOoR3AWfTXtXtQl4lwMhlBlXdGciTAKFGAkHdl+JqybpVdfPvp+D/AD623OfF0qUV7Wnp5dtfy/Lp2Pltlv0RbaC0YAkldoC4A9+v6mpba3Yp837xwBuSMk4PuVH8xUW2eaTAZmZDjDtn+WQP0q00V2wDM6w7eAm4c/z/AEIr5vyR7aWp5N8Yvhh8PL7VLu7Pg3S1fUmgF+y2cQ88+axLMQPmY55J5PfpXqqpZ6PZJaW0KwWsSgRIpVI0HoAOMdeAcVwnxQXbr0MTN5haW3yu455kPTJJ/WvR20aabCy2QjUjJaUnIAHfkN/OvazTXBYVyf2X+h5eX6YnEW/m/wAzM0/yyrS20KAu2Y7rGWOewZu3sDV6Nbud0E0rBgSoA4B469Bn9farNrpKmZLO5uUVjgnykBKjgDrj19DWla6Lo3EVvaSTsG/1t3cMqgH/AGRhccHqCc4rwpTSPWRQ8M2tq/irTYL+fyzJfR/xA4HmKM4Bzjv+dZ//AAVOhvPDn7aniXSNSv1uXttI0uNZEgMYC/ZI2xhmJP3uvv0HSvRfAdxax/E3QbKIww2beIbOOVmQbSnnoMgjAI9v1NeYf8FaZJtQ/wCCg3xBt40aTyH0qLAIGB/ZlocdB3NcGaO+WS/xR/8Abj7rw8jfiJu+1OX/AKVTPBG16Oe3FnNYwlVBYAtkA7cfn3B9az4khlEt+0uAjgpG8hO4segAXjj8OKbNANhiaNQVIUHHTnJJPfikkkkkJhaQMVxjg9Og7cDHb3r5aMuVWP2z2MW7x0/q/wDX9McsEDofMWSJJSHxwdwHBOSfrUtykBhaa2DzPINpeWVmeMAj524I5AIAycZz6VNo2lNca5Y2V3aTXKXFxHH5EMwRmDEAKGwdpOe/T3r7d+Of7Ovg3w9+zd8Q9ck0HwyItG1HS7jw4dP0qNbrTYWnELpNKFRpN/kzHc25iS3ABBHoYXBVMXSqTi/hV/uTf6f1ueVj81pZfiKMKl3ztJdtWo+b3ave2i+R8d2vwH+L1xoU3iUfDfXksLPTzqFzfy6TKkK24z+93uAGXjgjrW98Nv2Ll+O+jaf4x1fX7TQob/xBBo+l6sDMt3JcMHdQotlZxCCuGZ/3Y5BDcgfZX7Rfj2OHXPiZ8O9W8ZRCyHwvUaDpV6qW13A00bloJTmXzZnZU2orgqqqoC8hvPP2Sf8AgoJ8Of2df2frbwX4h8RC11bSbu7WPS7GAvNdJK3mo7qucDfI6AcEbSQDkZ+gwmSwjj1GPM4pO7Se6draPb5/5HyeZcUSnlcp1eRSbjaLklpKN7rmW6dlt6dz5i174O6p+zb8S/F3g/47GDxl/wAIu4hh07TtYOmX12z7GSSPdCYp1CMCy7rdl3A4faQfob9nLwL8CdT/AGk9V8J/CL4fza3fS/DO18QaX4J8U2L/AG63uXAkeIRXcat8yDKTsuwhiys0fzHwj9pX45eAvib+0pqnxQ0rwB4gvNGvL60km0j+z/7PkeOOGFHR2mZPLL7HJK7z8xIGag+Mf7SHiz4v+PrLUY/hf4b8O2On+CU0LSLu2ku7q4tbeKbcPLlLQyxTFJCjSxyhtoI53sa2pYfCUq0/rHs4KMtGnFysm9XFX6WsrLVXsznxOYY3E4WH1H21WVSC5ouM1BSajZRnLlXxJtvmlo2rpH1P43tbOz8efsz+IrzTQkWuwTynTbUR+QiGaOIwxCMtgBw6AFRuCjqCK474eaH4T+B/x98f+CvGV7ZeD/DF/wCLp9c8P6N4m0231Dw3HDG12iF4Cym0kaGVRHLblCHQM6OVVa+YvEvxI+MPiyw8P6L4g+LfiS80rwrZvbaBpTXESRWcbymSRI5I0WWNWZsnD7ieWck5rjYp/Bdxr0mtX0luNQhflry8MssTHoA0rsQeoyCfqeamOPy6hUdSnKU7NNqMfdfuqLT5tbXV17vbqP8AsfOsXS9jXp06LaaTnP3lecpxcVC6uk7P37vXoeuftZftK+EPil8fNe8T+GfFNlcrefY1vE8KXFzqNlc3KQpEzQSCBHZCVwPOjic8ZUcGvOo/EF7M0Y8PeELveJFdJNWuYrNQw7nBmfHGcFB9Ksabr9lqtxczSSSX2wq11IiswwwxuyCA3XrnqACeaoTrr6QGfSNNjQsNqw3c5UAE5B+RWz3GNw615WJxmHlipzWGUZN399ydr67XiuvVM97AZVjFgoQeOc4xXLejGCu4+67tqburWdnFp39FabUfiJqkrb9e07TXk5uRbae124Gc48ycspHT/llj2qGbwjZaq0cuu+LdcvpApMttcX7JC3PUxxFIyuMcFa52bxn490fxvZ+D9T06azW6E8LaqbGKOGQbcgR5ll+ZgcDcA2c/LkA10baNocD+eYDLjaEa8zKwbHzHJzgZyeMdvrTxGKzDCcq9qoqSuvZqK021cUu3W77kYHK8nzH2ko4dzlTfK3Wcpe8kndRnzO2qaaST6O2p+mf/AAT6h8I/C/4LeGfFfw3/AGV9Q169vvDksUl/4M8J2sImuIxhjJezmCAucNndKWyCME8HW8P+D9Y0P/gpR468QXfhyw0y28R+AbSf/R7vzZ5pYZIkDyKIwikouDhn+71OePYv+CZN1JqP/BOv4azSyfNHa6hGz+y6jeKAfwx+laviv4eWMnxQg+LWn6XFc6pBpslg8Ec5V57cgMFDH5N2TkBsZz98Div0qhUlPCQmusV66o/m7N6Hsc1r0r/DUkuy0l0XQ2fC/i65W2ml1pWgU6ncxQiY84WQhck4xuHzDttxyM8fCfhT4T+JPEv/AAVy+IvxiXxde2un+H9U02SO0sJHg+1LLp0SPFMVI8xBLGW2kEZHcYr76uNEtNY0gG2hKFpBOolJ3KxGfmB6HkgjFfP2n+CofDn7ZXjuO0tU8rVtA0m9VdvBVd8B4+oq6kqkbW+T+7/I4GouNvM6H47/AAv8J/Gm0h0nXdLiu7b7C0rR3EYYMr4IJ/ukEA5Hqa/PP9ov4AfEn9mTxtFeeF5L/WfD1laX11plqZGCWMnkvLseNTgqWRWLKPm2fOrZyP1Qv/Bltqfg240YWcSyXGmSwu6c5LqVOM9vavz/AP8Agnvpnxb+L/wwksfjL4mkvYLG7aHQYZPmms4oxJDJGZmGXUn7oP3RgZxxXHKm4tvq/uf/AAx1Konbt+Wx2H7L37K+hfGLSbiDxZ8T9RGl3YtxLp1tBBb3ekywuqbIi7TKRkFd+F3I/wB3JBH0T4j+Fvhr4TXnw88MeHZtRu7LSotStrW51a/e7upWnMc5Z5ZCWY5gPsBgAAAAcgnwH8T+GNEuPF37P11DpuszSNc3li1hJb216WMLMuJtxViIxjjYd2SMgEW7f9oIfF9dN8H+JdDuPDvjDSpnlltp4wgSXa0exVLFuQxOOUYbtrtg40p8tCm9LO9/672+8zqKVRrW/wDX9eR8kDSbxyr6hdRxYUZG/kDqfTHHuRVs2GnxorWkDSsG+Zy55P8A47+uelOu7eFIoHtLLeChDPJIcdsHCqRn6kVctrXbYKs1uCVP3vTB9Dke/NfJu7Suz6C66HkvxJa3fxja28MQUvc2qL5eAB+89hXtGnwQ28U0MqoX3sh2ks5XgYAxnpmvAPjR488HeG/inZ6HqPiSxhl+020mHuUBiVWV/mAY7eOmcZ7V6rafGPwBrMUs3hHxX/bbISJ4/D9jPqSg+m61jlXrxyRjvX0OaYatVweF5ItpR+7Y8XAVqcK9fmdryZ0Umk3c1+Z7PICRrubgbccDkZ5qGC51KO8MupXxT5iIyACAMev58e9ZFl418S6jZGXw38LfEl3vbK3Gpy2tlH09ZZ3lAzn/AJZDiq8Vr8bvEMrzX2ieFdKiLcyy6ldasVHHJVFtkHB/vEcfjXjvCStacor53/8ASbs9JYiLd4xb+VvzseofBfTbW5+MvhSS9mjuEPiSyXyy4bINzHuUgZ4OBkfnXjX/AAUiu9S8S/tv/EHxRZaVcxQXN1ZhcxyFNsWm2qAA7QTkr+GQDiuz+C/gfxZ4p+Knhvw9rPxo1Ga1l120huI/Bum2tmYYzKoJWSJJrhWGeCJFII4IOK8E/bb8B+DvBn7VPjXwJovh3xDfWWlX0SQzeLbye5uZpGgikd3N7K8oyzkjgcYwMGuPMMPg4Zc1Um37y+FeUusmvy+R9rwHWx889l7CEf4bT5m9FzQ1tFO+ttLpeelnxlrdeB9PhlvfEPi3T1dFbFglyhnZiOCY0YuMf7vXsayrbxtoc0U1rpOla1qDO/7pbTRZEA9PmuPJB+oyKh0231Kyt2SLTrGxiP3FtlaROuOwjA59DVuHR9Tjci81G6IcB3SCRV2jj23Ln13V4Snl9PSNC7X802//AEhR/M/V50c2qTcqmN5b9IU4xtbt7SVT5vlu/Qms/EXxCuJE1HQvBMen3FtOs63er6spAcNkN5MMfJyP+eh6Vq+K/it8XPFc2sW+tfHt2h8RXK3PiOw0LTYrcXNxktukjeS48zDZIIVeTnFYdnoNs0Uiv5cyof3k1/M0oGe25888nj2qwklhYRKI7uKNPMOxIQMH2OQOP8TWn9rYmndUIxgn2ir/AHvmfluccshwFWzxNSdVrvObXR/DHkjvrblPf/2Zf+Cdtj+0d4EsviT8RPFPjG88OSKzXcs1s0iRDzXiwBdXEUW/K7tqxHPIB6ivn6x069sNKGleF9K0nSbEwrJPb2K7I5HUfedE2q8gDdm74HevSPhN+1n8X/gj4K1Hwd8OfEv2Kzv7lLm4L2UMzhwNuUMqOI+B1AyfWvLIJrxpHlW3yGP3GPQHByP/AK1Xj8yWLw1NXk5Je9zSb10ta7t+C3HkORfU8bWqKMIwuuXlhGLtre+l76rW72WxLPBqIt1jl1ht5OW+yWyxD8AdxH5//WWPSbKUmWT7QV2FCZLqU+hx97H8JqayuGS582VkgRcB5XUvtUtt+76gZOM9vWqdxdQpOypdO24nc7KFyCcjqSSeuf6148HUaunZ+X/APqqkcM3yNaab3fn6fnfr56Bi0UWQ023tolhI2tFgsp7HOSf4eOD0H1pg0mxutHk0670xDbm5juFhBARGTO1iuMFhuwCSOpHeqMElpvC2jOrnkh23fpxXQ+FfBHjLxlfx6L4U8K6prl5cHENtpWnyXDs2emxASSPxxmqviHO6k2/V3OSo8uoQceRcum8Ulp0d7K3qcZpfgZvhxqsuseC7eKaLUAH1DTbmUSSSYBVdsrsSuAGwjkg5GGTOTs2eo2uuwHU9PmERiYieEoyPGd2MMvG0+meowRkEGvoL4ef8E7f2tvG101vcfs/6xpzXCyRWx16ZNOCv/wAs/ln2tkYVicHI4xkjPrnhf/giN8dNXvPs/wAQ/iJ4X8LrJDlW0ZJb+6cZz5Z3+UpHBYgMwyOhxXqLAZpj3z1IScv5nv8AO+/rv66HzMuJOF8jiqdCrGEVvBNNK92+VRba1b0ta/bVnxJGbeSdlubRJg4OfMmyG5z3/P8AGorGK4sRNHPNJcwlT5TSqWlXvgkffHpxu4GdxJNfoX8P/wDglJ+z54St7jUPjJ498XarYWskxS+022tLeNlQ+W4l8t7hlAYDlHZQHUlkL4Hf3n7NX7AH7PHiCPUB8PbSC6hsknsm1LVH1FdRLAsuEuA6BQoVmZU2/vI+WDHPRT4cx1r1JRjF93f+vvPMxfihw9FN0YTnK2llZeju07fJndf8EmPFral/wT08P20ZdX0zXr+yYzKejX5l6Y/uzV1Xwu8U6jqdquma34ns9R1Oz8uaOaNWO2KWJ9itnB34HOMdRwKXwH8T/g/4j8J6KfgJor+HorrxDb6feSafo8Udk06GCSVZYdyeZuBRRMoEmCcMBlW+Zv29v26Lz9if4n+B7XVPgLNb6ZqklwdWvLTUI0F8lr9ndfsUythzGJ5g8NxHGzhkxhSWr9BwMVGlCEHflSX3Jan4NmeJ+tYyriGrc8pSt1XNJux9t2t5CZSsbFSWyFduffFed+PvC8ei/Gl/i1eQzmxn8Lx6TcNDbb1ikW5Mqu+DuAw5BOCoHJIxzT+FPxosPi54c0Hxx4J8O6mnh/xHogubX+2rbyJosMytFLH821se5BA4OOvb6D4wtdaa6t7mExSW0qrNzlTn5lIPcFMN+P411ySmuXaxwpq12X9ItEuNJltra8fbIj+XK0WF2tlgV4xjDYz7eua+Pf2QIbDwrofiDTJbG6tfJ1vVoLeOSJQ7st2RlVVjkF1cAnGQQeO315rq2E2n24dy0AYqyK2AylSPqMHuOleH+F/htpHh7XtV8K3MUNy76rdywNqFpvVknuGlVcFiJFCvg4YEgchScDz8bV5Jo6qMOZannP7Uvxl+KPhTVvhzN+zlrscWoXfjKbT9dN1NPe20ttFCDNHMsqozAeZlSjD5hw3Few/tCfArwl8UNOtNU1CSbT9Qt4mis/EFjgTxbhkLJnKyRFlG6NgQTgjBANeUfEfwC9l4ksdS0R1W4tvE1xO8eCIPPe3nLgJ/BkKvGcjr33H0T4jfES78e/s4+M9E0OKW11u38C6jvtkmKyRSG1lEMscijg7lBDDkEcZxkzhsVDEYeSl8S1t+dv67l1MPKlWTj8L0/wCHPlQG5tsQW8jRwquR8oX+eDz9e1AhsMrNPcuAozKSuAfxP+PpUcGoIS6RMxkLBWJXr+GF9aW2in8/7RdyBEYERxnHIz1z8v1718o3JbnuJI+Uv2r/AA1q/jzxD5vir4N6Nfy22pW8FtbW/iGRvPEnl7fmMCYU5QMSwIIbGcAn6O+H3hvxB4S8FWPhiGLRtMtLC2WG3sNOgmkjgAHASSaUlsf3mGSeSK8x+M86z/FOE7cqNYscjdjeMxDj/PevZfNkIOLGPcchGDbvzIB4/EV9FndSSwmFj05b/gjxcphF1a768w6x8P3c8LLq/iXUb4seJDOsHlew+zqv6mrVnoekaZIn2GyjldcgzTMZXznrltzHv3FNFlcyAec0blemDgH2+Yt6UOGtLgCaVCNp/dIpdhyR1PHb+7/OvmnOUtE9D3OWKZ23wMvtUl+N/g+1hIjH/CTWO+RGGAftEYzhs+np2r5f/b9vxcfttfEK9tZQCNf27lZSNywRKeRgdQeRzX1D+zGstx8fPCd4sqiCPX7dmToSobdnGRkcf3ea+bP27fD2q+Jv24PiFF4R8P3V+58UXC/ZLG0eVkZWCAbVX0CnHI5A9qxzCM3lv/b6/Jn2PA9WjSzarzuydNr/AMmi/wBDxa51Od1FxcLvk5Blc7t2R27560mqX0l/bRRQaasGxQH2B8ytjBYkk+mfTngCvWvDv7EH7T3jFoS/whn0pZGEYfV547NFZ2IUFHYNkt/McY6+5fD3/gjL8cfE9n/avxV+Lfh3QrR0RnS38y9m2BQcHOxQPugFWb+leXSy3G4idowbf3fmffVOJuHcBHmqVoXXaXN/6Tf7j4qjXVPOSztctI+3YqZ3Buox79envQ2nXkcokvoQqls5lIIJ9OO/15r9JPDP/BIf9lzw/ZT2/jr4rz3t2iPtuJb+KziztJUiMtluhyocYGD7nfsPhh/wTO+EzyWw8C6He3djp4kEktgdSQsThVMriRGkLHB9AM4Ucn0qfDuLt+8lGPzv+R4GL8Tsmpv9xTlJ/wCFL8XL/wBtPzW8L+FNc8XTxad4Y0y4vrnhRbadZyyyHrgBUXJPX/I49V8Gf8E+P23PGdvCdG+CGs2sN04CyawsdgQh4DkXDIxXk9MnrxX6IaN+1p4V0TQ28J+CPhpI9rBKzNBZ2i2kcdxhSCgJfagO8qSoByoGMYOZe/tt/FCOG0n8P+EtJtZdQcIHvbZrpjyCoUQspHygkq2TlfwrohkuX0dalZv0X/DnzeI8Scxqpxw+Hil/ebf5cp8yeDP+CJHxvvrW11X4lfFHw9o1pPLsMNqs1zPGy7w24OI1AGw/NuKnIwea9v8Ah9/wRT/Zs0S1t7v4meOdf1CSIRS3lqZ4rK3UdSjFVZiR0JWT3HHV+vfFf9pX4i6rpccfxiudOWe4iRksbdLeOFTG8r7T8rblWMBeTliMEcZ82+I+lx6lcQ6z4i8R3t9c+bDGkWq6vLcykumRtZvlyOh5GC2BjFdMaOTULclLmvtd/wBfkeFieLuKcY/eruKXSKUf+D+J7TdfBX/gmR8KdDvNP0XT/CdjrTWirbXE/m6u8ErJk4DfaMMu4j0yBweSZNH/AGyfhv8ACXTx4M+DPwivtcs9NSG202+u4FtWlkUMXeV2zg4XIVY1wc9O3jnh/T9Fbw+bz+zbmGeJFO+QIqSylt3ydWY4B9cDtxV2+06JtXfRYWtQ4tiy3Es8jjlW25DMAflwcD+dE80nQVqFJR3Wn+R4lX6zjZXxNaUv8Tb/ADZ6prv7e/xs8SXEr+Gvhp4f0+C4UiKPUr97t0CJlmCRsmG+bHKkHA44rmfGfxy/aN+J+jSTaz44OkwWFrNNFeaTBDAv7tlDbZQm9ckqpUSfMCMj14m+vvC+kf6N4RvJgt4CkiRGKGSWBW4XcQDyDwOfx6HN1vxzoaz3mmLHPi+gPmwIpLxhiPvORxkKBubjBHH3TWn1nNsTKyv8v+Gf5nNKlhqcS7qXw+Gh2Wq6xP43knv5dNklie41bNybmQDcxCZJJWRiAxGMFs+vkf7Pep+OPiP8PNT+I/jfxHLLrS+Kdpl1GH/j+V7OBQHQYwFSLdvG1mYksWzXo1l8RTqviyztYNEktjeGG0luJbkHejOEVFChlBAJ7+nNeC/snavGfhN4gv8AUxLImma1Zrbw+YjMrSwXHTdyoJRs7RyTyK540Md7eFOpo5Xtr6bn0WChh58OYuoknySpu9tVdtaPt3Ps74JXvge90rRZLLSotM1mw1WJLh5nfyLmYhcmGRuGb0BCt8jYXbyfP/8Ags18ItD+Injb4Qi9shcLJ46mtJ45/nQlnhUjuB9wgj2ruPBs3w48N/D7UrHwvDdNOurWZ163vQShV7lQgk3jyypU5wnYc+lYn/BTPQ73Q/HvgHU9MtnkhtPH1vMyTzqy7WLMixuRuXJ3nDFgcDGwDn6bKr04OPZr9D5LHe8r+R7x8GvCOr+Ffhdo1p4anN1ZWoUtpshHn+Wo/wBXFK5AYH+7KerH51UBa4j9rr9uj4b/ALIV54du/F/gvUdR0PxHfXNrq13pWBdafJGkZBNu4DSZVjlQVbABXd0PqPwN1qzm8FwaPK7x3duP3lrdqElUAJkgdGUFgN6kqemSQa8G/wCClXwm8P8AxL1P4THxLaIZofiEltHeCNS8ay20vyhiCCMqpKkYOBwcV6t1yp+n6HHsmdN8VvFnjHx9+zjNqfwP8c3No8ttFf6BrMmnYW5tXXcoMVypYKyORh13KQOAy1+a/wAR/iZ+0tLFNb/FH4j67bQWszLqMemXHkJLGDjIRt8Odo/55/xdG6D9UfCdq+m+DV8J+JYEjtLOCOBb6BNsAXb8odCSYcbT8xJTp8ykha+Jv2pPHngTw/8AtHX/AOzX4t8EvM1/aW82lalZoHV1mQH94nUKGyN44wRx3rhcIqrzct77Xtc6+duna9u52PwD8dfs1eDfhDpd/oHxI8XTanNcW/2HT/E+ox3MxQySRMkPkxx2+wmOU9AcAttDsM+4fstftGfCL4/a3r3gHw1dRR6ommz289hKVExg3+XvMW5miHCt82V/eoNxbcF8l/Zp/Zp+E+hXCxeN/CGl6hHafZrmx/tO2luzBuVX+SBXCj5mYhiDznjNfXvgbwn4I+HmlL/wi/hPS9MNwN9xJpmmxwmd9uSz7RlznPXJ5FXTwkJVnVk+9vyJdeUaahFdv8z4Pb7SsBD7EAk6JIxHPQgDaOntzTIbW54liuHI28lW2rj8Mf41agi1CWJATtKx8hl4P1GWz+dLbyXQYedqRDcbvL6fTAzXxbkj6LVHiPxXjX/ha0EDsQ0euWSue/WL/wCvXtT2vkKzXdwwibLINwx+bfhXh3xRmX/hcVpE772bxJZqGL53fNF1PXvXvMUN/FJIqQxSKu4eWEAHXHYD/Ir6LPdKGG/wL9Dxspb563+JkNlcyX9wJYwZI+GMit5npjHGOnvWjNa2UsiLbtuZTuZSoJUHpkAn9aTToL+R1cTQ2xZcH5FJHXkA7v51NqTyCNY5b/7SVJVvMBRNvr168en5V84j2W9TU+EHii08GfFnw94hv7wRwWWohmCwklzghRtBHVto6d/StX9on9r3xR4u8Wr4h8E+GmTTdPu5JLnNjDCX2qiyfOu7f82Xw2cZGO+eO0Wygs/Emk3MMxZP7Xt+Q4Cj94M8AD9c1zXjHx/pDTtoSarLFGt4VSzhhAE8hBzuIbj7w7HgHp1r0cKpTo+y5bxb18lb87nFibKpzXs0tPvO98O/tOfH/wAWQWup+D9RgsjbRR273AIV7nDlizgKkcmAx4OeCAASWz2N54y+Kuv+G73VvEXxo1G0kjtD5lhDcfZfM3R+YBtgIxhth7Z3Nnk14fp2q+MPC9smi6TZQTySglEt4hM5BJH+rVmJ+hHI6dq9C0HQ/jj4s3aLeeFtVeW5h8wAaetrLICrIdpkKcEIwBJAXacHitatHF/WJyjJKGltbO3n+NjGLpOkk02+v/ALfxR8H6Lo/hmSSa8nj1AXL2LzKJfMuTHsDSF2wo4AxgHPmc9KPAupeHIfBGm6Tq+iW0sbE/aWv5sEgTBlJIwQQFIGD05z0qr4c+DHxi+Kvi/UPCF/oK6XqFlBE81xr9+TIVIPlqGi8wbmBBGTjjr663wj+APiP4i+FbTxJLNdWME2o3Vld2FjYP5g2RAg73kVN5YpwQAFBJJPB0q4N/VbyqJNNPT3n+vQxg17bSN0++hpeJ9c8NavotxcXOqyoLy4jWeW3tE3PJGWCpkk4Vt2SwI5UfernNb+JVrYT2x0vw/qV1bae0UdjLLOzeVs3AkkfKEZXA+9jI710Xwq+CGk6no/2+3BuYjZ3TXUKzqZPMSWWARERj5GbZu25OSOoztHP6faeGbr4MeJPEcmjWJjk15Pslw21dhEsJMID4YYRwcZxjcep55qeHw7/du8ldLstdNN/wCtDZ8/xaLT/IZbeM9a8YeJItO8F6C7Wkd9by2CxQDzmaEHmPZu5I6gAg4U1S8Zv4r1O6g1/UNAk0+3nvPJtkwXwyNucYYBkcEgEEDsOa9a+C+vm58X+B7Y29uumzWOoJDbxuw2q6YYLJgK5wcnB4IIxVL9r9LD/hCPC2oaBYC2s5NUvJ7WeF0JlEhEm7BO44XbksOOnY1pQVH2kUqemq1vfR2HOMuX4vP8DivBej3viTxbc+D4dZlso7too57oLgMzndjaM7DkEjqTtzxxV68+G3w8vfEUUz/Eq4utPFt5kzblRy4cqsaB2KlmAA29jgY9U/ZyuvEx+I8Z0O8s5ZJtNm3DVxK0cwyqlUMZXa+CcHp14JxXV+J/BXw5n8W2114ybT/CmrW+imV4vtkHk215lFjVTGZOASxyw3MAMgg08V+5quKly6aWS3t1dr9PkPDwjON7X+8wF8BeHh8RfDkH/CIwpa6jM5s7S7uUY3UEduW3sY1VsGXnJwPlYDIBzx3xw8HWOj/EPxBb2GkTQfZNQ8s+XarCi/3VABG35QvCj378d98SfjJ4Bl8b+ALlPFFhe3Ggu39t6givLFdFwFb5XClkL7mCgAAOQMCvKPjZ8W/BniD4ua54l0qe9hW8nR1SKBEAJSJWAT52XBz+RrbBTlUqq1Ry0839ry8v8xV4ctPWKX3LoaXwx8OLB4q0C7vLiG8S01i3MgikZlQCaMqQCATlgckgDjrzz4n+yPpUY8CfEHQbl5Yli1jT5F8sYLBU1CMndkYIORx3NdSfE/xSu/FGn6v4S+HNxcC3niL3spncNjaxwpCDA3cEgZHpXFfBnSPGmp+PfiX4S8M31vpk1r4jikaWQRgLGlxcRNkvkdWU9CRzjHIO1bB1aeYYd1KnxOdr200Ts7f15Hs5XiIy4czGnCOypN/KT2PrjQ/DzeINA1+x8IalHNrGpfYmvNNS8DGNIlRoztXBBYZ5YgHvXt37VHwV0z49eFbXTLmCWC7tL+zvrSWO4VGgeME4+6wYYkYFRt3YHzLgEeM/AnRbfQYNY8bjxa97qX2KOCKwt5VICxxRFZlXGQSx5PTPSvpaaGF9Ls4IJmSNrG3KFGJKjyh3zn8c125a4yqVYxez/r8j5nFJ8kHJbr/IxdA0ptX0eLSbq1ubYxFoyssbRyROVwrpIh+U4B+eNjjpmvMv25Ita0zwt4G1wj+0LfT/AIk6bdSSBAJ41IkjxgDbIDvPTaRtAw5Oa9ZttamsdKSezBuVkkxHlcEqclew/wBkdO+fesT4weFNM+KvhNPCF1b7BJd29zbTB2XyponEyEkfd5QKTgj5uhr0muWKt3X5nG1zJryZq/DvUIdWj1CKzmR4o3Ko3O9XUtlHU4KMMg4IDc89q+S/2p/hHZWf7b2j+JtD0m2i+1eDfNW2nQrBJJFMU2qQD5XykZ2gjkkqSc19MeGtBuRrF7rHiGZ9NuLWDy1vrOVW8tEUkNxnzl+ZuJEBDKTs5WvGv2m76dP2gfD2paxp2Yz4cuFXUbaMlPLjmDhigLso/e9fmHGTt6VxzaUEnvr+TN7aN+n5o3p9R8R6N4E11/CIuLPxBY+H5ZoYLqGIpE8cZw+X/wBaoJT7hKj5QcEkV1n7IPxo8Y/tA/AGw+JXjnwraaLqN00im0sbp5YigAKyEMAULA/dy2MfePbjfiFrmnapGkmp6Kps7y1ujb3x1SQpHI9uqJKqKAEIdjgghs5I5wTp/sX395YfBLTLW1j+2WL2cLlrdcTW5ePcQyrxIB0+UBuANrHJowdZVJyS2Vv1dysRDkUG+t/0Pm1DdkffUtt5kiGRz26H+dK0f2ndHOY5NvWMkNj9cfpUUupS4LwWjbCMlwh/ouP1p1vqY2N5FomAQCzbRz+Zr41xPor3PA/ixcWun/FOzu5VkAbxXYRhIEHBaWJR0xxkjPoM19DypNNc4eQqWOSwXvnrnHX8a+b/AIyXNtP8RbVpjtZPGFieUGMCeL5twI4GPQf1r6HSf+0pwunF5mPCEMpDk+h+Y19BnnvLDx7QR4+VKyqy7zf6F+0l1GDyxI6SKoJc7lVs9e5ORjjgZ9qZa6tBehpLe6jEe47vKJJz3HOMEeh59aiNtqUMiST26qrjhp5M+mcKSO/tUki6csmNUuzb4bcj2xxIGwRyAuGGP72R+VeByxWh6t22Ntnmm8Q6cbVQc30PLYIHzjrgdOfUV5vr+l3t3rkN2bZboNduju+fmbgqvPbn09K70eMLGHWbGGS7jSOS8RUlmZItoBHzZkYDqT3OAAa5S81G/m06K70DwVd6pJLJuL6fI5RWUZ2syQ4BwR908+vevoMndoTVt3H/ANu/4B5mO+KLva1/0PUf2T9NvY/2irKaTUNkb6ddosELkGPMZ+9wDgZGPcjpg59Z+GFhZ+Pdf8VW/i74oal4k+w3Wlx6Prk6fZxArCUt8g+4gdymcHOd3PFfOHwx8XfF7wf4x/4Sbwf4UA1GW2dIYbyxkkAZ0DMSzue2OuP4TjpWzpei/HvSrE22r+J7TStNvrmH7TE9ysMTlW4UMQmTlsAbs88U8RhlW537t9F71ltZ/wBefUKdVQUVr8j6gtNf8IeDvF/ijxn4u1IaPv8AFunWllcxwvOkjQRI5ACBcNJukBzwuDk5Bp2lfET4efArX57DUfFmjWNtqvjKaSN5bq2ttiTxGVGLuHcIswVegwCfUmvlzxJ8LNX8b6gbnxF8V5J0WUu9mbkzAEd8qzn7pPJGf51Uj+DPwT03W5brWZLy6liIWSF42K7j3zIEPXdxj09Oap0sDyJ1ayXdJN+mt0TKdZu0Kbfroer6P8ffg94asNMt4/HNjKbHXL5r6OIS3SNDNNc5fHyo2coRgfe2nnArnbP9oH4I2Gk+JPBeh+A9V1C01PUZLy1s0tIreIM/klUO0ls742PUcEZPWvH/AI4fFD4P/s/eT4itPhNBqtpDFteW61MosDs2yP5BBOTxnuBx+bPht+1Rd+PfFdhoXhXwdpGm2w00aldxQm7lby3+VELtOqhsndt8rp9RVShlTpc8XOS11Voq/wCfW3fYhSxftOVqKfZ3bPdZfjT4+0208LReA/hrbW2naFcX/wBksNUaRt6zqwxk7QACBjPBwa5jRbn4v6zpL6X4tgtZNPtLyWbTo450RLXzCSwDITwCQMAjGMehqtr/AIq1ie5hEVjp94gk8sQeaN8bAYA5ycjjPHYc1r+FtI+I+sXMXhLVvtFmsunR3yzxyCZRG5Vl+VAmflYDByeDyea8uWLpez9mqV9d3J827fS3e2m51unOMuZy+VlboR23w78S6ijSa54m02xtYo5BFHbMCfMLZUBpSuThmBKj1we9NHws8F3ViLTVdS1fV0JBCJcm2tt29WWQgjsQuOSBmtj4b+DRceHdW8WeM5fsmoWLS/2dDdzLvDiJ2LIMbhlivQ9O4xiu38IeD9B1/U9F0ua5e4jutJllkjkizslBhA5Ps5ycngjgZFckcdVhUU6UIRfpd/i3qaOknFxnJtfd+Vjy7R/gzo2n2rDTfDemiNEfyl1O8lmc4JJwG2Kc5PTrk4zUFpoGrxeJoRaWthalxs/4lqxxXZbZgDKIzAchT16Z5Arf+Emq2DeN7my1zVI/ISeeC6UqsYibaQAHbJHJHIwAOfSqOsavPbfFWbXdIt5bgR3rG0Ml2xQgkqOmOMZO76c9q5/7UxcledXd9NPysarC002lHYnax+IkDzWGi+Erl45WZXkvtWcRuTjGFYIDyTkg5IPbnHzX8I7jxD4f/aV+K+j6bqBSSO+1AC5uE3KrQ6tGN54IJ+bnjv19fq2zkjHjGHxJPdXzaibuOQWf2clRuVt3L4U4zx1wcelfLfgDU5Iv2yPi7DHapE08ut+bIzY+RtYt5ATwQuMdgf61FSrOUYtyb1fXyPpMjp3y3Hxt9iL+6Vz6j/Zg8MajrGi6n45uPEsTmWwk09oo7cBX+43mbgRjhdu3HbrXuvjz4xeHvgd+ztB8XPG8d3d6ZpOgWU1+NPtQ0yxMY48hCwzt3AkZzhT34rwL9l3wjqc2oR6zaNaCzgsWSeOSbMm6Q8Bdq4xlDnkfTOa7r9rXRJPEv/BO7xloSzt5i/C+9ZZYh5bK9vDI4Ix93DRDpX0OQySU0uiX6nxuYq/Lfv8A5HcfAL9o74G/tH6LJrvwY8fWOtW1mVS9t1DRXNkxyEWSF1DpnDYJGDzjNd1q93HZiF3jUMZQqfNgAlSM18tf8EwfhZo/wv8AhPZ6jpcKrL4j8PafqF44GDI7QRnJ9fvE5969f+MfifX/AIXfA7xt8Qy6aleaBY6nrVhHqL4jCQrJPHESmCECrs9duQSec/Tzsr+V/wADx6bckvP9Tppb2Sw1aS+guYmtn/1y7OVCsQfr0bt2rxb46/Ef4ZeJpLGYfFnTtE1nTYpI7W7uLuOJfLkC8MJsKykopwGGSoIPFO/Y2/bAn/a88Aat4h1L4U3/AIZnsXiilSe7juLe5DoXWSFxhyMEZ3IOowW5x8T/ALVn7F1lJ8Vr+/8AD9u1vZ3UztttZDEY2Lblxjg9TwRivOrYdykoOVkdlOsuTmSufWFx8c/gVcxwWei/Gfw3Drihf7Qjsyri+kJUZ2RzZuCWXpEDIMEEkCtT4PX7+HrOym0TWI7CZJ4bI3NncLNayRpIC0ZdeATn7hKksTgNiviH9lB/2lvgZ4xudE8CeLNMWK4uYYl/4SCQRW+WEhDSN5b7CSgUsqhiO4r65+G37PH7Tmv63D458SfH/QLO+lYT+ILPTvCrXdrfjOEWOUvbOFARsqco2/5kbGDz/wBnVadaM4S9X/wDT65GVNwkvl/WhxH2jRdkdz58j/Nh1HOOcHOR09gaiv8AWtItUUW+nJIrdwxVe/BH0qg8mnrbxyWmmuBt4ebLAk5PoB+OcZqs2tX9mAkvlSo7gFZIR8pwBnnPYY/lXzaie0eNfEO+tpPilBd28CRxf8JJbtFGAMLtkXpz64r3f/hMPFF5N5VsjKCcB0APQcgkZXvXgnjaZr74k23mxI7yeJoTlCV581cgDsDgV7hq9rcWlwbK31FlwvJBwuOv3s+/oOgr6LPknDD3/l/yPFye/wC9/wARHbT3d3qEiy6giqiNvUugG5f4ecY7c9K82+JH7VPwq8AapfaNrusXZvrPb5llaWTuw4UgbgoQ53D+Lg9a9Ls9BupLm5ke5t5kgiAxbqXwB3IAODz+PrmvhT9psanefGrxC8cUDBNRKLJvPzYjUdMdByOvavOy7CUsXWcZ7JdDsxuKqYWmnC2r6n138FvjjovxftYfiB4a8OzQJpWpeRAuoRrksER2PyMcghh/F611cnjzxbNqcA0nW7Z2hiZnRNPQu0ZAzk4JJyBglsjJAI5z41+wNosTfCaRNQkh3vr07blQKFH2ePHBz3H/ANavcdNVNE1cy2LISylyX2swyNpK5yR9PrwO2Ve1CvOnBuy/zNaLVWjGpNK7K/jrVPGuq6bdxy+I7m4tBasiMl65QIVAKhCRgYxwBjj0NfJHw11jxLbftG6HaXOpGS0tvG+pw+WsSJvhiEZijJVQSF5wTk8/Svs/xW8Ft4WeYWoT93uDuFJbHQkdcf41+fHgzxx4tsf2oNI0C+m058eL282e1tHXcJJFSQgPI+CwA5HI7Yrqy1OvRrXS0X6MwxrVOtSs7K/6o+7vE/7Q/wAOtCiaPxB4qdJ0JE+bSUNtTrzIFQgBSPvY4NXvAXjXwf438Lr4y0eGX7Fdh1sp2lh2yFWK7uJHDLkEDB/pXxj+1VYWuofHy+lK7nGg+SQBn/llLkD25z+Oe9fVv7F1jHafs7aHa3Ns8PlwXBUS5UgiZyDjbnPI7jqK48bg4YbAwrKTfNbT1VzXC4qVfFSpOPw3/B2POv27NZs4vhaTefZoRLeWqR/aZhGMZlbdywH8OK4z9iL43+FvEfxy0n4eXWs2JhudHWG2jt9rPLJHHGzDeNw+5FIw3ccY64Fd5+3Ha2fiTwtp3h+9uXiTUbvyEkS2MrfLDOwIUsN2Mf3h17V5b+z/APDnTPC3xi8NeI7aLV5HtbUwQSyw28ETYtpBvOJHYZycDHpXoYOnCeUSbT05n5dOu3Q5MTOUMyik97LdflufoVF4Y8PR69diyZ7iFpGZS2dxzzgsqnB59lyePbH07xve6Zql7Pqdkk0cOkS2ksLIBsjGBuDMRk4zj3I64zXEaJrWr32oPb+bcXEcZDYkncoSF4BUDkYGPT0Na2i6Xq3iPVb3RndI3mlMLBIFKgOCzAA7gRgfyr5vExknF+Z6kbJM3be6j8LWN5Ff31pFai0DAiUOZWYuhAwC3BB+7gY5+suh/tA2HhjUdL1nSvDL3UVlpnkXUtxuDFyqDKlW5xsOM9jnFYWqeDLvQzJ4c1K+EtwCA9yrFvLUfKdo4+6VK4xg4966Twd8F/Cqaisut69cSWgXzJpbe1QNIjI5DJnO05A3A54I681xUqcoSslaxpUlzRu+pzmp/Eu61XzJNN0fSNNdZDKZ7XT1Vi23AJc5ZsemcHqRVS78afEC5ghs7fVFMMkqyBnXATYpA+4Nw4yPfqc4zWrrfhiKDRtTEV5EklnLLbpcTT+WFcN8sgAIzxg/iBzmtLwfqNmdGktYfDmm6gUtZY5b25Qm4MwjMgfcSAVwh6DPUZpOm6ru9LFpuC0OfX4j/ECbTodO1GG0u4rP/j3jktsszlwxycqScgclu7Yrx/4dx30/7d3jGK50EPc6lpF1cfYYomXLSRRXACAbyTjDDrkjmvrLRtNaTS7yW50vS7e5Fv5c2yCOKMsBN5cm8/xB0Zgynkr15yfBtf1QeGv+CrR1YzW0ySWcTSShkYEnRhkls4JyCc56Dnoa6Y0XTnHmd02l+Z7WQ1VKhjadv+XMn9zTPR/gj4a8aWHxHjtLOLU4rNGkOswPdGIQFo5PL3RuRk7sEDBxnPAr3f42CGX9lLxTEbCGf/iiNbhFrcbgkv7ifEbbSrYO4A4IODwQcGvFPC3izxBoHxP/ALK8O2zjTp7qR7/7FH9rUQbAULTlflAYnoeCSuTXa/Cbx6Pip8BfFdhrV55SJe6ran7bMFEEE1ukihnbACgSnk9AOa+iyFSjObe1n+Z8hmDThDvcg/YV1fUbz4E+DLjUdNgtZG8I2saxW0rMgRECpgt83MYQ8k9SMnGT6R8cNNXxP8F/F/hooznUfCmo2uzGdxktZUx/49XgP7OHx5+DXwj+HPgz4b+MviboEeuWHhu2tLuxs9XguHEsVvDHIFEbtvw+fu5zjjNe0+HdXPi+w8SXT+KFvtO1N0OkRsqBbeB7KEMg2gMcuZH+clh5n93AH1DnCaml5njUoygoc3keY/8ABPXQrbRP2dvDMsdiYX1HwlplxcoVwfN+zIG3e/H6V5f/AMFWPD2sWvwd0fWvDGsXOm3z+N7CBNQs5jG8IkSdM5HXLMowePWu9/4J6Xdtafs2+CoBLIF/4Qyy+V5GbaWQPt5PGN+B6AAdBXMf8FJL+HXf2btW0S41NILwa/pcmlJJtLu63kRIRW4PyeYe/APB6FVFGVTX+b9RUbxoW8v0OO/ZZ8BeIZfhZomr63eXV9q00oaW8ihi+0SSIMljuAjB/eEZIGPrX0X8JP2ivhvqfxQufgFcanf2/iy1s/tMmm6lZsWkgGFaZZYwYsblYY3A8Z24INeK/s33unaD8O9GtvHviu2kNiZLS4Mqyx2ssgji3Suo3K5LYIBKhQTknAI7n4UweG9V/aV1H4g6PBa+XhLa2msYgiGOWyiuDwCcHfKcj1B+lZxn++t/XQt3VK/U8i03SPEt3ZW8sd0iq4CxRi3OE5ONx7H/AB96S50m4thDJf3kUhQ84kGV9ucN3PX8hW9dyx2xX7NFGI0581oA24565wcDpgVn3urBZTElx5qSNg+XCFUNjpuKDH5V8ZeR9L5ngHjm2jm+IaMt6nPiRAimMk/65fmJyRzu9O3fNfRNzZ6TZ3a22pXc4TIUiOFuRgDIGVFfOXxAjgk8aieMy7pvE6mSIyMSoEq4PHU9R2r323fUmuPLi012LyDZau2Mn1/d17+fRahQ/wAL/Q8bKGn7X1LskGmWkzJbTTmCUD5AqqAM5AxuPHPTvk18E/tB3PhZfjf4ks59Xj3R6vOpiFxt+YYA4BFfel5q+rnbBJ4dVEAKbo7mRi34Fx35r4w+LPwK8a+K/ipr2tabpkWL3WLieMu+P3Zc7WJOccY45NcmUzjTqSc3bQ2zKLnTioK+p6x+wlE0nwphv7G1kkhbXLlRKUJXesUZIBJ5IBHbjg17wLY3OpwJZRP5icsrseTx0AHI6/n+Xlv7Jfw+8Z/Dv4YQ6DrN3EI49QuLwWy8rG0yopJ+XOSI0BGfT1r2DTRZ3d1aOzyhlaSRmVflA2lQME8nkHj0xzk487MJp4mcovS7O7CRaoRi1rZfoU/Hlrqp8PPpYVS1xGFj4fr/AHThQBXyvpX7J8Nh8TrbxrL4iSWa21P7eWQ+WVk37vLwUJZeDzuUn0FfXLR6nrWrXGrXWvwLp7W6Rx2H2eJQgAOWJILFiMjrj24rLk8PaPazS20RLGSFmWSIlwFwSR0689hWFDFVMOnFPfexvPD06rTavbY+If2lNKktPjl9pj1jVIjfeGLy4u4k1WdY/NSG5VCIw4VSPLQ8AcjPXNfSn/BOeQTfsvw2sl2RK2sXQaT5mbb5hycbgDyATn9aZrnwR8G3fiKbVPEHguLU751aKK8u1OVibcGUKW2kEM3BXPzHnGK9F+Evgnw74M0m4tdN0JNNsIgrRwWcECBWydxHB6kgkgZ967sfjqVfLoUUtVb8Fb9TkwuDq0sZKq3o7/oZPxR+H9l4lihsrk2199mIkQzKo8shSMAEZzgkH1yfU1ieEfheulOt0sUCqigALkYPXDN/COK9ij+za5JZXSWryQRLIXlufNj3FQvHKge2cY4B6VlXWlaZd6pK9w8MFq8jeYnmMQi9Nx55we3+NefSxVbkVNs650aXNzpamPpN0kWntJDJAUCqPIRXDEZ9TxW94L8exeHdZtdVmiZjZXTNMsDqG2MAOpGRkbeevavkb9on9skfAf4yR/Cj+wHuSGt3/tL7av72KdwzFUMfRMsgBOCY+te6aPrkmvLHqclxJi6kQiEYU5GDkgH0xyM1tjsNXw9OFSSsnqjno16VaUoxd2tz1aX4m6TrXihb/wD4RwTOQTMXuflcq+VDDbg9cdQMc9uHt8Qte8FWJuPEdpAj2AW5jaOIfPkvlmO5hzyoAHbqM5PDeEUNnrTXeoPbR26rIZWuI2YjK4GT0HJHNax1+1utKuNC1h/M05rVIIxbWySEhC23G5l7nDDPTHHGD48avvLmvr2R1uD5dPxNKy8Yapr09jpNw8sNv4kdVV3jWQb5CrFnO0beCpG0E4yK3rjwpZW5h0t/Flyy2vmRTG0hc7k2AgrgjOVYjnsMdOmDpnxu8MRFtG1K31N1s9QheBVma3Max4U5xGApKgAFSQc5+bg1NpfjW11Ke3to/C02q+dM24y3PmBg5BAILgqQOrY5ra7nJKEH87/5GbXKm5SX4HXXXwm0vQrS4i8Q69eagsFyqQxW93Fb7owm7fulOC3JUJnkj/ar5J8c6yR+2xouq2DriXR4VVQ5zuXTXgOQq/eyhzgdc19O3viTxTpc9xeaf8M7K3uwzolzBpI3Q/L9xS25SflGDnuwHJxXz18X9IvfA/7XHgPXfiJss7a4S3/tG5kmSRIYmvbhHYtGTwInVuOQGHfiumdKPKny21Pc4ZqpYjEU2/iozS9dD1nwD8S9X8I3N1DbW91dWl8xt5pZreX9zG5T5xuAGPlA6kc1S1D4m678Dv2ffEN3pSaJrN/4h8anR18PatqP2U+S+m5eZWCuzcYBXYeFPPIFdnoPgHR9L1Rrb4iaI/2G4jNpYzxFs/a32bGGDgAdcn5c5HJBA+ZP2jvA+na74q1Ow1/w+w3i2jmSR1bYVEmcgsScMSOBX0WSUPecHo+vofGZhVfKpb2PEfjX/wAFKvCfjrXZfCfxD/ZG8PaRa2EE9g0ul2ymSBzws8YKod6tg4Jw3AI4r65/YE+OHwVh+G/iC28Fa0+kaldRW09noGteKo55WaOM8pbB2e2Vtwz8uSD1O0AfD2q/Bv4e6q1zZ6ddxK7XA3lZ2Tayk5+TIQkH1U810VvZ+OvD2lJp13YaZrGmwBcDUrMLkklRzGUUje235kbJP419ZVpQ9hyRdr/P9f1PDpVJxrKUlou2h9PeEvj78a/gFpVtbeDtD8BX+laXo7Omjw+J5Wkgt441/d+Ydxdwo4ULuODivRvEvxFk+KHw217xH418C3+gXxFkb3T9RZDgRywyStCVc74iFBBIBbb0OBX5S+NPh148sPFM/ijR7y9sXnvgYoLG/YG2znKgv5f6Zr0Xxb+1R+0F8LfC+naN8MvirLHEsf8Apo1HR0mn38DJku43ByB/DjFc9TBXppQ3fm9PzNqeLSm+bZeS/wAkfod4btLO68E3WmnTLtbS6juGspYogq3DMi/J5jfKy4TO3knbnHG6uGmTxZ4Y8Xw+L9C1W7j1BLaKMT/bXBZBK+1flYHbjZ90jrgZwTXwHpH7ZP7Vuu+KNPt/E3xc165sbu5ignhtNXlt43RpANrC3ePgZzxjpz3r120+PniHxXBHqvhvX/DnhsW+gwSTiXUr4FiY/PlMgdSWK+WWDFmOACOuBySy/E0mpXXyf/DHRDG0Ki5bP7v+HPuNv7ChlaWezWZcFvnBcYPI4PUkc1bNpoE2nvcaZphU7vnDW4UDknhgn49a4fwDqniGz8IWcWv628t4lpH9rdLgPiXYMnDORjIzgce3Wuh8Mazf3iCCO8yAv71BEjZ9wdhGfXk18dKL3Pob20PnT4iM8nxakEcaRQx+KFMQaQnkXH3SCARx0Pfnpivozw7beL4L3UD4nFlHA8ytpn2aIhinJIYs55zjnC/Svm34ksY/iwyuAG/4Sn94ka4I/wBIHAA4XkdB6V9TakyXJ3JOVj4+VGVmA7ghpOvuADX0WfpKNBf3X+h4uTttVPUq6imlT2aOmk3RlJ3MwhY898jb/nrXBmwslunmtCuJNxXI2jue59+prr7jTJ4TLJbxTM83Ci9vBsU4zlcliDg9AP5VlWFwkNqlv/ZDEhMM3kA7+uOdpz/WvAinbQ9ltGn4Wc2Mccb3MLvMrNG63YcRqufRyBnnnArW0G407XdTuI9XjhYk5T90rSEAgEglTzjFc/od3bXLC6GjGMokqrF8yYy3PzAAc89+9a+i6vpen3iO/hciQ8BmueQOASTuyTx09u9YTilJuxrFycUjRgvtPvdFa2uFIEJ2gkchf7xbg56k/jRLZ6ZpNzFHZQ7jgCNjls85wCO2ecfT0rAi0zTNN19Ft7KOaR4nxNPfZeJMZKqpzuzzk/qeg6e08y9ulvZtRWzFvEHIe5CAc4Jztx6ccZzWDp2atsaqXcpvYJFpAjntUaf7Xl3iRS4XJIByeo45q/YXSSWl3FGCJdjIEkYg425DZx7e3SqWjavdXt1AmqX8bwhivlMxUvx1HY4P6Cuz8PeHra+gcQwIJNp3ZZGLgZBB3Nx1/MVi5KOjRdm7anLTRahcNbWi3SRfKAucEkYAx16HOfes+80pLopDcMeUJkZECBJd3Q7l+YexP69PVbfwzp99frJFc20SWUPEcMCGQuzZXlUyQDxnnnj1rQg07w5dWFzb3F7bNHJdu8YExd2KqSRgKOgH4c1vTpy0kjKU01ZnyX8U/wBkbTPi9qlrqHiXwzJezWcqy20iwnMDrg7uB0yACPrXWfAT4I6Pod9rWn6v4WuZHhlV4p4Z4s+ayICpBk3LuZ8gkDGMAgivYEk8OpfM1haXFwIrgiQm3ciMLs3ISOCCN3/1hXE63feLB8SLzS/DiafBJPfxb5LmIDcgWLG5juywxGQuQMt6cV3VKtepS5ZO9jiVOjGd46Nm1q/gzw9dXwFpoZs7W3bZNOsyGZwSvyhCxVMZxyG7kYHW1pPgzw8mpPBHfT3dtBOEitbu8jxEof5mKqo3bhjjoDk/XWu/DOpavPFc6bpW/wC0W0UyT3cyIxdhgICuTnYq9MZwcjtUtpoPiKGdR4nsb1xcXO4pb3c0awOQr5L7AEYnGAByQBXH++6bGr5OpWtfh94DgEsh8LW01zGsa/bYbOQIwLEuTsxuLLsBPYAfWltJLTwkNNurPTLG2MTgW4g00wSRBfmYZkIDYGecnjA61vWsfg7Sb0R6pcW0E4KPam4naRXYKMbizBT83ODnAGOcZOJ4nmsvEdwuq6Ra6fJG8A86SSNCsSCPgZ6nJ256dSeck01Bv7WvkS5W05TAsvF8dvpqtqtgHuLiU3F07XMLKdpLKQQcEgYTGeNv0FebftU+HdA+Knw+fxJf3Ednd6CftNvdTXoZJBJ5cUkOAMkuUjZMZwUYYwSR3vivStIvrkJpSXMwDIsZRRGrINpB2hAc4yOeflrn7nwnqE+sLaOl7M8kJk+zfNKpVAoOY3O0gFwDkY+cevOs6dSUXG10bZfj5YHGwrx0cX06rqvmjk/2HtY8UfHbxZq3hbxx4qvpZLG202exlWQM8UFp5yCNd3ADGZCxHViWPJJqn+09okulfEvWbXWbeaKa42vblZAVH7w5yCDu+9zgjkHn09U8BfD67DnVPCXgzS7TUdWtvsm+0s0s5JCkiSlBsKR5BjUnIzgEcGqv/BSjTls9c0LUbaz2G5sbnzVyqhyktvg/MQCeTx2r3cijKlVhF9b/AOZzcR4rD5hWnXpR5U7adrJL0Pzh8OfBG4h+L83jzUned7L4g20NuxG1Qk0k74/8c4zXso8OaXJHvl0lo5UTN1LGy5dxuxkghmOPbnjvTLeIReHvElxdDy5LTxPpFzhSuRg3CnkcD/Wdq1HkinuxZpqvlyS3BXymKnp04I3HqO/avrPiWvT/ACR8lS0/rzZ88X3izxhqXxavvDbadEdCh1+G1uZZ4mSWPzQWTlyfQ9QOlavxB8D295Es6SxPhNweKMrkcAcgn1rrLfw+bnxJ401VYE82Pxf4fm5OOGgkBPT1IqfW7VLoq9xpkWPN35X5/wB3nodyjHTOKq94en+SJSbev9as+c/h5p3hvxh43U6EcSWsE0paaEp86QyugJYDuleqw/CuKfwb40sv7WlIsnt7azjukVGCYmt3AB5YbGXoTjHXrWN8Jfh2bT4nWto1r+7uNKvFU221gx8m4UDKnGT8w6jp2xXcaz4YsvE/wu8SW+o3sgvJrqEKkt1ibb5Nzdb26NhngiAJ6lh1JorVIpb6afmOjGTa011/K59weJ7mw0DRp9ZmSR7aCDa0f7yUZJAyFDF35IG1Qc8ACuT8NeMfAVpcweK38RrPBMZEije7hgJO4rny5GV8k9AR0wRnIrW1Lw1os2lldeuFt4GCNd3cM0kTwoJFYuH/AICAM57EVhaPZ/CaDw5p2maJp/h95dPlK37XNlPfCZWgll2eY8QOdzK454ClAegPxmCwtOvTfMz7Rumoc1pN+W1v87njPjzUY9V+IKa5YxM0Nx4kWSPKYYKZ89D0r6q/tiwtWeSK4aIZO6OANt6kk8R9enANfIfxE8WaLpnjJIJddtIgniVoow10qjcJ8YGSOeOgr64k0Q61cN5k4h7BmeIt+HLV6HEMYuVJX2T/AEPEyZtRqadSa38Vedbh5riOLbuVMrKXUdyQFGM/WoLjxPY6baeR9l8+VyqoI7QoORzguf8APvU//COWR8yK3ug5l2xlv3TBeDycL+FQxx3Nhp0llHqMd0lpKFSUWgBZiTtOFTjsOvavnVBHsOTvqU7V4pL2INeDyzE5ZJIFwp6g4U4P681uaV4fvNWuzC2uLGpgLeZFbBgSBuPQZH4VTgh8HR+Hre5ntGg1zdM8omlmDsqgkBVOFA5zkDPv1qnoOv2AvE+zaesTucea6yMWUdiCMfQfQ1M4a7XLhK60djTTw5pyyNqKyW7XEjHFyYgGb8uc8816V8Ff2YfFXxl0O412y8Y6JY29vdmEx6oJmeQhQwI2Kem7HJHSvLjMmou8awAy28m394pUpjODyQOuDnHbqa73wZ8QviF4Q0j+zdA8TW8EVxc+cwZFL7iijHLHghRxjvU0nRjWTrJtFTU3TtB2K0vwisvDct+LqGKW7tNVks4Z7WFFV5I22FgWBYj5TjkVq6VCdPRhd3B3ozI0LOm5G464HPX+prGubjXvENmstzr0bm5vXnlldYlEUrOXLg5A5Yn046Z4Fa93p+m/bIZ73U57go2C8dwuTJg53dQvOOOR2rkrR5mnc1g7Kx337OVh4E1n41jwt4k8KW+rxanprSGHUG3JbtGm/csYIVgcEHcD/DjHzZsH4Ur8R/jb4r8N/DHwjoGlwaNNGHU3TwIm5CPuKXIZ+fuKqKAAeTluR+FHi7wl8KPi+PH9/a6zqcVrpjRwRae0DESOu0797RgrtXjBPLEnHNdN4b/aH+Dnwz+MXif4pTaR4oNrrsMQ+zypZL5EoOJGP79flbYhXk/xc4IFfRYJYeeChCpJb69GeXX9tHEOUU9v8i1qH7OnxD/4QqLxRB4W8L2VvcXAt5oG1CM/ZwzmNpJXKGLCtyQGZhyAC2VHI2HwQ+Lngn4pP4U8eaX4dK6lbSXNvcWVyIrVY43UTM8kiqy+UNjsu05DrtJ5AdqPx8+Cmufsp3n7PEN/qMUmpasZE1ArZsqM1/8AakHl/aN56Kh+XG4npnNdFr37TfgD4h/FfRfEF78G9a1nSdGstRtJbLVdLt23TStavHMkLylJMLC4GSMFwQCRXS8Lgpx+7r95g62IT+/oTa98Kbqy8L6F8Ui9n4h03VZlt9NvNDu5vMa5dmVF8uRIyCzZQYGcjBxnNT3H7O/jTxD4qHwttvEfhi08QRaRFqM2nXWoXbyxQFwolfEBSQqxx8rYBOehBo+IXxrfx98J9O+GVh4M8fw3EGtW00WrwaPaWMMSi5DbvMhRkhCxuy7lj4IDE5ya9f8AH3gXUfFfim61SPxx4s8PPc6Q1rLq2kaBZxxm2GDtXUJLV2wzEPtEuQVJAQ81cMswtWTcYXWhnLF1YJJuzPCvBvwE1TWNEufFMGoaRLp11qi6Zp+s6hbTRDUZGm8tWiSON2jGUOS+AN5BY7WI9G+G37NEHibxb4jtPir4bK2Wjwx2506xjESX0hDSKRIhVjGF2EY2k7wDgqy1zHw9v/iofhJefB3WvBvxQXT7LV5hoHiXwZcQaZdzWguGeORlmnTbuDn5SGBU8qCua0fhzZ/tAfC3xzq3iLRvhX4s1vStaWGK7g8Q+L7We8hSFCqSrNLcnMhyxZMBfmVQwCA1rRwuGouL5NfmZTq1J3978jJTxD8CvGPhDVzqXw+Twbry+GGuvDo0S6k2u7R/IrKgVXlD7AfMX5s9Rg1d8YfCLw7rnwC8A6/8LbLSfDmua5q9vcTT61q7SO/mWc8jQeY+6SYFwuI1HIUHaApIofED4JX/AIwstWvvAP7JVxp2tahbTRQ3vibxJbi3snkBzLDDDczJvUklcKmDyMVt6n8P/HepeHvh34Qt/hlq0Nr4E12zvZ5p7yy3XCW1rNCBGFkI3M8ikg7QBnngCtoUZSuqnL6r1/rYzlNRacL/AInk2peD/irF+0Q/w88N6Vpz6zpFiLuS4luHOnwQuobzWYDdht+AAN5PbAJra+NnwKuvjB4w+GPiPxn4fg8Q+ELq11KSS80a4lSESKkZRbhJUjlCF4jwByQAflyD1i+NvFnhL9onxn4/s/hfrB0i38M2B123uII4ZZJI/OZGtpQ5SYhNwZdy4LAkjCg/PPx5+Lfgi28U+BPFC2fxd1PT9K8Syam1p4j8VpdN5iQMYoUhMzRlAS3zs/mcYBIJNdWX4GjTnzp6pv8AExxWLnKPI9rHi37cun6P4FNt4U1P4E2ngvW9VMq3eueHwjaPqscEkUiSQwxMZkZd4DeZEpyxAMgwwxPhJ8K/F/xy03xD410HWdH0rw5pKkX3iLX72S1tY3GxtgzGX3BSGOQAARkgsAfOf2pv2lPgReftaeD/AI+eKvgx4xu9Fkl+yeItF1F7Ui5ZIWFv5USyurgMdzo7hW8sD+Jq7j4a/tj+AvCGheO/AHir9nHxWvwx8WX8uoaZpunahbNc2aSQxrMjRvLGsSkxmVQkn7okquQFK+2sM+dy6f15HmfWIqKS/r8TRuP2JfjXZfFbWPhxY3Hh67n8Qafpeq299aasRax21u4V53ZkDhSeAFViScgEZNZfjX9k/wCIHg7SdD+IPh7xB4e8U+HNY1SKyt9S8Pa08lvA8jmNTI8gRVXzSI95JCtw23Ncx8If+Cnfwa+B3xjvNX8C6H4pk8FahoFpps1vrGr2t9qSvbtK0UqbrllSMCZo/IVguAHBByph8a/8FNvg14O+DNr8CP2fbTxJp+gT699s1i/1rSrea9tbQ3i3TW9pEjtDnICq0jjCjuW3CXQjyspVopnrUP8AwTg+Pei/Ejwzo0OoeFUa38PajdTyDUpdhVppFWJV8vzWZROrbgu1ePmyVBy4v2CPjLo/wC1Hx14vsdBL+HZZv7Ysbe9aS6dLfcHkO1NuNhMoV2DbCMhW+WuW13/gtv8ADrVv2h9G+Mgj8fR2Ok+FrzTHsk8PaYskk000Lo4In4UKkgI3Dkrx1rlvA3/BW/4QaD4T+MHhu4m8fXdx8RdX1bULC4uNM00G0N7arH5ZJnP3X3EYDZG3vxWc8DFq/wCr9exrHFRjp+n/AAT/2Q==','','','2014-05-02 03:48:31','2013-12-25 15:20:26',2,1),(39,'GIG Club','ติดต่อคอร์ท',NULL,'','','2014-04-16 04:06:27','2013-12-25 15:24:12',2,1),(40,'Skyville Badminton Club','จ. พ. ศ. 084 6640808','data:image/jpg;base64,/9j/4AAQSkZJRgABAgAAAQABAAD//gAEKgD/4gv4SUNDX1BST0ZJTEUAAQEAAAvoAAAAAAIAAABtbnRyUkdCIFhZWiAH2QADABsAFQAkAB9hY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAA9tYAAQAAAADTLQAAAAAp+D3er/JVrnhC+uTKgzkNAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABBkZXNjAAABRAAAAHliWFlaAAABwAAAABRiVFJDAAAB1AAACAxkbWRkAAAJ4AAAAIhnWFlaAAAKaAAAABRnVFJDAAAB1AAACAxsdW1pAAAKfAAAABRtZWFzAAAKkAAAACRia3B0AAAKtAAAABRyWFlaAAAKyAAAABRyVFJDAAAB1AAACAx0ZWNoAAAK3AAAAAx2dWVkAAAK6AAAAId3dHB0AAALcAAAABRjcHJ0AAALhAAAADdjaGFkAAALvAAAACxkZXNjAAAAAAAAAB9zUkdCIElFQzYxOTY2LTItMSBibGFjayBzY2FsZWQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWFlaIAAAAAAAACSgAAAPhAAAts9jdXJ2AAAAAAAABAAAAAAFAAoADwAUABkAHgAjACgALQAyADcAOwBAAEUASgBPAFQAWQBeAGMAaABtAHIAdwB8AIEAhgCLAJAAlQCaAJ8ApACpAK4AsgC3ALwAwQDGAMsA0ADVANsA4ADlAOsA8AD2APsBAQEHAQ0BEwEZAR8BJQErATIBOAE+AUUBTAFSAVkBYAFnAW4BdQF8AYMBiwGSAZoBoQGpAbEBuQHBAckB0QHZAeEB6QHyAfoCAwIMAhQCHQImAi8COAJBAksCVAJdAmcCcQJ6AoQCjgKYAqICrAK2AsECywLVAuAC6wL1AwADCwMWAyEDLQM4A0MDTwNaA2YDcgN+A4oDlgOiA64DugPHA9MD4APsA/kEBgQTBCAELQQ7BEgEVQRjBHEEfgSMBJoEqAS2BMQE0wThBPAE/gUNBRwFKwU6BUkFWAVnBXcFhgWWBaYFtQXFBdUF5QX2BgYGFgYnBjcGSAZZBmoGewaMBp0GrwbABtEG4wb1BwcHGQcrBz0HTwdhB3QHhgeZB6wHvwfSB+UH+AgLCB8IMghGCFoIbgiCCJYIqgi+CNII5wj7CRAJJQk6CU8JZAl5CY8JpAm6Cc8J5Qn7ChEKJwo9ClQKagqBCpgKrgrFCtwK8wsLCyILOQtRC2kLgAuYC7ALyAvhC/kMEgwqDEMMXAx1DI4MpwzADNkM8w0NDSYNQA1aDXQNjg2pDcMN3g34DhMOLg5JDmQOfw6bDrYO0g7uDwkPJQ9BD14Peg+WD7MPzw/sEAkQJhBDEGEQfhCbELkQ1xD1ERMRMRFPEW0RjBGqEckR6BIHEiYSRRJkEoQSoxLDEuMTAxMjE0MTYxODE6QTxRPlFAYUJxRJFGoUixStFM4U8BUSFTQVVhV4FZsVvRXgFgMWJhZJFmwWjxayFtYW+hcdF0EXZReJF64X0hf3GBsYQBhlGIoYrxjVGPoZIBlFGWsZkRm3Gd0aBBoqGlEadxqeGsUa7BsUGzsbYxuKG7Ib2hwCHCocUhx7HKMczBz1HR4dRx1wHZkdwx3sHhYeQB5qHpQevh7pHxMfPh9pH5Qfvx/qIBUgQSBsIJggxCDwIRwhSCF1IaEhziH7IiciVSKCIq8i3SMKIzgjZiOUI8Ij8CQfJE0kfCSrJNolCSU4JWgllyXHJfcmJyZXJocmtyboJxgnSSd6J6sn3CgNKD8ocSiiKNQpBik4KWspnSnQKgIqNSpoKpsqzysCKzYraSudK9EsBSw5LG4soizXLQwtQS12Last4S4WLkwugi63Lu4vJC9aL5Evxy/+MDUwbDCkMNsxEjFKMYIxujHyMioyYzKbMtQzDTNGM38zuDPxNCs0ZTSeNNg1EzVNNYc1wjX9Njc2cjauNuk3JDdgN5w31zgUOFA4jDjIOQU5Qjl/Obw5+To2OnQ6sjrvOy07azuqO+g8JzxlPKQ84z0iPWE9oT3gPiA+YD6gPuA/IT9hP6I/4kAjQGRApkDnQSlBakGsQe5CMEJyQrVC90M6Q31DwEQDREdEikTORRJFVUWaRd5GIkZnRqtG8Ec1R3tHwEgFSEtIkUjXSR1JY0mpSfBKN0p9SsRLDEtTS5pL4kwqTHJMuk0CTUpNk03cTiVObk63TwBPSU+TT91QJ1BxULtRBlFQUZtR5lIxUnxSx1MTU19TqlP2VEJUj1TbVShVdVXCVg9WXFapVvdXRFeSV+BYL1h9WMtZGllpWbhaB1pWWqZa9VtFW5Vb5Vw1XIZc1l0nXXhdyV4aXmxevV8PX2Ffs2AFYFdgqmD8YU9homH1YklinGLwY0Njl2PrZEBklGTpZT1lkmXnZj1mkmboZz1nk2fpaD9olmjsaUNpmmnxakhqn2r3a09rp2v/bFdsr20IbWBtuW4SbmtuxG8eb3hv0XArcIZw4HE6cZVx8HJLcqZzAXNdc7h0FHRwdMx1KHWFdeF2Pnabdvh3VnezeBF4bnjMeSp5iXnnekZ6pXsEe2N7wnwhfIF84X1BfaF+AX5ifsJ/I3+Ef+WAR4CogQqBa4HNgjCCkoL0g1eDuoQdhICE44VHhauGDoZyhteHO4efiASIaYjOiTOJmYn+imSKyoswi5aL/IxjjMqNMY2Yjf+OZo7OjzaPnpAGkG6Q1pE/kaiSEZJ6kuOTTZO2lCCUipT0lV+VyZY0lp+XCpd1l+CYTJi4mSSZkJn8mmia1ZtCm6+cHJyJnPedZJ3SnkCerp8dn4uf+qBpoNihR6G2oiailqMGo3aj5qRWpMelOKWpphqmi6b9p26n4KhSqMSpN6mpqhyqj6sCq3Wr6axcrNCtRK24ri2uoa8Wr4uwALB1sOqxYLHWskuywrM4s660JbSctRO1irYBtnm28Ldot+C4WbjRuUq5wro7urW7LrunvCG8m70VvY++Cr6Evv+/er/1wHDA7MFnwePCX8Lbw1jD1MRRxM7FS8XIxkbGw8dBx7/IPci8yTrJuco4yrfLNsu2zDXMtc01zbXONs62zzfPuNA50LrRPNG+0j/SwdNE08bUSdTL1U7V0dZV1tjXXNfg2GTY6Nls2fHadtr724DcBdyK3RDdlt4c3qLfKd+v4DbgveFE4cziU+Lb42Pj6+Rz5PzlhOYN5pbnH+ep6DLovOlG6dDqW+rl63Dr++yG7RHtnO4o7rTvQO/M8Fjw5fFy8f/yjPMZ86f0NPTC9VD13vZt9vv3ivgZ+Kj5OPnH+lf65/t3/Af8mP0p/br+S/7c/23//2Rlc2MAAAAAAAAALklFQyA2MTk2Ni0yLTEgRGVmYXVsdCBSR0IgQ29sb3VyIFNwYWNlIC0gc1JHQgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABYWVogAAAAAAAAYpkAALeFAAAY2lhZWiAAAAAAAAAAAABQAAAAAAAAbWVhcwAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACWFlaIAAAAAAAAAMWAAADMwAAAqRYWVogAAAAAAAAb6IAADj1AAADkHNpZyAAAAAAQ1JUIGRlc2MAAAAAAAAALVJlZmVyZW5jZSBWaWV3aW5nIENvbmRpdGlvbiBpbiBJRUMgNjE5NjYtMi0xAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLXRleHQAAAAAQ29weXJpZ2h0IEludGVybmF0aW9uYWwgQ29sb3IgQ29uc29ydGl1bSwgMjAwOQAAc2YzMgAAAAAAAQxEAAAF3///8yYAAAeUAAD9j///+6H///2iAAAD2wAAwHX/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wgARCAC1ALQDACIAAREBAhEB/8QAGwABAAIDAQEAAAAAAAAAAAAAAAIGAwUHBAH/xAAVAQEBAAAAAAAAAAAAAAAAAAAAAf/EABUBAQEAAAAAAAAAAAAAAAAAAAAB/9oADAMAAAERAhEAAAGnY4QXMwjMwjMwjMwjMwjMwjMwjMwjMwjMwjMwicJwAUAAAAAAAAACcJwQFG8TRhRYEr611YiFM+NIM0CAUACcJwQF2V55rt01HzpVRNt0Gv2dHHOx8+KMt31bBrWZPkef7VdUFAAnCcEBV6ouwTqdb3+4Ty+4Dx6Y3np8uMjrLBpjnOn7DSFqoUACcJwQFbHXXVPB0vS0RLtWamXe9b4PsDr3Iuq8dTqVG0Rbr5KqAUAD3Lx605pjulbNfHrfJT49UjxnrPJdKj8LRUvRjMcrlqDRy6JrClrhXjwNqNUlE326qA6/zbUec7XrOWYi8WrkP0sfQ6Nd05rdaD6VuNY0XnOycy+aw6VoK95y47nnkDrs+QzTzeb78WcJwAUAADa+yvEuuqr4s2DQDffdAN5PQCwTrgnAWcJwQFAAAAAAAAAAnCcEBQAAAAAAAAALVC0/Eq60CrrQKutAq60CrrQKutAq60CrrQKutAq60CrrQP/EACgQAAIBAwIGAgMBAQAAAAAAAAMEAgABBRMVBhASFCAyEUAhMDE1NP/aAAgBAAABBQKZSdesStYlaxK1iVrErWJWsStYlaxK1iVrErWJWsStYlaxK1iVrErWJWsStYlaxK1iVP3+tP3+tP3+tP3+tP38GMUyuDmhiiPQLgGhxva9r8hhKWpRlCQxELeUZQl4z9+aC/cus5gYYX/tIYPXGIUACrJjuPJci2OqgaYy0HJIpS4iHHo8Z+/ggl35csouLF4xSDZsZcoVuWVVO7kI8PNXtLh5m1LOPqn4j6dGmXyth8Z+/hw58deQS75dTAfE11AK25xOIhKbYgoImOjkIPY4yM/Kfv4JtTUZDlkz1GcZ25MMiVH0NZGwADWGNsRWL2tK2VcummkWbqWZTWUl4z9/BVFhy6uFZKcIYLidzQVbl4ganZE9iZO35pkHcBCciDgs2mQWUf74+OzWiLMZETvlP38MPlIAgbNJis5lGG581xMnuyz2KU5dc/0jWMyYqjAZ6JK6b/N43jfyxeVXTUymVG8Dla15Xvb4q0by8uH/AFyBMmM13cza0SzPkcxCMsZ/amuYY+1PpVBY5IDEQ0pjmKQgFPecJDlbEqWWw3+txFCPacOf9PEMIxbEkyeG2O1tjtXteMlF3Sk7fOUl3PbtyhvbRRQUUZxlZ+x6xkoyxuxOyLOGmjhzjXfyCUcoLG4/bazjAWGVLxIhiJWjlM8KRMfw7K1muIhS6sD/AJs7X67EnGJ/yzqkHPuT1c5pWrUn011y6YknCl0nZQLOPaIpXeKVA6i5O5Le0JSoqjSd9EtqtFqQdE1qjBpm9rsjq5G7Ve7tuU/f9KLskSGysygjxEXqBlJhATMTkzux9OeUJOpZY95jyhhOiykxNGysyr7yx3kpdU5+/wBafv8AWn7/AFp+/wBafv8AWliPmW0VtFbRW0VtFbRW0VtFbRW0VtFbRW0VtFbRW0VtFbRW0VtFbRW0V//EABQRAQAAAAAAAAAAAAAAAAAAAHD/2gAIAQIRAT8BEP/EABQRAQAAAAAAAAAAAAAAAAAAAHD/2gAIAQERAT8BEP/EADsQAAIBAgIGBggEBgMAAAAAAAECAAMREjMTIUFxkaIEECAiMVEUIzJAQlJhgSRyobEwNGKCktEFk8H/2gAIAQAABj8Cb1jePnMx+MzH4zMfjMx+MzH4zMfjMx+MzH4zMfjMx+MzH4zMfjMx+MzH4zMfjMx+MzH4zMfjMx+MzH4zMfjMx+Mbf7u2/wB3bf7u2/3dt/ZFYgFLXNtnYZwwRRqudsupSp9BLHx6/V03f8ovMLAg+RlqaM5/pF5hZSD5HtNv7FOnqte5j0qiB6nhhU6utK1apZG1hVi06Yso6q4O1r9fR6PQV7z+LWgof8spp1l9mqu2J0foqllJ7zyjV+K9u02/sugfCwXFMWjQVFsAyi0dXv3VuFBteGicNRqfwIdY3nr9RRJCrhx7J3npD7zVUpGUug1KIY6rH6Sh82I9VNKusp8Xn2m39mvq71hrmjxYSDcGN6Ubj4cBh0NMLfx7BRHDMvjbZ1aZ1J2aoKvSsQqEagD7E7wvT2OO22/srUU22NulhVwn+vVLqwYfQ9eOq9h+8uxPRuj/ACj2mmCkthKlFGuyeMswBHkZiQ+sJssDdJogYtmxhKYoghm1kX7Tb+ydClwNuyYaqmmi+JP/AJBTpiyiKKYFYnxs3hLIqU/1lKp0t8Qv4sZqjU9IyX2rMSHvKbH6zEz4DtUid3VTX2Zo+kXIWwSw2REpDUnxntNv7Po9fur8LTU+kPksPfKU/kHYw0A53bJpKmtgLbzGY7Tf+Ey0aZc3mCpSYNxmW/CWtr8pYgjf29FUV8V73A8YtKmjizXu3XYC5muagT2uk/nl+iqGpW2C8uaLf9USpU9s1BeVSVFx4dQd6bKp8CRNLoXwfNh6saUXK+YEw00Lt5CYaiFT5EQilTZ7eQmF1KnyMWtUrVlBUE9zV+0off8AYym+EYsdr/aVvySmQoBK65jpUWZfMT+WfhP5Z+EIPiJUfohIsbGzWmY3+Yn4sDSX2RmBGHSDXHqVVx0to8bz1BpId1jKbM6mjfugCULG/dsYe6gW/jijJ8tO36QPVbCuEi8Q0aqXXb43j1a1VbsLfSJonDYVsSJStZhowJQLGw1/tAV+BsRlUE6ymqUqtu57P3n95h7lb+1h/uZFU/df9yqbW75jYHZdewzOqf5Sxqud7dWHG2Hyv1YcRw+U7jldxiVl6eq315hjg1FLYDt+kZA4TCuK9p6SlbVe3duDL1NKx+t5qUn7SkAWxVRcBL3mW/CPmaNPaufCBtG+vWDaaMCq9tkwKaq22C81vWH3Ms3pA33muNv/AITOqhsS21wUdGAA2K+IkzvUFt5Ax6Qpizti9ogyjXWkBoltYm95h8qukvf9J0n1a/iAL/SUG8NFsB1NH6Qvxm5S+qVK4S5cWszGCjo7ANiuWJg6R9LYL6oW8zG3+7tv93bf7u2/3dt/u5Om5Zn8sz+WZ/LM/lmfyzP5Zn8sz+WZ/LM/lmfyzP5Zn8sz+WZ/LM/lmfyzP5Zn8sz+WZ/LM/ln/8QAKBABAAIBAgUEAwEBAQAAAAAAAQARITHxQVFhofAQIHGBQJHBsTDR/9oACAEAAAE/IerlxzdM3TN0zdM3TN0zdM3TN0zdM3TN0zdM3TN0zdM3TN0zdM3TN0zdM7p+P3T8fun4/dPx+6e2tFiPPzPYvVqBdo1rnEpr7iIEDSPrYjhrbT9RwN6hTKCRqJ/iOBPUKT3d09mTwsjkZZaP6+4Pn1EKQo5eiViOIJ88IcU9B6Ek6H4c+pq7AoNYu35gQSWHT9XCM/Hxrx6zFhmvzNfd3T2CjY0x8W0Uscn/ALEC4wjReUKQT5XFvxgFtXCNetXGSWE66vzLh0Wz/IN9bafyXpqE167JqHIfFZ/noSpoxr8vd3T2ur/IZhZ/lmvrL7SaKb+YecZLVf37CGBev+3ovqvDzOQAnhy6vOagpxMPzyff3T21J16F3xR5Dyo8LKXZ6qBcI4/CNopppXXlBpDy83qws5xrpmP2LULImICuz89pzmAHyKlzDUWA93dPbzAQ2hFS267+oFk+CXBipQfap8yQFu8Rn0GHh3iBaE6RjKbXpjQirlG8kunMyC/VaynQjoPHmwHoDhoYe0STWWir+Pd3T23SLV5PRj6/gj/dJkldFrHXn7MV1rdCD0OKEVNAsq6/8gERXWh9x2EF0f0TdMRvZ0sy6M5CvfqUtCTulcFXRyTh8+phScAiKgjyZdYzWi5p7eyf2WooaKGLggikK1wriRrwRSZGyAqgVYq96oriIyZZZVc/RcD5W1Mb0um2Peg6YgAFpdUSAuo0xPaFalnOO4m4EHhzVsTsH+yzcNBrmZCNVHqIRh0lJyjhi8jBbhOuoUWjJzxMI+1NOFyjEAgFFx9XPgnvazLLrBI9ecJgoaHRlAUtUVUA2qXA5QOBLDS5cHbQaW6kfkODQ+2OZPADXnLfJRx4aQMNgteqBiIOXQpP7AwGAXXMbpwyvqZpwZUvUR3igYBxsYdgk4HhmUERV3k3fKgp4I+gDNjW6vRUtQ2XxGbS+KPDiAU/cwlSUGWM8kCtAROP/wBYIKNzRUvsdrVqmcuN/QkWIknXH0aGNJ9GVas1Ln4nVgVWowsMlh2gtjdYN2Jyi3blfGd0/wCS2yzaqlDpbmk6sFZHSf5FWmpMhwsiudLnJKB0izn2RS9IDnQViDqiQuYOZCCMlteF1uaFfcq8ECGzhmKVCjU/vLqNRndPx+6fj90/H7p+P3T8fmFV83PLfPLfPLfPLfPLfPLfPLfPLfPLfPLfPLfPLfPLfPLfPLfPLfPLfPLfPLfPLfPLfPLfP//aAAwDAAABEQIRAAAQZxxxxxxxxxxxpAAAAAAAAAAApAFAFBABFAAApAggtpNpMAAApAFhcwQIEAAApAR5xwBRBAAAs9hBFdJNopNFcIAQ9wc0Ag1VpAAAABRxhhxApAAAAAAAAAAApAAAAAAAAAAAQwwwwwwwwwww/8QAHREAAwADAAMBAAAAAAAAAAAAAAERECAhMEBBUP/aAAgBAhEBPxD3b4WhMYirE2Z3VPZnWQaEQmlwsvFLwpcQSIQZ9IInCE3hCEIT8b//xAAUEQEAAAAAAAAAAAAAAAAAAABw/9oACAEBEQE/EBD/xAAoEAEAAQMDAwUBAQEBAQAAAAABEQAhMUFR8GGBwRAgcZGhQLEw0fH/2gAIAQAAAT8QEAIQRuPWuNea415rjXmuNea415rjXmuNea415rjXmuNea415rjXmuNea415rjXmuNea415rjXmuNea415rjXmuNea4rd/n4rd/n4rd/n4rd/n4rd9qo1MiTRA3ySeyarVK1IDQnO9TD4363XsCek/dOfUBCJZHr6oYBTn0WrIjQy7NJjxKoG8Bqwq1P5A3PdxW77JjvSYm0G6hBRYRL+Ny4WI0JdzCpDcqSmDafQXg5N5iVb4A/NRA1PTr1evoKAKjrlfseo8pFAmaaSVq20NKi+IRHRQPkiJ2YpNqhZIJSTCcQAYqOgbRmP7Q/77uK3fYaQGEYaIIjKyBDsbr0AlQhLQcZEmzNWtYSjgFY/+UzK4EKABPNjAdfVdmOpysAxZZWRo8ldzPqH7SlYMJT+r0YNJCicXCIGvSG9GVDvNr/VBi5M6NThJGICBbhbFyP33cVu+2WRclkkpG+YeFSwAZEAkDUh7ZoCeKJCcyqBNCDrmoV5AIDMSpXL7I1eBQuiEWHpM9PSdzAQt0wK4J1pwI1GLuQjUlOtgAKWSRXYL/A9l9/FbvtY9CCw6QiScTkuUVKNiu+Fs/c04GGQiO0mt/UomLzKbDK/FSNj+iPS7X6jmn6tuLuavWpKAIHJIOqQTtIVjAkCa3GkHPIIOVDmA/ZUFDxcWEFTA7PzhKlRxALAROL6X/z3cVu+0ETFpm0uXoXqAZGFJNOpvg/Kgz6D9V1d1pA3WERi4UqmNr7SwGpmD3s/KPDk3UF14LOhQ1ALKtSFZggnR3Ny00Acd0EE6MT9NXQuBB6gnZfoUibK3solN2C2xSYn8EZBGpdfMRV2/lCZEBuFtYZ093FbvtNFsCgkyw6SyPZ0o8LZNHuiHdoxLFi3QiFbzbp7L1WMssS4O9XrFdmYi2xIvwUUQ4sBS26X/wCS46IYuOVAd0oWgEIIcZT9rjXirz0iSJOkVrZOQv33wwrsYRCyL6diilsSExAhOu7T1wRIlL2KTleQhKwyUy4HWMUioZEsj7YwST3sUmZIDULI3+pooFSsv/Kk1QjFIWNMUaB3jCpHS1qE2wAErU3eMp4mwwtjMUvrXiNbgx1x6GedSiGWYi35V8+JeAywUST3VfNDpU1fikN2OtZS7qXZqR+ExQfglzPpAwuIoXVZbSDXObacNuFTGS7vWiDWhOJMnr7zJX3ZQwn3ThNjldUEUk+6FCQ3U/WoAnhAtwsBultqcoJnIgyT8jRVjSRADCwko1Cg+7l0kH0WoocTUTuWUTcg6UCPvggLjs1IqiGBLMEuNIqyYWwDITGmKjJqZgoidi2aaZZIFCzImOtRtQsgIzNiXsUjbN3lJjdbao86UQSEV3EhoamdGBTC+6hTN3pBDOvm4sUBXRAMAsGtDEX+KZIEZwLNc70p4NnJPwAn0UAONLu5rpmGFYm7ZhSfhaXDyEyy3s1yHzSjPYk/b6D0FATfkmM+kjMgaW94xMNJkTKjfqKRwFkBhgQj8Mk0fWqkJKE6ulThhRThCII3zpTq0YOfeEmJJk7V1E0n9pctuAyWzGKSXgsCxIAZJpq1QiSO2KV6EOiSQUMxiKBA5YYN1FzqUAcuQ0w2bCD9VN2iDl4mHXWp1gxJyfup0QTIFHDDpXWjlmetcVu/8lS0JYFGSNbUpJClBN1WO9C4Oibf8qoWRfVIyRi0daJzSIwQqsJb5d1oMwmSOtzO974jam8hEbpl7Cb0lIFJtLzXsRQfwgSCRicmjmo2C+pUbJkuYmDSoEp81JJNY6TXVPudoYTnWaaAFkHEsxXFbv8APxW7/PxW7/PxW7/PxW7/AD4E2T5v8+7u7u7u7u7u7u7u/wD/2Q==','','','2014-04-16 03:56:27','2013-12-25 15:39:16',2,1),(41,'NG Gangster Badminton','083-1231508, 084-671',NULL,'','','2014-03-03 06:46:53','2013-12-25 15:52:55',2,1),(43,'SunShine Badminton','0875935790 (แบงค์) 0817811071 (อู๋)','data:image/jpg;base64,/9j/4AAQSkZJRgABAgAAAQABAAD//gAEKgD/4gIcSUNDX1BST0ZJTEUAAQEAAAIMbGNtcwIQAABtbnRyUkdCIFhZWiAH3AABABkAAwApADlhY3NwQVBQTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9tYAAQAAAADTLWxjbXMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAApkZXNjAAAA/AAAAF5jcHJ0AAABXAAAAAt3dHB0AAABaAAAABRia3B0AAABfAAAABRyWFlaAAABkAAAABRnWFlaAAABpAAAABRiWFlaAAABuAAAABRyVFJDAAABzAAAAEBnVFJDAAABzAAAAEBiVFJDAAABzAAAAEBkZXNjAAAAAAAAAANjMgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB0ZXh0AAAAAEZCAABYWVogAAAAAAAA9tYAAQAAAADTLVhZWiAAAAAAAAADFgAAAzMAAAKkWFlaIAAAAAAAAG+iAAA49QAAA5BYWVogAAAAAAAAYpkAALeFAAAY2lhZWiAAAAAAAAAkoAAAD4QAALbPY3VydgAAAAAAAAAaAAAAywHJA2MFkghrC/YQPxVRGzQh8SmQMhg7kkYFUXdd7WtwegWJsZp8rGm/fdPD6TD////bAEMACAYGBwYFCAcHBwkJCAoMFA0MCwsMGRITDxQdGh8eHRocHCAkLicgIiwjHBwoNyksMDE0NDQfJzk9ODI8LjM0Mv/bAEMBCQkJDAsMGA0NGDIhHCEyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMv/CABEIAWEBbQMAIgABEQECEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAABAUCAwYBB//EABoBAQADAQEBAAAAAAAAAAAAAAACAwQFAQb/xAAaAQEAAwEBAQAAAAAAAAAAAAAAAgMEBQEG/9oADAMAAAERAhEAAAHugAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGGFfu4WeAAAAAAAAAAAAAAAAAAARt/K4383rlfPo3xdHvnD2TtkCf06Rp0Q3D0AAAAAAAAAAAAAAAR4Cy3wgbvauZ8982/O+3lH5k19Cxy+d+iTIeV8ZNRlhsutpNTbaMwWVAAAAAAAAAAAAANO7U94V57P6Z75H9z2Gylt9HxOerZrxwtLLnuh43bV++FX0JLz3ZP28orjRm3jTkAAAAAAAAAAIHEnc0lNdGHR8typ9Zx8ye8Czwn9KjSYvtGnfHT411jGk4eOvaKTl1ycTN3t2evZogs6ywvpnjXhAAAAAAAAAc5lFK7t9oAcp1eopr7XsOIj2FfP6NElxPadL3yXL9tqWzxZN+Pmqqu5GHu7dmvZfFYV9hfTPGzAAAAAAAAA17OeKfuaG+AAAAOYp+i52XdRJcSTSee8vGTG9yrHHTorx9P7r2c/sbdmvZeWVba355Q14gAAAAAAAFdYj5X9Ej8efSHyiefSFHeAAFdyHd8LLrIsqNLTH8y0OTn575nnB3VvQsd3yvScnn09L0ECfHQuqe8uo9GjK894owuYw6gAAAAABSXYArbIfNcfpny8+nZMCHS08U775ja3S6g2wLGfWg8/ZSHIZVM2mdfeUk5n6ygw1UaO6oYFx5dzX1r5tJ05LGp67l5Q7/AIPoPmp13afP7o6ul5G4KvDv9JX33zyvPqbHIAA+b9rI+dn098tnH0R83xOs+e9rbmPMukJnK9toKuXYHvxad0ML3qVMrdHsx0+FtqohvhWM2HsyPZy8OnGQ32+1HRTW3nokt75wt/djk5fQjHIAGjeAAAAMI8satoAARPIukm5VmZHoOt4/3o6NW+NOHuv1RX7LhyYQup1bY5NXsuBN057yNlWaM0iRUSi4AAAAAAAAAAAAAAAq7QlwELqeds68PCdaVc/nLC22Ux3bsZebXLlm7nBLwAAAAAAAAAAAAAAAADypt6xbCp6pR9BYWHPvJd1Y8D9As4gWYwAAAAAAAAAAAAAAAAAFfYYJfNW3Vm+sBKd3/H9hd8+E+eAAAAAAAAAAAAAAAAAABSch9K1w3/NpPcyfNEaWT5Ie+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf/xAAwEAACAgEDAgQEBQUBAAAAAAACAwEEBQAQERITBiExQBQgMlAWIzAzQRUiNEKAJf/aAAgBAAABBQL/AK0KeBA+ftMvWJxMFuyfPQF1R9nbPU0TIJRZhmp8o2GemdiZAT9jOekN1v7i91zyLGdETPMpLqD35vWrU5BWhvJKbBR8NuJyBjPVG0H0aIpItJLg/fNnhXPO/dMAA4ON6p+WxnyW3pqJ5j3rPNW7NCUjIlBxOyy6GaaXEaj02TPKvcOtIr6PPUh0GfplKmreGi+ndmyj6CndR8pmeZ0PptX+j21q4mmDMleyBp8PsPQ4GkOneH65Qs7GHvCUGGjjg9meuyj5jZR+Ww71vbZLKjTiriG2zWsFBvnq8MpYY5PGafHFjZn1bAXSeyp/N2Het7XKZD4NeMxfa+ZiwasAFYauxxa2P6t0lyB+gzwWw71vaMMVLxapvXP0ciP52x/VukuDL11Hpod630+zzZyOLw3T/S/0ckP9mzPq1O3po2QAIsd7S/29Duj9v2d6t8XTx+RPHMRdr2Y/Quj1Vdmeup3eXWdAfICga7L1kpxbmOHZccL39NXc70libp3a/wCtcxte7p3h+wGv/UpaT4geOquWq25+Ux61+mzNu4MnsZfmVw6E9Hdqii1qoiK9fURzP8b5e0xzprJxeKwKe3j/AGL6FWzF7CMrjXzdhdceenVq4mmtGdrubatLqJbkSNld3eBnoU9IxJDIHDBKeITES0LUMaooFS7B28jHpayYqmbN2vY58rmeWsq+WuFf9Iwf597KNm9cWsVL1aylWrpniJsyHiGxE1MvWtfoFkgjJ/MtAfiHRlCwrV5zFzM0FVNKgs1fyqRWih+yf02T512o7UcodYOIBS5ZNYYi2RnbOoa6111xtwqlBdaMz9T7D8s6nja9MfECiF9fK1XVxedV+JuUai25+qEFcyOUmrgVL0CErh1OtYi5gTDVXK26ZR5j8uZWdbJUryrqvkv5RVMBJ1O4OTpmGRyMXdVa41a3iP8AaxVX4WldT36kSyo0r3IpVMSUwIuZ3CKCkgHoEkNl1JIpSzGA16ULQGsljXWyq1V1Eas112kR4cjrDE0hSXh+pMqwtJUiMDHyElRn81iuu0l+IuVDDM30ajxG7ReIbJagsvf1Rwq0TdoqvB+HPOljUUtmJW3e3XGHAlYSXkTAhgikA1257+g+hP7Y+ulD1M9sQiWvhq+hWAfM9sqiHFDjswFlriBt7mSAuvRlyXVr+eS50Bf21z6kKnqX1yUqf0JmeIU7uVYtEelukm+6vccR2/jIS2wiXiTj6bNoo7U9Ov5/3/29JHUR0Ir/AOOmRAns7lWGrZpLgVQ6IUSOmLnv7qO6vRRwU7qjQ+ukB0j9lu1eJOOYVWa/Q4d06nDM0NBypiONKDrL7PNFUMbk1r0WRslqL1mNLyrI0DU24EemPs+R/wAL5Knlb+0Xo6qfyU45t/aCjqFi5UzfFq6n/ab1Pv6ISCdJQx5V0RXV9qJYHr4VGoiI/wCWf//EACoRAAIBAwIFAwQDAAAAAAAAAAECAAMEERIhECIxMkAFE0EUMDNgI0Jh/9oACAECEQE/Af2fG2fF+uw2DKbhxlYBtiOuDAM+CtJ26CVlZFORws6hR/8AIN4wyJSp6RKq4b769YNhLpQ1Mgy7tfaOR0lEbZlq+UlNfnhcD5++IvSXX446B10mGn7fLLI/yY4GVu3wKJzTBl32cLxP7S12OeBlbt8CzbNIS77ODrqXEUaYp5cwyv2+B6c3KVl1+Pi3WMW0jEQEDeXB8CiWzscQE1LfeHc7QNtvCIHyAPiFixwsfu8AHBzEoVNPIdjCunaaD8yqMCIgKAGHlWHfwbSuQNMrAhsmCVOkU7YlZvjwkcodQjEV6WpZqAjMGMZgBmMcnPh0S2rSD1lOxop8ZjWlFuol5R9ltIO3iI2lgYp1DI4eouDVx4ttfNSGk7iVPVMjlEZixyf2f//EACYRAAEDAwQBBAMAAAAAAAAAAAEAAhEDIUAQEjFBBBMiMmAwM1H/2gAIAQERAT8B+zmq0O2nF9Kyd7eVUfudK8ervapwYQF9PM/Xp479r098qmZH5xoEDK8l14VdsOTQgqJ6wRpVMuVZst0bwqXywQino8aM4VL5YITuNIsjymcKj8sAIJ/GjrBUQ2TKcQTZUR3ghOuoTkKcAntBoaJcm8YUWUouheo4PshcoWwQukeU5QJlUm94YTxdVJhU29JogRhytxW4pv8AcdnGKWytn2j/xAA8EAABAgMECAMGBAUFAAAAAAABAAIDERIQITFBBBMgIjJRYXEjQFAwQlKBkaEUYnLRBTNDgII0krHB8P/aAAgBAAAGPwL+7Xr6TSXSKuM/TXHqptMlS6522AfRCeWxSeLPZ6qZXb0DedJe8fksZd04jYqCBFs1M2d/PuPRTNsgbjkrtgst6bE/PO7bAUwpi0GyWyPM+LFa3uVdW/s1X6xncKuE8ObzFh2BZ02ATkp7J8vVFdLkMyjD0SG5rfy4/VVaRGkeTb1eHu7uXgvcx3W8KT/8hk4IPbeCJixw67UsxaWbTvLauHvxzlyX4jT3G/3cyqIbQ1oyGxrfehn7KFPKYsiDrtTt77TvK0Q7478Oi/E6TvRzff7u0WPFTTiEGMEmjACx3Xb7WA7TvKOiOua0TKiafGwB3B7Jp5jb72jZPlIksyAoVPWfsmO9hWUbpSQ8zEgjiOHdOhRGkw57zcwV4UVp6Z+xd0v9gyHkLynu+SqdgFrGzayeQuUV0QzvFo2SzRADLF5TjElW0yMvbzeKX/E1eE9jx9Cv6zR9QvGhteOlxVIdQ/4XbTm87RZSMbXn5JoT2c0YAa6Rx5IMzzNktlv8P0fidxfsopEi8skXcyqz/UdPyXiQWz5i4oxIBMRgxGYQgyD4k91zuSE8bK4rscAMShDc10OeBKMSKbshzTnMYGtJUyJFBE8kHqYRKBdwi8qhrbuaLnGQCZIkMBuFmrg78TmocSKXjORzU1RozdY74jgoTYxkxzpFtMlNaTpDuP8AdQ9AgG4HfKbDbwtEhZJz6n/C1eFBYO9634UNw6XKmrVxPhd7Buhht5xd129U3gEWf/dhe4ya0TKfpMeeobc0KHEgikOuITa56iEL1NjQG0ykAj3sEMYlUWSzKl7qeBgENHhcE94qJW6TRMTWo0UGnMqo70TmoHzX4XRboA4nIUtqf8ZUHSG9p9UHPisY6W81xUQ6PFuM21cwiYjna52JLV4bXxD2kqIDSyH+X91VpDtY7kMFJkJjR0ClEgtPWSq0U1j4DitU8F4F1DsUDtM0pnvSIPUKph3veby2SAQ6Nk3l3ULSIrTM79+ar/EMHdN0PQ5urN5TILfdCgD8xTQeN+85RG9F/wCvUmsvVb+IqZwQlkhPFykjTg7NXY5lF9ZE8QqYbZWaPq5SHETkhChjuedhhROEq/SN39N61epB6nFXOiD5qdBefzFSaAByGyHuhtLhgSNswoomD9lXAm8DBzMVJ5q/W1XwGfVSZChj7qQra0/4hCJHOsifYICJcRg4ZL/U3fpU2Al/xGxusYHUmYna5jmzGSm1omipFXBVn5WDYHl95oPcL+RD/wBoW6xo7DaZJtRe+jGSbCiMALgSC0zTIVM54u5clDhtaCXzxMsEK2UuldIzBCN0pJ12Cb1QWA+q6rqEDnmEHcxNEME5XTJVZYZ6wMIOSJTY0pVNqktHohicZld7sMP3ToTm0vaAbjO7zcCoyGuEzOShugvruIeaqpBRIlTW601CbbxyWhxXmkFrpzyKhUbzGTLjlgrp4uH3Tx0Cb2QC+SKn0TIgyZJwUL9ITmRDTvEzPJB9NLBFbKfKeKLWRGk9CmwnHxGMpozmtBZFdRTCIJqlyUTVGuGWzc4md/f0CocQ2m2z5+ja1mGdnhsn1W89gV0Vv0QJAIHKzoPSNYTuclTBbP8A4XFT2C/mleI0OHRbpk5SHpD9mF39JiDZh9/SSDmnMOWwYmTfSq2cY+6k4SNkmD5oMHpe80FfymfRXD+1n//EACsQAQABAwMCBAcBAQEAAAAAAAERACExEEFRYXEggZGxQFChwdHh8DDxgP/aAAgBAAABPyH/ANaTzvWG/KTwwclGSQ5HWeOxUxXcDPyjrtSftdKxp7tKR4puzpCvrWdM8C/JOiRdRhkslcMPUc+CwblF9MUjJK1bHPyAdb6N6G2OpSLLfRFSEkSJ8AHY+tBhDjUnLGKRaUWbWfHsM3HelKRXd1ZqTX2VJvMaONJkOLmuKw1GQmSonkfHGDyq21xHWgf/AE0iYacJjfSycujka9g2+JCnp9z0pGH/AFbxUAPUlPpQlG3NBPYrDrnoymWaeNZ1cGmbl4Z2uH4e5GcP0Cv5xMnZS0drtz6tFX/n8EUzdrS/ZUQmOXuKfSGTo04a6CLXH21m1+jXzPOuLrgPhkhmBs638VzW33nB0odg4HgIEtb9Vo9qVs4vYdO9HX2dYDZvo2q21b9fsfCxtoW8OfxUkBsRd3d/EK8cJvQeTxgGnkM+HdIOc0UQroI67/hxQZBOlHjMNMD+j/KLoXw7jS07WUp0qW5NN+ou9fhATdXaag/6ib/5dgMa+zphoMh4p+tvdoI73VmlPZ036mJ8vwjWQEvoxSYx7xFH1Hmx6H/HrCGrH28JpGxR0KtFWLVpco4GB0pNpscb/rWI9PAoFWAurXGqnJ5H3oTbuCJ/r/73Bw9b90lO2halypf73KXDcz/xUQlnRntz4iQ2JSKRyaG60kms1l5llWdukvnRfsJQanl3tT1TRhZy5nRA5NBEOPBeNSGfy27RiLF5S0dqSAunkLfBOOwX1KvBi/imoqUC87HlrYJC8aW0sBTRNhkQE/VRYMAyuCm/gQb1Y4DDFZ3WhZwJq527nmvXAcV0EKVGEkaCuluqTwlWroBgdisdMBMHA/NIlFhjHaoEjAEy0iIFpH/qoJcQYhtSiLYqF67Okn8VL0kBgf1QGwLyNFWJ9d/VWpPWqu2oSX3pMkTzez/ggx3CIhIeLNIMEgHbDS7KA4Kg2JFYngqdpTJmErBAYf260PLliKhlv+NG/pSO7S9MN4CrY436lI58FbASu1gwWJpitym1RRXeo+atuP4KJQb7MdqMJz+NXeWvJ1enSoEN0b+XFWmJO0Ln90qxnCIR+9O6sAoAd3sg4IroQBY+tL2iziedThXaj+a6bghr0ysfUoxbyP0O9AVNwXZpqAikw7eK1wexL2oMEjdb/p4WjosXlzSd17cit6KgDs4TyomwUMiehWBC4m7u0v7GCoefeMUG43FObdxwKObTtdph2x2pw8UFgQ5b15cahE7ZqEb6CGnRcnuVHguQKtKN+XQGhNFeqrGI7j5dBXncMjzWY+381SqFz9/+KlZ/EH7USXeo9KDleAgPDvqvRPHt6U7rkrmNRg+VKRobXvtUC/eiKuRXor3oLkpioWxXCL33qWrq5+lSz9370GqVnP5caJ7HHMOm3egRSTLiocXLNCBUoEC9qYmR5aEUUFNtAbe7qdKF/hxYD7mk30b08UawAGAmagAKJMRJgjNTvCN7fP1Q0Ad3MI9DzUdEUrkDi5W6kozmrKs380wbMJXjFLBc1gdSiu2FYjgmjjIB2Kt/EUKjbllCJ9GgW8StyH3muhBNbFTdxbFEBCIRABRigCsAhU3+nxebLKWCHfaoHt+kI5yzF/WjcqLZA5z0HG9AkvPiwW9ZpC2EnlAJ3pUhCLbN0NN5bRfWj6v7U27uO2hmOG80ZOAzvSAWxyCPcr+VxQITFSBV7Uql89sk3cFSY4wa1EqmdwEWN6YUx5ZY3lGQw7BzseTb5BZnj6lczneprjbwJoctD0aXDn5MVguxNutXzcrJp8h60FPqrUK77qiZJlzUS+d6vj8nEEhuUmjC88UZi98UZsRQhPqBT4eSDUmPg3KA8R8o5XHv4UoOmnPyheEJ9PDAzr+UnjQhrMS48COYM9X5VCthYo5fxOghsb7Cr0O68vysmC+pQDJN2ULAB0/8s//aAAwDAAABEQIRAAAQ88888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888g8l08888888888888888888xRTQ5w8888888888888882DUARF/c88888888888888joF/BCfX788888888884w4smACPjGcvt8888888884gM88pgT342dWq888888888oY8888rDvovXUv888888888o888888Gj0VLci0oA888888w8sAYcKcVi3E+kEw8ggc888g44Mk0D7ZESvdiMc8c88888s8c88kcLEFWybYQU888888888888M8jFL5ZncM888888888888888c1yzm8888888888888888888tLBF88888888888888888888qQr888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888//EACMRAQACAgICAQUBAAAAAAAAAAEAESExQEFRYXEQMGCBocH/2gAIAQIRAT8Q/JxvEHBcEo4uDslwiXwERUcEa2YvMRbZcf2iBZHqNwMm3gVpuEoNQabGP2aVOME7JRlHcwH32CMdl9R0oyyDHduonqYFFTaG/vzc+JiP+4S0B+4K/f6bTfwPi0H9w3CT0lIPEuEbRVTzwBUebgtSwc/Ri5X7UkoO0PAcA1cwlwVtQtfSDftGq3uMlgTox5lxC3wPiExUZ294rntKmoPGNxDJqJV8H1jPPCJSX28xAeBMfCg+hndghjMCBPEpFZd8LMpFFqhGbPeYbQ/rEoWO3E9Sowx0J9Km6M8WlP8AhLEqXtYgW1/J/wD/xAAgEQEAAgICAgMBAAAAAAAAAAABABEhMUBBEFEwYGGB/9oACAEBEQE/EPs9hszPEzsbhS+kRf3MU7IgLeDaJSBioLQbYiNSu9O4z/Jvfn28beNcR1MsaZVlmRMz84343g03EVn8qdR3eYcHvFQsFtw2yPj08AZvMYSyXsw0yYm4OA0m8VQR4fcttLvuMHSNbwBcfgcsQCTupE7keo7KY4BAY0mk2CWKssDnywUrgpgrSCqTSDIe4C8IOY8zqwB1FX2YNThqC4s3Ae5V0zxHJEprwKtxTVwztlVj7P8A/8QAKxABAAEDAwMDBAMBAQEAAAAAAREAITFBUWFxgZEQobEgQMHwUNHh8TCA/9oACAEAAAE/EP8A6H5/jY4ysUGOYcP8TEzKRIJJzjWpbZiR62K2b9aEpGEwm9Dd2hv/AA+tXfkWOhY9iuspFnqNmmyBY26dnij2VN6Siys+iSNsDihAJhJPRoJBjTloRJGRvO/8B19f+CqUqsudfRCeRIjcd+pUet/hFjqnNX1zr6dcVfLdirIu/wDtU0AXajmvQ8mn3+k7U0nuUrsXqGCbIHvRpowMPOKhPJAZmWKz6oJd3NBs0tcnP639VC3Ej4Kzoum3B6TY2fLT79HQyDIxpSVLyMq+mkdoKdQ1Vbov2bZqUzJkyeihOxUzffNfKM41D57+mCXGtIUrtuWhknc9HVXBKArAJ99jGy8lGHq/MU4dzJNuFGcTk2dqcdfo0zYduvzUiSYblXR3E0K/qpF6f3UgboV2+5mK8hJnBu05ubMI93QueXHDyXwVjiNKB2dR4b+kC3RSSGzHq7XE+iHJnjib0CwZMz6hcgddKVmV4PReL6y6hY7n28f4HL/cywVOA0LfDx9InWpGxhFXmInzURgGSewFGBRZIPMkOo9qMAFAZJcHC7OiX1KNzuyBI+Gh4muCF7vrcX6v6ZpGc4efUsBsj8f6qZvifRWOfVTzB+ftgARkmXAmW9tWtqAKzC2A2R4gW2q0+KLA/vl+jR+oLqyl1V25qTiRTqkPa3Zq0cxep8zN5v8An1WPD5rasU83YwNyhEEZEkaQFdCaUZxI/JXT0/DWv24LFCMlmi3ebDeejMI83cby356aVnP0zLxUwJmPzkow+CoArip9EA9mPX4yv6pWr/agmTD0pdCuelMFoNOWN/TPo9RZdD5+04XZqCXvatReOBCI4iDdZyV2/wDHY285H/fX4z6KCbqjnNOnFqw9K4pH29M+j1g3EPF/tERRZGim+YjvRmxqhklu9vagi2sf+M0PP5n+etnYrT1HFsqSkZWlhumlRe4jFwG3ms1nDxb0w6fWN3b9oxAG5i5IeFIdhpLrBWAWZLTBhsxmnxm7Cnm94q+3/hZBKBxDf2n1ENv+dRWB6OKdEHJPVXsD5pCBYDtd+SnwSz94Jmo2tO4ZExmmxwpgBhMcX9H4qBuXn6DLjkIA3eKS43JEjO8DLK1DnWfBSRjR1Vr/AOsTbe2aNiCAwdKRA63pScNw4Mye/ig735ZCPYo6iwmDtK8UgC2I3wQx0Zr9v9ONL2ShKuInJ6doRX7ND2py7LqV0p0qM7pejhfB71J0O87vaohCGYFuLxNAEplxJhIiOSi1TQNTMcaHHoBMweYoiGLPolqGVuySJMA7EcyawCbLAagWY4qbAIycT4Xv9j+zUqRmmOy73npUiUWhHuRYHFzKUCJtwpSQCMkAzreYpNwkxwGLhxPoXUkywmQOJJWAp6bO6VsSmXMPWlrkyE6YNd9oqbhATBdX+qZYBiUNuaGBimc4KjCBRNCm9HWvjVVTU5nwP9UWDTGg+ZaexBZoiBZja1G4TNgABf6qR/TICZl5desUeq+BzTF0yBL7AZcf8oa1HIK3IsBpEGaXSShAA5dAzSKEUQXgGfadaMLNQCwbkxOs04FmV1gJo4TRLe7KdAHRrUUTwBmU0KryxpUTYUGgjzRmDNdGCG6uO5peaLXJ0IPmiN/393SPahNYIoS2wvSR4ris4+ocqQ0TRBF2IvJE8V1dfpSEaRcif3pQ0IAYIK6BE7VM3te9DYYbgCV8DTYTsUBhS4Aypq0ulYGBCIqpMuulNTB+CbXJ2T0DijxvgAgtjvTEO6OIVNDyPNIPARNJwe800UQE6jq+b0p1nCMNrQpkMCcG/s1fhKRfHLR6QCFMEg36TVsphBhi0vBFt2geAqKqA0vKDQS3UMDrL/09qNFEYR7HTrl2igftBQ7De+/ioYRiZAllfZrjXRwNlvW6wVBwQ9aB5u4tJfYVKM9BARF4HByJQ4TEYlbMJZwjkaVaKKDQVLGqpK9KekEYLPZbg7NIDCGRHN8EdGs8ILrNpyvFA9lCO9paUS7AI9IEolxugD4DoYetF1ojR9kudETihQrSSyJh6fTr2omXYoQCuwu7Rl9qT6a7Ers+pexen+MHw4CwElsum4XMF2Ewr4UnOiUcFpZudFXmpiNkRF1rxMK4gorTA0T37jTkKRXOYD80cbgOlxhB6EW3mogqlCXk/wAtQtDYHA/7TEYbpgeIzU+TiyS161HhLK3v0o6ZQOV3xTvewizGD/CtD9dquVp+G037hF/FGTLyl4RB0q1Xe6y5hcXvhzQ8zwvK7rq9a/No61bPbzejZlw477kKs5U5m47GlaU6GCiQLAWbl9Kuap4iR1UDzD0pG1Jcqdw3OkDipgazEnSWVHHlx9uAPcaCsMA9gfR+5pP6yX0bH15wCDoE0Tfs2y3VxUAci/iSjWJrfvSU9VonUb5aa0BUPjCHxQ5LQIj5bKcE9KWi03qEN3N722NaGuetxnJhlaj2iibDdaMfsKAA8vMdgADp5aP21KLXSFSTrb0QUJNx7TRQQo1xYi+lztWHMXyu04rrpPm/5o8uLkZvxU+o68p+Kf2EZTeIxxd61EcMT2pT0PzUDbpRFu3pGG952/SrBx9r85P3Suhkr5FM033X/Kv35nYq7n6ZfT1oClQWLYCm79By4lFYlketR9iBiOIpF5AQkW3KDzgUEC4ZnhViJC9IAUVwYTCo5qFdCSCgYk2JHxrQniiCUlr4uR2qNYpIxMvKHSrYwzuuI0xU5v4unjxV1EQG7ATzE0RGRDJyXmO8nikG592VN4nZER2o+tsIEn81md9OJIQikk2yxpRdTBAoRm4lsjI1Ms3sts70Qdpd1K6O2NKFDGZegDVYGDFNbM3WgCgjKEQ/NcbY+6M4W6GqUI5b1DBoDTAzSpCBIZGBB5HjItoIRxEpqZpoIICliEA7UiJfrpiosmVQmAJo/Vdd1k3EiTzUQC3SMsSf3ehOzenks+aWcYEkzC0ujUW9R71IjBiRgLAj4PLTx8XdyjPSD3pnKGC+qjVFekmpQtO/D0Uj+SGKyTZSUguJyU6O+smKSCyObwC1Pt2xBF2B596gD/ftosoYEQiGaVsgSBOJjZtOlTsRkgoByuSyYyRLJj7rWcRr8Wq9rxD46Vpp02rXnf5vXn2tWVQrAvrH9c0lwLFBGuz3moRungbULjmT9vXMcVvjliajme7N/wCqs0sbdIxTG1utOwxxYNKf3X9vFOsr5/Wpd2X97VclInd/eniplywYH52/gEEvTK3Fr8B8lJHP6at01urPVQfNXQHQVPYrJBGAHy1ZIlyHRh8FLGUZYj+acCvSu7UBYIjT+GdAJkiybNR2oqIDqztxUIRMGN01ToVfBNC+WahRGcIH2a1GEfK1H2qPg5QHWKHkPcd/4h4kY2eP0uQinJw6fxISMj5h/H0pfiDwF/HvWn8QIwtBMn60QULluaPch+gwMc/Vp81Ml9v4mPsAVg7cOzQMKwij2nSpImlYkwox9d+KSiRdl01/z+K/SuAEGx5Kj9bmo+ZaCI9v/ln/2Q==','','','2014-03-07 14:34:24','2013-12-25 16:36:48',2,1),(44,'K-Fight','ครูกุ๊ก 081-306-9501 / เอ๊ะ 081-821-8765','data:image/jpg;base64,/9j/4AAQSkZJRgABAgAAAQABAAD//gAEKgD/4gIcSUNDX1BST0ZJTEUAAQEAAAIMbGNtcwIQAABtbnRyUkdCIFhZWiAH3AABABkAAwApADlhY3NwQVBQTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9tYAAQAAAADTLWxjbXMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAApkZXNjAAAA/AAAAF5jcHJ0AAABXAAAAAt3dHB0AAABaAAAABRia3B0AAABfAAAABRyWFlaAAABkAAAABRnWFlaAAABpAAAABRiWFlaAAABuAAAABRyVFJDAAABzAAAAEBnVFJDAAABzAAAAEBiVFJDAAABzAAAAEBkZXNjAAAAAAAAAANjMgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB0ZXh0AAAAAEZCAABYWVogAAAAAAAA9tYAAQAAAADTLVhZWiAAAAAAAAADFgAAAzMAAAKkWFlaIAAAAAAAAG+iAAA49QAAA5BYWVogAAAAAAAAYpkAALeFAAAY2lhZWiAAAAAAAAAkoAAAD4QAALbPY3VydgAAAAAAAAAaAAAAywHJA2MFkghrC/YQPxVRGzQh8SmQMhg7kkYFUXdd7WtwegWJsZp8rGm/fdPD6TD////bAEMACQYHCAcGCQgICAoKCQsOFw8ODQ0OHBQVERciHiMjIR4gICUqNS0lJzIoICAuPy8yNzk8PDwkLUJGQTpGNTs8Of/bAEMBCgoKDgwOGw8PGzkmICY5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5Of/CABEIASYBJgMAIgABEQECEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAABQYDBAcCAf/EABkBAQADAQEAAAAAAAAAAAAAAAABAgMEBf/EABkBAQADAQEAAAAAAAAAAAAAAAABAgMEBf/aAAwDAAABEQIRAAABvAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADWqRdmLKAAAAAAAAAAAAAAAADwQ/Ku2QhjseHMAAAAAAAAAAAAANbZFIuGpUy+/ea7Zf+b7UAbvUOa9JNLeo15AAAAAAAAAAAABDkwg9okj4fYuUHFMOzrG5eKNNElesWUAPngyNAb7QG+0BvtD4SCNEkjRJIoSqKEqishIvn0U+4VUnsmbTidjLVZ6u26rG4cr8+/F8LH07k3WTzqoGm0zmgfka70LasV+eqYLfJI5zj6BAV0ra0TsudOh6atJ9dGiCoL5qlP+2r1GlTWiRmtGgez8ttj07JjyCtWWuFigp2GptUbTVtnn9vFcIOc18/kRl287e69w/sBhpt1pXP7MxI+5m/HiqVzpUW1rzSrPGtT3Iy506axt58E0zQU/BRrd6Ne6Jbns/z1P35KLpTsFj60xOZN/fx/vK+qcr05eoZMWQ+16w1oskDPV2nRWvfiw83txE5WZzXg55dYXJv5epaZ7nh0ej3mjc/sZZbempy90a9UWae5iKlK9FYvlDuyJBR5O/J7rc7B5entalvqBaZ6Gmd/HrNestaw9i97mpt9PhfeWdT5hNekZ8Gc8V2fgCyVux16nTXOgUi9U6ed2iJ3KdFoiJh0+L85N1qjFnpO1q8/sXGWg5vbzftFvNLp05ZSPscTQb3Rd6nb824ewQxQ8rFLXOkXSl2wt0zDTGvmwNXtFZx9W97WjudHje+Y9H5vNei7WrtGCvS8IWpRPSLy88jOuxPmhp6DLcxli76dLrpbZGO0Ivatnlc8rdNSKhJjoGjKcyLFp6O/XbZ3KValbLS+iUeaYLRGTCKBdaN0uXNJ7Q1jNtfa+aE9qbZ0Xa0d0j4OcgSobeeQLbzuWiCchsg3sWrPlRxyeQlcMxGlV2Zn0WSpXiml95R1ikGq0bkV7JaowsdStseQc7h3zm/QInfOeeeh4iDi77nKVqdG52Xff0N8j6/MVcs0bKeTaagiJ3W+G3uROElcsKLGrgsau/CyKz5LQqngtyo/C3qj8LepYuiiYjoChfS+KD8L+oGUvXNN6vnUdvV2jFS70Od+ejDn/u+ik+roKP8vIo/u6il+bsKcuIqHi5CnebmKhmtIq3qzisrMK5knxCfZoQibEKmhC/JsfPoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf//EAC8QAAEFAAEBBwMDBQEBAAAAAAQAAQIDBRU0BhAREhMUMyExNSQyQCAiIyVQgBb/2gAIAQAAAQUC/wDBpF0aKYbzPZXONkP+FsVytz1g+f2H/BeTMmlGbE5o041eX0/5ZEnhTRuf3V2Qsh379spGYxM6i0M7N/NJCHJRGPfS9ZmkIuetUN+zx0CYlkYQ/qlK09qdn+eYFUXXbB67ENfMe43WrYTEBhZH+TZpiVT5YJVm02v/AEES85CGomTaJk32XwhGEf6JTjBveir3oq96Kveir3oq96Kveir3oq9+IvfiL34i9+IuRDXIhrkQ1yIa5ENMcK/fkU12JhqmXpxZeRv6H7sH8h3fqPF6r5O1c2VwxVjcOS6liEOnwb0+EUnxC1wpi4UxcKauFMXCmLhC1wha4QtcGWuDKXBlLgylwZSIpkPdD9ixO4u16aeTsQ9r20T0pNOgyVlbv4usmTx0ETb6NXJzXJzT6c0NY9tNpdVU2NoeSvvhRGenPxhpuqboXRuvhQ3IUKcmhDkqkMTEhrD667H061yVSbTihiYkd23+Rh+xYnxrW+FFS9AGuErJemw4XdnWNUctHpEGG18OMrVUPTr0uqH+t9s/TrutldMIb13Ko9C3Ll4E63yonpVk/HdnvO0uj29ipAlbWGM47Lb/ACdf7FjN4QWp4e2RFz3W5fU6UvIAmhJ4oC/3Iuh0iyn/AE/doP4lh/UrRl5Rlnw8oulVZO4GqyJWu398fuV0yyfiWs3+VA9L3bf5Ov41kfZazt6S8r+Qaz0r9x/9csWdN76Icg7+zlvjUd0qjbODAWWzJRvVAdXr/Ghem7tf7KRN0orKj4UrX+6E6bu2/wAnT8Kxu7X/AGqyh685HeYjHGyySK8eT0aWgKxY+UT7UszpkBRXMaMIx7jeqzur1/jUpOwXvCEGXdZdrfK31cymHtlldMtf9qE6bu3vyNHwyfyxxvutdR+jyi04v9Hyp+NSln1SMWpCus0p/ENZj+Ivcb1WX1Or8CG6Y3y+5y28SNb5q/kO6VZXTLW+NCv4j929+RF6a34sbu1KpzeNFviiRbI3ZsLK7u/fCWcVKYKyfg7j4y91lR/zEQ9Sn7Kku2mD+LrIb66vz1/JodIsvplqu3oxi8mD+g3ivVrZ978gL013xYf9VmkHW4+iLfPuKoiTQGD7GcawJwBvEd2NHe+RwsZcqEq765IvToGmxYp1mlX7JUEQtysKz1Ky4t6N2iRUwpejetCLRCArIMnnB2Co6L26HZ2xvLu+aJuWR5M1vGL7vXi9Mc7tTh/e3ZKYivauhd4/2yKKnHHse3POi1enrVMIdrkWuNgkWOWVbK24p/N2fzG8cse6Q99f57XAoqFxR6iCYU1wYGXqam3D09Daf1Qw7Gg/Zt/7F2kiuzvRaPQ5V1lF9Fj21AeWevku9Or2kb/KXFxr74M0938gD0Rv0qxH8ZkP6eiYTA8uc4e0Dq9TP7NzdbTPHS7Qszvc3m7P+EhWeP6EtvDs/hx84YYky3CabaWrHzZ/Z2X6tWt7fU7Rx/zmM8sMbMrLzuzX7l2jb9J2c6Q/osS+FBVRVFzgje+Kug4B/aJmlXrQ8YEj/rNqP+wA6E3614P22B/RO3GFhRnvJsXPHKuhh3ekdv8AX6ZUConUPVhWQ8+KRGPCn1f6fs/4xGwKLKytGNktcqHqC4oxFBi2c+226degWxQHrBC0SHFzM6QU0aLEukEKAUbYNbXwgaFAoFegP295ubUZb7Wp6XprlHwZbPXgdCZ+zD++gBE5Qwh2laLCYoYtYlVmRY5xOeOVOjPFoldVC+uIlEaPQq9P+Put+tEbwF0Z+SOMVTQ3JCLkxVygq5QVcsMuWGXKjuuZHXMDrmR1zI6bZHdS2BWXMirmhlzQ65yhc5UudqXO1rnalz1TJ96C56ClvSXP2rn5r/6CS5+xc/YufsXOTT71jIwly7BemtrjbC7Gueb4RTrgSVHCvZmxCGTZJbLiCFwly4Ka4GS4SalhOo4UmXB/Tgorg0+CzrgouuBgmwaWXBjLgxlwYq4MRNiCLhQ1HIEiuLFXGCp8sV1xYa4sNcWGuLDXFhpmZm/8Uf/EACwRAAEDAgQEBQUBAAAAAAAAAAEAAgMEEQUSITIQIjNxExQgMVEjMDRhcFL/2gAIAQIRAT8B/gzQXHKFLTyRC7k+mkY3MRxjp5JBdoXkpvhZHZsoTmlvuoqeSTaFJBJHuCbE9wuAmRPftCELy7LbVeVm/wAp8EjBdw9FN1WqaHxHt+AsQlObJxw7pHuqiplbIQCsP1mJVa3NM1qq5PBi5EZA+m5jrZUfQCw3a7uppXxzuLVTPL4gSqioe4lhOnopBeZqll8MtHysSZ7P44bsKqapnMwN1WG9Q9lL+W1YjqGj9p9DIwZlR6QBUsrZGktFlVazOVF0Qn7j6KMgTC6xFwJbZVT2yQXv++OG7D3VQPquWHm0hv8ACqJA2pDlWQOmaMqqOSmIVP8AjhYd0z3VT1XKhe0RWJT9x+y2R7fYom+p4tqJGiwKMriLXWY+yvb+F//EACMRAAIBBAICAgMAAAAAAAAAAAABAgMRMTISIRAgInATMEH/2gAIAQERAT8B+hn0RmpYFNPy5pH5EXL3HNIUkxySHJI5I5xFJP0nqKVikur+auSME0VdSm/iyC5PstaRPYqkUnFElZkIpd+k9RK5Sf8APNXJCDyVcC0ZSFUTJ7E00Q1KmwselTUpIgmpeauSGCrgivgQlxI9yJ7FXJDUqL5Cx+lpP04osi30Z//EAEQQAAECAgQLBAYIBQUBAAAAAAEAAgMREBIhMQQyMzRBUXFygZGSEyJCYSBzobHB0RQjQENSYoKTUFNjgOEFJIOi8PH/2gAIAQAABj8C/sNdFfc1d+DJmsFB7TNpu/gcQNvFtArXVjV2fwKZMlNpBCc8QRXvs0ptTElZ9sc4ECVsyFVjw/1NQcxwc0+h2c+6wWBMYD3IhkRQ+F/LdLho+2/WQ7dYvVbBYhI1TkVJ7Xkfnasizmu/BaR5Fdq1lWYtXakiUO3jQauTMmP/AIAQ5oDtDtScx17TI0CJDNo9qHYu+teOlfSYzZ29yfv+1Fj4to8iVlv+pUmF5/43ejEf+JxNHZw5VlVjMLGC8oMaJNFw9GbnADzWcwesLOYPWFnMHrCzmF1hZzB6ws5g9YWcwesLOYXUs4h9SziH1LOIfUs4h9SzhizhizhizhizhikMIh9VMau2ZrfBWAjY4q93UV4uo+k3dNN8IDYUf9xIeTFlJ7QpfSGjgfms8PtUvpII4qyLDWPC5q5nUsVvUsVvUsVvUsVvUrmdS+76l4OpeDqV8PmsaHzWND5rGh81jQuadCfKbdSbsojb3wFBeL1iNTYhEpo1WgtUWI5kmsE1PXRBlpMqC+U1kwsmFZDCa8iU1UcTNAB19E3ngu4wS8134dnkVWYVN5vV7uSLjcFc9EtBEtacwh1mpWMesV6xHJ1UESoijZ7gm7KI2/8AAUN3qGw5ycRJBrb09upppguN1ah/Ciu51nksdyazUnKHvBOfqVZyJMw0KrOalrCZsofu0P2pzw+U0GznZQH1xanTdOdEXh7k3ZRHH9T4CjjQXHgv0qOfyyoc4Cxt9EOLpIt2p9B3qXqHtTvOyhvnaptY4iWhNm0iSYfJBRNlDx50NPlRDpi8Pcmnyowj1nwoaNM6C7wprk7zIojQTAY2sNBNoVXwHFKiQvwmaibKJNeRsQrPcRLSaIm1Q0wedEPdph66KrohlQ52s0QzRD3aYvD3Jm6KMJ9ZRD40S0zmaJgVjYq7QGjRW0oMdZObCizxXtKBOI7uuUTZQC5gMzpQkBZRE2pvFMPnRWZ+GySypTWOIITdlF0ql1HGiHRD3aXbAmboROpYV6yiFxQKLTcQpJzNRobhVzhoGmiI2FdNPIMxVoA1GmJtXBN20Q90J9W5E6gm7E3aomyjjQzbRDPlS7dChboT9iwn1lDC0EgakD2T5bKHVWOcDbYE6sxwEtI9D6UzY9RoB8AmNlDt6l5qmSc7QAnN1iiqCCPPQplRDsQ2Ju1Po40C242qbRWGsKHPVRKu3mnboULcCfulYV630iHRhMagqjIve1Gyl0J1zlFfhMRohEVb7097Xzay8gowsHfM3rsBE+snKUlVMdkwZI/W3eSh1PvBNti7Mze/U1dm5pgxNBKZ4qyjdwB8O9RLJWp7+zD3NFgkhPBYcKd3dU2sD4da2xRi0AENTmNwh7ZCd5T+0jdpWu8lhErZTPJRYem9SrGq5oMlhYniiY4oO4hHdChbgVmtYSP6iMJkOHY6qqmEwmgaZC0KsFbGiED8yhlxm4TBUSYsrzkgYQDbA4LBY0KI5oeLapknMe9zg5ukqK6sS0uKhnYsO2JkVt7SgRcXz5hRIzG9+tOc05sVlZoZNMDWyqXeShuiCdZ9s0S2ysA5YHG1hRWunJ8Mjio48xRAdtCf6z4BR9wouhwnxe7itTXljmE+FwuUasRI10GT1tKgu8iosJp7rvdesFGgsajuhQPVt9y4rCT+cqIdDYp96YaohNuLk9zHAtDDaFhp/DVKjQ9FhUS3UsHifiaVBJ8L/msHjwza5p+ITXa4hHsCh7GrC267PYniGRWaJyKgB4IcHAKPuzUQa2UH8sWftUJ+tslgzjoPzUN7O7Gtt0G1YQN340Q3anqJvqPuFOMR9VpZJEQ4rXSE7E5pdVGMStPcdMeYWDxAbLVgsf8AmQhNf6c2XhaDwRO6sH9W33Jo1uUXaq7sSIZqE2CIYcHeHUsKJutlyUXsIlRnitvQZoiWK7whYPCgzdUErrygw3slPmoMT+W8jgVAe1tUdpr/APal2YGK1tiwg1TeohfDe3uymRJQnthvIaW2y81FYL3MIVZ8JzWll5o7eC2vPGChwXQndwWTbJMwdj+zDeKbBrzIFjpJ7jEDqwlYKOzcSBOdicGOcQ46U6G7FcJFXP6kTCB7wkbVOEQyDLE1lNe9zmyErFDhPbXay6smtMNpDbrLlOSd+hYP6tvuTN8J/H3qHWeW1J3KbnvcNSdg7e4wiViqQ+J1ox2Pa1tesEHxW2iy9B0OEA7WjDiCbTeuwEMdnqQh1G1BcPtDzqDVBH5AoNspxQj2j5bVlW81lBzWOOYWOOYV/tCv9oVkzsl81iP5t+axHdTfmsR/NvzWI/m35q545fNeJY3sK08l/wDVilYntWJ7Vk/b/hYnt/wskTsKsguWScu7CB2rIs5rIN6lm46lkG81kG81kG81iQ+Z+SyTDxKdEcA25QtwIseJtKPZmFL8Tr1lIPt+SykLmVlWA+RVkdiziH0rOGdCy8P9tWx29CzhvQsuz9oLOG/tBZw39tW4QP2gsuegLOn8lbhLuS72EPPBZw7ksq4q96xnq+JzX3nUvvD+pYrupWMPG1Tqe5Yg5BYnsCySyQWSCyQWSCkP7Kf/xAArEAEAAgEBBgcBAQEBAQEAAAABABEhMRBBUWFx8IGRobHB0fHhIEBQgDD/2gAIAQAAAT8h/wDg1MKK3nK4tm8p4St8bRv/APDENaK8ac7AO6D5v/wi6Q5s5wKG4crWlkF0lrkKMdK3f9i785JA8IpoN/1pmdKAjf8Ai/cJ1HMs6cD+uzIWfMM+hrw/7GaLPTQu76N0YjQ+5n1mPN3VCeXMy4yqBbydkPhpryrTGxifmFN/hf8A4G6DFMqaj3q4jWylZuuDhHq/CDXjuZzOhox6s+3/AFVWXpr1gTnu/lDlr4Uedf5/ekdhokhS2pfA+bf0hOi0G4/ygAi1VB/+ACCCiCCCfwln4afhp+Gn5afsT9ifsT9ifsRkQXQptswkAvhSIW1yHzAmPNvmBuvY5wA0NoRpKdgvlexsY2w6gfJL4zMFWPOBlXcx+YgAtcXQ65u3OeaAjf71s+IDRPF9QO9j8VPx0/DT8VBXJf4JzCbnx/U/d/U/d/U/d/U/c/UfJa25xnpGwaoGUtIShhvPWlwLbHjDMS4Vyy0idhu6jOtVbsZ+JdE2Ppruj/Zhvn8ZuR6ssrNRK+1LwXFGq6MOzwBd5icT5zBOCDOwe0I09wNmFCwWw4f4H3LBFyQ5FerpKOR1qG+DwPuW81cmEqw1nY9JxXL0z/FiazRy8tgAUQV6wS7TK0rOV3tZ2lPjR5Xi/XZn1PdstRLVUNOLfCAA3Wr4z0R7Q0uy4SmQ3Gb54cCC14BvZdGhLOkRLYXG0RWyHPIKQ7qrgA7xdbBOAb0gIF5u2d3yT0TZyipsN81rWxssbnAlbXxfEFDe/Nj52Mxar8L2Wp8CwwX4fubAS4KXs6Bo9IKMiZ3wbDRWbqDaiFi4tn2uzlOpkTInjPWdj7XdMTqauw10tvd8sVi0Rs7vk2WM7078dltHBq5w7GnpK6dA+sK3mIU0FbFDvteMQu3Jxj7lnuifH8gvZG5t1FBC3MJUdjC+o+0XJW2PV4NlSnjJzIvReE2Xi8rpsHmvjYa6bb3fLO6cNm7742et+Gy+jEbKkULajOGpz1aJ4MQfLVPB/SP+g9Ez4XAcZ6vsYkpkeEABjRRptY3yRekHRLZQmmrwIYPhjMDd4zHjkUHGPeFFqtmp17Bl4L8bN54NvYuE7Jwgo6C52HLZfe6PKK03IzcGCBRbpenGOjszWfboLjsssrkO531AtAweOweLR638w2b/AAL8eFaCw17M8OPghBALGnGpzwYjn/eegTtOezU6/wDHcyD/AIgrR7iOk5/aau7TYE9EaXUuRLZzhpLqCo2Q6RZ4P8AaW4PQZkbb3q02dtyNuIxVmuUVo6HzlJAuC+MRVOpFG7CCVZVdZ4LHvFx8GGxOCWKL3e8pmt17GCBfBYnmZCekCQI8UyLvHGNgN4IneOE77wneOEy8SEZU37LQgpEZQlbQG3S9rfoGpueMehr04h9TednFE3vsCJfnK+W6lamsVGXBe+Or1K156Yhd2Gqpdfs6TLXUuljVbLwYCI6/KqqVoawN/Bg68Dv5SgH1a1sLVTd89YBaWdOOUTqGkNIbVvXJ9ri3uKHWtboP5GL3g9NI3gckY4fEuPJgeSvcjPYbhk/bU77wgp14+GRjRPFEH1AItt1xlFaaLHmMTfIVcVr1TlVv5FE3A64fqoRC7kw3mFZqEzScvCa4X1yo4eMUOBzOTtlxERnGuJa2Wj5NSidfkMzBWq48pTAYXzPmIPGElvf7Ln0DKU2cIAEWqcUyzERlluHwYDj2R98ZvEH4jEUWGmGPaE7wL77PWb0/sDY71UKZoLcGiGvWE0TNBjB5vTWrNBRee7Qgm9JeX7KblWOKoRUmWfFbndeESq6vsI6e+jCG0WgPjZc8TZaUZql6sw7OJZg4zGGQD0W/SUt0p66fUQr5uN6YIQ6wLN+j8xdbNXMsRyKLfO09JUWqU44o92Us4j4v9nKX6lNXtAq4zJAJTjEoXYNyrmTyT72Z5oXhygdpD/ZqGGeHYm4aiuI1iDea2FvIHmP1FivR48CIL+8hVmLLi7I+ZsC3S/KhAXv/ALBgVCvq4XBFQ53THo/cAPuJilMRQ2z8wlVYrnTI/U7BwQoW5PeVKNVe8THv9UiBCYpimbrnUs80/IuYGDfZDIKEs57u+cVswrNxiDa63iiq8PWCsAMc3L1ZXBnx0+6mYEeMrww40DSHJJlsTArVDSBHb3QuzEvNih1vRglgutS8YxR0dl5SNDqVvlYfV7osYDo4SjW6ZS+PoTRtIo2YF0tql41HLNWQdDYILtyFsTjCgFvEVjpCxxyvcoa2hU0oVUp0RuKLNGtIBB0v2M7BwQWEDG4YUpd3X1AW8zAuBUUCukpE5ymqlduibu9X1jEUsimIBUaJVPObs40d2FtbdsAyYunB/wBGtdB6MITQH0nAIfeGROn1T8pHdudH3OyPmdlfMeK7ec5rt5wsVerpX/yDyw4drPOrIXXVyfZhv2dnCJuvnfU53bwiDhPP6ndX1Oyvqdpwb2nih7SPGbmOqQ3wd9Yb4xOD5yG+btynb/qN2B8c/dz93slaR0X0S3b6BvQY+93QLpcjNZ1wjbqVPhBh2p8RpfOCvaJ34sWfNNviLt+nimvkoNo+kH8D9w5XBGnlHzENx0syp4AJx5FNw9ucStLz/uMyFuCaYzWuqJh+afuQ3qTzfK+oPXxP4gO96qJX4h8pnw30+k7q+INSezlOVn70/an70/SgAADAH/xT/9oADAMAAAERAhEAABDzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzTTzzzzzzzzzzzzzzTzjRTzzzzzzzzzzzzyjzAwQDzzzzzzzzzzzyBDQhhijDjTzzjzzzzjgzvYEACc7y6/jq5coTCxRdbagjH3s0LmGONWXzCDw8PzAyPIQePSmSrQTzzzR6SQGTwkWsy3cx2yQDU2QzTWbjiE7MMVwyRTCBzwhjSzyRBRiACASSjhwwABDTgQgQggwjQxxQxzxwzxywxzyxzxzwxhzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz/8QAJxEBAAIABAQHAQEAAAAAAAAAAQARITFRsUFhcaEQIIGRwdHwcOH/2gAIAQIRAT8Q/gxvMaPeCAwuvWYax9+OOoTGrdBkFppylNVL1gt4GsNuo14S3NILbMTFUzIlxTB1PJxWsSzxF6lURJ4THq+LwObYiHQGXY0dyc7q7sozA3RyiKiy9zKKvV3mL9Mo6lLhtM4dMZm+D2fJUOu0PiCD7mTdPr58Vg8/giNQC9p+LmRlLp9wJfFfEYpKIfevdmdCRKHWO/X3Ze51d/IwqjHZig8r49InAuj87+NB/wAwJURq94dhX+iZxAqcQJ3mMW6A2Iws0jBF4tiK+swiC7d4QIyt38teTDWOkZ5jDCXbL9wiVqlt6wExNQWRirn/AAr/xAAhEQEAAgICAgIDAAAAAAAAAAABABEhMRBxIEFhcFGh8P/aAAgBAREBPxD6GQLiFQtRzi3jrVsBpN2zWsQpZsIgXc+aLUPhslR/ME5MD1CqkAAlCTIxbCe5ipuQUYSBBAb8HSmd1Mzy1dTAtNXcOb+9RFrFKjtRWlvEOEwU1eAVBELGfqHOvqZGDCXohrMwYLUOPU0RrM1eVc7QgBg4+Iu3UzXKbiD9F//EACoQAQACAQIFBAIDAQEBAAAAAAEAESExUUFhcYGREKHB8LHRIOHxQFCA/9oACAEAAAE/EP8A4NZThDXKgOa0d4YckYCvC0L7MBGW1YE/8PGJd6gnqxb2ieJWZElr2X/29/xrZ+qQeZeQFKQU10lroDFuaQ0DVNbsaojA1aXQ6f8AYleaEzKohcbSlrNqBV41VVnXtATBhxPvCXf++op10GlInrk+sXeIh1OAbI+TtP3DQFoGwlXIodUv/rAlIJtGrPFCJbZNa52RDNbt7RXUxHmoEz8/eVA3VqL6f3OkYMXmx9o2bh4mwuyuFNOEcUHSrIG5RlvcOcuJd2FVg6LDw7w/6bl+lelSu4FqKmFeJpY+yDK8ixllhV3Jcb60vg4i3E+KyQC+TGpq2JkOedCKkO9QnUjsF8VjSH/RcADWIg8SwPEw4ROE4ZdOngYGAtq3CGdVo4wRhnjj0xK2bMPzH59BvGFRAtzBI9NCyVhjld9DMJiAigCg/hfONWMFAcVZT9v3n0r5n0r5n0T5n075n075n075mvp9bDPv3zPunzPunzPq3z/JYxjetm6yC7Qb0fQJ7gtgWGu7PoimxGmDfH3zAxLh3vaAKAORLlxE4LESq9LhYWeuj5lEsDVXz0uB7wyKYNQtYSmy1MxUplIXoGXYuCmO58JcZ6xtVwApzU1u2YVKfjf8Si+D3PnmzpN4DV5PRy/1aZ6sCbor2n2f0nJ+3Scv7dIbl96Lfj+DRI0fqGBhBAkqsBS1wSfUbeiBRjC4eXKG6MPabS9OVyiWeiK/NwgQU2wAgz2i9oDQBx+ZbRvfYFoK2OEce2Mbrb6W03RHFA/m+3oDnaGdXbU4AR4LX4lzwDPemJWjritd8Q3B1BxhT4iIRCtAPSANYhiXS/xBZjsXBZTYIVdjNfAgfcwLY4nMdn9wCziFZXMj7AqBa9Cf7CL+z4y1F6/ZVCaAAAa6aLHjdglk1MppDDnFBXhYsVLganKFKtvBfzAAQLHj0eXoNICLAy3+ifYbS4C7jSVZh1OEb5VLjUQasqU/I7xm4wB8/mWMXB9YUx9ADIUXRbwZdvQ2tk9vo0InSy43f1GMJwXY8VHeEyisCPF96T6tYX7QUbGm7tBCXwDTgBK1RirU4F8pr4rutlM+ICUCocKU37RrmcJ10zNYgnUf4jKqGEHt/cp8dpoXX3iBbi+l2vD0x28FNZ5S84ApFVfp7OP6Db07kTpIlJKi7/N+1+iIuDgBpW0oxLROt6OxMexl9zWNZhT4Sy6i+rj/AGCiIomjNjGBikfcF6Sm8nK4FKUD3D9ymM9IhOvhdjOiB8TPQkurb+J+4zqOp424fAQAzuEDnGJYpk3KLHySkeDwj/cAYKSPS4qt+x6G7A+4/UrYHaV0t5vT/fpTt2+VfX2UJ5wkeD0YqZzitTAUkNa0Ux9xAhdN8NpYe325Ya+esP59og1knPF+CUJY8QNWdeHvBcZYNRQzBtZRnTEyLK07TyaPnjL2lBuxRro+6UXq8J6NKO0gXfHKLuqrCooxpr6Pt8iVbmeGxQmEjzoP3OfOZkfprHtOEpjGkXC5VeVEFEwI4e8KAOAZOJuz9xsUVmwGvv7RanXgb6f29KDzfJOPpxA6d0fvNnpYc1Fu6PTAN/xRSuBXgbw9hJhoOK7CHoEv4bFkIRLeSWnpcHNqONtI51A8E1+BJp8OiYf6mW9NBoiexB6XKt3pL0oyHDSnbEPrlVCnp0n9SGv/AGB8xXgheQ/XpaaJA2cOko2wY092INUE2tAdE5wHZae7H4+gvrM5ys0TGnSfuCycnxEC9YO5H5P09EtSmn2nP0IUgW7zj6zZLhlr6Bc+zyzjDkpWEDGWKdvrKgFSOSQQMpO5rAaZzGx+xlGxChimGPhcb/OJUEw2iULkbgvEyUB2VFPf0BWqflAUVOMCUKc/Yr2g2rkc55D5jVqjsw+lAlqTZyDDcDBgYL053HpLHd1D8XEAVTOtdU+33JXaw/D0+i2IaQW3Af4meUADTD2x6/Y7Rniq6vHCcQK/KjvT6emN75gYeRElOBnPxBkQMqksvhAUqiBblVYLaY0rSIDe2AtlanWHqA1LaHV0PPQezGdQrfELXR05PL0fYcNDipEs1iFOAJU0Sx7S/AsWsWj9Sw1ldGz3jAk1B1jRhdQquNN96pl9Ay+K6yyvoB65fgiJaKQ6aukbPFqL5x0ZKHHR8TBo+JkHHhdoY46weEaCKba7RZUGvYrsQaxogpMsAIFiy2GGFBoCb2qKS+w2xY7q/wAiKmaxwxEHBmocXvNFrMV+5cJZ5iNJgdnl5IOUxNj2oLeRmXziygYAbJIg6IY5S0/EgJYXb9uWTWCzi0vbPaHlO+FIKIL0NICXrY1fRaoqnV4R7BNfA0mOcQ0KBt+V5pZCteZvMnD4oFLvZww89mIAKFmSdBXB0M6bwrVCHZGj183G81tXRXVevtE8JOPrvLbmk7RXwJWWHomV3uQBQ3ztLvQ5hVqBfyXkY7SoUFkUW6A4wxrCBwquFaS6+6UOQqh5yhVCF0MtV1s8Sl3BWghfhNLSc6NLeKPMJxADwpVGkVzimYFRX0zzgqpBKxY4fJXaOwNWzH3G2JsiDDNo9gviHQ1a7iNfPtEMVZiY0JnEF2Px3dEutsYhECyXcqyEHLiBYg0m7xLpdDvJq2BHSXYgitcbvTnLCpaAiugvAqNbyiwSF8knwOFKwiW7RS99rQLcOkbBYzemB7FTkt7i+IaoIU0DRXUs7xX8Ydon0usV4MhWNAugWAZnJIJl2LwuHEHNwuYag8wTEoewXjUU4aksWWU1VKU2zbvFC5rjqveFfSFh0cWVri6XS92WGbAVwQH4YhtFKjGR5H1tBEtJtxIHDWe5WIzpDZtYjQaCtaioaWDhpEQeETLNdIZB/LA+FJvABYKxFta4IflGbiaHFA9sHZg1qqOI73L5mNfCBUrQV4uSMs2HkPmIbYZ3tI5alDUI+aj8psdwZTYxxreEb0G0JwYxVRD1g9jJ/J5j0itsxWvNeDMuYW5fxqbQOFS0lnK6CGdpR5yVNStff2ldE5VsJFcqHmKGzNeJdkH0YduGCWLLRvQhxo9IbpB3ya45kZuXIAUM8gITpdewfCEiNqH6v6ehDRWLwFB9klZ03W3yEmYaQvCAexClXWJwgA6Bk2iickOzb8nprw0/S+mIpD2SbIBPzuYv1ZZM66MzmjIQcXlmWye2bRjOM/hAaYjFGxw1kv8ARAT0BWgA+3vLjSiuFx+B4lmhtoC7RyhvMHJLF+iQ7QKyl4S0PGDPNKX4qKUp+rwCXeeG8zlQG1g6jUdusYQMs8LCnLJ3uGwCAAYKFA3xNszkfXlFv3EjgsHK+NvlrXaUzjVgiIar5OiUOG9oSnWOWh23pYeH+kxz3E2kVujkxtKTZgVHB33lMByKtlocXQgbZUIt3s1QvoSw1Q5pY3VVkzyjzACFqmGN7mjvnJlA5NhhycY5g0I62wUAxYgHFx4oHs+AaWIvFXTmtFgbC4KWE3ZnNmYRL1lKW01OC61yEJLEEIpW8voEvGGaLwXdawlimIyCsUBDpUaGmwjU+h/UteMnDYdO3CCV6rdaskuKwdZRXPME2pqO7wjWY/BaBdBxylMBTDBWCYxtEuW+4XbWnhCwFEjpTq+kjrVZ5CwjQy6OiVLgceJXelflBM/KtjmhddPMIGoKKiODfGrNXItuuf0YiKQFI2MAUGVQunQq4bzWurKOt2yBVlmnPD4lBmhYlg2ZOYRs68Y2Dbbd2HGA+rJKo2IPG5Ur0o2IkqEqIbSiY2mJf8L/AIY9cGYgHVvj3mk+zoEhWrtJciCvvxMwnyquy4XXSfePmEa3EGe/qTugKeKHXnQaWyF8B1WP7CDFeH1EyZTgN3t2wmCG7Aweax9o8tDZb8TXLeZ8scsHMwloAHEafL2jvK7np1d0t7BDNfkGhCkTo/moR3vWvwkceIBig1Bu7XbRb47Rb5VBmc3GHi35n+ghOCbLfBPrnxPqnxNK7ucFBSvGscsiPZCbtkAHHIudMG5LnKR0OmVokflGyajvL+CtVDGARfM1q8Ri0eg9j0e7qa4fNYLH3YGruM4hHFFe8WB2S+II9S0e9Q+2OFaV5IH91GJfODY85gf0DlFAbWqq7W4moN3+e+YqeQF8xU7EEPaAQdo2pCtrminHlZWBwYtXv8Ry8XoAdcU+84wHef8AJ/qHMhuA+GLadqD8OD4EYzyUVvp2pPYMU/FLxh6c8ALkD7QVGXmv0n+0n+8n+0lVJiRys0jTyhIWAKANAP8AxKNv/gX/2Q==','แต้มไม่สิ้นสุด...เราไม่หยุดการต่อสู้','','2014-05-04 05:32:12','2013-12-25 16:48:45',2,1),(45,'ชมรมแบดมินตัน ดอนเมือง','ต๋อง - 081-811-3375  โต้ง - 081-831-8586','data:image/jpg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/4gIcSUNDX1BST0ZJTEUAAQEAAAIMbGNtcwIQAABtbnRyUkdCIFhZWiAH3AABABkAAwApADlhY3NwQVBQTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9tYAAQAAAADTLWxjbXMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAApkZXNjAAAA/AAAAF5jcHJ0AAABXAAAAAt3dHB0AAABaAAAABRia3B0AAABfAAAABRyWFlaAAABkAAAABRnWFlaAAABpAAAABRiWFlaAAABuAAAABRyVFJDAAABzAAAAEBnVFJDAAABzAAAAEBiVFJDAAABzAAAAEBkZXNjAAAAAAAAAANjMgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB0ZXh0AAAAAEZCAABYWVogAAAAAAAA9tYAAQAAAADTLVhZWiAAAAAAAAADFgAAAzMAAAKkWFlaIAAAAAAAAG+iAAA49QAAA5BYWVogAAAAAAAAYpkAALeFAAAY2lhZWiAAAAAAAAAkoAAAD4QAALbPY3VydgAAAAAAAAAaAAAAywHJA2MFkghrC/YQPxVRGzQh8SmQMhg7kkYFUXdd7WtwegWJsZp8rGm/fdPD6TD////hAIBFeGlmAABNTQAqAAAACAAFARIAAwAAAAEAAQAAARoABQAAAAEAAABKARsABQAAAAEAAABSASgAAwAAAAEAAgAAh2kABAAAAAEAAABaAAAAAAAAAEgAAAABAAAASAAAAAEAAqACAAQAAAABAAAA96ADAAQAAAABAAAA9wAAAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wgARCAD3APcDASIAAhEBAxEB/8QAGwAAAgIDAQAAAAAAAAAAAAAAAAMBBQQGBwL/xAAZAQEBAQEBAQAAAAAAAAAAAAAAAQMCBAX/2gAMAwEAAhADEAAAAcUbHg+6obAoaChgKGlqoaCoaRhaxsus+r5l3Z099l60jYz9S4aCodAmHwqocKgdAkcLYDCeVUNBQwFwyVSNgWMBQwqn1rZda9XzbHZ9X2zL0qhpj61DClw2IWMLVQ0FDCFjBc+GnXmUMBQ3yeBkKsZEeIZB4GU9iNZsK71fPsdw0W+42u4bHm9q4bFLhpKobAuGAoaKoYGeNjvzqGkKhhS4bAsYSqGAvU9x0bTGpgPT4py8TInXQIbHj+ksYKoaCRgLhsCxgqhgZ4yOsPEMBcMBYyDxDBVnsMLnO/8APdvNAGuBMB0TMpL/AMvvWMOelDCVcNilw2BYwFnsM8Yd4LhgqxkQsZAsZFeIbptZmjMXt5YA65ADa9t5ZvGO92Kys91QwhZ7FWMBcMBQwXPGRpguGgoYC4YCpZQnjnkr2wgC8gAABMBvWzci3zLfYBhnouGwLhsKsYCxhLmjDXBQ0FDAUM1s885F6ZAFgAAAAAAHryG+bXxreM9NthscarhhC4aChgZwyNcfB7g8R79Gnc6v9e64gCgAAAAAAAAACYk3fduP9i408DDjpQwpYwM09GmPmPYLGQUfI+8Vdcay+x5Mcbd2CDi9V1Hl9QAABa2m17PHJsTskLxDH7pjJqG7+ideD2c1YyLfB7IyANMwAAAiQgnyTgY/Kj1VzAGRalEWWEZ/WeJWJ2wq7WIj1J4PYeD2CxkL4PYSBYAAAAAU9xphz3GAjKx+gm2Z4Ecs6ppZzWWpM3rHHNvOmzEgAAAAAABASQRJASQVK/cGlt28Kuz9BMAHmZTHq7wl0vZLCLJmIPRASRKhASQEYWXzTj0b9l6tTc69FRi6Zctzz9Sw5puka3Q10bxV1XWWzs0TK413PHoddro0US7nsi6upTb8Su0qa9TTjUFy2f3zvappcO1TEvO1Gq5c62wg08ZzfpHNs/b0fSL/AFKd2GRaazO+gc52vVrxZ4lhnuqLKqLiaYXkzeek4NpVWbGvLoesNhqR5X5FNecbMXUW15wjYdPdXdJf0ibxqtvrXWfQTwaeHJ14E8XITvLqAueDdhO0OC8q8BLj54BgBVxRgLuwK+4BKHLB3lYgM/eSFUvoM9r4DTH/xAAtEAABBAIBAwIGAgIDAAAAAAADAQIEEQAFEBIgMBM0FBUhMTNAIkEGJDI1UP/aAAgBAQABBQKsrtrsrsP9A5C+1ZWVlZWVlZWVlZWV2VlZWVlZXFcVlZXEv6ByF+TK5rK4rK4rKysrisrKysrK5rtn/jyH7hcrisrK4rKysrK4rwVlc1lcbH8eQ/c/3XhrK4rururis2X48h+5rmuyvBXNdtdkyU6O88t0hMERREjzXlLXZWV+rtPccxl/2OK8tZXNdtcTyIWRyFaL/XbXfWVxXgrJDuiM5bXsiO64vhrK7K8Ww+kLt1DrBxXFcV3Vlc1lcVlc1m1Oxoe3TuTr/usrmsrKysrsrisrKysrn+3bJ4HOer3drHqx0bZMfHjk9UNdlZXFcV2121mwntitc5XO8GqlsUVd1eCsrms2GwbFY96vd4UcrV12yQqV56ys2OxbGa56vd40VUzW7PryvJXFLmz2bYzXOV7vKi1ms2nVleXZ7X0Mc5XO/Q1ez+teNM24FDN/Rip1SkSm8V4dlCSZHexw3tY5+JBkuxNXMXPk83JGvkRm9sSAWZnyKTi6aYmO1stuOjGZlZpdfXNeM0COZ7IwRpSJzvntbD7dGjEhcqxq46IB+VSVxWV5pUocUU2Y+YbthzHwyxJY5gu6vPNnjhDlSySycIF7kZqpLxrAkor2KN2RZZIhYU4cwX6ewmpDjmM+QTgAnHLHijCDjei6J/EeQSMWBPZOF+lv47yh4q80MPp7N+BxBuG9nOg6vif0lRHIbQMeVn+Px24LXRhYiIicqiLjgCdhdVFLi/48DriwxRGf+S6UFqpMAuNe16Y8rB4k4CqjkchDMEgzjLjnoxozDLj5AhqMrCo96Da2UFykK0bRlYRHvaNBmYXHORqfFgxPsQzBYMzC497RtGZhc+2OlBYrZQXrwVvVOdp06WlLCM+U1sVjS7CQXUdIoEpwTbn8cYqxjT1R8LSfbZJ1T9UXoPuCUwCdMra+30/49p7PS/faE6IzhKwcQnqRt1kQyxT7JeqBpkoc+c55Q6l5UTUdBU+nD/8AsU+24r1zX8p0qfRftISp219q4Hqa4RuuBpf+Ej+W1cix9kdfiNqT+Ow2vttP+Laey0v32heuTJQK6/UGtu6woOvX/EetrdUtR4/8p0ojhR/mkhMC7rFhFRJ79iAbXuJOlSInVAhSPhDG2QWjijdJl7n6B1iI6HJEsaRp/ojlvabdnSTUs6yyfpsZw/Uha6U0C7KawgtUz0g9Kypj9R/GCT0Zm5yAxCQDjWMfT0o5IXRZQdmF7JxGFkx/b4TVMI9unEmBjDAmSNcE6t07LCBgGSobZTY4GxxyobJKRoTIyfLWJIkRmSWAjsjsJrBkMjaabViIotQJqvC14Y+vHHLi6sfrSYTZKACgBSYQ5KxojIrSgYZrtQJcZqQtxrUan//EACkRAAICAQMCBQQDAAAAAAAAAAARAQIDBBASEyEUIiMxMiAwQVFQcZH/2gAIAQMBAT8BYxjGMZq58xpZ8gxjGMYxjGMYxmp+ZpfiMYxjGMYxjGMteKw5MtotdwYMtawpGMYxjGMY9mMzz5dq+4xjGMY9mMYxmae+9LOBjGMYxjGMZN0Ws98eRQhjGPZjGMYyZf00yfidmPZjGMmSZf11vsxjHs/tVnZ/egYx/fY/4HBijJ7nh6XienJiwcu9pUQTp6Wq8cmPS88bgjFHT5MtpYjFzMemi2PnMnR9LmVxROObmHTRevIx4eWThJfTcckVPDzOThBbHhiE++2khxY0uO1bTaxX1MVoqaek1ibWIycMcWgzVjpOpWfjWf0R2mcf6K1m2GYgrWa4JZ6dIisycVqH+zDfqWU/gxzHUtUwYu/G9S3ykx5LU9ic17+8lb2r3gvnveO8k5LLidWy4nVtM/0Rlu5llctq+aC2a957lrzae51r/wCEZLVnlB1LTZnicq99v//EACQRAAICAAcAAgMBAAAAAAAAAAABAhEDEBIgITAxIkEyQEJQ/9oACAECAQE/Ad+F4Yvudl9eH+Ji+9lZJXwiCpUYkW+e7D9yfdhLjOS5K61GxKs5wK3VsoSrbKO+ihISrfKOVFFbF0yXdZYyv0a/wpSo1tekpV4a2vRz5o1c0Kb1UOdM1c0XzRKdOhypWKdqzUqE5ZT+jEY+JInz4VboT+RXrPVZ/ZdyOWX8SXA/ESf2IaTFFIaTFFFFI0qjShxTFFUeFFKqKVGhXl//xAAwEAABAwIEBAUDBAMAAAAAAAABAAIRAyEQEjFBEyAiQDAzUWFxMkKBBBRQUmJygv/aAAgBAQAGPwLxjge/jvW4DvW4N71uDe8DWiUA4C2AcNUGuAv3Y+ORnz3Zja3Iw+6B9e5e5E8re5dzPHcWXCBl3MWzfuK9PebLM7XmzNN0eJZ7Vm7XhsM1CiTqfB4LjDu0yUzNUoucZPhSEKVX6tj2XDpmaiLnGSfEsuDWN9j2BpUjNQ6+yLnGT44oVz8O8Y0aP1+qJJv2I/T1r+h8Vx2dfsqY903xCPvGiLHCCF0tJVqLl5BXkrNUZA5jwxYYeWr0XLqpnD9xVHx42Z7BKhtNo/CsMQ06nm6TffkuwK9JqgC3ZZ6hWZ2mw5g9htuFnYb7jtpcZdsFmefxjIYSFnyKOC5ZXCDhnYfwpaercdoXff8AaFnqOk4tY0TJTKeUWxzbEYipTMFSLPGo7NtRujNeQ13tg7TyU3MbJldTSMTGnZwRZZmOhpXU9xVqYPyoAjkuJV6bT+F9EfCkPdlWWmP4qDUErzApBnCXuheYFIMhdboXQ4FS4wF0OlZXPAKljpUuMBQKgUvMBSx0qXGAuh0qSV5gUrrdC6HArM4wF0OnC9QSoDxi5v8Akpa8yspNhsuNtCiVLHS4IU3G0wmprtlmT/lEJ1IptP1VMEYFFVFG5TKnqmuTEPQ6qfVOXDpGyzVHRKa4VNFGB/3w94TPhOO+DsvqqabUaLtTqTjcJ/yoQ90G7BNHvgUVUTWDRNDXiWo0vRMVOqNtUWH6gqpV/wCyLmDqXUE1x3GDif7LW601XCGoC65hdJklZtpuggE5uxVRf9JtRPqlD5VkWvsuGy6dUdaUR6lWeo94TEGnROZsnhT7yoqarNT0TPjAuzaq5ldDcJiHequ+VlYFDlkahmRy7rizdZXhZWBcSVClvSurqXD0CzjXDOD7oZtkGDZSdV0qHtldJhXug0L/xAAlEAADAAEEAQUAAwEAAAAAAAAAAREhEDFBYVEgMHGBoUCR0cH/2gAIAQEAAT8h0IQhNEITRCDXOlt5GqTd7gAIQnrAmiegQ/uaN9xNEJqTUnpCesCE0QhCGHdo5pnRPQJ6gTRCEJpCakJqTrUtDa0IQhCEITUmiEIQmiEIQmiGwQWJTbJkZNEITRCEIQhNEJohCExohyTwIIUrkVUdNIhtCJR4DhwmSE1IQhCEIQhCE6J0TohCEISOGALqxNDWRrRCE6J0QhCEIQmpCaIQhDLHIlX8HCT0C3myGGvsmCbkIQmiEIQhNSaIQhCEJo8spDXnL9CbRV7tKE5IQhCEITUhCaIQhGQhCEj+T7z1V3MZCaJomiEIQmpCakepMkMsZMTrHcfpvUtsvI1smRsnohPUCEJonqBCbCQk6tLeB1Y2xfSjQIx6ukv7Pk7NxCE1JomiEITROiEIZNRZGFBTPQxPJn2KdMxTCUhCQhNEITohCdkK0QhuwPG0DfgZgY8v2lBsazR2a/YWuyEJ2QhCE7JpCEJNGTiHq5WX4HcOR7jRNmmuRCpL9o578E/ohCEIQhCdE60SZZZ9CEWEwrAXW37zGUw0IQIfLE4aJpOtJ0QhCEJ5ZK0j6hvxKxm3f8BNp3kfyjBvLryTOkIQhCEIbrB/K8L+E9Nu1GpPhZIREEIQhCEyf9IEmVh4JqQfxh0bwPo2AUzkhDfbz6qTyjGnZX6NtZ6Otgf0UnlNPxBr/Rsaz8k0QhPY/wBdEUu2BbRR9n2NIy49Tqs10b87GfJHzGIs9dolOlPwJVKJdtE1IT3G5VeF5Gx3qlOAFRT8B9EN9OCaIQhPbdUG7I+4/HAuio3NmkT5l0y2f1jY2vhlFL/mMQsR7PCe1ge2+wbGGfmtS4EIdPgXWx9jmThavQo3XlfxMIsr+wM6KkWWNrE46PQ8KjKDT8TRC115i/hPKzbdD62xWvA+TY+BGr3lCKCeF6EsV8j9Xhv6kxBVsfc03u/apSlKUpS+q+u5KUul0pS6N6FN1TYf7SAadaL4PkQ/6EqvIhEgnYwaiE5OwSuU+DrKDY9IKvA2rI8ie9b4Ia+QggnRE/sK0o8GFpCc4q/I1gQoUVsDvGNEByxFUL0NxW4TnRUWKT4oj/Dj5OBvbXYVnE7JqbyocPlfSFsdQ2GQG+B8Cpu3ybYH3JhlNUgkaVxgdiVyRJ53mCh0VSJJ+RU3iwMf8ZJG7AtQ+IJnxH/tj+AmZ7kI6JRRJhzyWcfLssY02RIXgTGjIoFyoWyNmFVBFRxQjXZEbBFwZYE3I4N22sIrihqvKxInB2T9p+0zC6om/QwY4izeT0UoOcgnacuBiDfkwNwvkTZGMkJ8qDd/UG8GyyigvOMCg7ym3B8JoU7cKNeChgNhDZPcYVKrgYVJqRlINbBMT5EK8wiD4xDdq0pTNl11rSsMbQvvLNI+hOSGP/Ak7Y5kzrkX/BktbDHBw1nwdhkuTmFi3g54FVixJE1VCpybUfZzHIXelDQCduTwRhSXJa0EnYRsIa5FCCS7R0ySIwZLkU3hp0Qvelgb8hvJRO+UGBNmYLisQlUHkmyFS2wzdoICcB4XIhtQ8yFom7dC2MI//9oADAMBAAIAAwAAABCabo/Bk61HQkHJq/JprtpYs3fd6ReDg87nnUSR8K4hpVrZ+L+zJ1XK6pDCQzClUAy5p2Qgy4ARympRTk2Fiee0ioBCvAu6BnwRD12giIACBIVdSEKCmnr2AAAADCcB5P8Amn73oMIAAMI6sL9BjDlkaiYAE3EjsHkO88Mc048IAICbzByP8888E4gE0kU888IM0CqgUcQY5Wx1F4AMci/y11nIQXEIi8VNpj+JwkH2NGPqQf2zBgje+ff88hhc/giB/8QAJBEBAAMAAgEDBAMAAAAAAAAAAQARIRAxIEFRYTBxgaFAsdH/2gAIAQMBAT8Q4DHA5F1faOt9mHGcZJ5cEHArZ9o9ny8h9AIOQwg66WpcjV/uHgR5ADCPhAw9vCosMWeKHBZ4A1LeksH24GNb8Qs14A5ByMbAFxHfIWIZyGOBFyniCQ3z0WenXAi/AFsghHXnUUyzshByBI0Mi79FZfC+Ll+ZKlMxwIt9O5cuXD+Gk64+Z1vI8etS8uX4PN2jYOLU9JXfWCIr9dkCy2slqtCkAB3Ip0awFr6NS1mkvZqW+VX+p7IOQSTrti7URlQO6og8UUkdQ0/ew9aKY3oj/ZZdTv5mqsYaU4KPzOwsf0QUyvR+ZVK0pr3ZUD0FhI+qye4THFY3v2hAPmLW6h1S1bZVJIKch2+RGV+EN3DG7dhldyzOaDfwgBNuNhdjglVbZ//EACERAAMAAgIDAAMBAAAAAAAAAAABERAhMUEgUWEwcYFA/9oACAECAQE/EPNYpp/JS4JilL5o4Dj/AEQmEPMIQmT3Blg8jpYvlCZhBX/OOA1tp9YhCEIiExCCW9kGf3Mn/Zw2QmYQhCE7GOTTLm6h+xBohCYQhBM3om8e9DU1iDRCPDTYxsSnn2onT8BCEEi/AhBCEIiIghtlfg3k2NCE/HCIiIQT/CsfViw6y9bE9USPvhDUS7KFGhKpJtiYSXkWrLRwpwMU4sNainf1RynRjYOjUvhR9BqRvsbfGsPtn0xLSX1D7HAyZL2Q0ew9ovQ20eyQblsbiXiGolwjkaXNItdqCNauGi7eoXUPXobQl2cIhJGIPSJtEp0SGHBCjYpoiLiTiOIcqESP/8QAJxABAAICAgMAAgMAAgMAAAAAAQARITFBURBhcYGRIDChscFA0fD/2gAIAQEAAT8QpuUm868z1Lnzr1NNZmu5nL+F+pX83BrBjHGF1EcpafEz01Pqb8yl3K3cy4lb5J6yk18adM+Xxrdz2ZtNPC1blpp+ZkYzLy1zDe+ptGv6iwMMO9siLzznwv46eF+cQpNJr4bS5L3M5Wb3HCU9zIoaqabl+p/mflK82Q9ZWUt7rUdato7jVXsZa07lJ9z0zNqsnxFnhzlZhPiaz6jfRNNeL9RNR5zap8TSq89rm2pbOz3LmOo7n7hM7GIU8fnM1up9R+5rqfMvXuYcXPQ/2X6glTVRbLGJz1L9T5mnM4tT0LlX1LZyS6NIPhvLWTUYzjAXiPS5v/iYyicz5S64Q/E2uvHGcSibep8Te6YMn3L/ALi2XnxK1Xcc8N+H5zW52rwU9eKYBnuLvlUHlTDsuiNwy5hBaEdMKAar2Iai0OZcErcrc03MMXKk+P4P/c18Gnrx+Z9GGG0VfCfMtK9TF0xJXbxBrTcKPqVMtlsBmWpL79hLXWpTcT2TsFsa8oQ+JSfHj+E6uJ8y/Up1mWrKXPVYtJbnz2m8dDlL28UVWLV6bLzn+Cd0FfkNokafI0E8k1L344z7imXr3N9eOsw2Q3xKTosrd3KXuVNExla1cr1KvHjWPPouUE0mbEmXzcUEdQ7mjUQJsT3xN2Y+JXHhS77ialOcT0ZXVz5jd1EVcrfMsaBgg1DoJ+H6lt4lDhxGjkqX0uGo0Y1VJbX8DcQW0z5Dj1L5oufW565nxF6R/UoQIRvxid6h6TNwJLVxBcVLjq5vBcEs9RqzTPqbTc9yj7qKZkMY4g9NRupTGf4FXnUAO3RqkYvVmqhLL0yhYtRKz3xBfmDOoq81ML1MOot8a+5T3PufUe0pXMpWGUqVp8WdzdtVM5dW5eS1qt1Gzdff4p8uhGpSaGLNBxBI5LnPEr+494itP7gRQlbck02eNL4l5eOGplx/ktemX7TrTN9ReoLIlorUz2jLxeOUbCZb/K2XvbKsB3WE4/MWuTYHMuKOHpjlgjURvx/kzNP6naprqfEx7S85QRw/Uv3PZLVvMsZUnCH0ONW3Cmko6m6kZMxV2/0tdeAdwUQ4SW5b2v1xN/c2pwS3aW7ZnL/iX7m8LeJT1NpvMxqvUajvmcTjmC2y69QvKQOQ+/caEVqbZb3/AE3LYrQrA5IPoKG0OvsBXdGlHMSmEVqWuazvUyqo7z58+uLT5S15KhmyQsqy/wC/UCgCFsEahZBm/wC5QaixHTDmnDOb6ZSgsy9BO456lJmpZtinqL6RV6jWVrc+MeNXQPEHrK37hpgoo5D/AO4iJ9o7Zd/3XBFkGRIlRGadPuII/DtLamojurnzLGJm3G/UqvyazeV2j6mRwHziXzja/Zw2ZmPGe5ipbGv41nGZTMd+LxUyTRnAHdzYWYvxKl1pnuZ9JTi5r5L1gzL9R5CUqt0QHQBo7qNwEkVqegpC5XfioHv8shNoubdRgHULOeps/gbgyCldEvqF6ghaHolxgHIYj/7Nxr+ApCzB2UJOZYm/Y6hXHPhaY8TFyV4ryhKicldZgtpZUCCrxwFv5n+UwEpq2n4lOzbhIEpQFMmNxXBWv4H+w97juxqZBmA/LGwUzEUKweyVr0ZYkOsWCFEXE1KVuXuejLEtedT481/BBiXuYcSqjq5UqR71xHfga4Q7irv+LwFS1wkw+irsvqAYw6lTIWxEUlSra4qU4VR6la9ylyuYVPH7P6lbo3DPmm5db+XG4Nt2BMrXfEor/n1H6TTaLHZfgssTppix1Nk+Maf/AGZbhj0cOU/sIX4Ms2PL8uFmVt9Q8V4/Er1K9T6/rXUBpOXuOe9cuPQl4bc8EvFRTgwhurLf1HZwioy8wAGg0BFStro1CFpicITFS8bzFMgUOOYZfyiHW9kESz/wXTLILtHNxOV/nvmBvH5jAKmADLBrFK20bjTmtanUqmKg0UZqpXG/cVMnrtuLNpDfB9iM13/ffkzbo5YkbVhLs8EEFOxULh7YJYZEdBRKxUrK3xqHEpgBuhcsg53RFlTeoQxkApLiSrelAKNV/K/Pvvqe00vibeu4w03icKJZqjHL1MizXcuqf8mC82VFvHEWmgl1GiS8uMdy0orEvqDjJUvFupfvEwQnyCq2OVVGsGWNy2f9oqsEpLlgIbMiIVX5uOCv27qZChtIhqxpVDhG9LhLwQdkaH7Vqo0d2pudkyVGK202ifb9AYlaqVWTdFBhoJUBLZox2TibeuKrmczbjd3U2uo1MeVZbwtQbQbixBIXj7lq4ucZpZUOtjPBEh40quChQZV0TesZAixrUUXEORvpiWvbBsKnYzzDmEm4U4hworOKmDCs+8ETTQzLizEsiQWYWszJaMNrhYKVleEYfMerThHhCBNqC0AH1UsEF6e46UtgdQ8CPTGW6NkJAoV/zHAZElyqiioVraUB4dsHTMyvcudYJ+QEkyuGQpiPHaZxhJ7GNI1a0j5LXbttTARwrP8AqVfbQlStLQVbuNLaoZtKBbf2Ay8DK/Cjfv3KzqqmjNAuIRwI38hXWFVds3FuR+i5ZI33t9jXkltqmeS1hoNkV+mIlh/iylwxK+TFYoIs93dEogtUk/cu23SNSlNRAjUci7yhHaECWyx2UP5nN1bCZ51OSDjwC7QdxgNGALQFpfOZVephi8E0pRmmnL9TNfUeAFr+4pDhgyXGAlBTAvEDVLHqEVVqiKvaRM+kDmIKHGWV1MBIAi8nUmWo1OkeJRAQiw0ViPOblWcSnVPENVXBZjAWsXL7ixJlHyWm2tqa9ThBaDARsiNeOopaqgmy0txjQozUQFrMzWbhNlDpcMwC0S8hqu4VAGpU2OYzINHrd1FTRCrhcNFoEOWXUuK1n1LPQrce9hK4lhO6Y/WbwzKv8xm9mQT57JU590plg5FOSZQiq2BGZwDMQ5R2y6bCncQ5XZnUym/7RkWAR4lbaOM3VOYDKjRahDj0A1GTuYiWRhs/cdIy49xFhiHuWh8p5laIsJGHV3YmAjfUWJnW494r6uV8jon/2Q==','','','2014-04-16 04:02:05','2013-12-25 16:58:17',2,1),(46,'ทีมแบดมินตันสายไหม','0879924758','data:image/jpg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/4gv4SUNDX1BST0ZJTEUAAQEAAAvoAAAAAAIAAABtbnRyUkdCIFhZWiAH2QADABsAFQAkAB9hY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAA9tYAAQAAAADTLQAAAAAp+D3er/JVrnhC+uTKgzkNAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABBkZXNjAAABRAAAAHliWFlaAAABwAAAABRiVFJDAAAB1AAACAxkbWRkAAAJ4AAAAIhnWFlaAAAKaAAAABRnVFJDAAAB1AAACAxsdW1pAAAKfAAAABRtZWFzAAAKkAAAACRia3B0AAAKtAAAABRyWFlaAAAKyAAAABRyVFJDAAAB1AAACAx0ZWNoAAAK3AAAAAx2dWVkAAAK6AAAAId3dHB0AAALcAAAABRjcHJ0AAALhAAAADdjaGFkAAALvAAAACxkZXNjAAAAAAAAAB9zUkdCIElFQzYxOTY2LTItMSBibGFjayBzY2FsZWQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWFlaIAAAAAAAACSgAAAPhAAAts9jdXJ2AAAAAAAABAAAAAAFAAoADwAUABkAHgAjACgALQAyADcAOwBAAEUASgBPAFQAWQBeAGMAaABtAHIAdwB8AIEAhgCLAJAAlQCaAJ8ApACpAK4AsgC3ALwAwQDGAMsA0ADVANsA4ADlAOsA8AD2APsBAQEHAQ0BEwEZAR8BJQErATIBOAE+AUUBTAFSAVkBYAFnAW4BdQF8AYMBiwGSAZoBoQGpAbEBuQHBAckB0QHZAeEB6QHyAfoCAwIMAhQCHQImAi8COAJBAksCVAJdAmcCcQJ6AoQCjgKYAqICrAK2AsECywLVAuAC6wL1AwADCwMWAyEDLQM4A0MDTwNaA2YDcgN+A4oDlgOiA64DugPHA9MD4APsA/kEBgQTBCAELQQ7BEgEVQRjBHEEfgSMBJoEqAS2BMQE0wThBPAE/gUNBRwFKwU6BUkFWAVnBXcFhgWWBaYFtQXFBdUF5QX2BgYGFgYnBjcGSAZZBmoGewaMBp0GrwbABtEG4wb1BwcHGQcrBz0HTwdhB3QHhgeZB6wHvwfSB+UH+AgLCB8IMghGCFoIbgiCCJYIqgi+CNII5wj7CRAJJQk6CU8JZAl5CY8JpAm6Cc8J5Qn7ChEKJwo9ClQKagqBCpgKrgrFCtwK8wsLCyILOQtRC2kLgAuYC7ALyAvhC/kMEgwqDEMMXAx1DI4MpwzADNkM8w0NDSYNQA1aDXQNjg2pDcMN3g34DhMOLg5JDmQOfw6bDrYO0g7uDwkPJQ9BD14Peg+WD7MPzw/sEAkQJhBDEGEQfhCbELkQ1xD1ERMRMRFPEW0RjBGqEckR6BIHEiYSRRJkEoQSoxLDEuMTAxMjE0MTYxODE6QTxRPlFAYUJxRJFGoUixStFM4U8BUSFTQVVhV4FZsVvRXgFgMWJhZJFmwWjxayFtYW+hcdF0EXZReJF64X0hf3GBsYQBhlGIoYrxjVGPoZIBlFGWsZkRm3Gd0aBBoqGlEadxqeGsUa7BsUGzsbYxuKG7Ib2hwCHCocUhx7HKMczBz1HR4dRx1wHZkdwx3sHhYeQB5qHpQevh7pHxMfPh9pH5Qfvx/qIBUgQSBsIJggxCDwIRwhSCF1IaEhziH7IiciVSKCIq8i3SMKIzgjZiOUI8Ij8CQfJE0kfCSrJNolCSU4JWgllyXHJfcmJyZXJocmtyboJxgnSSd6J6sn3CgNKD8ocSiiKNQpBik4KWspnSnQKgIqNSpoKpsqzysCKzYraSudK9EsBSw5LG4soizXLQwtQS12Last4S4WLkwugi63Lu4vJC9aL5Evxy/+MDUwbDCkMNsxEjFKMYIxujHyMioyYzKbMtQzDTNGM38zuDPxNCs0ZTSeNNg1EzVNNYc1wjX9Njc2cjauNuk3JDdgN5w31zgUOFA4jDjIOQU5Qjl/Obw5+To2OnQ6sjrvOy07azuqO+g8JzxlPKQ84z0iPWE9oT3gPiA+YD6gPuA/IT9hP6I/4kAjQGRApkDnQSlBakGsQe5CMEJyQrVC90M6Q31DwEQDREdEikTORRJFVUWaRd5GIkZnRqtG8Ec1R3tHwEgFSEtIkUjXSR1JY0mpSfBKN0p9SsRLDEtTS5pL4kwqTHJMuk0CTUpNk03cTiVObk63TwBPSU+TT91QJ1BxULtRBlFQUZtR5lIxUnxSx1MTU19TqlP2VEJUj1TbVShVdVXCVg9WXFapVvdXRFeSV+BYL1h9WMtZGllpWbhaB1pWWqZa9VtFW5Vb5Vw1XIZc1l0nXXhdyV4aXmxevV8PX2Ffs2AFYFdgqmD8YU9homH1YklinGLwY0Njl2PrZEBklGTpZT1lkmXnZj1mkmboZz1nk2fpaD9olmjsaUNpmmnxakhqn2r3a09rp2v/bFdsr20IbWBtuW4SbmtuxG8eb3hv0XArcIZw4HE6cZVx8HJLcqZzAXNdc7h0FHRwdMx1KHWFdeF2Pnabdvh3VnezeBF4bnjMeSp5iXnnekZ6pXsEe2N7wnwhfIF84X1BfaF+AX5ifsJ/I3+Ef+WAR4CogQqBa4HNgjCCkoL0g1eDuoQdhICE44VHhauGDoZyhteHO4efiASIaYjOiTOJmYn+imSKyoswi5aL/IxjjMqNMY2Yjf+OZo7OjzaPnpAGkG6Q1pE/kaiSEZJ6kuOTTZO2lCCUipT0lV+VyZY0lp+XCpd1l+CYTJi4mSSZkJn8mmia1ZtCm6+cHJyJnPedZJ3SnkCerp8dn4uf+qBpoNihR6G2oiailqMGo3aj5qRWpMelOKWpphqmi6b9p26n4KhSqMSpN6mpqhyqj6sCq3Wr6axcrNCtRK24ri2uoa8Wr4uwALB1sOqxYLHWskuywrM4s660JbSctRO1irYBtnm28Ldot+C4WbjRuUq5wro7urW7LrunvCG8m70VvY++Cr6Evv+/er/1wHDA7MFnwePCX8Lbw1jD1MRRxM7FS8XIxkbGw8dBx7/IPci8yTrJuco4yrfLNsu2zDXMtc01zbXONs62zzfPuNA50LrRPNG+0j/SwdNE08bUSdTL1U7V0dZV1tjXXNfg2GTY6Nls2fHadtr724DcBdyK3RDdlt4c3qLfKd+v4DbgveFE4cziU+Lb42Pj6+Rz5PzlhOYN5pbnH+ep6DLovOlG6dDqW+rl63Dr++yG7RHtnO4o7rTvQO/M8Fjw5fFy8f/yjPMZ86f0NPTC9VD13vZt9vv3ivgZ+Kj5OPnH+lf65/t3/Af8mP0p/br+S/7c/23//2Rlc2MAAAAAAAAALklFQyA2MTk2Ni0yLTEgRGVmYXVsdCBSR0IgQ29sb3VyIFNwYWNlIC0gc1JHQgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABYWVogAAAAAAAAYpkAALeFAAAY2lhZWiAAAAAAAAAAAABQAAAAAAAAbWVhcwAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACWFlaIAAAAAAAAAMWAAADMwAAAqRYWVogAAAAAAAAb6IAADj1AAADkHNpZyAAAAAAQ1JUIGRlc2MAAAAAAAAALVJlZmVyZW5jZSBWaWV3aW5nIENvbmRpdGlvbiBpbiBJRUMgNjE5NjYtMi0xAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLXRleHQAAAAAQ29weXJpZ2h0IEludGVybmF0aW9uYWwgQ29sb3IgQ29uc29ydGl1bSwgMjAwOQAAc2YzMgAAAAAAAQxEAAAF3///8yYAAAeUAAD9j///+6H///2iAAAD2wAAwHX/4QCARXhpZgAATU0AKgAAAAgABQESAAMAAAABAAEAAAEaAAUAAAABAAAASgEbAAUAAAABAAAAUgEoAAMAAAABAAIAAIdpAAQAAAABAAAAWgAAAAAAAABIAAAAAQAAAEgAAAABAAKgAgAEAAAAAQAAAZCgAwAEAAAAAQAAAZAAAAAA/9sAQwAIBQYHBgUIBwYHCQgICQwTDAwLCwwYERIOExwYHR0bGBsaHyMsJR8hKiEaGyY0JyouLzEyMR4lNjo2MDosMDEw/9sAQwEICQkMCgwXDAwXMCAbIDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAw/8IAEQgBkAGQAwEiAAIRAQMRAf/EABsAAQACAwEBAAAAAAAAAAAAAAABBgIEBQMH/8QAGgEBAAMBAQEAAAAAAAAAAAAAAAECAwQFBv/aAAwDAQACEAMQAAABxS9fxoSISISISISISISISISISISISITsY9WGebzfo8GaumDMYMxgzGDMYMxgzGDMYMxgzGqPZ+PAAAAAAAAAAEmKRn745eR9WGPWAc3wvj2WWFNfPjc/U6fLt+1x7Dl2ayK3Glg9aNbbY7gy6wANYe78SAAAAAAAAAAAzw2OX1JHmfRAMcuVNK7id3z/ANWqnZo+WumNsbZaONzMNuXyzWuX1Gl/Q85q8c7gZepalMzvz3Yc/p66XufFQkQkQkQkQkQkQkQkQkAIlFs/SJ8j60M9gFcsdV15NAdfjWGvESExbKnljEpj2Po9b4mjSwaUdjj/AESlupwLHXOX1vFL2PloSISISISISISISISISIjLGT0w9uL2Q4PcAAVK21Pbh0h1eSAAAAAOvE71+88MNefzJjD2/N6OvzPN6Dzeg849R5T6DzeiJ83oPN6DzehPm9B5x6xbPz9MWvLkxVvkxIyYjKr2bjTXhGzEawQAAATb6zzr96+eV5rzX6MJYp09B5v0YAAAAAAAADDKPQ8CEuvyoSISISIw9ETyO55Z8/VUvH6XQc9uW6POkEw2ejf6W53bc/O2xwMMe3hhLXGEjIeJ9oAAAAAAAAGvLCXqfLwlMQkQkRLjRbLjazDry29JE27sUi43wonlfO5j0fPLf3vDO+x5czn647WjlHTywyWrCRCQVh5f09nVgWdWBZ1YFnV2wZ75CuoAACT0/mYS24oSISISIpdupmXQGe4Hr9e+R/XMtK/rdXldfDOMr5wkiEiE4plT9fPa8KOSfTaZz9PEF6gALbU7Fh3dZU/GnRclNxmLopUIuykRfG8qM6/KvKjIXhRxeFHgvU0223z8afeaVTXzGewyO19H5HXw15fL3Kr18XeUfFN6UUXqKMLzw+FEWCmoH1X5Z3eBWQtAAGWJEhMDYhr5/UOhnf4/H2GD4/P1+T5B5/Vfld4gWqAvFT+rUmv8a48Lfmo/j9A7ee3y2+92cNmtlxdM+VUujztaBW4yJ6V96GV/k2t1OXpUJgbkTq5Xrq2y+az9ZY7/ACZ9ZHyZ9ZHyZ9ZHyZ9ZHyW42lEvKeDanXjjtsOxPG8k86rZY01CQ3om3WfHHDTQ5sx3cD18k16GGpFLzpblXs5Ax6QFkrn1Slt7h9z5znfhDfIBfKT9Yzvxe98gyvn9efIejnp9MmttMerVeJoV1s0VpMWVWhYor46/hz1o6DnJjo+OrAESA9/BDp+OkTt46ya7PtoJX7Lz9Nebyovb4eewV0Enc+jcDv4a8z5hY63pQL1ElqvGnuc+vxwdGSzVz6vWeTxrv8ttnzwuA73O+p535Ht1GduW6cGlG9rFIr3t475hMDfibZ29zSw0+ec3LHfMJh2uL9Kpbs8jrUbPWteZvgA6PO+gVtYtfZpmN6lgdGQDv8D6XS3Y0N+h53rBlvlZb5o73PrXPn/S5utAvUekTdLXhGGmpoo7OILVVqw0GmuApqA+h076hnefntx+XQga0A6X1Gt2TDTQ+Z2SpzqG3MBufVqra8dMPlFzodoDSgHW+m16w4a63yi3029Fmrf1WW5XrD82zvxRvkABbPSnqzaMayvSyxWx1eURYAdSJuPejmYaVKuzG+YTDc071W1o1tqo4dFV1Do5wmr38LdWbjllXMdKZpG+YTDb1LtWbXGdZx0pesb52i96G/jpq1bq6ePq8b2uuxt5lEXsrRsb2RQ87yKbhdSaTwPpvyq9fEaUAfRaf9Oyu+c3L5gBrQDZ+r1G446a9JsvOx9Svdbs9y/JSvS4rc9Os22gr9g5Vq8TLudKVRxuCtqlZ/ZB8svXzW9Q1p9j8fbjcvXzhj7Pv7aSc9ydIjby0id3HUG21B5cfu7Fs+VndG3kVLxuY5nTatbVvldno09LnY2xp5dTWwa3tnya683Ex9r19tT2vh2MtB2fP77QG1qSvT22dBE7zRRO80Ry9OwbhX5tjDp5XLhz+2EaAAAAAM8Bsxrpp7PEn3w8wyxRb0y8U19niPbygkIlv6nR6fKxZOrycWQxZDFkMWQxZDHb1lbb0aStuUOD6cAAAAAAAAAAAAAATLd2Znu+bxZLZYshiyGLIYshiyGLIYshxh531IAAAAAAAAAAAAADPBMbU6i+G21CNxpjdaRG60hutIbrSG60hutIBn1AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAbk91v5PCd0cJ3RwndHCd0jhO6TwndHCd0cJ3RwndHCd0cJ3Rwndk4LvwcDT7nDz7gp0AAAAAAAAAWxk6vnsWQxZDFkMWQxZDFkMWQxZDFkMWQxZDFkMWWtE8TVyjn92GUrYMpMGcGLIYs4MWUmDKTBlJgzGDMf/EACwQAAEEAAYCAQQDAQADAAAAAAMAAQIEBRESExQgEBUwBiFAUCIxNCQjJXD/2gAIAQEAAQUC/MaC0stLLSy0stLLSy0stLLSy0stLLSy0stLLSy0stLLSy0stLLS35kWyb9hFvv8JCRHGWIPnXMxh+WJB3/Qt9m62bbBkG9qnpdP9lZNvEWCjkUpguLxbtOTxUJuA/Pi3aT6Yyk85f2qJHNTxwjQJ4+nG/8ANeyavctbviMXlIVSA6z/AGdSKOKgSE/zG7YlLIPjBJ/+tuH5Nrx9PRyq4zf3X8YJXctxWLsIotgpfEc9X5UW74lLM3gdmI8F82rHBoeaIY0aWI4s5W84QHdv2RtMf6C//q7O7yfwGe0W1bNal0wWq9eseWkX5Efguf6vmwajvzV0mb/jt8N3/V8uG0pWzQjGEDE24O+b/jZKPnNZ9b7f9PyYdhs7SEOARzk0ImK5JZrP9BiUP4qQZxB8OHYRn4JNhxMVyy/RTi041MMkU+Pw/wCKpVLbmce0frXASwTD8OHU8GLETFJIkv0jfZyTkSIbI9I6VmzO9XjVL5o4aa09cA640ey0FJ3k/wCjsXYweZyzWboNogkA0TRr2YhgSblJ/Sr4dZOqWFBB4nOI2NZlP9LiB9PWg/8A1SrliqoKryFWAJ1Iw4olt3Tu8n/SlnuE6CfSVWB7Zc8lm7/JzjrnHXOOucdc465x1zjrnHQ789TPqb8Kw+kHUEdZ1e+F3yYxpln4zf4qf+b8K22dbrgoty8r3w37EXj09bSWLtXhZ7M2bmtRBGdo0lvFW8RbhFrktUlm6zWaz7hOQTjmxISbNpwcc/LM8nwupxK6sy1luXH1SlKXyXbDVazu7v2Z3i/bTJaZLJ1k60SWieXbDKhOGQchq5W32IOY3zZBCQ74ZhzVPFieiF8u0DrCMpy9bdR65a79cXtOcnyVwyOapTDVh1u2GrVutMD2bLNk1nLZTfZxxE7N9vBSxGpSeT3y7p+kWeUqNSFQKxOzyrfSmB7Nh884jnJcc6451xzrjnXHOuOdcc6451xzrjnXHOsDpyFFSJGC5A1yRrkjXIGsdsxLLrgNbQBW5+RzlB+VLJ7BH8XCbVfrgVbdsrGbGxS64ADRXVSGTfJOWiLu8n8lmwxyk8pdKVd7VlmaLTloi7u79sSNrL1og41VYzY3rnQQ3MUUGEMcNc2bJuly2KpCeOG1e7sL3dhe7sr3dlSxq069zbRcTtFbnHXOsLnWFzrCLZKaPUJiBk+IXHU7dmaeyd1vmW+ZDuGhKL6ook2GP++uC1964sSscap1+n6+oi1yZbk1uTVA0+R4vE3bP5NYBIV1ihX19cDDt0Vj1jcs9aYGr1umD1JzUhTisQPtD64dhsrahhVOK9dTXraa9dTXCqrg1FjcACP1wWnGNdqlZliUBju9MIrci4rrtGRJa59MPrcq032Vg0a4Jyec+mCA3biv2ONV8QjKc6wWrg/pX7HJtdKQHs2YRaEfObLNlYsDriMSRS9KFblWWbJr1hqtZ3d36YRX49NYtY+3XAq+3VX1Cf79cIr7FJY9Z3D+MABrsLHbG3V64BW0jRivnm/TFjZv1wSts1VjVrfsdMOr8m2rpdsJyuYnSmB7NhmyaUmhGyZ7B+mF1ns21YKwASk85JmeT0a/GqrEbHJt9Bx1kjFoRnLTDoSbDHOTzn0w6tyrSxCzxavXAq+3WWNHz7fT9fSJY9Y0A64EDbpr6gsecCrbh1jdnZrdq+NyjE2MwmvaDT4pBe0ivaMrd17EOuC1tiqscs71jpTBybLNk1km2K0TdP0AJzGHCI4O+TXLD2rPSoB7J2bJpyaELBnsGUWeUqgGrV1jJHJe/Bw2tybaxKzxavXAK+gKxk/8Ov08DOSx423T6/T9fIax+xor+MBrazqyTbGcMTQHhBiL0lhejOvRnTYGZPgZ16M6bAyr0X8fRTXopq7W4p+uDVtiqsYtci10rBeweEWhE89ArVWRp+vImwKS9FNNgX2bAvtVBGsBXsNa0b0gl6KK9FBei+/ooIIohEsQscm34o1+NVVuesqBkwfhsFYATEkYvTDKvKtLE7PFq9fp4H2V2ec1UHqJ2M+qYI/z64vZ41PoaegfgZZjXKKuUVcoq5JVyirlFXJKmslZPZKrbTtQ9co4HOUWwKWfooJ8CfPD6caYliYeUdsNaUo4GHL0Q16Ia9ENVgxrgnLRGT6nUCSguQVMdst+K34rfipHzZCnoffit9lvst9lvsrdPlEbCIuvRQXoh+Ls85fLXhrL1sz0CVKGcut0nQTff5a8fPMTvm/yxk8X5BU5yut4i3iLeIpzlPw0nZa5rdIt4i3iLeInfN/I2yj8opxjDdgt6H6EbapfsQR/j+wZs3Zsm/YQlpffdb7rfdb7rfW+t9b631vrfW+t9b631vrfW/8A/e+MVcUq4pVxSrilXFKuKVcUq4pVxSrilXFKuKVcUq4pVxSrilXFKuKVcUq4pVxSrilXFKuKVcUq4pVxSp6xGb9jdnpH+xsz1l/YWJPAWTsmZ3WmS0yWmS0yWmS0yWmS0yWmS0yWmS0yWmS0yWmS0yWmS0yWmS0yX//EACwRAAEDAgQFBAIDAQAAAAAAAAEAAgMREhATFFEEFSAhMQUwQVIyQCJDYVD/2gAIAQMBAT8B93heGPEPp8JnCQsFA1ZEX1CyIvqFkRfULIi+oWRF9QsiL6hZEX1CyIvqFkRfULIi+o97hIMiOnziZ4w62qqpuKdWjFBOHgA+VLKIhUqDic00/Q9O4fMfmHwMZHWtLlX5V5aO2DHWEOT3mQ1cmVHcKTims7eShxpr491rS82hQRCFgYMeMNI+g4VwC4Qm019z02D+09HG/gPYa2vYKNljbVytn2XK491yuPdcrj3XK491yuPcrlce5XK4tyuWRblcsi3Kk4CGNpcSUz1B8bbWgLmcmwXM5dguZy7BO41038XDqAXhapzHVYuYze36jPc7LHx1Nm7d0KEdsQEXBo7qSQv9zip8mOvyj36GtuNEGAIiqtcw1amEPFV2CdOB+KcS7uejWRrWRrWRrWRqOVsv49PGT50nbwOmHFqkFHdOSslU6OEcGVc5HjWbLXN2WuGyl4svYWt7LJWSslZKcy1Qn4xCcL39llLJ/wBWT/qbFTGteu1Wq1EUxtDh3T25buyjdcgFJJTsEwUGNvQx9xorVarVarVRSSWrOcs53R4T3XGqHZZjt00VOIRxaowGIuoFn/4rqqqqVUoiqtCoOmioERRMFBiE7EYW1WUAcQOg9QWXe0k/GIRxCOARx8BOdccIx84tTsQpTaAzEJ2ITk1Hx0HuKKwKwLx1BRjvU/Cc641OA6BiFBEBH3+U9ouNFQKgVAqI4tTjiFDCDH/L5U7GMdRqpg91oTTcKqmDsIWXvpgY2HuQslmyymbLKZsspmyfDFS4hUComtuNAnwxMZUhUVFEy91MJrGNLyFmlZhRdXyg8hZhWYU0klUTIms/Hr8rLZsrG7K1o+MLRsrG7INA8YeoSeIx1g0WYf0D2Ur8x5d+wRUUK0sX1Wlh2Wkh2Wkh2Wkh2Wkh2Wkh2Wkh2Wkh2/6eskWskWskWskWrkWskWskWskWskWskWskWskWskWskXDvdI2537DRcaJoDRQKoVQqhVCqFUKoVQqhVC//xAApEQACAQMDBAICAgMAAAAAAAAAAQIQERIDEyEUIDFRMEEEIkBQMkJh/9oACAECAQE/Afl1dVaauS1py+zcn7Nyfs3J+zcn7Nyfs3J+zcn7Nyfs3J+zcn7+bW1M5Vwdr0jpr7JRsyMcicMf4H5OpisVVcuijd0aydhLHhE/RHTbNr5W7K7Jzzleul/lRK1ErUUfdJPgl8n5Op/ouzS89/gbG7nVS9HVS9HVSOqkdVI6qR1UjqpHVSOqmR/InJ2RL8dSd2zpY+zpYnSxNhQ5Xc3Yu5C0E1+x00Pj/HhZZPulpO90cp81chJyfBDTUfk0oZyt2t2HJsuNqasyX68F3Ijot+SKUfHZtSNqRtSNqRKLj57dGGEe2dZmm7x7czMUr9mrzwjaZss2SGnZ3ZuGZmZilcnVu5D9Y8mZmZjnVRt35mZmRd6ubj4ISzXJP9RyuacL8sk71zFWaxVzMzMzMzHK5CGRsxNqJa1fJCOKsPk24j4VZMirus39E7yFA2f+mCRijFGKFx4Lsv2WRcuJ3JOsndkFVu9HKwtRusnavIvFfNZMhKzrJ2QlesnwJXo3cirKvlkY2pKs39EFWTNNfdZPkgvusncgibI+ey1ncuy7qzyJWpJ2VErcUbsjzWTsqt3G+RSZkzJmTMmRu6zf0QX3WT5MrPgU5MyZe5BXZLh2MmXIL7o6XLly5cUmZMyZcU5F2XY3SKu7G2jbQkkOCZto20O0UXZe/wAF/g0Y/fe1c21/BirK38nckbkjckbkjckbkjckbkjcl/Z4IwRgjBGCMEYIwRtowRgjBGCMESSXj+k//8QAPhAAAQICBwUFBgYBAwUAAAAAAQACAxEQICExMkGREiJRcZIEEzNhgTA0QlChsSNAUmJyweEUYNFDcIKisv/aAAgBAQAGPwL85arlcrlcrlcrlcrlcrlcrlcrlcrlcrlcrv8Aa+08yC3YdnmVtCziKkg4a/KNkN2nINe2U81cVatrLKiIAZANmhO0GjYZYz70NJMzcfkxJyRc680QYhvc0TXcs+ITdTGP7Qi43NtWwzB96A1t5sCbBkLBKalRvPaPVbrwfX5EG/qNImbGlyfFycbOVL3/AKno9nhYBiPE0iJ8MK31oOzvuW86zgKBK+at+Qhv6RS6EHDbiOIlwFSF2SEZRXNm8jKdQCIQ34nnzRh9mm1mbszUh8Gb5ROY+Qu9K8yZmlkSW1smclOK6zJuQq7bxJ8S3kE4/IYnP2/fRPDYbP3GjYGV/wAhie2tB7puI/0g1gk0XBTzyUz+Yt9ifMe1D4m5C+ruSEOG3ZaLgpuUz6fImv4WUNjOwvMh5+y7ztg5Q/8AmiblbdkPkZabitmI4bA/9kwtuY//AAtmCJjN2QT4e1tbBlOtsQW7R+y2jvxf1cOVFt/BTd8lsWzEO0OBUnbhRdDhHZcSdp1iEIRNt0t6y6pM/hw/1EfZBkJsh96JMtcpuMz8k2YY2jxyW88+livKv2m8Cpt0R7w7otTohvcZq1WQy1v6n2IOifixPO4UTcVJu6PkvdMvN9VgnLaOysOiIiwIRnmQpwoMNv8AEUWu0W4JKZM/kzn8TVYeDh96DK42qxWn2l7elXt6Ve3pV7elXt6Ve3pV7elXt6V+JIjyCmM/ycQ/trQ28Xj70M9jMokky4UXlXn2UOfD8nEH7azTlD3qG+x7phnxq+7MXddmhhmxilxryCENlrgNFjlyXiO1XiO1WN2qxO1WJ2qvOqv9jNp9EHi4og5osOVQACZOSk7xHWuo8hYtiCeblvOJ9faOi5i4eam4zJvNeYr4XaLC7pKtadFYDosDukqew7pNdpdZO0A8FvKbbHD6qT2yV4UoLC/ldqtt5Dop+lHmVIYnWCtssaXOOQXu7tQgI0MsndOs2HOxnDj7VsJl7lKG0TzcbzWfFNsrhxNZkIZ38lIXBOnQDKcltMY23yVlFt/BTKsubZVDW2kmQQaMfxO40OeMA3W1WQhnfyUyDot1j3cmrwIvQV4EXoK8CL0FeBF6CvAi9BXgRegrwIvQV4EXoK8CL0FeBF6CvAi9BTo0Vpa51jQeFG8Vnos9Fnos9FDhMOG086xjuG9Eu/jRseppm0rCFkKHOzuFbvXYYX3oIGKJuisYxG9ENnKja4+1JKmahe64IudebarYWRxckALAEXcFM3mv3YuZ96tlqZCzF/OgtGGHuj+6rYbb3mSaxlzRIIBWVdqIbTc0XlbkFgHmV4cL6rw4X1WCEsEL6qzux/4r/p9Kk54vnY1YhosQ0WIaLGNFsxHTFbahPLD5L3h/0Q247zJeK5eK7VeK7VTLy4cCgRnQ5xuCmb6occMLe/4oe8HfNjedZ8dwwWN50Y3dRXiP6ivEf1FBs3ODuJpJBmBZ+ahtLTYKBCFwtNYON8U7XplQITboV/OrZaVDhcBbzqujZYQrWrZbid9K3ePOxC+pXhbX8iSvdoei92h6L3aHovdoXQvdoXSmQ4ENrCBN2zW76KwF8S6YuCsgQ+lRWQRJoy86oJwQ94/1RPytTnHMzqtZ8N7uSkE+K+5oTnOvcZmrtkTZDt9cqHxM8udIYy1zjIJkJtzRKh8QYbm8qrIXG/kg1ok0WAVL1ejEiGwfVOiPvcZ1Ww/hvdyUgnRc8h5qZMybTVbtY37xoIF7/tW704otvpQzs4P7nf1WbPE/eNAgtNkO/nSYxuhiQ50d0MUWz0rO7Q747G8qNltUQW5Wmt3hG/Ft9MqO7bghWczVYwjdvdyoNt62ruAqthDO/kpBFzrALSnxXfEZ1WiW4zedQ+K74RNFzsRMzRJomTkmQsxfzoc8HdFjeVVrP1EBBrRICwImq57rmoude62q1nwi13Kh0T4rm86xiuvi2jlRsg4rPSs6OfjsHKgQG4ol/Kt3hvina9MqGdnb/J39U9+4bsO7nR3bccWz0zry7RD2/NqAEF8uYXhP+ishP1C8J2q8E6oNDdkXnzrbbhvxd48sqO7YZsh//VVkLJxt5KQXmbESLrhVZCbe8yTWMEmtEgpm4J8XI3cqrYI+K/yCAFwRe6wNEynRXXuOlAa0TJsCZCGQt8zQ79IEm/kmsI3BvO5UOeMZsbzrOjuviWN5UED+IrP7Qctxv90d2DbFMvTOs7tBvdut5UCCDvRL+VJjuww7Bzo8zctl3oUdh7NniV4kNeLD0Xiw9FbGZorIsM+i8WGrY7Ole8W/xsXvDej/ACveG9H+V3ReHmU7Kwc4b8S00bLT+HDsHPOqyE34ig1okBYEStrbyuWNqt7Q3oXvDej/ACt7tBn5NVvaLfJqbCZc2jvHxy2yQElL/UunyC94d0he8O6QveDL+K94f0hNhswtEhQ+IMNzeVLIWYv50WXNsobL2T4rrmCadEficZ1WtOBu87lQ5wxu3W86z+0H+Df7oDeFEzc2vysU+FYyxv3W1S6ndKy0V40WWiv+ivGiy0V/0WL6LEgx0U7N8l4v0QPfgTy2Fb2gejFZ2h+gVnaBLzYi0HacbXOoB2yAwSCkIht8lvRok/KS8d+gXjv0C8eJoE2Ey5qLjkpnOjdMliVs58lms1mt0SpuKwlXFXFYStuJGf5CyxWRnaBeO/QLx36CgMGXtgKxlfRtnKsGD1qT9ttU4Pqpn202mRWNYysbljcsZW8ZyosJCxO1WNyxuWNyxuUz+Skf9qz4/MZKXzGauCuCuCwrCsKwrCsKwrCsKwrCsKwrCsP/AH7u+qy1WWqy1WWqy1WWqy1WWqy1WWqy1WWqy1WWqy1WWqy1WWqy1WWqy1WWqy1WWqy1WWqy1UzLX5ls/q+ZHgLPmJlfcrirAsJ0WE6LCdFhOiwnRYTosJ0WE6LCdFhOiwnRYTosJ0WE6LCdFhOiwnRYTosJ0WE6L//EACsQAAIBAgQEBgMBAQAAAAAAAAERACExEEFRYSBxkfCBobHB0fEwQFDhcP/aAAgBAQABPyH9sB2/pDbbbbbbbbbbc8/ou5PxG6B5yyXURSGBWhwMBnQfwg0OK08M1QEGI7SGkoulyhACSQFyYY9QGg7YJaoT1dIbYLAiEgBkoCHSU2Ce9pnDJZ/gFZ8QSJAHDRM7MSLWFBZpNc4rqTtVt5YkoikvK5jgogInITMgC+EWLOAbm0BYVsFXmesAkK4KwLdUgsjeg/YKLAVMBBcVXC/IGIGqDM5AGf5GK3e+I82IOgAje1+TZchiZAzp1sA94Sg9Ifupew5whX8AMM70ErwggoCDof2s7j57PX6xJlVvqQ1K5euJKBOlYSoY1vFbnHkCToM4SDJsoN2o1MULTk6Dz4Cc4C0t5xKKTB/ZAZUFBxtV04xycS5JxopTdYqV2wLB2ePCQUTMEVyBOVyH7IUf4M4XR6D89JzYNH2HrghNSrm/XMBlfh80PQfmEkCafg39INaKgWAgzHsDeEIRk1wUURiMRiPAojpEYjpEdIjpEdIjoYjoYjoYjpEdISmc0OOMRIkYjEYjEUdIAPP8pxrV7C3gxQaBD4yAiXECwafsB/E0EXNywC8AbroL8vwgMgCpJQWZlArmzt4S0LDoesfKA8D9m/4gksCMW3rFXDQaSmgA1BkCD7puAh5x9oIXoOnxPxzcgGpOUGPBtFNgYNNZWzGMVyGQ/ZP5CICSIsoxV4ORCBQDJITIdSOpMPzG9oFoO9OAAEc265M+dottXOZak4O1eUIUmEzP8QoCHfI+Zl60oQALAORhoB+wrKuQRcriCNQ0Om0daSze8JFxc4bD1sfmFaMzDpDCmF6mO2eaf4pxYgMxkNOEgXXQmlYIJLganL8wAO8dMnMIhpeW1J0qlCV1N48ItTgov4VoQpnHwy4SgblhcmAgAyEBXCORhuA8z+FjXHsXzOxfM7F8zsXzOxfM7F8zsXzOxfMFp8uGDDWAMfp1USKsFuE490tOTDa1/CI1AAMwKUVmQAjOp6xn/SfYRHT8IEZwt+AEHBjURjURjURjURjURjURjUYkHauItfACZ8gPM9MCoPM/gYhw0N4ty4foYFIRHmLLw9+MgrhoIBFQNou58tQkwyvu8+2T7rNfro2rrG1PWEjck+MZ1MZ1OLwY2RmZoZaNXAW0CMvCmuAxYhALkyzDXDyHhg1UTRYCgPaFGS3hnU9YzqesZ1PWM6nrGdT1jOp4jGDAtYrQzcT1DmeN4UeL3n3XDwjseZwHu3ZHG27TaIYkZ/4cdCLTeGtFiJ2IiQ41dg0jGj3tPsIOmxKYeawQORkTAptHzg1AOUI2Kv8AUPEFWQBZgMOz6wlI0FenEuC8RZ29/wAoPay5amBBoxTYqBuIABYDATLAtQsIWSSak8IUqH4Rv3vBCAgICAehFOcUMJDGjF67yhvvAAIABtgAzZIMz1Meg3T+/CEBMDUkoQeIJC3UvjBgfRRn4/HCCm+rQLwDJoSyyhNHN4zuf2nc/tO5/adz+07n9p3P7Tuf2nc/tO5/adz+07n9pSXlKIzHxPphakSteG5DchvQeSD0+QeT4vaif+r4WwxKDGo1m4dYMp4AhJJZLMTV3UPExFobn8D1wYUi3ZanpxBs0CIy/wCsxOOTpYOX5R5KhyRk8FlRcqIHbhGK8y0G/wAeMEWggBlBFMkMqtQ4jgrJrcIAkoGNgMzAikhnqVzgY+fXM3t4cNueCdN4GpDA2hhPjyiAAgIuALKMImFpcGJxxio/ARhVQW6glQPRj7wlsR77wUBgZFBq3BKUN6BaAXETFUInOIEDp6J7QKAMmATnLhgSArRAw+uisHYQPAwaC4SSNxU8+FGczzwU8upvi88SdzwgewutVz09TgLIPZrO9ved7e8HKoEtK3jOpjOp6wasAE8uNHSI6RHT8JIFyBzjGvF5xnOEGkIIoYcQpcw8SpdwdMG6pdX4HrwgElAygGpgmXrNcx68IEICXTfWXIhRZyHo14hzWoB0fmdtJzgHgEAcH1qEl+jhI8ygr2HF3yBne8sDYVBj+XASwSoG3Colnf0dfTAENAByhb6NwjFxT03zaAAAEBQATOAS10EqxGc48Jxolzl3M4aHwh1K2I1EANzNSNNd4SAJJQFSZmSHwGfCA1AbPQL/AB4wNYVCwGLGom06zYdYN7oi5ZAS6pj+PbhIvOZ0G/xAAAgKAQogwC1itDJ4EmpzPBzh0i8Hdh4CEoMxlwenEdBqpsNvnxwbZXc8zw84iivC3YeAWGsd7z+B64lD/PH4HrgF1mts/wAcSsV6Ln4nAZlK5hIWSTwBzZfvkOIQUq15ZHv44V3bPUn268NfQT4bLxtgB9CHlnDswiWgOGy8degXgAAQAQhrE2HIS5UoNBkOnCdAEgfpkPE++FvAya7Q17KJucBkw5AMzBXoDPUqnCvZ0tn436cL+JAajJlQf4NAyE2ptDUs8FvIZl3abhITGd7MvG3WAIIUEFRslqXbhJJZLJqTrwr15YNvnxwr7x0L8Wc8/Df7g/Hox+bcVCO4PfxwPVUP+b38MTlyHv8A8j1wr8QwCMsz28eMcdDPRPgYnCFS/kn3PynulD6pDleJKkubj4iFBGxkd64BGLQlZ5uluE1TuIyzfHjAAAgKARwjkJlm9AcNjAvpqejiGgA2gjmQGTpDBuodBt8+PDR9zOoYIaQEIf1oTQCUrWloyGDcDANSbRVOc6hwKhaW8Bc9f0q1WS5MvH5goKUj8jM9XxeGpZJJ1OfCsXoH5OFfr2D1PFkt6y5emFkmcZa/Dx4hAtQ7QX8/TC589G/sMVU8xP4HrgxRVKLOFYuITJBq+krefWFvvJRz+aLFfkZ94IaJzCDRfAxuhDyI06x+3ebn3aPv8EUYBEEnxU9L9cDId64OGG72Z7cLKmokZDM9IG8GgZCalpDnBcBACAhAYgAj2MpecRfM+6wPyIrzme+RUOcSC5uTmcLXyDBAeMBKDZYDPwSQjZSaXgAL9YI/wklvc4ipBAzGZVOAUE/MZ4DkNPx/EGkk0wM5cORcJBBq9l4/OGyod2fheWC4aKivY9PDBQ2FnnhzqPHjbnKhHeI4qh+TMVPgJa1uDU5U54hFQ0NRN7CBuS2sAAuc4pXkTBKOUZAPOCDk5AQcKBsCsJZdUmCfVUp5xJT53PWFFxvJ9tlz1jeRoE/8wAcUkB1MGDpoFESu5igemJx3bHtG7qubk5mDsgIUt6rB/fXgKV6RBRr5o2embPTNnphkE3HBgwwdIcguGjNHC2h8Nu6CgggO0IAMmATV2Mc0FKjz/MA9a54mwkVBg3BS3nxVslXgP2vzVCWVBiRVzghiMmpP5n8aggBm8pdPCpPtp9tPv4mfkPAEuSGAVpPup9tPtp9tCEIyczwJ9TWKKKKKKKKKKKLBoEQdJvHpNw9P4KUZXMUUUUUUUUUUUUUUUUX8FRYSiiiiiiiiiiiiiii/gGGGcAALCKKKKKKKKKKKKKKKKL+ARYAnfFO+6m06x9HWdznc53Odznc53Odznc53Odznc53Odz/73tY2pbUtqW1LaltS2pbWFW1LaltS2pbUtqW1LaltS2pbUtqW1LaltS2pbUtqRQiAGf6Sgr+j+k/A5D+csFDmJJUKG+FzEuAeQn3Kfcp9yn3Kfcp9yn3Kfcp9yn3Kfcp9yn3Kfcp9yn3Kfcp9yn3Kfcp//9oADAMBAAIAAwAAABDDDDDDDDDDDDDBOEEEEEEEEEEE44444444444r4sMMA8eAykMMMIIIIIIIIII4pgMMe6T2974Vsrzzzzzzzzz4JYkMMT323W672qEMMMMMMMMMNUAMMNP3333334sAEEFGGKEEAACIIMMTj3333d878MMMMMMMMMN3HHHHJ5z73UbDHEMMMMMMMMMOIEEEzx32EtmpIEEAAAAYMMMM/wD/AP8A+P30hR7/APyjUJ9997GUCNsCy2ly95gyKDSm99t999e97rXbY997NFTEd993896/hBBBBhcfsf8AejiRxyPfYUvfdHbrjnfQUPJffY3Dzcr/AHkA33mL22t33aFV7X37Pb3op33hf33oDkN7345Xzb32Un32Nf30mT32Kf1X3325w573g/T3gH33tV722N4lnkJPMDz33MH32mCLJMICAFv0aMOOLKNREAdKJMcIT77w122uCIMMMMMMJHAEIHCAMsAEEEEFJEMMMMMMMMMMMMMMMS4A488sMMMMMMMMMMMMMMMMMMGDFIMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMzzzz3zz7777zzQAMMMMMMMMMPzzzzzzzzzzzwQcckkU0UkkkEH/8QAKhEAAwAABAUDBAMBAAAAAAAAAAERECExYUFxkdHwIOHxMFGBoUCxwVD/2gAIAQMBAT8QhCEIQhCEITCE5JqxeQe7zZ8Qj4hHxCPiEfEI+IR8Qj4hHxCPiF9VJtxCkvqzfPGo5iHoxp2xL9jOD0aIQ11H/AyB+xu/bXHZxDZuhNKlywag4F7ZjN4gj/QGkTWcxOqohCEIQhCYrKc3kcEj++OLIri1g3cGoh8KwWsYRouX02Xb4eS/1/56P3v8frSrg5lrMQpDdfo3P6Nz+jc/o3P6PGXY8Zdjwl2PIXY8xdifct12FyUufc859zyH3PIfcVpZLYj9LGZLWLLn8qiXxXT6ebeWrn7elOZiVC5jVPRqYV1LYNIsl9RDl1ZLmM2r9DIDS0ISNGR1RAGPXbMozMaUJjzvPyc7z8nO8/Jzhc22nobipc2C7/n0pk3joEPSLcYJpmzmHKvopaJCTyZn2HPGxSVPicxzHMcw7PwER4kiHMC34gh63cWqpr0VyYJXBBAj0ISGUZXqIQpeJ6HSTMcuWCVMiIgggggSrM0K1OQJrmRW9cErkZIMaGbVDaNfxWujRYpxEj4sqNISi0uheJIatGwJWaWOY22R9i2TQ9oZ598UiGrxSLBIrTGqdxtmyIyMhq8EqRJDzeC1jV8i8QSmWC1jRYrWNFgkUHrwWZlQZR4ZmJOI3DFYiG83z4dMViG4YrENnBK6VTXobMGybIkkiwSrNEN14LWKbaWZjn6zwSsbiG67gtY3EPMSIkF3CqEivoqn7CpYpxIZYrET6/d2Jz5kCSWgigqhECSQ3DCFwmg1gps+ht+gl8PQzbPQUbRjY6lCBiNZj1nF/ZBH2IfXyEklEQSqQ8Hc9CmLH4akDNtJfW0kjNj0RsOiE5Ul5DSeo36obDojQEwyeYf+EIQhCD3q/g7JKxzHj/XAmEIQhCfwFu0GbI8tGz3vueVvueVvueVvueVvueVvueVvv/09hefk2V09zZXT3OR09zl9Pc2V09zk9Pc5PT3OR09zZXT3OT09zZXT3OR09zkdPcbPw/ThCEIQhCEIQg1C8RX0kbxvG8bxvG8bxvG8bx//xAAnEQADAAEDBQACAgMBAAAAAAAAARFhECExIEFRcZEwQLHRYIGh8P/aAAgBAgEBPxD8tm3fYZV/Bk/TJ+mT9Mn6ZP0yfpk/TJ+mT9Mn7+WzkpvsuNU2C20mptJcDmiI07+h5Uf8arBEigrd7aVQtAejc+ENUrfx0ot3AhzH76p0BAPjY7uiA5lKUpeva+nRz+uttJWX3ZRTEMQxIxIxIwIwIwowr/3+zAv+/wBiupb+/wCxscrMgyMyMVDm2VLpSg2Dzge37+Pzw/46XvyNWbFYmCdV0nsiO5C28v8AJE7O4otlrRKV6AmXBSMYzekPZJG4bRJEL11TSdLlOX0vwteRCb6Wt2R6lEnQjnkE/lmQryJXuQ9D1PU9RRXh62UhY9T1PUoolr3vPRFbo3Nx4nqX4G63Asi/UckGv2CjVtdhm1Xo3FTcDKKKKKGpDnvg9g1eRJsWjcVG25BCJIxI7D6klOgNgWrwNbjZYTG+5gMBgGmDMU+Xq12Z3oV5EyEIWc6AgrrZdHTBa01q/YivShYi0bio22Eoo9JIYubnOoUTWQsmll1hubjbJCxaNtOgUdetGUr62ENVBBUgohKifQlgM2k2269GipuxBNQdey7iESabwJNoJRTUEq4JTYso3cuxGtzOZS/cyDs3fQKPVYNqBRWzINuQ3aHcjMg2fOoeLSkV5K8leSvIvsmZTIPuYw4mZjMQV0cpRaetiHdeqrQZhty/BRWV6VlZdOZylKUpRSx/oqV2IQv66bTqMhlM5nM5nM5nM/8AgP8A/wC/+4n6SlKXVuKjbbpCEIyEZGRkZGf/xAArEAEAAgECBQMFAQEBAQEAAAABABEhMUFRYXGBkRAg8KGxwdHxMEDhUHD/2gAIAQEAAT8QqVKlSpUqVKlSpUqVKlSpUqVKlSpUqV6IqFrMdt6DCjQ9VnJTkpyU5KclOSnJTkpyU5KclOSnJTkpyU5KclOSnJTkpUqVKlSpUqVKlSpUqVKlSpUqVKlSvS5VzNJll5f89SpUqVKlSpUqVKlSpUqVKlSpUqVKlSpnnTL/AC8jYK4Buzb2dXt2CvrMuqXLsfsp9VAVaDWZYfVBf++pUDONZWbt/dxxDZDS4KrVL4drHQg+xru9QehlRQBvBZqd2tr1dfHD0O/WUpZFDjh8EyEpSrJqVGQgWq0BDdmxYf15N4NBMJmzCQvAFDWxrPOvfmZmZmZmZmZmZmZmZmZmZmZmZmZmZn2XW6GnuIQql0oJlRB83btp2iEbQKs5wYya0Y/lKxVQ9LYA52X/AN9UYsxWDfXWIAMio0FfMQIqWnD1Gxy39OY98moeWNCipOLbxbLxhi0pHMa9KUtwCDl4ukvj1qVKlSpUqVKlSpUqVKlSpUqVKlpaIwNBqyjG3urQAmNHIj61VoKUOp2CMFwh2KvML9VIvoT9xFF8Um7mnnGeLjQb9EMVtCxR8JeSjjAZXQVrlmE7sqGEc5d9C5iB2Y/sZe6wA0A6EYZio95QK81EwHqFJ1PSiUSiUSiUSiUSiUSiUSiUSiUSiUSiV7GpVb6Hv1rDul+pXDmpaW6gRh0sRbb4+gMlgUcjMqCBaHcWyLXAvTE6FGgG3oCoImgLVsBuuhD9hFgDOWsBQ5Eqq+kTbg15zly1gAAFBgDb1o0b0VgMA9V9GJIDt/jZ5M1zKlSpUqVKlSpUqVKlSpUqVKleyuG8AAaHvazMEXwrH3fXb16gnBLGNCe1lXTK8gOh65mRL0uQLms09pcIph+mbvNb009nWXkTRgTPeRyqbKwFKtd264PvKqVKlSpUqVKlSpUqVKlSpUqVKlR9Kkt/8L8sHI0v96c4d5hF+Sr4itm4VlaF4HY9KlSpUqVKlSpUqVKlSpUqVKlSpqlD5dJjb/mlZynCtuC1qdeDgpBTbJoWgSjhWRv+hGwKUu76W4MtwZyGchnIZyGU8H1E6D4nOTlM5ycx4nOTnI/+FLP1T+BOY8TmItwS5UVgHAlTedbxOp4jzPE530nOfE5z4Z1vEo92WlWpF+h/qwZUcEDXo/jxlNLQ0HF5q5XVWfXr5eBxY3CdSYfuU4Mpwf8AmdHX/K/68XxafX7zXSW2Wt1BSdCDv0z/AIoIQgFqaAGq8CMGRdjJp1rt/fAAAAAFAaEoqmA3XAIG19Q4H5Y/8+0W1ypXvqX3iCMKy2HPzRqrXriU3l0KASuAIh8INf8AqR5MvLWEiKIVsC0LaLs129w6oho/QE+rsMBiLLoKZ2Bz1fp6W/2G/wADnFdrY9Hgeyv+Xg/0UKu0qR4y7qprUjYpvSXKzJpFlrUrB3lTCbEirVzvsOYYhVYXpKM6W5yHN66CrQZV2gMcloJw0nA/s0h9MpM7zUK+gmya69Xi8o+AbU/669MTExMTE6QDeNqBEaX8vpziuDqvo8Z8sfLHVUXvcQgWr3jlqI1ZOtefrnEHs1loZQfaZ5bRaWUOxR2lRRfS1XMFYOSnkJbx3JRlklBOPH5tsKCjAYOUrpOxr0DeCDXhp8zt0PWpUxMTH/GSpUqVKlSpUqBBrbZqV0HNz2OcACgoNvYLhWKWBq+4HVIrYlqFCIAFfTxFuhv5iQRltE6hziBao54hzROY+ktO/PsNCNVHVLfTXCm0qVKlSv8AkrH+KgVwBbEFup+j6A9tg/HJYmJd5rXjAMB07A6nZl0W+thfiGUHwR+8MGP8OQ8yzieZZxP8QAAAAAAAC1pwlVz1b6RraROT/iFHrUqVKlSpRKhTaDZpgoBiivaQycWtrI1yBe0dWBy0Y34xKlSpUqVElRf7ZHYI4XGt7EUb8Zn/ADp/cz+h/c5zxETUTr7zWLiUbva816VKeEp4eiVFDVIw0jWuYoapE9Q6s4XkJ/Qn94mevrE/vE/vHoZlItuv0mufbj7Ziy6scL9AfF39ohGjXEs4nmWcTzLOJ5lnE8yzieZRueYZNpesBxcePt/s/wBwMc5tFZOx9eT36+f3IRvNjgrfi8pT0BsRfvFLVeuY6x9cW1+dzi+ubXe+sV1Tqv5i2q6p+Z/VRXV60tYgVdWTACgDhbP6DLd18y3i+Zbi+ZfN8wHbuST4U6dSPKoTepe0HC2A8EqAAj3e4aPcp9gwvG2rQDdmN3qlBrC7gxzbfSpqxo35+v2mZv6grucnOc31M19Z/ST+kn9JP6Sf0E/oMMe3xromPS3Lwi6Gmau33FX3kWHdJtFVVbVtfbuC50G70IKWKfPacD5HKH2GC2HBq5NISI+SSPMQzBVJeBIsBtSiB5sb+3TVo4sfr2Eol24XqHBI6DGsWPKMOVRTqDtyY6Ns3qHEdKnHO+JmTji0PwLYEB6xPdXLeLwujTT0Gohp+7CfLbDkPwEACjAYD26tzFbsbc9OcEIQ8QTqSUb1CQSrRTdWefdfyNwifHOoWf6gVNcuh1TkGfBvC4kAFDdeGtBgm1ejoB2yQQABoBVegQbDtGByLXXaJJsKtaq2+26BfWhQX4x1EG8QDYMBMLNRVktivm8oLWLlyUACxraIbBtAtK2a4m7mqFHg9FNrSw1evAl7pL5BwIbSNy4W8vOO3tz+SWqQPKQw+nA3fQbGgRoLUANXaDdQ6lizZ6reYe0pyrbk1zs0xgeKS7RyAVW104wm4aCb4H/Rp06dOnTp06dGhBXNAm0OR2GsD0YBlyGr4iaLa3FP6qf1UH2+qirHiaUijyXc9oW0azD5QNMhonVfRXD0uX4KyeD8+uqA1MnUTTdwa8RQKzfN9YiUmVcrLwUX0ghgC1rd19rJtd3MCQO4vZ6XGguqQi9oPepgwABgDY9nSVHV5AYSuT1FkRqB6kr5bkerzLeLLeLLeLLeLLeLLeLLeLLeLLeLLeLLeL6aFRwcXYjDl2vsb7LXPgd3Eb6xXm/K6HtB5wJ1nvgc+SGTEMoAUEptqynd2PMV6xZxfVbSvVStto0WZ8DXd9oZag1SYA5rR3h0Kr+e8y+mmJaaNR8ldzj7WtrnSa9hb2gTTU2BUGppbXDdBoUUAbS3BjjXHWWbejFhSqocDY4rgipcdAfNKL6XPnftAdW7D8xYgis2773EIUdLFdrlmqWj61M4YJo3bn3ykoxQ9Kpy4/O8H91/6n/tD9z+ege71EIBAVoU0Xp7rEaqBsumxxcNDGJXyVn3lZVE6OLAX3uG8feEPsRfWLR/5fiOIe7yu5daxHsM9EuMuDC/xH5tVeKbfr7bYEjLV3QeRex6VIE1i9Ia31LkRVVULalq7q7r7aSKHGKmrmUL2o9Gra4hepMmLridPBaWvCu8NjyMf/aR4T7K2JuuVr49wLoLOY8TmPE5zx6U8Iiaie4CwOKoiFWC8ZYlOfbnYVsBavCMArjVuuEQQRNR2lH8BjqaD0M1zPaFoTDKhqZdH0B7+gNi44EhfoHdw9pZ6AeqYDuod5QzTqKuz3k+09q9qL6sOBgvjcBs4NWFn0mLAwtSBmnHId4FFG3tGhbR1jngOa+XGJ231WN60qHpFrNCs2ivwfeIWW6Zv94GBpFZ/THbVitPHjnABYRsourgC9zjn2mrCIBdMq9NS3pDaKq+iQ2OpppAqYELQesJjZs0D2tdXIaH6ovo+M5y5kHKDq9pb1qjUFwdijt7bki3bDZO6uheEGgYAoA0CMFmVavY5rQdYzdqLvIr967e20eSqosDm+Ch4ehG029yR8t9vXmuUZKO27yGWWI7At7qt1thlhKHAGrCE1UKq9DqcvRParbSnDnO9msOYge5g0LAB6LWsT180/ip/JSqwMNaNFuriI9eebpdByCuz25MloYwNXFsHXlA0HAaAYCA6z2rTDpevKK6cHVm06qvsUBVQZXgTISa0pQLewQESgLXlEVIs10f3g7+7HoCwpwD3z6CrQCs32D8MHtUBVQFrwIjnj6UoFnYdvQlxJHQEUc7Onb63uWImEdufo9xaDgVfvZ3RbVd/alL77uZpyO4HozRdR63wIiWO6xzrmUcJjhD2LIzuE8Kr1Pbry6xH9TdZehjLmvQM7VhomO17S4rTrGtbqrmFgAAFBgDaVQMDyJa8feOOQWLq2/Ptw/2rKwl9aaOaQvAwGwYIAdFKgC1lggtGun2gDzv2oIFMCjg4oGOB6KzetCsDmtE5sOmZXtbjl6FJBrjNAdWWNKd7q3ysUBVoMq7RWhVa4G0dV9HtAkL9QGk50wijwqAKCEhqO52iUS1bV39jIU3nVod3Ece09V27adA9qcVitYNq6q6OSAAAFAaBATZUlrRHjK5DESnKNUtr3VfYZY1QIWGcLzz6ABLQF/yLjv7kLnne2909QPSv21aOVF+VdF8Ittvsq8TT3WKZqUOiHoESaAjk/cHset5uxHdNuo8rG56Io3QUnWTjSDnHQA4G3tFERRGxGkdkdpoARV6zFfMexCEk1Cvb0Ph1c6T7LCrPKr68wuoo/BGmEg3I0NNBz49uDVo3Xab7jBmrg4oynFel5w00JZ108l4e0WGiTRy+WNXEQMQwGgGhATRneF6vYhNl1fyd23x7WcQANQ57AXaGQCQwAoh6mHaALWMCgFcofF9S9qstzXs/iwc0g4gCMUBQQVKiNALX6QLlAtv9CVjjfH054oRADykEBJVlWZ7zfoOQuO60B1adj/iuw1hYswuqjmQAAACgNolqMLK9ytwWuREohKqWpyq8Vz7AtolIuJLuk18nYPTE1Fpl39oHxPp7adYWzdB4FOt+lBSVhR+wOILbn25VmDuM+5roPQKytA1HG3V8jwi236ZtxybLXueeX0Gijq3vdrkQoK8tS/NoXA1BBXhTllb5ROgpV6PaqggCnHR+sxXnDD5uKsMSi2PCoo4Yu39WJ1zOPHUuwvkRqmeX1hqB0/a/JHZhMGLoGympnJQiucL49uNVoNV2gqpwxX0fQ2nFeiv6Bml1eUo8B4+3GoWI37tqtnjUDk0KgCiVsmku6wfuCq0za4tjv8AiKLlSb3A4xbTFYXDotfpMm3BU6g3U5Ksv1gWu0xWt0VfrE4IvXTadVfRjR2hFl6lbarbhMixkDldKufguDgrXzcLPQ1Xk3nN1VcrveBNva/REDmEttG67u8UC1o3YGvCZL1xd17h62PXaU6zy+jiokc7ZfY7eh1SxVN5Zfrf+Wp+AChoc3SObeS7C9A5AAdPbYRKXRDjvFVwICtMHCE4HIOA+AtdIFAVAq3X21ZWWuoDaOFteharijVfo+/oVUNNOOz9+PcwTgdYNa1+sLGAOji4PcqarWNyeEXrRvAAAoFBwPYV9QpnuwRVVW1yvF9H1N7VDxCfB/ua278bzF8v1ihVPMEMDS3yvhilKHj/AFNyJdhfTpHleRJPpUtweWlLSWwQRouNtpYKg3/pDpxkZDstczOFfBSnJWX2l/Q2YX0Iqj2wVpzQngJkC+M0KAM0DQv0bpwulreTigdowmAGy/1BFQ8CxyLTPt/HafPfxCyGvUU9xNpzVV6zc9HXgR/baz6BhzpAN+YaDtwfyhSBlIoL5gxfy94WfL9fRrR4iLlnMqBRUNrlrLJDha9A/Mf/AED9xbQHHD+YOgHGg/M/oH7mgWtwdNCuluuInSlBveJXX6Zqv7T5/wDj0O9sKaW0Ooff/bRD2XEM19vcmuj+C7+PR7ZxOtX+j7yvbYls62x+fZZowcdf9rDPyN/XQCpixV+I0p6jd/2DGWIBUa95F+IEAa5PsPUpQRNfjGg3VwPSjK1pQ+kva165QMoo9kpStidalq+ysJuP9QAEgy9jqbuf2k/o/wD4Np6PAS0tLS3otLS0tLS0tLS3/wAQWIZVHQlf/QAADXFdEwghR7JSUlJWVlZT0UlJSUlJT/4AkwMcE+ez+kz+snE7KhEHFn88J8/5nz/mfP8AmfP+Z8/5nz/mfP8AmfP+Z8/5nz/mfP8AmfP+f/3v+eghp9f/ADPk/wBT4P8AU+D/AFPg/wBT5P8AU+T/AFPk/wBTlfPpPk/1Pg/1Pg/1Pk/1Pg/1Pg/1Pk/1Pk/1Pg/1Pg/1Pg/1Pg/1Pg/1Pg/1Pk/1Pk/1Pk/1Pg/1LvrJtDXb/mplSpUqVKlSpUqVKZTKlSvZUqVKZTKOEo4SjhDHE9dmv4P+apUqVKlSpUqVKlSpUqVKlSpUqVKlRPWmDd3jTV7v4/5qlSpUqVKlSpUqVKlSpUqVKlSpUqVOiVynRCCnSFRd8cC4ZiOKn3ltg9bH7T4h+J8e/E+OfifHvxPj34nwD8T4B+J8c/E+PfifGPxPj34nz78T4B+J8+/E+OficH53KfPvxPn34nz78Tj/ADuU/9k=','','','2014-04-16 04:00:04','2013-12-25 17:23:42',2,1),(47,'Badbug','',NULL,'','รับเฉพาะสมาชิกที่เรียนแบดมินตันกับทีม','2014-04-16 04:05:13','2013-12-27 15:13:34',23,1);
/*!40000 ALTER TABLE `teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `topic_subscriptions`
--

DROP TABLE IF EXISTS `topic_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topic_subscriptions` (
  `user_id` int(10) unsigned NOT NULL,
  `topic_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topic_subscriptions`
--

LOCK TABLES `topic_subscriptions` WRITE;
/*!40000 ALTER TABLE `topic_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `topic_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `topics`
--

DROP TABLE IF EXISTS `topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `poster` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `posted` int(10) unsigned NOT NULL DEFAULT '0',
  `first_post_id` int(10) unsigned NOT NULL DEFAULT '0',
  `last_post` int(10) unsigned NOT NULL DEFAULT '0',
  `last_post_id` int(10) unsigned NOT NULL DEFAULT '0',
  `last_poster` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `num_views` int(10) unsigned NOT NULL DEFAULT '0',
  `num_replies` int(10) unsigned NOT NULL DEFAULT '0',
  `closed` tinyint(1) NOT NULL DEFAULT '0',
  `sticky` tinyint(1) NOT NULL DEFAULT '0',
  `moved_to` int(10) unsigned DEFAULT NULL,
  `forum_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `topics_forum_id_index` (`forum_id`),
  KEY `topics_moved_to_index` (`moved_to`),
  KEY `topics_last_post_index` (`last_post`),
  KEY `topics_first_post_id_index` (`first_post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topics`
--

LOCK TABLES `topics` WRITE;
/*!40000 ALTER TABLE `topics` DISABLE KEYS */;
/*!40000 ALTER TABLE `topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uploads`
--

DROP TABLE IF EXISTS `uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uploads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uploadable_id` int(10) unsigned NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `extension` varchar(4) COLLATE utf8_unicode_ci NOT NULL,
  `order` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uploads`
--

LOCK TABLES `uploads` WRITE;
/*!40000 ALTER TABLE `uploads` DISABLE KEYS */;
INSERT INTO `uploads` VALUES (4,1,'contents','d7cad332497c38092eb847ad33cd5c8e462da2c3.jpg','jpg',999,'2013-12-15 08:13:51','2013-12-15 08:13:51'),(5,10,'contents','e4fc24370670880de7b55c78219f640d12cde4c2.jpg','jpg',999,'2013-12-15 08:22:25','2013-12-15 08:22:25'),(6,11,'contents','bf0b288ef6813fd225ec018466132ad990786198.jpg','jpg',999,'2013-12-15 08:59:15','2013-12-15 08:59:15'),(10,24,'content','52b6e365d9bf6.png','png',0,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(11,25,'content','52b6e4b54d969.png','png',0,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(12,29,'content','52b6e5fbdf17b.png','png',0,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(13,9,'content','52b723cd3ff54.jpg','jpg',0,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(14,8,'content','52b72676033b8.jpg','jpg',0,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(15,12,'content','52b8519ab6c33.jpg','jpg',0,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(16,13,'content','52b8f0217a10d.jpg','jpg',0,'0000-00-00 00:00:00','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `uploads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userbadges`
--

DROP TABLE IF EXISTS `userbadges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userbadges` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `badge_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userbadges`
--

LOCK TABLES `userbadges` WRITE;
/*!40000 ALTER TABLE `userbadges` DISABLE KEYS */;
INSERT INTO `userbadges` VALUES (3,1,2,'2013-12-14 22:40:58','2013-12-14 22:40:58'),(4,2,2,'2013-12-14 22:42:22','2013-12-14 22:42:22'),(5,3,2,'2013-12-14 23:38:50','2013-12-14 23:38:50'),(8,1,21,'2013-12-22 22:13:35','2013-12-22 22:13:35'),(13,4,2,'2013-12-23 21:57:46','2013-12-23 21:57:46'),(14,1,22,'2013-12-24 10:28:25','2013-12-24 10:28:25'),(15,4,21,'2013-12-25 00:59:53','2013-12-25 00:59:53'),(16,1,24,'2013-12-27 11:18:38','2013-12-27 11:18:38'),(17,4,25,'2013-12-27 11:26:39','2013-12-27 11:26:39'),(18,4,23,'2013-12-27 14:44:28','2013-12-27 14:44:28');
/*!40000 ALTER TABLE `userbadges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL DEFAULT '',
  `password` varchar(64) NOT NULL DEFAULT '',
  `firstname` varchar(20) NOT NULL DEFAULT '',
  `lastname` varchar(20) DEFAULT NULL,
  `email` varchar(30) DEFAULT '',
  `addressno` varchar(20) DEFAULT NULL,
  `moo` varchar(10) DEFAULT NULL,
  `soi` varchar(10) DEFAULT NULL,
  `road` varchar(50) DEFAULT NULL,
  `subdistrict` varchar(50) DEFAULT NULL,
  `district` int(11) DEFAULT NULL,
  `province` int(11) DEFAULT NULL,
  `country` varchar(11) DEFAULT 'TH',
  `phone` varchar(20) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `fb_token` varchar(50) DEFAULT NULL,
  `tw_token` varchar(50) DEFAULT NULL,
  `gg_token` varchar(50) DEFAULT NULL,
  `picture` longtext,
  `signature` text,
  `birthdate` date DEFAULT NULL,
  `role` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `fb_id` int(100) NOT NULL,
  `link` varchar(100) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `group_id` int(10) unsigned NOT NULL DEFAULT '3',
  `title` varchar(50) DEFAULT NULL,
  `realname` varchar(40) DEFAULT NULL,
  `url` varchar(100) DEFAULT NULL,
  `location` varchar(30) DEFAULT NULL,
  `disp_topics` int(10) unsigned DEFAULT NULL,
  `disp_posts` int(10) unsigned DEFAULT NULL,
  `email_setting` int(10) unsigned NOT NULL DEFAULT '1',
  `notify_with_post` tinyint(1) NOT NULL DEFAULT '0',
  `auto_notify` tinyint(1) NOT NULL DEFAULT '0',
  `show_milies` tinyint(1) NOT NULL DEFAULT '1',
  `show_img` tinyint(1) NOT NULL DEFAULT '1',
  `show_img_sig` tinyint(1) NOT NULL DEFAULT '1',
  `show_avatars` tinyint(1) NOT NULL DEFAULT '1',
  `show_sig` tinyint(1) NOT NULL DEFAULT '1',
  `timezone` float(8,2) NOT NULL DEFAULT '0.00',
  `dst` tinyint(1) NOT NULL DEFAULT '0',
  `time_format` int(10) NOT NULL DEFAULT '0',
  `date_format` int(10) NOT NULL DEFAULT '0',
  `language` varchar(25) NOT NULL DEFAULT '0',
  `style` varchar(25) NOT NULL DEFAULT '',
  `num_posts` int(10) NOT NULL DEFAULT '0',
  `last_post` int(10) DEFAULT NULL,
  `last_search` int(10) DEFAULT NULL,
  `last_email_sent` int(10) DEFAULT NULL,
  `last_report_sent` int(10) DEFAULT NULL,
  `registered` int(10) NOT NULL DEFAULT '0',
  `registration_ip` varchar(35) NOT NULL DEFAULT '0.0.0.0',
  `last_visit` int(10) NOT NULL DEFAULT '0',
  `admin_note` varchar(30) DEFAULT NULL,
  `activate_string` varchar(80) DEFAULT NULL,
  `activate_key` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (2,'admin','$2y$10$DVPP1ybhH.6UoweD2r65hOUZ.SCB790cY1/LQ9./fefqBwyTvxpqG','teebadgun','Admin','admin@teebadgun.com','669','3','4','สิริทรัพย์โชค','บางกรวย',59,3,'TH','028876656','025646700',NULL,NULL,NULL,'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAIAAABMXPacAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAADG9JREFUeNrsXV1sFMcd37u9s+9sYt9xBHBr19iKQTQUQ9VQHw+UOiqqSIgUt+atJEpBxYkq4Uh9KS95KH3oQ1zUpkklghKqPrnqQ4mViAonhUoQqOrYkBBMw0fsYjDFuMD5zrf30d/dltGw3tvb253ZnTP71+k0tze3O/P7/T9nP843OjomeeKe+D0IPAI8AjxxTwLVO/RkfiaVm1HbUfkJjwAn5F7u39czH9/J/gsN7Ux84aX+Jx4PrF8ufwNtjwDGAtC/UN7He6kOmXxyOnsOr4u+cGtwa3vw+x4BzOSy8sEX6fdNdgYT6DydGftW6Kfim0IVBOFP5/9oHn3aWf0j9RuQ4RFgV/evZ85YDhjgwCPAnt+vXPc1HIDCRzEGpLK+8bv+Gyn/zaSPbGxdklvTkFsRypncycX0n+2P5Jry0dcC3xE2GLAn4L9p34npwOgdWQeLhP/ETSlSk9+yPLM+mjXeDzzPwlzTgiAMfJn5m7BJUYCt1v91Sh96WmbTvr9MBtGtt1UJyflS3b5UPmI1sOvKx2UJ8PlvycEz/uBZf+BTensu82ROeSqrbMrnHheaAGj34LWaVLaC/r+9WPuj9rSuR0KVy0T96b095v+qPvS+RCD8jlyjzzf4wAsdQENm/hnwIWIQHrsj/+FyBeg/sBgJv7qZ0hnDrcw55vFcd7scPFvb8Eop9B9CKni2Zslrwbo3QJhYBAB9uBSrXkufg+nsGGsCLi3cGAy/E6z/lVQJoKCq5rGf+eWrohAA7I5NBe3sARwMXgsifphRWDv5qBb9ujfk2iELu0K0gCmw4sAuAceuByr1PLphGRwYgMUkDGjRN+F2SpOQYMWBLQIQSPFiFcPP/CegCxZzIwD0ttB/wAFYdJmAsXIZZ0WC6gE1BBr3OViAWhAUJixfZQJcgQL5qn0ibRFw8S5LAuDKbIaT8pBBbRF1GWbxlqIIGwKgrfa9/wJGCz5tRi9jYYNXaBAhlCWj8lWbWal1AmYVHw+MTtzktTyV8B+TbSusLgfuF2IMBRZwM8llVMuX/J3Hbv2BzxYVAYVgkGO/z5a6uYagIuBkH4nLUoL+3JONd8Ucm3UCIsF8tRDQviQBDhYbAY01+WpR/7b6BL/95zJfd80FtdbnxCdgZSjFV/3z9a4RsCJcBUawuuEeV/Rz2VWuEbCmIctjUvNKjGHyUydn+eFv0/8wcEEhmf2s0pll7Ajge11QVtnkchrKyQiYCHQ/VjvP9RA55SmXCdi0jD0B8xk2LqhtyX2+6p/emrcXgRkQsCKUWxHKi0kAd/+T3ipEJfztZRkBgzDv7LNwuQqLKyQYELA+mo0wLcqYWMDKcIqr+mdSvS5XwrRsWc7aCOxxAN1HAiq++jMjQDQjgP+pCvWXGK6Gfq+JpRHMzbcI638Yqj9LAlAQMFwaEtkClLlXGO6N5fmAbV9hZgRz6RYx0c+kdrK9SpclAagJWNVliflmAf0PoM/Ob2e7T8ZnxJAOMYnG2VydZS/EzwLgfOyXvnwJCMl5VtHYWhxuCCqc6q8sh2vTJR7nhBGN1zQwgMBaGGji43/y2VUMU0++BEB2NCv2HdHd1GoLv4rVpKvF+XAkAI4IHDgfh+F8eKw/Z5Iv2jzt5TQBUvFcjc2MyEIc5qH+6p1J/PJajtcFbWtSbK5U301W5oWYqz9cP9uyy1ECIDtb03bOWd5Lramo/7JaphaQr+fn+h0ioLHGVjCoKAwgALC9+FDh6fodIkDNSressFgZIBNFJHAlAGRSO5mc8HKfALU8trxOZz4MNNYwU39Azynrd4cASG+rxcrAfDXAygIKNVfyRckpcYgAVAbFBxNwtAA2KVC+Pn3/Nd6B1wUCpOJaqYWAjDBgphqIMcl/HEdfcvj+AATk5yrnwIwRNLLIf4C+A2mPmwRIxbPHndHKKmQz1YD9BBQpv/PoS67cIQNHVNFy6Uyik7cFAH1nkk4hCFA5ML9KgVLAeGnaZgnmWMovEAFIiopPCjLLgXEYaAhaPwXkZMovEAEqB8+1mE1Mb92L8/A/QJ/3Wpu4BKiJKezADAfGaxLW/I8I6Euu36ZqngODUGzBAgRBXxLhPmGTBdqduQ2sLEAc9CVBbtQ2U6CVisNVjb4kzp3yKNCMOUAMuJPYYNP/iIa+JNSjCspyoOuF6gLZ6kVfEu1ZEcYc6MZhk6vQYqIvCfiwDgMOdEvicCBTvehLYj4txYCDhRVZ2fuwRUZfEvZxNaU40MThsilQJrVTZPQlQf7C5PDht3W3y0m/5uFNwHssVCiJaxtzocZ8nSyn60veVp/LrsoVbrgcpjeuXNm0du1aj4CH5MqVK+Y7z0pq3ay+11yQDC6buKdBH9LW1iYUAUK4oKamJulRFSEICIVCjh0rEol6BGgFftmxY0WjEY8AN13QqlVtXhYkLQyMJnvu3r17x44daBw9evTQoUOaj2yP9QgREIlEYARTU1PG3XYUhbTXrVtH0MTHy5cvDw8PG+9BqPxHrEJs48aNZft0dXUZ6HJ7e7uJo3zTI6AkNDZzoUQiUTb/8SzAKBPdvHmzcZ/jx48bfHvuXJn//enu7vbqACOJxzcbGwFcPIKt7lcHDx48f/68caJlxss90gQA/Z6eHxj3Qaqzf//+6elpehljz549ZcPv88/3eJVweYGPLhsnoen79u1Tl4+AO9o0H7qyfft2YVc75L6+PtE4+PzzC/fvGz3wUFGUkydPRqNReB4z4X3btm2SqOIbHR0TbUypVOrw4bfLlgUmk6uenh5JYBHxhAyCwUsv/dh+zo60R3D0JWH/U74YkHuamlbCy8MgKi+to/i5aKsOVeOCaJmdnQUHIyP/rKieKJvRegRUTMOFC5+NjIwYBAboO7wWYni1QF9NBNDxGRzcuDFF/BK8TSQSqQpvsxgIWHzi9yBYtFlQX9/LpP3mm78TH4vx8UsDAwNq+9lnn4F4FuCaTExMVpMFnDp1+siRI4uJgNHRUdqCVQmHwwcO/ALvwlnA6dOnFwHoLS3NxuDG43G26LMhYHJycnx8fBEQAHB7e3sNIO7u/q6IaejtgpT5E/LVqzuqhYZkMqkbAOrqws3NzSIS4In7QRha88kno7FYjGg6UrpLl8Y7Ozs1WgN/NTeXpH0urXG0ltGGFYstxc51lVTzFekAr4hjqR87OlYbm6A6/pmZ26ojam5uccxkGRCAeb7++gDmgPauXbvi8S6kEG+99Xt8fO+9oe7u7t7eH5LOg4N/IgGjv78f8wSUJPsGTv39+0hgx891s3L6JwsT9qGhoePHh9XxkG2AFT11z8ujPzkQHQ+efhrdu+mQMDDwa9Im4yR5IMlEurq6AIJDBGCeBH0IktFkco6ez/DwMPTamaIGwwDxuhkBvgL30BWoiGbwxFA0/TELmMWrr/YTDgxyDVgP+bYi67GbBQ0ODj6sawUd12zBTDRbOAkOZJyPQU/p0/el0KeNWzVlcV0QdITY7P79Pwf68D9o7927F1NF+8HMT/G+LAcRgwYXTgBmh/CAaAQtIUAPD3+ojgSeh2xUE9ANGzrRQH965Gos4ZH/MLAAjJWoNkaP2b7wwi68A32YIWIsbdG81R+AkjaCP1yNGpwxErgRmifSh/iWZEHm1I/ov3fvTxCNqGlyrHJsETA5OUHa6mxVO3Al66eTd8RbTURd2B9KjaHSnpOmkJ4CV+2xRQA9MjJJ5sW6+WSMBrfS8UOBXLl2kdlqKHLnqiuCSEWi8UhVSQDKrqquSJEru3JcWwQsXRoTB8GF9XBViC0C6DyH5KOOuPsJ3aBK2iSJ5Fr0lfJmzhGAORO9QwxEmUMt49y25JTndAEFu2TCaJAD0VYIJ65b+hmXWpaN7N13j6hzVIu1spdn8yrEUOyQc2FoqOPAmPr7+8v+dmBgAPkiDRx+2Nf3snoCGZm4ulSnbj9w4Jfq/CcmJgi46ID6gxQiQ0MxAoraHx/xrlm3sSwo7sgqy2hR3A/CGBOtqpNFMVSipQauY+FyGF1AjReFtn3wR6e/9Kqf2t+aIWqko+P/RZlmbY4equUUlkEWhDrTfKWuOwdN3USbl8GyIr7STFstgNlmk9ghKcqwZ3ptjmxE/W85iWJ2QgZ+GSapqmdn5/p4PI7SlOSm9Io8tJKs3JLt6vkDgrtmwQOeTVP0AfpS9XZxUehD1RBJT7rKJfvXHQk5KMYDxaI9JAlCcETq/mHQZMVJd7LOEeCJy4WYJx4BHgGeeAR4BHjiEVBV8j8BBgALkDrUKFIHdgAAAABJRU5ErkJggg==','ไม่มีอะไรที่เป็นไปไม่ได้','1984-09-28',9,1,'2013-11-21 07:53:12','2013-12-23 21:58:55',665821861,'http://www.facebook.com/uttapong','2013-12-04 10:36:29',3,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,1,1,1,1,0.00,0,0,0,'0','',0,NULL,NULL,NULL,NULL,0,'0.0.0.0',0,NULL,NULL,NULL),(19,'','$2y$08$Gm7atqpFnkMXwvssZEqfrujDVJauYKjTo9t46jBhf20PmfByxNNQ6','',NULL,'uttapong@ymail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TH',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,'2013-12-02 20:19:43','2013-12-02 20:19:43',0,NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,1,1,1,1,0.00,0,0,0,'0','',0,NULL,NULL,NULL,NULL,0,'0.0.0.0',0,NULL,NULL,NULL),(20,'','$2y$08$IQzEL/R8wqhYt8m.loilde9NWE1f1yxbWjNHKs39xypLCpFBORElG','David','Example','example@example.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TH',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,'2013-12-02 21:52:53','2013-12-02 21:52:53',0,NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,1,1,1,1,0.00,0,0,0,'0','',0,NULL,NULL,NULL,NULL,0,'0.0.0.0',0,NULL,NULL,NULL),(21,'aofarashizaa','','Aof','Arashizaa','aof_arashi@hotmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TH',NULL,NULL,NULL,NULL,NULL,'data:image/jpg;base64,/9j/4AAQSkZJRgABAgAAAQABAAD//gAEKgD/4gIcSUNDX1BST0ZJTEUAAQEAAAIMbGNtcwIQAABtbnRyUkdCIFhZWiAH3AABABkAAwApADlhY3NwQVBQTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9tYAAQAAAADTLWxjbXMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAApkZXNjAAAA/AAAAF5jcHJ0AAABXAAAAAt3dHB0AAABaAAAABRia3B0AAABfAAAABRyWFlaAAABkAAAABRnWFlaAAABpAAAABRiWFlaAAABuAAAABRyVFJDAAABzAAAAEBnVFJDAAABzAAAAEBiVFJDAAABzAAAAEBkZXNjAAAAAAAAAANjMgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB0ZXh0AAAAAEZCAABYWVogAAAAAAAA9tYAAQAAAADTLVhZWiAAAAAAAAADFgAAAzMAAAKkWFlaIAAAAAAAAG+iAAA49QAAA5BYWVogAAAAAAAAYpkAALeFAAAY2lhZWiAAAAAAAAAkoAAAD4QAALbPY3VydgAAAAAAAAAaAAAAywHJA2MFkghrC/YQPxVRGzQh8SmQMhg7kkYFUXdd7WtwegWJsZp8rGm/fdPD6TD////bAEMACQYHCAcGCQgICAoKCQsOFw8ODQ0OHBQVERciHiMjIR4gICUqNS0lJzIoICAuPy8yNzk8PDwkLUJGQTpGNTs8Of/bAEMBCgoKDgwOGw8PGzkmICY5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5Of/CABEIAOMAtAMAIgABEQECEQH/xAAbAAABBQEBAAAAAAAAAAAAAAAEAAECAwUGB//EABgBAAMBAQAAAAAAAAAAAAAAAAABAgME/8QAGAEAAwEBAAAAAAAAAAAAAAAAAAECAwT/2gAMAwAAARECEQAAAdadtmF08x1/EUueZ21lJIEkgSSBOyRLpuX7CaBo2h5rEq00GXXrBjDUXterTnPOa+E9B52154zq0ySBJIEkgSdIbu+E9Tkx8/XCl51hlQC5+kANOW2Z6FJT2SoJCpeTwPqVhNbGpgp2Mqcm2aHq1Bpob2PyP00nIqOpmahzmDGD0GTSIlL66bS3h0kzzvL7PjZumdF2hfK6V1TYJHMNjRp5UB6XxXduMOEqFnepTDmymvlxla810cmlvCTOzM4H0zgi8RtCVukmrQmsG7VjSG1KtHG9XXHIrDLE3wkh69CcHLldDHN5D6ql1zGbpV9DU6K/nNfPbzKSBjZz84gKC6xEauvh9RmiyKbaxdM4Rqvz8iwWsDJ6TBMG0KWL0qpRHsrD5FXPVEca6fYDc0MPoY5WpGmp0FQ9Z7FddQtOweUF9QRE1ztJWVmXIJk+vpjRspUqpnG1lh6zJM9JO0mn9G889DzqzMPoRc1NSDxsS3N7M8bos6jwnpHldzcnnFddSqtGoNU3kY+1mXNKnCpdoRET1HJdRnWzZggydNi5mczrrKtZBxIlYjeB6XHjSE9K2p5ucFh3EWCyaNsBkLQszXa1Z5Mxak8lBqjgwAyoWIG3ZMR61eXCTVqy2b0VmIW+PhoXQ289NV0dnNO11FnLyF1LczJvqX5J6rq35yUTvQxIJ7FeVFPQoDgMtqzVALWUKslBvvzmINAcgUByCSDYiOBSFQGOGkzWEcC2FQykMgJah0XKlDNVtsAqJvDPRkwAWhFALa9IZq2awyW2LQwY7lgc7HoJM5yPSMHNt0rBzS6VIyRiMrpy0pwEQTdlaYVSB0Gp0hVhtB35qZxFecBhABAoW52iyqI2iCErmBtgg01aJePpnpAnZsuzTytMeXrZGoAlMo3Onl6mVFacJQZSfnnoy9jG2gzkz0lTdQjeIoJ5Oj//xAAqEAACAgEEAQIFBQEAAAAAAAABAgADEQQSExQhBSIQICMyMyQwMTRCQ//aAAgBAAABBQLExMT1rwP2txmm01dtDaUTrmPUysVOSpE/ieIBAJiet/2/2/R/Ont8TMsGb9v1XE1QxNpMAmJieuqRq/2/Rk/RW/cR5C51AH1LvaNxtAWY+Prmn5NJ+3oKuPRWj6jLFT64GH1fiqoewj5LyBSq+WHn5MQCbYwlKclvjb/0ImPrVpltePbUnjHn461DZpK/vtXztmJ5irNsVJtEuWaUfV9PJOkx7yvkDdbpxNf91a+APl1lPD6hYy5xmCuccFc2zbAAY6e3RjNdScdf+m/JUPfSMV6sZcDBUePk9Xr820rnYViM0Q5jnaDa823PEocHGZ6PRl/gv50ztX8WpGZj3D5fUE3UWp5eo4VCJVLB4sR5StkrqCxV8+m1cdE4iorGbyPp/wCbEYlabCOB/jn4WDcly+TmbYPBm2bIgxNOu61G93wWjY/HkBFHyV2boG8uQsewwYcahcwKJeDiuoicZxZU6MjeJoF9/wD0+Jm6bo9h3Zlfiv8A0DvXPtJKlgWmZvnI4O9mn8QsdyzQAcKjb8tntZ32wOVm74Z92dt0vvStuwM+HavQi1rPSyGs0bIiphcgHTDkHp5+mx9ynYh/j4WLuRmywb3bzD91wxH96tZ4exrH3NMmBmEZi53Sm1kfT0tfaKxXVW22xj4sMHlszVangTT281Xqa8doOENk3mcxgYZeWLts+TAg+6qpKKzGmc1sfdZcKaV1JavYtoq1FS6jX1ctDvib4TGGfg5mr/P8qfkLRfM/0niO3u1J1B1zkV6v62rNFSUj+ZqAUvWlsGEwmfcfU9nJ8mYh99XqFTRNRXPBjsAE1KNq7kNyUaRMrFltgrW/26pdHbYC+ZkwhpmyayuyycVs2PMGGZlfus69ueHxjEsnlWosDopzFMbUAQnM1FW+xCqqGab3gssgtti3XTn1EGo1E7OonavnYsgvadlodQDC1Bn6WFdEZX1K5z0CNfS05qBOxXGsrM3LOs867zr2Tr2wUXThunDfOLUTj1E26iYvn1putm95ytOac855zw3TkE3ibhDXco3wNA0VpugImRPEJAgUmbWEBBnieIcfAgQqsKJOOucFc4apvvgayctkF1k57J2bJ2nnced1p3SYNVidrMGvE76zvpDrkndSdyudtJ2klOrrU92mW6qtmzMzMzMzMzMzM3TdN0z8mfk8TAmFm6bpum6bpvm+b5vm+b5vm+b5vm+b5vm+b5um6bp1a51a51EnUSdNZ01nSE6QnSnSnSnSM6TTpPOk86dk6ls6ls6ts61s61s69k4LImtDM+rCP3QINUprGtQxNZWzPrKkbvUQ6moV93TyvU0WHt6bPb0pj3UJOxpZyUFebTQNQ0LUTdTDxifSnsi1pXGVXday7OgFKoyxKSrPSXcadyXqPAKLBKKWrs61uTRc01NL2Hhv2JU3CtFymiqyu23TWb+Cwm+p7V4bNqNZUHGCzbm0203Oc1DG23PHaVL6Xbzk5UDMvOY+A+lDKDjZWyrNXnsKfJJOjZjnTsN5ZhEsxNRycmodlvHiU/1i7Mu47dQSLs5OnYtYWPAsuhOTofvP9Kv8WpOL3/JiP/Xo+3VeL6Py0fZ//8QAIhEAAgMAAAcBAQEAAAAAAAAAAAECERIQEyAhIjFBMFFS/9oACAECEQE/AetSZuRtm2b/AGQ4lFCiOJnx112XwvhN9kuuJkRXB9cXT6Jvt+OmbkKVjd8cutfguhsXDLMsku5RQkVxoz26KMoxE5cTlROWjlowjKMRFN/TaNItCcfp4/6G4mkaRaHP+GjZs0aRo0aNFoss7HgeBUCoGYGYGIGInLicuJykcpDfw+CoVNlodejtQq9io7NnZltDGL0R98JHwXoiIfsj6P/EACIRAAIBBAIDAQEBAAAAAAAAAAABEQIQEiEgMQMTUUEjMv/aAAgBAREBPwEp75VXTNWXKrirTdkn7d8VBoaGK74pWj4VCGhsdRLKRDpFURoTg7d61aBWSMLVKBU6vknoajgr1dkkja/TbY0aJRKEyTIrq2ZkyQdGUvjJkzJmTMmZMlmyWYkEEW0QyGQyGbNmJiYmJiYmJiYkMhkM/oT5CfKT5TLyGfkPZ5D2Vntr+Huq+Huq+HvYk+zbY56HKQkymezbY56HJtIUohPYuin9H2V9Wp6F2PtFXVqeiv8A0f/EADgQAAIBAQUGBAQFAgcAAAAAAAABAhEDEiExMhBBUWFxkSAiM6ETMEKBBDRScpJAYkNjgqKxweH/2gAIAQAABj8C22Uer+XmyM6uu8fmZgxLDEpQyMfClwj8yX7tlCCH+1bEZPwRe5x+ZXjJlNkf2kuiGy9RYGfg+Is7N1+3zLKP9o9jfCBMfMfXwzcsqD+VCHF0MOBM+5adESf9wkIfgtYxzoS+UmRqWnUj+4tOqH1EWfitEspKqKfIY476kYLch9SBN89lRcl4rO034oreoYTXg8sdlXKmzo67H1EuQ3xqfYhzbJ+LoY7abMGPHMzq9lf1PZiT5H22WVE3hUxi6sy8MlxW3EwMfAkOPDbOS+oxMvBkUe3mPZ5SmxNPa3wKLq/HdjnvfAzbOpTiimx0OezEqmym8xMNleJn4aFXkj/MnjsoI5MkiKeb3GFO45Xkqmvsjy29F0Kq1vfYU+NTElKmCHHmSXIvb34Gt5dl9yU9t9HNF/kOcnizUzN9zCUu5JytMUt+/ZGSZhjxfAUI5DL/ABVCzXM5LZlVvIUu58VfUqGO/bRxvI8svszkyUeD8ORHqXLNUX/Ox8h9xFZVx4I+LGEmlnClJFXJSj+rf/4fCs4YPeh8YeZeHibyXPxQ67GdS6dEWcVaSVm+BL8RO0blkoR4czyK5ZlIjJ2e9SMXTwUIXeGPij1PMnB8zCcTMq3QpergP9W6Ren5n7bee5Df1zxL1+hgmZGllFZy7EaWc8OR6U/4miXY0vttilnUfkMVSXBmGBjJ9xSW4UllswKRxfEq3VkGs0UqerPuetM9aR6z7Hrf7T1V/E9SH8TVZ9jKy7GNjYM/LWJ+Wh/Ix/CL+Rj+B9z8lLuY/hbQ8tlbRP8AF7GNpaU4UPVfY9VHrRPWia0a4mqJqiZx7n09zJdzT7mj3PTZ6Uj0p9j059jRLsaZdjJ+PJGMWU3/ACMjC53Pp77d5v25LsaV2NEex6fsaUetLuZo+k+kyXc0ruaPc0e5o9z033MIzX3MYzNEjTLsZS7G/sZ+xmajUOrzNcjCn3+VkZfLyRpX9Bn8jORnI1SNbNbNb7Hqex6nsep7Hqex6i7GtGuJqiaon0n09zJdzSu5pNBoNDFGmZdu1ZjZvsO0oqLkYWbf+ku3ceaLrjj0NPsfEuq6afYpGOzcebD7mpdy99PGpr9zyyr9zX7mv3MZUNZqZGbtKroOfxo4s9aMj4V+CdcSkbezIylKFMyUviWeL4mqzZCzrGqeOJRSh3E5KNKcSqu58RuUYvDiQurdRlPhr/stYXGuGJX4SfUjKUGsSV2FUY2Ly3FnJRblTFFPg/cufDkWVnGN66rzQ5cSU1G7FLIq4Yyk3eHWLZYQpefAbjG6uBK4mo3d5VxzeoeKRYXsVTIdK05lqnVeWqI0Uk974kZXnfvZchpt5YGMnQ8sq3ZZmEpULqtHK8t+5jTlK8XnaOq3cSsW7ryoTo+Wy1Yot1UchR3FnTdErvLRvO6RjuqPofhyrzJ/tF+8tCxe8fUt1uoWfUb3pqhKm8hzdDo2f//EACgQAQACAQMDAwQDAQAAAAAAAAEAESExQVEQYXGBkfGhseHwIMHRMP/aAAgBAAABPyEkkl9yaP8AlabvRsvkbt4ZpUS/RruTIcyO7Kr1moOJ2PSeR/BaeEP/AEDwtHtBlUMraz3ijcYapvKHnA1jHROgwzBr0/6Vd6QVYYrMyWJyBMuR1ol6fSNyulUyvSEBAiEd++Nf+NR6WeU5vlzMdtiVrEKUPWAQquVTFbsUtdoQJU0vbuWEGko/kWwfEQZ2E4AHYYRFThmR5QT2BSsNIqveka7mfWQh0KK3iQWW9dEuLgbCUakvxKf6hKgs0iuyN55HBCjBumVvWMJPgll3lCI7zBVtf1l5feH8DBV7yhOSA0sucmJWBxiY4qNXLMiNy3xyrDPCHpiqFX8qCz8s9ZftKB7XKLZdTxt+0w9YfwBMYCy2yHOY5nuINynpBz3myWPEuV7scxQ7QnGK07SjXS56dDLXS33iam394xV1KVpTH6K1qPoCoMaQ/gjpvuAsGJXBVGkrBQ/uUt9kxau5ayVAluLLpGNXemISwWtnp0v8Mu0uXAJUTmBTTRLtU0iNXCLvEPlQ6U6Y9uwlOZAMGYUOUOURB0SjjEUOJup3QiWgrj0c6y6N8OImhbViaAJpFlxL3SiHZPEyqzBrTzNow7yxtzDZY0GF4uDG7mOJrUZA3qS6msosnjqYdh/A5dDWZzMbTQym/eLDmhzItVqYZkXjogua7q5jW5Vco4AZYspqxGzavi2FNQbidWYDlUz7gR0Ze/VuBh0hBTDbAeUt2i7y3KxTYqe0jlR0eCPFZaNvMpv7kIMPs1jij3yTJyi38InwOlU+sFPKxWqVzMyqYrvC7spdtGWaEBa1KJhSGDoxFcImaEVPjaZptgjZpcdW2ZfNB1moIUYL3REq1+J8j0cjYPCiqzAur2wZvN6xVOmZRFb0hCjwlUMXiXPuHmWeMsUSi3KBHhcIG7ujhlHoY3cnfiuot7RMqNbadamS+kMrbjl7PMsjqbSh1OgNn2w5UPdcseMawORd5TcsOEp4ZdLsWLAgIz0O/iNublta7HCAKmBDF/u/iE6rkf6pbYlEBXvL2X1ECtviGmvGXS+hLivwYJfMfsRDF2VFktNoOHclFM8YUGsCQaZwaCCiIV1TQPLyieoykOXVZgWyR8OURITfDHCgQGg1y8QBymm271uX0KNxHsNEfyO8vTDKwKShGNm1wV05WjBm/eOW/mMDBQQbuJanMBNZWmJjJba6hOB5E/AZr0LqxdHPBxPX3UT1P1xHUfVFWyTzl9TiERC+PaZu4tiN+52agw2DvFjLlcYG1zHysDlhBu7stPs4jtUmrGwFK9ISvx0Ao/0mx+nNj7SB0+lDm/ROWQc76/8AYbj+qXwAt5eR/E5H/XaajfRHLK+wjfUvH5TSX6/mI0KfL/cFYr5c039zX2lDHqP/ACXtYe5NJ6Mn4hj+MYfJQ/I9UvIPsfbAN/slX+5AY4wU6+9ievv4/kEX+CaJXmUd4HJPBLtifGRVlbZGbktJ3J35g1lLnZQ4CDxINdJTanEZlmG2qCXX1j5e8e73TFrDVROoexNz7SNf685ckupWvKPzs528qAVtXduH6mD29zA5skAeySOcv2RNTR4TdoaIJVW29dIGvszmit/1z5HO690fiTso8KJmmqx0gxR9OXOwCr/i+srKykpMXVU16oHhgXmXLl9Fy+nge0+GnxEvxL8TxZ4s8WeDPVPVPVPVPXPOV5leZXmV4SvJKckpySnP8P8AIdK/WJ+yT4XpTuo7iK9CXg+LnxDP2mfKsef3ztdAT+IR+aT9CTv+nWklquXKuyEdHfJnNSt0zPhrQeapqKcVNa6dCq1o1P3KIhqF1SRNCFmNGHyEqwjdMukBAuGuhLdsuVa4IE01Takt0+lFrPkkv5SVAZXJi6keRthjabK+aS/pAAzK7UFQi+ZW+Mk1lJDRGb3jnOPpFkyW2iDNDBLFopFGoaMY6oaMD7RZtTMdGO0tVdEW6lp1BfM14ZpVmiFKjg9Il0tu5ps4VNN4sIU4Juyx84/DU77ShDKLQ1+ssQC10aS2belylQWRv2mfQ2TQgAbGd1xOX0Uo4jNcuMhXu7QBagXneYkL2RvCCAHQUkCpXK+8W7Ra48JpFheyKqQ24tQtsox9bgO5NoJdotYY3A0QxYzWuI2uTDuLriA2bQZcvKuKitZXqXFhaxhegO0Mo8YrKsh2irDk3EHuzMfexdH75ng1TT4kRktNrEtqvdHi4x+s0NGht5jCuQXFa73+8QVgUtHrMmdcJ5J1xmY/RqiosUCs2YTHYB4uf//aAAwDAAABEQIRAAAQc6V5wg394PS5TxZoAAT3VzZ7SRnAwfumK+EA0Ev15JoSKF1C6w4jPC8kGVzhOkii3/r+AEmdbwJXVZFUXB4qBzWcpmbvtcbLhgc+bQZvXnAJOFX17gE4sTkjsZlCYQFcroTWYQNiqe2Rckb80xZ/PnnHdQIPsaipG6ufeOiY1jiudqIKeYXR/8QAJBEAAwABBAIBBQEAAAAAAAAAAAERMRAhQVEgYXGBkaHB8LH/2gAIAQIRAT8QGPwTEeRK5PfpX1o2PwgtUUbIbSZKobCo3RU2G6+QT0W5R6JmthcBLY9UJtrwAseG+oaWiUSUkVGruq0aV21BwTHCMeC8GxKUouBj03HtdET2thEIiDRNMBCRBsl0Q9bE57oati1Nkgk0TNm3U0QNnA3ZQuo/i6K6RI4PWerTGVy5cE2fT4KtmLtF3m3kcnEom6IIJ0mvZHYkI0pIKFaok+BN5HjqH2I5qU5L4f5K4f5Pd+T26SlgVKpkfKYNgg2PBLAcfIgguSuwkBtm9HtFTJnH4/Zk+hj0y+3+Dx+v6Mn9yZf3RkZzCf/EACURAAMAAQIFBQEBAAAAAAAAAAABESEQMUFRYaHBIHGBkbHw4f/aAAgBAREBPxCC+ouKLJSjhOYSos9WagsIY8Kjbok0WQhKjQWY3YJo+JolpFTNkVIWxI8C5b0ZvILSZug8KjtUJkSKHIIYHaVNVicyiLKDTAYkRmg+mk8oSpL4GwTGPLY+JMSnEY0RtTgMoFUIITwOohMqo4wGFvASqKaFzjlMWlKJNEQmFwho3WNpNAoY5nyVlaD9AC2FQ640WzE5Qm5kPZ3GHSOkdEnLpssssTjbkNyy9J6Q5cyNO6fYaOD7CcqkxP2T7GWR/Q0Yj+hr3XYnv2H8k9J0xzJjUF2FwrcZtrh0EuPb/RH3fyF8QV2sB4mMjfPQRWILNTJtG/3eDb+fBu6eb9Zu/Hk/d+Hi/UPY2fY3Pc//xAAoEAEAAgEDBAICAwEBAQAAAAABABEhMUFRYXGBkaHRwfAQseHxIDD/2gAIAQAAAT8QLSY+86JM6ZQ7APzH/wBX/Jpi7MBuvZLfWcNrWLxLMIO8WZe5ol71KEwE0BZdbItg4vAMDSbc0i7ZBRj+A6I57oRxasf/AIH82jSWdGFxBRltPcOiUsRt2ppWmIKwUAvmXmnQp8yn3dphDlgJklG1Q7pS0GfKm/7I6/8AzayOExrVH4jaJm3zKSXgVeJVA0a+Y2C7B5mCikQ2xnMEW8FZrMGIngYmL+HDMwFFGXF6YfDEuJX/AKCZQUxwLFqBHvH9wVltBVaNEwu04OYiOCXys0Et4xuEXhVNpTYKFHQHMEKOBdPSE/gID66vyIlTSstQxGsqP8VcpWpawjWo3ir2B7mksBUc9C+VoBS/iGDGohxVS9F0YV4NIdmLRnrE4TOq83E1gdmjgJuuu4E8AvT5jbwPWId4IGJaALqVmviC4ZFzs6MtsuYRwlQXWKxCxkV6QWjfqgYI4zrVg2hKHvneWoACUpb17qjBZascW1HzAUfU0wrS7Cwrc2NnII4Blf5qFzA29ytOyvMWCvKfmHED+SY0rsCt+bICTehqZ4E3mFLg8QqSgfkli2xNYCyGeIIUAaSsFXDK4uBU1pKp9WrN2BMVwO53+Yg6xHW2sommsd40D8ypRmyjoCDouWjlWXDmwd6H8yoXRc8Wm4jG0EP5O5YHJhP6Y4DyAt+80RfCZhTlTZFXWZm+wEcHXu7oPTeEqQuB1lqN5jjWKOVKpoLB5ahAYYS3XCmSBnOl/wCIygZJ4urZdgEBfWH0GnXAf1KkDYfBKTq/ifzRzhfbT8xmTbSKtV93UOJXwGWh+Ue4UxWHgS7bAwWieYX3Uo3h5OsOWo6q6jbRTNQgQOv3Y/M2muGx3GW4zlNwVo1LaAUXqtwUNALehNS2B0FVl3kJdS2JNB0pDNCZquXLRooPEuLBvMznZ+IqtLfE1wVxzBDLZau0VlkOjeLgotT0gq1k6ZinVleYQwEyKO38ACAR1GFSbIWq47QEsKIgDylLlgooOkE1ZXrMcTYtzGYO7hjFgOAth9RXFI8/eZWZWs0Xq5oq3DVbDoRAK2CxiMQRYCO0IZazaaA44dIBZm9mWsNw6Xipo4BnN3Q/i4FdYaHhEN7Faw05xKewWvoHquxKtT31kWy5d1wEyLVgHhNJSTXDhIWK1QOIqNGrL3gjzyHyEYYWhdJLCBygVWMMsy84LjKhPV9oEIaolYi69kE0s7e2KghAi6sFsHswDho6QyRLKhJLUW0GBYybcSqIVYl5/RLyxbt6y4MWB4ilbbaPSWmilfP+xdrUp21j4rbgcrYlLVBuK8KuiUYuUAwCnzKnqCrG275jCr6D2eqwTQU4NmtnsPaBgktySkAaJx/whMgWQ6MzdiJ5j1LB3FojrDmqJgCwZkPDN2ZUBCmpaj2lhuR2l1jbFTvdRq5uSxGaqGjAdfgNU4P7hBZlK7oNTPqovwDgJfq5xeXHuLQihvZfmWr5tMsxbx/kum2m0RmNmq0FInCS/wCFynnfW8XIBWdV3XrLNUNHqSodnoB+owBaAuM0REtvLfWZlbxmBa47BerDnQVBsakphqg5vyJ6lIIWMaZhHmHep2fuY1xQqs+LIhM2ZVVgXNrAa2uU8QDc8XBLVVwVgcwCsah6SI30WaylO+4TdmaUXr0INyUB7MTSoB4NSGRSiPgPtl0Rd2HcAReR3XlijqKdNdtI+oKI7yzQOmZUaFuwGPHPVquZaEjeqDZ6uOdet+eJwKc6QlhT+pXuBuay+wcWPuIyovdpMKEAJvz8y3pW0wxriLXSdFdYI4LxKGaN55JSDPyi2vZCPQTylHUnDjpLk2/4PwTXqKaFxev3GWzmBYE4pct6XA/M3CEwaixpYjVigvtaAM7AABwRpBhpHe9paaEhm84ik7tWh1qBwsBskQ2anEvsGq6A1ZaUspaDr5GGOSDX9ws3iYJcw0YaraGr1rNQCrZoiewllaRVVIleYEbjVoM3BFggRkUQuCGyFaomHBmYPit6pFLObAXbV5qFggUAVRKRtDpyyhQo1ury9JVNvBtS6pxD7u8DSjFAutBT4jL3+kRp0KvGwUVKpnL21VnqKYv68Qj3H1zBchYfiL/YDKcI2Ae6FzOVaKVbs7xY9IsFO8CmxObP6S4uAIwBRWNtIPHYbHcqFgHw4P8AswBY1xngluTfWfNu9CajAjf/ACUKIpdnr/UNicrgNDnCr038QVe0L8QP9l/xAj5PphHHcSDp3C+4bXuYLvt/th8sB+p6RgYW+MEGAf3vxHbS1bf4hu8QQYnbn+JQWFoUX7S0qnS5HkEcL0isDHBowoqYVImIH1+Y24o7n3AOPPI254Js38/SbFfP6hApzv8AqVtlu0B0XsYE6vb7Ju12+yG8uyfmAZ8QP5l6weUdAYNYP6cQuod/qhTI93GuSnciuvvLTjrzHlQGvVcVa/gjboeEcAIbFD5g13tjhDaNXV1iU5e4dLjkEVWF4J/kyf4sjlUhekNsSNKU9ROkOos+ULhA5Mo9nzzm9iLQTuwsWvmvqU1ju34ii19/qjC3LgOFhWAyfUQKHlVGOOz/ANSz0P2ZuohYWCrUd4Tu79uIbVvZfUBsv5/U0K39cQGoew+ocz45IF0UmpMZfLspzm4rL1aVL3bgIBDQC/mX/p/MdQEE6J7/AERcMPf6JUc77vqXgUd4o/LCKYaK9X74lUPfKvzMNsURWU5lJSA6Q4CdAnQP4iDZLg6m8rqqrXeIUrosvfpNpFcyvM753zuZflndLK29Slq/hP8AgZ1HxhyPc6j3LX+SX/0l4WhbiOz0n71D9iU59JQ3ep1Hpn6BhwYQP+lP+1D/AEocD3DqPcOr5n7zLdjw+pZteT6l2xF30xdoXjP+Clv0vuX/AEfucP6+Z0D994/7j7jtp3cdtoOw/wCukR0T9OIDe8/qJbnb/MS3uxgdyQ9j2+6Ibnt9kR+0+5+yfcdTwspDvUw2Iw7Lod4ZYY0tC+IXAsAiibV5hKAMKOXiBbrgAXxMQv0sCDan3mBS6HauKrwwfUHMrmnCwPMNdVVU2R4BCtamLFLYckv2PONybKMVTaelLVNSmvqK7ypVwwbQq6BklWKOlS5foGV9Ig6IEApbULnSkbfMrUtLNbM9MTBqxSTxftrKDwpzr09TOgs5POSOsupIl0tcPMzbA5CudIDzZZdHFggA6iELX9xyGztb66bwamsPa1qO/aFTUJ6DI07Q5CpTc7FLYT4GhKOVe8Vfh6N1d3d3n1LbAAgDWhjYhrAGkGeLw4huZrdBw2LazrMNzxTIvVvVlUgAybK8rz+YC5LMK8/uZmvMWj4a1UJDslbbbWYl0ulTI/xTURmNA4DYidRHLS9c9pgoAxjWjdq4BhMHUudeXSJaQNmAMFeWJQCZ023DpLAR6jo58ygFtC7W/Dciyq4A58Fb95SAwdroiLE12QTaF0aBpzYC5ehKGVtuhN5gBui9q292XQVgbh2wdbiFDogoc1HVBswG31Gp6lxd01Tpn5siM3VAAWVeu/qOW9ov8ruHIZliBuX2uBF9aAEaYgCdnQAV6X3HMrHAPTiIVw7FCtv9luihmC616JSNUqgC1S750Jc4aSNs5+IlvWLyrdzi+g6rEjdCgw/q/QnOLmBrH9wiCCaaWOka40jVXVmVod2vcjLsjmGmIeqLyIUxodpVCDXIoP8AbFTqyaFeGkaRNSovC8diNzoILsAlfBHQAwAymrntMTBRSug+IlMggEUpM9IpsELdgwJ//9k=',NULL,NULL,0,0,'2013-12-22 22:13:33','2013-12-22 22:13:33',1838067880,'https://www.facebook.com/aofarashizaa',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,1,1,1,1,0.00,0,0,0,'0','',0,NULL,NULL,NULL,NULL,0,'0.0.0.0',0,NULL,NULL,NULL),(22,'natchomtorn','','Eve','Natchomtorn','neena114@hotmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TH',NULL,NULL,NULL,NULL,NULL,'data:image/jpg;base64,/9j/4AAQSkZJRgABAgAAAQABAAD//gAEKgD/4gIcSUNDX1BST0ZJTEUAAQEAAAIMbGNtcwIQAABtbnRyUkdCIFhZWiAH3AABABkAAwApADlhY3NwQVBQTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9tYAAQAAAADTLWxjbXMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAApkZXNjAAAA/AAAAF5jcHJ0AAABXAAAAAt3dHB0AAABaAAAABRia3B0AAABfAAAABRyWFlaAAABkAAAABRnWFlaAAABpAAAABRiWFlaAAABuAAAABRyVFJDAAABzAAAAEBnVFJDAAABzAAAAEBiVFJDAAABzAAAAEBkZXNjAAAAAAAAAANjMgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB0ZXh0AAAAAEZCAABYWVogAAAAAAAA9tYAAQAAAADTLVhZWiAAAAAAAAADFgAAAzMAAAKkWFlaIAAAAAAAAG+iAAA49QAAA5BYWVogAAAAAAAAYpkAALeFAAAY2lhZWiAAAAAAAAAkoAAAD4QAALbPY3VydgAAAAAAAAAaAAAAywHJA2MFkghrC/YQPxVRGzQh8SmQMhg7kkYFUXdd7WtwegWJsZp8rGm/fdPD6TD////bAEMACQYHCAcGCQgHCAoKCQsNFg8NDAwNGxQVEBYgHSIiIB0fHyQoNCwkJjEnHx8tPS0xNTc6OjojKz9EPzhDNDk6N//bAEMBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//CABEIAQ4AtAMAIgABEQECEQH/xAAbAAACAwEBAQAAAAAAAAAAAAADBAECBQYAB//EABgBAAMBAQAAAAAAAAAAAAAAAAABAgME/8QAGAEAAwEBAAAAAAAAAAAAAAAAAAECAwT/2gAMAwAAARECEQAAAd8DVETdVkLYe1joOzmOD2AkoIN1jMtWwbklYiXa4pCYB4d7rwG4ym4GVmuhkOfNfYnOYVPQS0+OR2QPngLX1RfkOxkES00Cm1mhXJRCh4sNIVCOekZWZVZokdBCLQbhUAEED5opG05ZXpRoqMS/oNuM6wRKA9SZo3WGvSastYMtbDCrQ/mWtjrh3ljeRGFu8qHNMrFKJSRBs7OJpY9Cu7ZXTHUqGtZ6dVhy2fY16WrFCg8xlarPm/tyk6dBIoeZON67ng48i1x39TqJtvXrn47tB8vUn9NdebYIsUfMY+2q1vMUUDQ28XaZybSGpnq1UPtMmANeR8rW+gcABej5ludezUhzHcTiOncsyT2vLNLwApvITgdByY+i2sbZa5nRuqBvIQGz7LqjX5l7lVWZ1uJaOjYu9SWB6ptMzjS8YNUXkC0IQI47t/nzrv8AZxdqpzhWGOcrUAJUjdYMT1tKqAF4TSOyqzluFgB6Ioxk3lpWTdmB1SqzR+d9FzRX0nawt1zkUIMc1mWhJu8+jVKA7IXMgjTLM4dKuhnO6rybaGkWsW+eeP55up+f31UCu23c3Rc5Ai5yp2R1BDEvMabLKTlZ+wd7l6Shcv0vqOl5zdegRu1q5uIM4w0oCs/c30vqnU28TbzvIx9VQqhcbaDMS1stpl/N0ZfkmrVOGTUsn4DAC3bgJXQhxfZ8Oc3W6vK90JRnx3m8wIsXkoPoWuXW1sbNHgR5es6i/TGb1KDQOUSmxVjVYO+pXlutRMRaRMisXy5h6z6ptF7HXBVZXtZfPdPy0htNR3KjaGY5SJFh07jsICGR0GUeztN7JqtqCOOPXzWPZhPUbAfO8Vc6+kpcv2PJyMtLm53dpR2n71Z1PUORCjPs1j7FKvS6pxFeCUe3EQykS+vbRex1w12haKnOdLgSlDVtz1bQzdPQveBWNCvVkoN1QsULDoklTNQyYV8stLutbji7GOnL41se5goCC0CU9y3GlnP6jC7S2oxZRpAzegF62gLEGU08k4GYXn0bY9g5n6GOvz7J7FS55MnQkDK9uTzvDefNbTjRJqYTGhKMuupCEI1YDKHrLywi0CNZepZik44Esv8A/8QAKRAAAgICAQMCBgMBAAAAAAAAAQIAAwQREgUTIRAxFCIyMzVBFSM0Qv/aAAgBAAABBQLKusV0uunK3Su8exwqZt5uy8u2sYuRZYvNozvFe2d153HnceCyydyyCyyd14bXndsnft337JjsXrvXdoGp55KI42prG3q5TEAHq3IFfI1D6a9PEME15mL9m86dLCxUQCZd3aC+QVm+2/eQJ8VRy1uMeAqt5xzCYvkkedArPGrWMxizHH+1kbNoGpyaVHY6l9WBbyU6Azc7mTZY4mDntROSWoqBY48D2WN7f88dT9WuUGNZ3Zj/AG7PusJ7SiZCIzVVVI3VsjkxE1B4hGph5TY9iMHDT2Vfe0bGiBv0+WcVWUfbtzFXqFn0qNxflbqlb2i2hsdQxZtTU1EQy2gqvTcvtFy00YF8gQiEGefTcxvtdZ/JYGX3qU8AjyZ1h9YywQxR4pGxUBwyMJeWG/cxfE2IGELCePTU1KPt9YO+pdP38aBGXwdzrR+YQGE6nOYuyXFyipAAiGvI4zjBGQx7O2Vu3KTyjHU6Y3PF6lS9nUukVcrv1+t+OsfWPRz5UbbHr7Y8GNeFjWzvDWM5e4fV+uoiU/VjGZFnCvo347L02R0uvijH16uu8cHyTPc9PoG2UKiW6jtxVvC1IGVa+NvnijbXqAO6KGJqTg/UfGP0f8dlf6cJfkI9P1ZUtteRS1FsUbmFfpWt5Du6nMBaq+5FpCztrPGhxEYJscZudYb+jo347Obhk08kp28Bbe4DOq4ZyayCCjFHpZqmxb0d8nibBwWVb5BTCs4+OM4ziJoTrLTo/wCOyeJyeU3P3qanidbx6ezUz0uvZzK8erhbl1q9uMgWVuyP3Z3Z3p3p3Z3Yrcx1B+V3R/x9oBbtjTBlgZp3WnNoX1Mx2tiIhla11ulnNbk2eHysuxp2naedhp8PFpUQok4hFyTu7o/46z64fZlfkKXM+HMzPki4s7SaagTBRkhje9Z2p+UlmikzzLD4QmZj8aGOz0f8fb9z0fxA/wAvcEpBss9G9qvQyv6ZlXPQcW42L+sizhMW9rD1XJ5GdF/HXfcHtGGwutZbgUqND0slY8GGfpjqOO6qLwBbUt/slKlFu5dyqg3zon4677nqRL7FuvQ79DLnCFY0VgbB4lnlKfDiFNziBEUcepVf2YFvbycIcabzq31zsntTRVqz69U+hMzISHPyTMElRvYBKhCgf2blHgsVVv5WPl4zIejuXwbx/Yrds79MrVmTb7J8rj06m+7PQjWKjbUmLG8Q+7e03GAdekV9rEvPz5KboqUqhjUKWsQgVNusezHxbRXeD09Nr01AeAWvFJ7ZgM6k5TFDssw+OhUzQUjYpSUgLXkH+287rW4rNqY5WZNkpP8AWvtyBZ188ng5TbMKjwyPcidRHLEmE3zVQ/WJV9FgBuu8vl7FiswhdiK/L1/Qx0iJxiiaadrcP1XeJrxLhyrxsVbG+DpDDIRScglu+0xWLUW/cb3z0+TcPtUJXP8As+Z4PpsrN+XXkMc86NS2cRWqDa3DjYvvML/Pcf7CZn+KTEGyolfg+53P2ROIlbchqYvhpbLddtbCFZBbEpBhomKvGm8atA2eo/5x5KDUHpy1GGj6WHimF9rU+nJlscjhEOjT7GU/bu+8SJl092hBqKPUfQD43N6muUpHBnbVl4PbFnh25Rvoje2PbwU3zFbnRkH+0Q+YIsHpT9tvlnbgSahUGZuxFYOlA3W3iMPB9oPEMwf8uR5uM1oZK8bwIB6U+z+y+0PvGHOYp4zRFx+aONVod+iDkzUeMMcce/7yqY3FJkXJcw9a40Q+J+7D8qjw/wArP7FFjMOTezSogHl4o+1mZi1ZFmfaRYzuaYJuGLGnsUPj9/UY3mV/Tw5hVFUAlp1KzuElDiHlj9S85x95UfmHqPYxxEOjuCe0PuPrLaUeBqcYtfGy2YH+Tqf+6w+NxPfc3NxD8itGn/U5QmH3/wCiZXZG1H2wpARnVHGIvHHzOmPkZH8M+v4S2Do1s/ibJ/FWQdKsi9OsA+AsnwTz+PeHAsn8fZF6faG+BefAPG6fYZ/G3Ren3LDgWz4B9JiOBWvBP//EACARAAICAQUBAQEAAAAAAAAAAAABAhEgAxAhMUEwEiL/2gAIAQIRAT8ByX292vnOntXy8JqspRpYRjZRLrKb/nDTdPbU6wWKVkI0Psl1gsW64LaF0Mmvc1h2PZnhe9UkiSp1tbNN8lEuyTP1st294P8AoZPsmrorBY2ag2WxDFlB8GoXbo/K2ZHLTfhMfDLYvhF0yRNeiXGLxcuNmqYiivn/AP/EACERAAICAgMAAwEBAAAAAAAAAAABAhEQICExQQMSMDJR/9oACAEBEQE/Ac3hDf4MRRQjw8xSrR5vFl/i+yLvF6J6SdHou8ULMe9JKyiL52rFljkV/hBelstnOjVn1Qlh9kGPd6QVYZErkrLfpF/ZXikLDRBDjhiOKIrjjVkWN5lwzwj1qxR4KGIl2Mh1tzReEfIMh3r4R5RQxdE/5xDb434SfOPBrjHx7p2Mvgs+pDgsvMr8EJ4//8QAMhAAAQIEAwcCBwACAwAAAAAAAQACEBEhMQMSICIyQVFhcYEzkRMjMEJSobEUYnKS4f/aAAgBAAAGPwItYVUrfW8VRyyufs9l8t9VNzldUcquV1vLeK3lvLeW8t8reW8t5ZnI6ZquiirrpoCcdc0C5wb3Uvitn3+lNURzoIjhoAWU3CmbLLgbv5c1tOJAVVldtYf8WZhm0qmszWYCa3ZQdo21mbdf47LDf0TBov8AU3CBaZg6NlSjKUXYD6W2tDcnNNxcxk26c51zXR0U5L4bzsn9fSCxPH8XwcQzxBbqNAb+R0+FtI4jAQOSZzFD9LF8fxYUucKQwx0iYSF5KWHLNzPCD5br6q+ipVHKsM/Nx/qxsopSvhOxODP7on40Bdv3CRBCzCFbRnFx/wBVheVij3R6FUi49QdGeH5E8ES4Fx5BShmCnCSHJdFiHosJYiceugsdxTsN9xCl+UKKQbKf3K//AKgCrwkqKoVBDusLyn9UBKsKx+Jhj5jeHMKRoUHNuLKrTLqg1vsqrZFUAPJR1sb5WCjmG67X8aUsXNKY4oL5Z2hzQJbIrNPgsyNsrlbRdXh2WEjMKlNF1VyGK47P2tPBZjnMxUqZBw/xrVCd5qYQaLworq6uqqyJTlheUYyV1dDCFXGp7Kbz35lWU2kj9p4cJVhNVusw8oaKJ56IniVhef6jGcJmwTsfEuba+8KCYUzCamRJq+G23GGH5/qMZGBb+dFLV3VIVnToqRp4CJcn5btbPumdz/UdE1hhts2hk/uMo/qBrJHanmqaqUaISFmoB1nCStxRnbQGNu6/QJmXhob3VMU+Vvy7BNa77xmENpr5SrOtUPyNYlDsmuaBRF43UzNUiiKyu8RII2if0p9ZrLOcQzlHCxG3YA5A6KIxLTYrKfyKKfOqaCawc4UJuqrCcOxhIXU3tJlxbdbOK4d2raxiRyAQYBJtpLJxYcsSW3nJUcQmcXG5MKmAARXddjxWzUQDBcrsUF2WYDyFc+yo6XhXmnT+4KcMTpWDK7psjocuwUuCoSFVxVU5VMuCtTktl/gqpVZyUhYIO/GLgeIVZyU2tynoUOcrKgXBNJTkU1/WWgr/AI2jvu91PPPupojmmk3sYBDKJBTU+Ri1O7wb1dpPaY0zhis65hAKqAkFM0VHLeQCd3gehGiiaeCpYx6lAcoMPPZgFWEuaMAnUUmosnI30hZT4jVEJg/JHLcVCnAxNJ1W6muTh7qiKrp6KY0YeW7aoOCycWGURoYnBSg7rX6RRwz4WybhVoYS/sJKjkwJympvNOZQLJ046G9teYJrhzhkaZqYCn7ozg1PZlcSF8trW9brNiOLz1Rnob9AgoTJU1MWWfhxCpZTFkwrFHaI+p4UuKrVcZdFPLTqtjchhrF8aKKsZaQIBFVsptXRAhVCaE7FbitE+ElXGb/1XrM9l6zfZeq32XqN9l6jfZb7UNttFvtXqN9lvtXqNWY4jei32obbVR7V6jF6jFvtClnb7Krwg1f/xAAlEAEAAgICAgIDAQEBAQAAAAABABEhMUFRYXEQgZGhsfDB0fH/2gAIAQAAAT8hTgdUSvTr6imSPU7FHjQ+o92eKMJuR2DD9t9Rgq5D6nafojZV55UvHdOxm7KP5xA2m6Qx7ymunqV7/SA0tV/sdl0YhaS2upUQ8mpeg9SrAlGElRJmtJtbfA0zROVwoIo3KrAuO+VP3n+xgDVRrhjVb8RidtQhvcxS9CZhjtBvCKhosjss4koZTWInNHF1HyEumWMWYAveUsrMAAatht3CW8ELWnEbNuG+JAvOCXCgC1eIK4hv/lK92A6jjTEeFevn1gGHUSZwVLoFySUzZQxzQqBTRE2re8wPt/sB+KYMSm8Ncw408S2AKPbci7eCcE6Su2TruYWU/UJqr91BrAsSWqEEcotagCppTACUi2ENACVrXbCZppbsmNhjZssfUGWjtUtRZAsyNJZ8sLNxOX8QtcVsimrBFDKsPb/yaVS3mJVuYZeTgMxlt5I22T9p/ssev+Ud07ZhcSoiGG6lX7/SfFzRPHxjQjN/j3AJZvq9+pdVssnZKEpdyhud+WpQ/HfUrQO2FX4r+kCBN9I1FxMoqqiLk6T+/jQECHSGs3ARQ0rx6RAg52ruHToq+49ooJmDioouFRXOIMW5AOoprn/tMDwsrRhL10Ue0HGPSOW4Wj1g/wB/7HqXqWMmoP0TSAW3GCz7idO7rEBrJXMbrFXBomxYxZ6QNW2OlS5uEzP/AA2w2uroR6hXej4BLeZUh/gSgTCQw3ALtrxETFJT0RqY1j6oMAq+CZQRJNPL8Ekgwx2qHwR79Qn6r/WC0N3TPeafAnUpzSE5g1Aoy77O/jmDPHJlBMLlFLyh6mOorxdqg2NIXNVDbuHrQ4BEYCxkgDqVg7VBX+G2KOtivxD5OMeiGNIutTwwEL/5qIwQwjxNk9cHsxmhEmy8oqNSziBSheoHk3fUdQTbmKpClIUYlRgMohYvMfoP9Ykb6HMAljv4mREIQAwNLiQCgH9EwlWeuIb9nDsQyAOzJBTQ4TJNGpeRseTqLhfUYfL4qxa0uIlfpP03+sNifccRtIllvzBTykulAtYZWWt5eK78sptaBsJftjle0LHUyqNuKxU2oKb6mjwmpkWlu4u3B3jP5+5xow5WLn9B7n+jyxRuAUPMErYvc2UHLJGyjk0eUvQF1kg/+B4IEDLzcyFr3g/mNYdjnD6lepyeCJdo3L9hGkJk2Q7SoZqOqnMNhzFybLZ/s8oomYsZmgZXKM1BaylhfDoNQjHSlkVjHxOdjxKbamGUtpg7XN6XXxMB0WGV3HG9zP2f2hivgL6GU0YsT0v5gBpBixaO5gQ1OIuVAAGnEq3S5qjmWdclJwZQhjQEJxEua1glBuXuFWak/ifg2/lNGOHx8lf7SoZNL7rLMhe/jpDYrSPEIBPGYCiH7T8EAbJw3zCh6K2Rhtu2m2GMzKuCNNkd7J/cBBTr9PENgpbZaB7S/NjLrDLjA9g3HMrqVWPvlhcavE5jmKiNyMCA6XDar6EbBcu98w0HZuL7AssFOTxLoVVFaL/pOfvcbcxRYDbwIw0zG84YKF331EZKFLzHelgWVDy/kLEWoNQBZ0j1caJ9DtzlOLhneb9/PC1HrmEJpySguOzQeoxCtEa5R9TEndS/gFNhTE5YkxTuXIWe4jtptmuYtCm6cx9sVsgFANB3NkYGRaP7BOgBsPDF4l7ZZPFCsK+0oniZRsfTj9SwAu/gaKqLdXLhut07lfBeUsuKwXVsFV31Oiv3DBoJUDqYBOoeJWqNUZ4lXLrqCatH1KruS2up6FEyjrdutwMln3zBQvnCAmH6oZkrhIFhi/7JbI8ypeH4PwV1+WFgTH4NEuAiuDUlf8LJ+lxmeP2zcjRg5i2Fb+oFittxdhiFuKPRK715MYVqCipp+VvrmYQ+JULeQLo7uUiwzawnu3kJYxPceMjck3/YqM+IfcP2SgTyTnqOw+JV5cKjZW9krOmZh4GOMnqGzgFfCLwR9hhgRm/pEbUMO5zKzwJv+P6v7EvhI0VQoa3ELqAERG/agP0lsA+biDjcCs2LiNritenod/sjN4Xr8Qc0BLBldErFM9kHv+Jk+6vPwFhj7lbzoS2KY9m5Xmab4Sz/ANiF7AM4l/mInqPEGdvCbbgvFlX9I/EBU5j/AMnhUH6GL4ZEFQWO3mpRFDH2Rx5Y1agXsiHU52tPiVrS7QLvcxatls81nQd2QWuxEJ/1xmOhaSz4NcjVR39TZW+IwnLa1i3n9pQRV8RkuDFvqE1QPE1jaYhbrh8FjLPuC0PcHS4q7CZ5QxEIsoq5zWgkJFsfTZ8NzxYxWvimOIDTTOLBXpf7MQ1i/wATQJuULGZhphUiPhnZPqazshyjsxYsJrLMyxHobjK0fsqI3xTE/cKxvOTyi2QySnmF2fUVR1f9+IrLEqJQbTExihVuYHEbgu6hoPcA5lNOoZMRmmhtwTQhR4I74oP1N5YoUm2pZOEcwo2x06l7axAO1z9aNioa1qYZN5WUpQnLx+Jb2xhHwmZqNLTKXben4jPLwQmBmXHTknWbcR7zKlt4NoDRVvsgLK1pl0fSedSP6B+iGtMP9inZXEAa7uUj6mPuPGKzU5vjXlxBiKbTDfbMV5jDjaDqWV0238IhwGVRkVlx5gcdT9B/sVf4aJgJznMydXzEnHDPsl+DKEsjBb2TMuahSeDFvkWiWR4jh5q+Ig0IQ5DqKqI+kZNp7nLjshEthf8AYBRrlbipbT8pKXH5kEZt9oD/AO6Y/wDugP8A3Snr/TKSlq8xY/4MXR/YidfiZ/8ANYpRxWDN92PhivS9y6r45Gf7WNbD7iHHew5gSwnylEe+COo2nM//2gAMAwAAARECEQAAEEvE2u/hG6wPDPzaK6i1jOuAvCc08sP72N2i3ENc8MSUD5aglFGkYgStAyoxfK2An6OmDnvhHT1pNn/kH2VylHir7NobI93ePI//AECeCKOF/tjhYMFiSLfzYavg0IL00IgnBOCwi/pSVFBCm46uBy2d2TBoV/IOw1ZDGiRLasdZPFX93sALCRP/ADnzgKnliAF5x1DH09X7dBzd/8QAHhEBAQEAAwEBAQEBAAAAAAAAAQARECExIEFRYXH/2gAIAQIRAT8Q4CTrhGKe/RwMtts29hGnDXT4HvLNsyGNy/J07Zx38EXW2B19sW8Z8CKc7M9tJEXt+Wzmxx0S3n/iWm5YcnXx6n2W9sn7fhL0Exmau+Cy8tvM2dW5bIMR2BivaGO2DiDZjo42TYL3/OA7ty8uelpMvG1L6gJsEyEf3uVlPt/tdg/s5dkFwh/th+Sxn212Rdb1sshdiEIYg8bbvHe44HHYCQ7si/2vBeI7PV5y8DxB0TAdcFm/GzAKodJxUm8TDjEvJYDPrq/NE9oMLe8h7j36bCf5eVeJW7LgZFssssgM7syTWPL/xAAcEQEBAQADAQEBAAAAAAAAAAABABEQITFBIGH/2gAIAQERAT8Q4XI1OyPsT5ycr3ZD7BXh0b1Z2ZBHB2N4zvgdQ5bsg64MiWvI/TwoPD1HdvGqnLCbfTNBkPzh4n3gd7J4zXTttB+HgzPXsixAmJLPW2/aS+WvyByPGxnv5Zxncg+z+LuyP2UIY4IYY5bb7bZLIZ1E+3wnDnKOwRH2PL+XDZ120IE4Gl4k7IAYyei2+8PuYGTJ9g0gw9Txnnb4i7Nm9PA5qey3HJHc+SANqfbyR8b1NiSbHUT3OjYvUiZ7Wx7WzqCYny+qQ6Tu2dIlnHts/DHTtn1sawekGVvkdd2LFpaS0MWncAS63//EACYQAQACAgICAgIDAQEBAAAAAAEAESExQVFhcYGRobHB0fDhEPH/2gAIAQAAAT8QBXFUBrHkjr1uMMfiZwz4RdjQxmpSwOUM4mQgv6iObDAn6hCGLaJKOF9Et7zwP6lml/06gLAe6J1fWTCCHgitv9f1L+n4JSLTfROafDiFATsx/USCJfgmJtpyP6gCwfCYMIXYVgQSlgC31L+niGWuUCjmOjCmoqoU6ESxWhi5tNMl8xwLl6zk1R4SuUBdkuw5gPk8Qwsq4cpqV6ruNLpDqKifmMO0bNLcNf48phwDJ9S9grVwaQVzGvLKRal4uFukF3AHRE42ryROOxES3qYTbZBljYBHSamaoMw7gcdkoFIoQsykmiZQekrrgQ0C64lJYQ9G+BFlRoeJpRUfbBwqZB6JabK6gdchm98pZrkL8kpMc4jRKl6AbViOrqQz6ODyyjXq4hEJURyZiP8AtLb8y59QQG2r/U+IkeUqCzWSVNhiZncISGJmeyNQdO4qtEDEWGxK8S/cXQq4Kd3X70Z2P8IYtFJgB3Mg2Y+IS8o3wYadwGvGR83pNvmupRYIswu4kU1dsQeZcHK6jgBC3A7DsgFCKXZBYOmIosuVt0PcOZEykw7YMR5u0eJjx7EKLjxEl0f2MD6xawsEElUNVYe4LsIQhylJ91KsOIj+3YK19xGFdXKQWw1cEDy0n9yyjRHcmVJLMt5DiFQaTPqXyi6A9x2kS+nV8SkudTU4hmCcAyvJ+IeCDGNev5EWTbvIZQlG/J2QMmYidKphZwU7h4ESz5H+I0zzCTOSO/8A4EIsmEqJil2+GGFTRVt+EIGLWegHbkhu/Z4wZ+KjuJADDcOcNR2KRzrGcRlGm9RLZFeJQzgL1mICsC+EgQAkWqsp34iuTHBNOpQ+YxihSpfLT+JofmYRz1DG1og6e+oRWiq9WvPWriFObXAdo7joLm8r5aXHqVTFAxRwxEtI5gVcEVKqwjI3fiALd1bMb7yKYNaYoQtFxhVq16oPwQyIC2gLmMbu0vOD8F/cyDuowCrXZMcBeIgZ3nSZf51KaTAZpP5lYaW/xKEqYKuX1HoMLG3LlvXUMGMGFXA3BD/ijOCdU6cTcCnEVlQ5O5UcxoIRSSyLSYMQg6GGRuuZg/d0+mJWtsT0QsimqtQbwsp2LdsqK0I+bzLMwFoIVOKy/CREPDLCHH/ZXsnMZlmi6TEZAv3K/rXO9uptzYIw4Jian4jmXELjNaxT0xttKLqDbeYji7iOWt8r/UFVpGq1GqXY/M/1PG8MguAvcwVFOFW9B/2cVykOUyKTEMXU1kvmUNKhw4h4SLqpVLWD9IQQrnSSkJ7dRGlrBD4dsTMSqPYEwHiIIWKDoqc5hruXuIPbS5bAPBAF41ZGFADWCWqBiJa1XQ5/2Z7BaSCdopzhMT1aXtzOAIbWkrLxjKgSookCUM9B7HUdGKPSjhOJXSGShp4amB45QU7LjMTeGaC2ZKAtCiXAJSq3/kF0H/EcsUFhYOopDxLhcsNG9xubPMuCwzc3rMxi6wsD3R+mftcnQ0sFXQNkCkQ2PcRfEXzJxlUtlmYAsA9xCBtVmN15oPcQDmIlXlV6laB7ppOROnslrQyqMHDyeYaRmg8Cy8S8FuXuOlJwSkNh5H8TuCeOPcU2h8wXjEnGLZE+oSLAjBNmD4P/ABMchvh4hAGGAbCZGB0ImI/bF+D5l7IPUrKJsaDcGC4KAX8eTD41ATPVd8JoLtOtR7oR3rcFV4ZmXqrRxv8AMXCCixuYqlZ6OWu5iqrt/wAeoKQANI7HzHik3HickVrJUiqx4JQIA18E2LW3lll8vUVXu/j/AMGnYKgKaMOxDhwPmNckwkPuWow7eOarmWkqj5FGzoDEv6pptT5uCSg1mOLMq+Yi4FYTcb6HiZb28w5M8AcTDVQ/CBOoUD8MblVeY7OviWNioQLIjKsEWswQFaPMXYQnv/xDD+T9E5nRLM8OpWYC6WFHREDYRWgC1g1BAjHCet/XUIum5U/qOjfipQirdRF28THa85hXCtL8aJV2gbxmAM1L/s+JQA/EpSyvUW1bwIZGOgbv3AJhADlcHqNy2ZY44QYebr4mBfOZfO+6hAWE77MIy6IKpQpv8D8wlVQqjg6mHGYWXWJSHylQVxKDBeAAL0QgCpQOoJNaBtS0EqQL20LOfisjUGpB3UsVcf8AmQLBCCZXuBRDKPLPEOzEI5H7VdRCNIgDw2fzEXruz9EFw/8AMGsQbxx+obD/AJzExw9dEUe0PdRSi22pjn8R5wM6tj6JWaXb4lgVaZlTFcxjY6kbrlE4xWIhkpXDPdxvIFaaLN8446lpb+iv9iNacQGAFeIGCbXli/mUhzWf4h02daQtfZXzM049aVrMY+Clh8G4BaNgMLODh6hXdS2TCn7HzGoI/WU39lpUZdsrLw5lvqO5RK5TmW4pXE2UMx0oAP3I3ZEpRP3UEGMxbRofplKgOBGmpkS14WYyWrN0UYwQXyXpDgPgacwSgZhwIxK9DMpyKzM7AiA7PHEuwFqd3X3GOkFbTV/CHxCfdVnxDm2UtXBVPGmLyxCAhwy5Qb+DWswx4EKYIDBXSwHHN8fETfgXAu6MAqPqFfiGJllBFoTmlH6uNhZW9jkhLsVqUCoCgFUdQ6XYwFQXkyqC4g7AuYUfiBGXnnD3N4Lh71SfFSpS2A+iU4DKMLzEYIj2VpiRlhlwTwBtXfWNRWJaK8F99R1VACsClfkjuystHiEzarwf8R0bgwPo5Pcp3SLB8lSmB8D7y19SyG1gfZ5uZOV56ZX2PqK2yrrxM2KjX2rXI2SWxGxx9ob6rJWUat0cRtgGhNywi8aijPvOXlE0X5g5oEX6gNSvY4B/cxu4leVNHqN8DFpZP7iodAww0JVof9iCGg4ximH2iz5liMaSrXjJ7qCqNMKnyILY5/8ARE6k7f5ncctUaVXXiCxAdP8AWGXaENB/5O1wHwS01LzNDoRgN3p+Jg9VElT8t/cZAUTfonRIEtlq8pGMf5ybzfKseQVOXNwKR2EXJFUN+XsylrG7c33fL3EyYbK36cymp9COAg2bv6jEIADFR243k9PwWGAP1EjW8zrWh8MoukG+j1jmCkbQDXduYzXi1nEUjgxZZQw/hlAN1q1tOZCi16IEVxYRBcXnkH9kAyy1lF9uo3l7ZQW02fMLznhemsvuIA1P3Ro1BzeT5lXAJnP9oPobsy/sm9KaxNRgaX2VNS/5/wDsJenLFXkRMvwG21vavMeZjEfHMp7lXpitvEcVnE/P/dHXERH1Fqrd7uZhgLeqGJHkdMspEblIMEAcWVMVjIhzqWVxwqA2sp5CcJTSBsnz4iACig41AKyFVmdGvVNfkfcNMyX3EJTegi6Ra2S9gGfBDBNLaGoALRIy1uyFbWZA0ZfeYgWVtS0Q3nm4LYzxCyByYFi1cQK2FV5YFmQ2HS2QQq/+SjbatdwWTMEIWCPkbi8kP0ajgLYMXzLEetrT9wwiQ0U7ZzIAuYfSMK5C75iUulD1uZyY+QX8xLlUzxohqxduHzHQvSXQPvMNFDydQlHKVDVEX9I9YWU+HMsyOZdDA6odmVZBbghfq4UuEL+BmMVWFnkBjpZAOl/okzSCTsS5QKKqFG4Q1W8x3yLMC2UGUObIti0siOxK6INQAcuMpF3TwfTBKtodxfkUBfGIdkiq83LbHPmUeRUw2WXiUwtthlpvJ11HPESxFlKbV8wTQ1lgBcLycxSwOxuuK+ohtjamgwn+nDXxAIDvJDtrBqCAImVu4rTG32U8MxwT2BPyliWKn3hiZgg2DGIUwF7oNSiMUCsZ/wC3KlLghpdRfXrMsI1b53MMBrmcBsr3UxOd8RCjrcqlVVwwUUbWscTScc3TsjRXFelmfhfqUQGq+GY2iccyz5bN9hNgZMJDAtKg1KVSjpwgplGR7StBdWLXoiLkOC+CMmbYAIeKQgqnFEBYtuVq59QWVHWWZCvAxglCUGlncVTappzgOIXic9yuzkmNdea6hZQN18H8LFXSrm4iQ8uVVMNXELVlTMjA7RtqNBrEBoA5ue/l+2JC66gyDv5jyjUCgcbx+J8rQZ45RpFlqnmYC2+C5sux27lwQepgTVHrEGA2+SWBBcjg/EonGKyyrRuoa3Kc/URjXdg9wiqywHQwClAguTzHhTJCBwztkY3oSt1O4kQJfggZVnL1/wAglCC4fbG4TBXDJwsuBzSCFt8guYGksGv7iAuPmKuhu4OV/wApYl6p/Uodh23qZDQGozDZxLwVcCrlFbK9w4XR1B2B0grYMX1GRTiDgvuZ9h8rx8RChRhcuL0p8C/bcpgIpXLyX1AU3aO/92UreRyskC1dyi0kqlgYFcQEgAKvR/coaI8QuqgczFum+WVy4K18SwNagnZBYA7ag0WtPxA54TmWFyHHmKuXlEYFiC4jUl5jFQZaeEhNSym4Dk5Q5PUwlagcj15iZOC9zxL0QjoYijAL1aBYaq0UFp8S87or+yBmDq89QBbGP9P/AJROAP7hViR7IwaLdwAeULrT6jIcnMDIFcQEofTLCcXG6ISyhqvbLBJTiiD2C1tCuXJRQQakt0ifjiZZ0lf1lquuCHwjwqOLB+4PFCrX+4S0qIKvNz//2Q==',NULL,NULL,0,0,'2013-12-24 10:28:21','2013-12-24 10:28:21',624530012,'https://www.facebook.com/natchomtorn',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,1,1,1,1,0.00,0,0,0,'0','',0,NULL,NULL,NULL,NULL,0,'0.0.0.0',0,NULL,NULL,NULL),(23,'udomchai','$2y$10$UoMf6Tk.N1pK6h2GFqbZAuhgos940ckpiLdHBZvdsIyrNFvIEowtS','Udomchai','Techavipoo','udomchai@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,1,'TH','','',NULL,NULL,NULL,NULL,NULL,'2013-12-27',0,1,'2013-12-27 10:51:28','2013-12-27 14:10:59',0,NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,1,1,1,1,0.00,0,0,0,'0','',0,NULL,NULL,NULL,NULL,0,'0.0.0.0',0,NULL,NULL,NULL),(24,'wanwimon.mok','','Wanwimon','Mokmak','wanwimon.mok@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TH',NULL,NULL,NULL,NULL,NULL,'data:image/jpg;base64,/9j/4AAQSkZJRgABAgAAAQABAAD//gAEKgD/4gIcSUNDX1BST0ZJTEUAAQEAAAIMbGNtcwIQAABtbnRyUkdCIFhZWiAH3AABABkAAwApADlhY3NwQVBQTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9tYAAQAAAADTLWxjbXMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAApkZXNjAAAA/AAAAF5jcHJ0AAABXAAAAAt3dHB0AAABaAAAABRia3B0AAABfAAAABRyWFlaAAABkAAAABRnWFlaAAABpAAAABRiWFlaAAABuAAAABRyVFJDAAABzAAAAEBnVFJDAAABzAAAAEBiVFJDAAABzAAAAEBkZXNjAAAAAAAAAANjMgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB0ZXh0AAAAAEZCAABYWVogAAAAAAAA9tYAAQAAAADTLVhZWiAAAAAAAAADFgAAAzMAAAKkWFlaIAAAAAAAAG+iAAA49QAAA5BYWVogAAAAAAAAYpkAALeFAAAY2lhZWiAAAAAAAAAkoAAAD4QAALbPY3VydgAAAAAAAAAaAAAAywHJA2MFkghrC/YQPxVRGzQh8SmQMhg7kkYFUXdd7WtwegWJsZp8rGm/fdPD6TD////bAEMACQYHCAcGCQgICAoKCQsOFw8ODQ0OHBQVERciHiMjIR4gICUqNS0lJzIoICAuPy8yNzk8PDwkLUJGQTpGNTs8Of/bAEMBCgoKDgwOGw8PGzkmICY5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5Of/CABEIAP0AtAMAIgABEQECEQH/xAAaAAACAwEBAAAAAAAAAAAAAAADBAECBQAG/8QAGAEBAQEBAQAAAAAAAAAAAAAAAQIAAwT/xAAYAQEBAQEBAAAAAAAAAAAAAAABAgADBP/aAAwDAAABEQIRAAAB8poI6XPb+B6DF50F9QzzZUvXYXMkcjDQ9hyXnZyesi5Zpi4oUeVxWZs43RxktbI2KrYxd5XlSzh9WchOsVrPI4LZaWjux0fSDDznbo5yC27lmy830VK3mGNmtRlyx1Tha6e1VuobiPKodX0ZLsAKpKTLutEbWsO7qxPYGFik4YD0mliEGZPjQ7Jug/12qsdLlnZzMOn27XgNhPTFy2e/NutRccay1yiWBbB6dfIekZiAgYji/BgOGC3fJUWrVpYlyDSz5d6jW8lqMemHVsycyTlUWtXNJBbDIamznraShl4tDOnkbuTFeTC+x1hYPp5L8wb1PVvNs7XAlvYuuw5Qo9cXrIwKBEtAqsUQUjJ6tO2aUZirQIyKG7Cx7xcrSlyjQxhLgD1Ogl1DFkNIb1FGDCLYvPtQO593TUvd0HS81Y2SLoI5m1LuHUg2DSPhJYMCWtJEfD4DVquWVUijzahXk2a1tmTBJtpqR3QqQjPScsevnzhxNIqlbUmr0rA3GKJTD4OJASjzD0d0jX5kO6XIAsLZ13uiLpD1g9RG2RWbTgtHcYPEpN1VMCK4RKmrAq1ztFeufWirHS1DBnguuZzmsy7qXeCHEdIzdVfGZNYiZpcWQiOERAPQFbFqguiE9PfH0Xswm4hgx0WePXShQnSGei9zQwedm00qzOdRxPAxmFgUXg1RmHhOLRW9Q2uu92Fg6OcvmcrlWoTOvLo2RJpclW7Jo5dGrrsomNmryUo3TZUTgsZ8Hit6RJ4N9hw1mTYUtewhHp5+kR1W5q51i1FhdxisqPSqi0KPPPo6MlQTISUa2i9vUzrPqeAeWFSMAKdQOrU5mgJ6bUcgqUs0uCujnuQkgMmNC9IlhSE6ilVa3JNrC2r9BwWwtPokqNuPnqHCJcbdIXBbHosZM0Okhy6lNnk5cnQg6olU6tytER03/8QAJxAAAwACAgICAwACAwEAAAAAAAECAxESIQQQEzEgIjIUQQUjMzD/2gAIAQAAAQUCR4/VWtw500iEMr8mi5KYiUZJ0RPIqNEHJknjr9nWop7Yq0b36mNjxaOLOJxGhorH3j8fZeFycHQ1we2yUaJPG+8v8GGObfjMnxj/ABu4wKT40fCj/Hkvx0Pxz4D4ERiUrMkdGZciYOJok8X+82uGHEmY/wBLTQjXpk+mcSoFjHPVY3Vf448CPgRXj9cGhI8OG78iP+vx7bSW3KIN+mI3+NGhjNHWmpODR/x/9Z1uJjU412l/82aGjicRwOUZ9KPA+8z6TJaKzRJGSbEN6a+zZs2bN+mbN+qejjszbb8Iy9rVJ5c3xY+k5yvFWPybomvkiWVezZsT9bEaGho5HJGzNPfirvysvAvydKstXVLaxtGHO04zmOsdLiqHOjRKIW3a0ctHIVbK6LNs5lYeRlqsM3fJt6fFHRxSfHvFRDPHpcf7XHvQik2fGzizTNbL0h9jkyPgeXmisI+zHg5YePF/HVN4LaWG5mCKcmG9w1+DGf6dD7NdsqkjOseQvC08fjESlHwzTWNI0LTPjkqNHjf+ddGzkf62M31s2OjZT2OdjnQl1PvJNTc75Fnja3euOxHIb9ItaHRXU79aHO/WP6Nmi74CtkwxbKftmyn1L6r950X9Jfhx2KeL16Q52TKSE+6+16paSZZH1N/tl6qmb9oj7yY+X4P1I/s2J92+kXWzGy/vI9lM5fgiX+uWdUpPjY1r0l3X3vt/f0bHaQmPsoZXrftCY97QipVJxoro3+Gtr0noqvT9ZVpy/SMf3S/YdHIvtUxe2JlGzl736yTtuEmmIx/b+vS+p+s06/BmivVSMb/D7bpckSxX6dbJ+ip5Jzr2z/T9Uxt/gq75bnjyaYmYyjiT9HLvPO1636YzQ0a9Ma+SuMqZlGTq5EyK2NpeqeiX+zrq1xr2/wANFIZjyZ8h8FHJY5yPdyxMTNiaHxZpDKSo4QVHrQ/woZhxTjlGRPfDiZf6liZs2bNmzZsT/bLiSHI4PjPjOA4HI+jJl4rHm41jv5DydcZsWRHyCs5Gzs4ldVDN7X4sZX1eP5HjwxxnhheSsbS3ZOLEVhlVKj5a4Ip9R/HLSt7NfrK/W1+w/Whjfqa3S3rInTwylLibEjzd/Gq63JyiI46f9VcHNLFie5co+NDxMcMZS6Hl1Svbwuqm1shUomeLPJaPG588eNq/J6jFu4UtP6T7eNdczmcjkOkWoHK3XR08cvS4bfUGXNEzi+s1afy6vezPO8fi/wDiy5dFLTnKkb3kbTZyHRkY2ZvITrHrWk3/AJCV12Y5mhSjyltcJKV0mvliKeF/0fFszcufZJyNjGX6x4Ur33yKzOs6246nHk8mpPHyvKOtOexL9XOxZKTWQpuseZcL5s5HL0y/X//EACIRAAICAgMBAAIDAAAAAAAAAAABEBECIBIhMUEDMkJRYf/aAAgBAhEBPwFGc1pWiMlYsUUpqyhlFQhxcXpc/Roqh0OFrZ9ORcMR5Fi7KmmcTicYRQjLrVDVlj7F5CGorS0ZP+oU30ZHKWrmy5ZlqpsTLGOKMSha2XPH6LqGiooeqx5eDWWHqMfNLGtcXXYm8m7FlXTF2yu9OJUrBF0evpC/YsfhdnwsbHkdH5Hh/Ewxspo8OR/kcrVDdFz/AP/EAB8RAAIDAAMBAQEBAAAAAAAAAAABAhAREiAxIUEiMP/aAAgBAREBPwEQxGm1pyNtm4aYYJGH2kzkafg2Ot/wXg/RR0UcZwSWj9reql8EjTRzb9M2s7cq+mkWSp9HWmjIxJ+0xVttZ0b6I42nokSVZ0jTj9qA/KwwaGqSMqZEdNXhxvdJR1CFI03u3g46yS+1tYxPs2oj/pGGGDEr00TY1vo10zPh+jNEmcXW16ZWEviuNf/EAC4QAAEDAgUDAgYCAwAAAAAAAAEAESECMRASMEFRIEBhIjIDE0JicZFQYIGhsf/aAAgBAAAGPwJD+At3NtQIqf6Eem4UF8G7JmRh6zZH5s1FZqICBT1u/YikXP8ApOKirp3lTKYJ175Ua3pU3XjBsHGMVuyiRoT0e10cu+ObdWUBe1Ww9JugU+pPwp5dlEp6lkTkKyicLdqagUKsXR7TkLMU7R2DHpbUHU++F9YaUdrOk+hv0v0OOpuy8duynUIMIsuDtoMs2pK2CfSbTisp3c+UBXdZKQ/XGEhWR5GjTS0thcfpCprFZhpuNC0qSc3CqDFe2Ex3R8dc6j8IxdfLzSeUQPU2yy5Q6AFIKHCyKEG36AVm0ePClgVLVed0atyvO+EFlTWNlU+10AU+zLwvSmN0cLq6t0ZQHKJfZGqpR/hZRCyg4SspJykWVXw6ppKq+yUD9qtBwvHVIw9yBqr/AEmcg1boBPunX5WZ3dUircrL9X/FT6vUrSVTzbATgB4uszNUy46moc0jhCE7SEaWkJiUXapcIAByJTtJug1BBFlLhZaqYNiMPcU30i2F+sfndMiqosnqLosGhED9r1K2GblPTUaUaTLbqyzcphxof//EACMQAAMAAgMBAAIDAQEAAAAAAAABESExEEFRYXGBIJGhwdH/2gAIAQAAAT8hajP8oY4e1NGUXCUM2TiEEURDKIGQtnQE7E9XBI7YhgCwvtE4jbQjGajksGSvBcja9BvQyaEhrA8JYM5lqmDMQ2E0NC4JXoJJBv6L9CV0dMOp9IfQjUDSMTMi4sBYcNQZCWUInL0cQ6aEg0YcEKQLYmkA9zj5iHRsIskMghPwixONYMyxkMOCZkJOCyxjEjQSIZQmjzPZjbtGpZgWuKYmK1DRiEhcLlYY3yl4ZRtstlWJOCKvg0bg4OIly5/kWY2+CZzgWpnsmkx45NOKF4NCGU/eLybHgosYjitjzhTHEwka19Ms09cevyWJ8KQG1EiAR/IhElyULnhlwjs8ReilHxcaLmlCt+B/7AH1t2/Wx7sKZs2ZCdt1RztUsMW1tnoWW29mK2abG7DQhRbGxOSEuHFGDLYch0xtRjZFOJcWDcl1u9i2LbFXehYpNElobK6QokTadK67J4kHsZM8GyCcWIQDRmi4PEh5BrkhFym0mXubQoGT0a7Q1HaLWEam2zi8NZtRJGKpAiNuWlkp0WjGMll+F9BqCRCCBQbpxNDsZO5/0vYPWhG4hfp8MVY74vookQ40/AlcWtpjdmCn4Pqtp+jRez7IGww1GwfoULJRmY/R8TwEqYu05voR0SKrwxjvDGOmkhcpfszT4Mh4cFL7IazoGSCuS0GnGmMKVBVtCoUbviGFZTwqjgfwF7cbHww2pLArYiauzQpKNa4ohm5qpwfg2M7FJklmi1bJINsiGslMgZBIhlqQn0lk7yVgfn+B4g1O+w0R4CH8Nngwg6ZiWF8C6MKFaY2vSNuCuUObxRmnkv2UXYe0ajEQoWoYQNRSvRiEJ7OxD4OouCi4rg+QdO5mf4Fk+mZb6Y5soVpgVDSbolWy5yN4mNMbQkUbFkUprnl9NKbyLglEkghGJPKZ28PSQsho2LZ7xwOhojsNGit5LEMN5H3uBISpi4NB2+cPTqO4hKhzVbcwQcZKhLPBSahjguoXh7ZVCOkFLtDkGWwZTyQNIS7i6TKj6K34Gjrg3Y4NGAaM0nD3mSJebQ8lrJyplTVNGf8AYuGDCdEv0MK2tjK0a5G+GQxkGJNmwmlJLopJJDK+/dMqLDGJEUY42J0iryi/6Cixgo2PgyDXIXJ5YX+FUv3wuJdMIfJ+PhHD2uKIreeImwjsxqpSHmgvCXUJLJjsg8BP4M9CZGESsmOnVbHNEf8A9A2ZiPI4pEJIHLH+eUQX8v6fGtGCvyhAljSEIfGykrlFX9kyetM0XdrlO9iEtJPfR1olYEVLloxLsSlBBBV0xegrlloi09NaGBtUcGxsbMyqRk1Rlegl2Wr9HzNvqClK0vZC9FtKQi+gGJJGVT01WroTRrX0ixMR+hksxwN7Ew+z8TYJUFhbRFprogkGh8OQ6MMk4Q6pjwbYyRJoibrWP4Z54xTUQlhGxhb+oVlo0dE+0j2eDZrZTHbaYImRv+xgbGwsk0IQG/Rt0yOkjFFlhYiQarFVnb4jEC6lU1cJPEQlG2auK7F+f1cmYFtzwqttMRl7CjCCL/RCzy8CSyx266NJo6p3LwzkiXngvm3ZmNXC0ZaFyXNDGfV+yxA7VhlxxsmQBVGxl1Z032NEu6iElN/2ZW40xgl/b34Yct4GhopcsxL2i1vo+zRYmLuWCr9GKbMIRK3Rirh+6FO15P0ZyL/YHbv41B1D5KyiSjuGipklqpkaWT0PwdPtkWexlLCm0mLXxG4mLKJR4jOlKaG/F1CJb8GqyLgIi7e/jGTvSNEl3cZHVS6oi2uhoKms60ylls36yuzXeByhh7HfW/H4UsEy/Exl7K+krMKtLCMsqKSG6CrS/wACq9OhKP8AsWG23r0xUcaD2TelpOpjj6/ARt6XYtLE+ryZK6MWoTlNCdXK9n//2gAMAwAAARECEQAAEPznpif2dzJ3Fve0yDzZ3u68LTiyqfTkvEC8qRGXJ1T6BUi9GWhqtvN+72H4UBnY7Ue5okQN3FsiMtdMTgNJhEr3ga07x+0j1QApwz3wlr3wwZdDtZ2AwlLmnntXpIgO4dkbK492d8+JnLNAburbgFr5oh2CfGdvWqKf1wPO3Rq4q5MlBxt3Vlr/AH/g9Q49wj3/xAAeEQEBAQEBAQEBAAMAAAAAAAABABEhMRBBUWFxgf/aAAgBAhEBPxD19dhZtn3WbJ+/fcq5YMZ/hHxHqAXnCUmS7GGMu7D2JvxvLbbxBYTFfJM4Stu2yxjke9mc6nPl17DK/wA4SaZ2VD9SX9u28tnCThkAOyXyRHIKfHqWMIOduf2OW/GSAcum3pahc9tCebsNlhhPIw9hUYu9IziQAbfpHNt/S6sCBLAcjfIdeRssJLdnME9js8L1I+ywhsmNQ2R+fHDjDeTAb2c3nkw24xiXb84BOQ1r5Zau3LZjbhn3bZ+IBmE9iSTki0+78Tg4lpjf+/v5Jjw2eBsrmRONw9L82X+Sz8k+Jw8/sauMLltHMWnx8l+/duvZM0QGxgfy3+LkD/tt7y0gPbV7sa5B7DdwnrnnyLeSfP/EABwRAQEBAQEBAQEBAAAAAAAAAAEAESExEEFRYf/aAAgBAREBPxBML2wWGe2PgYiHkfi1fbC8RC15Gv2yQso8tmY9hHYLY/su8QDkoc5aeRyGySdsywuKnU3S2IvkmZiHFuRuySe2XIQQCddL+4knQsnBkPJVJcsJMbBCvnwo+eNjLgh3lv4Wv8l/J4wSNvITb5897KEPmWJbjI+wqwfjChdI87LvJUSWvLNsWIGFsZNnHZOX+2b2AfG18G35EYmM5cmcLHl4TPvwuwR2aPJOARuW3ljYszFlkdMIsbiwMjZAyc+sHbsKDPYuzZ6lyIKyBsWZLbEMi/sB2PQ5JydjkdaQUg3JGVI+GlWEcW5myclx8s2AMWPqCHG0yP2P6W/ycR3sOphP6i8I9nPfjL//xAAmEAEAAwACAgICAwADAQAAAAABABEhMUFRYXGREIGhscEg0eHw/9oACAEAAAE/EHPKyo/CU0XkogbcEFwg4jFplzsVK2qj+aVUtsHVMF7gBewAsMPCupoKnZDRyjBK/mh0SxcxIHERCEArYWbiGpw5SXOkdxhzk0h9Qxdq+Jpy+o1cRAyOjku4klTVmG6FdReqPhLaWJ3G6Yf3DS7sXEoXVkJUcEKqxbZUUIZvMJdOp4UmdL7ZWCJZqlMAc76lZouCYCzDXNGpR4lJLPnzGtwXsiKlBkIWgHGuYtgjKjSH0hbJy3F2y5K4wmdr6iVqBmENBAS3iFUVsAkF6mTkAw2bKQqg4nUC9YrWrv1AoJYqa5cRkgxYSaY5JkjsZmwQoHD5lhydSv1hqXs1UoIbQRcUEfNAEFsotj1GLrmDpWs4h3PAiAhFEV06y9VTup0ignGUwUAAKKmgwAH4nVQYLlVHiGhmUv8A4ZZaXqcx9eBQqz19FEG0CEryRGsGg8QlKgHc3TGgDj78QDlC7S6icZAfDoXBIt3YZTGvT49x/HubLLOZSpiGdGHeqIqGVPQiu6LLYVXxLseXiVDttAdsIoPBNgV49xR5gsFzg+v066uAdTlmQZD0SrJUEI40Z0+f1HBVmP2e5xWmvr1GcyswqoRbtREpzOoyFVqmVidIISDuTWVUPMXwAyEOO4fZXllyAV5Vb7OPqMlkiEBqdDvfMYI6lLB+O4xB5XSnf3C1D2DVerhGHMpVeg8S8CGFYnqF2c8xHcTnmipeE2Gibh2WXmCeaZZw8RtopZbA+iWWR2hEbEjM11lcF4iq0lpP8ozb5JXEqU3XDuAApxbiQELqiNrJ3fTCEtXyEqhCaPiMtXw4+iKgGY8j1EBpT3K3Ny+8xgDyVGuQhcWVVHyQmegs54UtlaJepbH3PcbGGxnZp5yaAU9JcJKSLuBp4BmxFgDpKjMM4Awg47u7Byk5BuvcIFW9Mp9CKXku4+ChoHL2+pbBy5nCqI9SoTCIBAbXMbKjoPcBo2bdy0ofA1fqG1+an/Db9kW7/FdfvJcNZ+kQ8u6V0tzCD4gEQcAQhjTkIM2gWoFIxK1z6jnRSeYqMkgRQOh58xCWrYB1L7TOLF6D1Ep+k0Ya8iky8sr01N1wbpSfPlR2wqXKyEGIQ5dC+eviCmLSl7JmdwVhVqSi2QKgKMTzNdxV3KESy4AGXN8HSKHA8Sw9mPRVuMu44gXzEPiIByUCpt4lFo1IJwYJKF9kbFirk2DqkUK0ZtfFm8Q6EA1hAzUqwhRNl0zWBFaXxKLWQj9bJ0JWnpjrfI7CpbrCLDIRRgCjnqJIQqDENbSbMFuef/Y/m4XHevkdjoEtesvokMnPs8QkYES+xAIjyTYN+IDT3Nx7clqalU2jh8wK8MoVy6GVJYCsjx+FLV7iMJTR4/X1EvjSXOgHUAAvEvKwTYNkKtdy60vYUOz4ghEdJRasjAeJsgcMsbYYgWHBU2HxBgy46TuOmVIwUJ42LS3ilmnR4IjlKdOMeODpIaaZVDh8y8dhOR7hAGeZzVVwkVYsIqtrmEt4QAcbgJ9M40YRjuW+KljTj4g3+DmLvcmkJeej1E0or2ghHSUqgf0RiUIyzJPM7+yhuSXPRIofRJxBdkYiwBzkOlA6j78EyfUaORQUPBYuoGlx/lggNsBqBGwLjAItN+IFdjQYO4azsliP4sqTCi/bOnpjOAO1ArOjmUVMzJxFSivUEitQbq+YFshigBXF15lwBCx+JcHh7jlZ7hGbqFzHGohqG6pHxAIc6YLKuH0+Ijc2DYPcC1P3HbsQj25hU+ZnbMl4IZ9xblJdYg6nUuWXanhGmcMoGUKl3NBg6lZlt5hAFN4dhKAX1EoFjPUUWVVC5J6QtXU2EFKSsfEsoHHcJpIHLxDG8xaZVZQ65zYOYNizm5Yv8p3XDMvCc/irN2C6KuGFXilX3AGsPd+Y0fAiR+jI9R0nyeY6yEi2gJY+JWeaWMqwTxkDZ+kLekIIoBaZfyy4FLUy5cDnyOHx4gMQt2OL3LY6xgK/MBWC24IE7lh4ipqtbiXFljiPZ3FB1p7Oo3NgJGQ5+HKbcTbKOCaYoO4pMNZa8tdxqRi/2bN7SkZV/wBSnPVKtWGr99xLBSUnuWxqIwCQPzGVcApNemNJCmDAJJBv5jjBmh4yAsAXh5r7mZx1gPx0xsfieiVsZd3KSMjX2KWgAywrmEEtRxv+xS821vHR+oAwZNAeO2XAD1FYJZUtCeBjHcH5h7fixe4RWtizrVyBFIWg6Z04f4mAQ5DcrcZTf4VRYfK9d1EvqopYfHUXKQ7J6U9bzEAOjZ58CVtqyjq+f1KZ1A/09MEr+0dlylzL+4rw3DRUnQwvAO4+0CwuB3g9t8+Ze66bLAyOgVACBcKfxRW1DfhdENpsiPJ8eYXO4i2F9w6qSFbQdviiL4A85BtnqBtdK3SvAXqopIVaG69r8x6Nqhc+bhzZqUE39w0otOWquklOlKwoFXX7lktXX7lfGjp4PM1rHXqeFbkMIain3IfQ/wCEVebP+3F8RIMdqEPmLby848ytIf8Aov4cycy4lHYffMNw0UJY1Xrsr3ASFY900XBVawBddL3ANBYdVADaq8W9hG8xLzR7iooq8B4XySz1xvm2+V6gQBAWhYJDALs7dkZptMFyNDh9wKczKKO1LCwX4YJ/BXGNh+Lq5y8X4sjdFjLl75hoqDC1DXTMb1nKjAKqm7qJTvCwdwcQtG+/xCp5BSVb10eoy1qgeX/rC6Lbe2HQKsAdzjIrY5RSn65jAJ1bTln/AN6gHsFwBwuGZihFqbfm4FFAXzmDbqQoRZmBE7+IpTGwHiOghTolHM9WKPMPoj2QW9fWJjml7Je4uCV47LhVB6Y4/QFSg24Tr5WogLAvi/NdQDFWrBrLja1NJ5uVIVZ/SDxNfEMBTefwR0SwdoHVvmFKm0pVXH/IGBVngGzeZc4Gf+QfxN5wFwCkguSyjsF1BR6WWso9t8EAwBUWCTwcfcUC7fOeyL0RDuE3csGmXusMU+2Doez/AGX0ikPK+8+4hgCN5eI0whgFqqH+7iPMLsvnxPMyInOLKn6KtoPiI26GXnAe2DepAodXDg+oSKoKATz9S9Lg0z/yl9JrsD5KhVUh4r+4uq8cBv79xC1tsQ+d5fcfGWwBpfMtFQ1ZbXzKv9cxp/AdIa5lx08zlIy0JRQHIf8AZcGIyy1nGhHkQny0tDh6jTiMCy9qILxwcGS+K1t2rr9RbqUAYccs76WAlK/idmE16RbPVUaH3CgReQnbH46qWybw0nxHQtShKdRBhmwqbErCWM7YZUDXcf0RRfEXWJBbuJjj/9k=',NULL,NULL,0,0,'2013-12-27 11:18:34','2013-12-27 11:18:34',634474689,'https://www.facebook.com/wanwimon.mok',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,1,1,1,1,0.00,0,0,0,'0','',0,NULL,NULL,NULL,NULL,0,'0.0.0.0',0,NULL,NULL,NULL),(25,'winnie','$2y$10$ozXoJ7oSdK73f8HmBdfKveEucPB4foNynaDrd32GeZN9k1buXP95m','uttapong','ruangrit','uttapong.rua@biotec.or.th',NULL,NULL,NULL,NULL,NULL,NULL,1,'TH','0900998889','0988788999',NULL,NULL,NULL,NULL,NULL,'2013-12-27',0,1,'2013-12-27 11:25:26','2013-12-27 11:26:10',0,NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,1,1,1,1,0.00,0,0,0,'0','',0,NULL,NULL,NULL,NULL,0,'0.0.0.0',0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-05-09 11:17:01
