<?php if (!defined('APPLICATION')) exit();
$ThemeInfo['Bootstrap'] = array(
   'Name' => 'Bootstrap',
   'Description' => "Based on Bootstrap from Twitter and inspired by LiveRoom.<br>Be sure to read the documentation found here: <a href='https://github.com/kasperisager/VanillaBootstrap'>https://github.com/kasperisager/VanillaBootstrap</a>",
   'Version' => '1.1b-2.0',
   'Author' => "Kasper K. Isager",
   'AuthorEmail' => 'kasperisager@gmail.com',
   'AuthorUrl' => 'https://github.com/kasperisager'
);