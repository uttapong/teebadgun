<?php if (!defined('APPLICATION')) exit();
$ThemeInfo['FlatVI'] = array(
   'Name' => 'FlatVI',
   'Description' => "A super sweet port of the popular <a href='http://designmodo.github.io/Flat-UI/'>FlatUI toolkit</a> as a Vanilla theme. This is a fixed width theme.",
   'Version' => "1.5.6",
   'RequiredApplications' => array('Vanilla' => '2.1a'), //Do not edit me, this has been tested as a requirement
   'Author' => "Chris Ireland & <a href='http://designmodo.com'>DesignModo</a>",
   'AuthorUrl' => 'http://tama63.co.uk'
);

/* Road Map
- Cont to support 2.1
*/