<?php if (!defined('APPLICATION')) exit(); ?>

<div class="SplashInfo">
   <h1><?php echo T('Deleted'); ?></h1>
   <p><?php echo T('The content you were looking for has been deleted.'); ?></p>
</div>