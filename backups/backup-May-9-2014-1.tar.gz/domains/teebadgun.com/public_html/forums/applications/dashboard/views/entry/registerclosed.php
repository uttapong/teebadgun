<?php if (!defined('APPLICATION')) exit(); ?>
<div class="FormTitleWrapper">
<h1><?php echo T('Register for Membership'); ?></h1>
<div class="FormWrapper">
   <div class="P"><?php echo T('Registration is currently closed.'); ?></div>
</div>
</div>