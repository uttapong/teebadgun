<?php if (!defined('APPLICATION')) exit();

// Application's bootstrap stuff can go here. Define global functions, mess with the Factory, Config modifications.