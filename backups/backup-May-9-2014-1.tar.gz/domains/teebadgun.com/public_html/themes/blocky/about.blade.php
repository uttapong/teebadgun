@extends(theme_view('layout'))

@section('content')

  <section class="post">
    <h1>About</h1>
    <p>This could be an about page.</p>
  </section>
@stop
