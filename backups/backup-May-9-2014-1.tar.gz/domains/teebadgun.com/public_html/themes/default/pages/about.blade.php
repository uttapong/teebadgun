@extends(theme_view('layout'))

@section('content')

	<section class="about">
		<p>This could be an about page.</p>
	</section>
@stop
